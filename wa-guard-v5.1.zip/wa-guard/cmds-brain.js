// ═══════════ تدريب الذكاء المحلي (بدون API) ═══════════
import { isMainOwner } from './core/perm.js'
import { answer, teach, forget, listTaught, stats, defaultVars } from './brain.js'
import { db, save } from './lib.js'

export function register(c) {
  const { cmd, P, T, panel, kv, registry } = c
  const SEC = 'brain'
  const scopeOf = (e) => (isMainOwner(e) ? '*' : e.jid) // العام (كل الشاتات) للمطور الأساسي بس
  const split = (t) => { const i = t.indexOf('='); return i > 0 ? [t.slice(0, i).trim(), t.slice(i + 1).trim()] : null }

  cmd(['علمني'], 'admin', (e, args) => {
    const p = split(args)
    if (!p || !p[0] || !p[1]) return e.reply(`${T.info} اكتب: ${P}علمني السؤال = الجواب`)
    teach(p[0], p[1], scopeOf(e))
    return e.reply(`${T.ok} اتعلمت! لما حد يقول "${p[0].slice(0, 40)}" هرد بـ "${p[1].slice(0, 60)}"\n${isMainOwner(e) ? '(عام لكل الشاتات)' : '(للجروب ده بس)'}`)
  }, { sec: SEC, d: 'علّم البوت سؤال وجوابه', u: 'علمني السؤال = الجواب' })

  cmd(['درب'], 'admin', (e, args) => {
    const lines = args.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 60)
    let ok = 0
    for (const l of lines) { const p = split(l); if (p && teach(p[0], p[1], scopeOf(e))) ok++ }
    if (!ok) return e.reply(`${T.info} اكتب سطر لكل زوج:\n${P}درب\nسؤال1 = جواب1\nسؤال2 = جواب2`)
    return e.reply(`${T.ok} اتدرّب على ${ok} سؤال جديد 🧠 (${lines.length - ok} اتجاهلوا)`)
  }, { sec: SEC, d: 'تدريب بالجملة: سطر لكل "سؤال = جواب"', u: 'درب (أسطر)' })

  cmd(['انسى'], 'admin', (e, args) => {
    if (!args.trim()) return e.reply(`${T.info} اكتب: ${P}انسى السؤال`)
    const n = forget(args.trim(), isMainOwner(e) ? 'all' : e.jid)
    return e.reply(n ? `${T.ok} نسيت ${n} إجابة` : `${T.err} مفيش حاجة متعلمة بالاسم ده`)
  }, { sec: SEC, d: 'حذف سؤال متعلَّم', u: 'انسى السؤال' })

  cmd(['ماتعلمته'], 'admin', (e) => {
    const l = listTaught(isMainOwner(e) ? undefined : e.jid).slice(-15).reverse()
    return e.reply(l.length ? panel('🧠 TAUGHT', l.map((t) => `▸ ${t.q.slice(0, 35)} ← ${t.a[0].slice(0, 30)}`)) : `${T.info} لسه معلمتنيش حاجة`)
  }, { sec: SEC, d: 'آخر ما اتعلّمه البوت' })

  cmd(['حالة التدريب'], 'all', (e) => {
    const s = stats()
    return e.reply(panel('🧠 BRAIN', [kv('محفوظ أساسي', `${s.seed} عبارة`), kv('اتعلّمه', s.taught), kv('من ردود المالك', s.learned), kv('تدريب تلقائي', s.autolearn ? '🟢' : '🔴'), kv('النوع', 'ذكاء محلي (استرجاع TF-IDF) بدون API')]))
  }, { sec: SEC, d: 'إحصائيات الذكاء المحلي' })

  cmd(['دردشة'], 'all', (e, args) => {
    const t = args.trim()
    if (!t) return e.reply(`${T.info} اكتب: ${P}دردشة ازيك؟ (أو ابدأ رسالتك بكلمة بوت)`)
    const r = answer(t, { jid: e.jid, vars: { count: String(registry.length) } })
    return e.reply(r ? r.reply : `🤔 مش فاهم قصدك. علّمني: ${P}علمني ${t.slice(0, 25)} = ردك`)
  }, { sec: SEC, d: 'كلّم البوت', u: 'دردشة ازيك' })

  cmd(['تدريب تلقائي'], 'owner', (e, args) => {
    const a = args.trim()
    if (/^(مسح|امسح)$/.test(a)) { db.brain.learned = []; save(); return e.reply(`${T.ok} اتمسح اللي اتعلمه من ردودك`) }
    if (/^(تشغيل|تفعيل|on)$/i.test(a)) { db.brain.autolearn = true; save(); return e.reply(`${T.ok} التدريب التلقائي شغال: البوت هيتعلم من ردودك القصيرة في الخاص (محليًا على جهازك، وبيتجاهل الأرقام الطويلة والروابط). بيتعلم عشان يرد زيك.`) }
    if (/^(ايقاف|تعطيل|off)$/i.test(a)) { db.brain.autolearn = false; save(); return e.reply(`${T.ok} اتقفل التدريب التلقائي`) }
    return e.reply(`${T.info} اكتب: ${P}تدريب تلقائي تشغيل | ايقاف | مسح`)
  }, { sec: SEC, d: 'يتعلم من ردودك في الخاص (اختياري)', u: 'تدريب تلقائي تشغيل' })

  cmd(['مسح التدريب'], 'owner', (e, args) => {
    if (!/^(تاكيد|تأكيد)$/.test(args.trim())) return e.reply(`${T.warn} ده هيمسح كل اللي اتعلمه (${stats().taught + stats().learned}). للتأكيد: ${P}مسح التدريب تأكيد`)
    db.brain.taught = []; db.brain.learned = []; save()
    return e.reply(`${T.ok} اتمسح كل التدريب (الأساسي فضل زي ما هو)`)
  }, { sec: SEC, d: 'يمسح كل التدريب (للمالك)', u: 'مسح التدريب تأكيد' })
}
