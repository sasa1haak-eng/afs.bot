// ═══════════ المطورين: تمكين + طلبات نسخ ملف البوت بموافقة المطور ═══════════
import crypto from 'node:crypto'
import { db, save, log, ROOT_DIR } from './lib.js'
import { isMainSock, mainNumber } from './sessions.js'
import { buildPackage } from './pack.js'

const userOf = (j) => (j || '').split(/[:@]/)[0]
const TTL = 30 * 60_000 // مدة صلاحية الطلب
const COOL = 10 * 60_000 // انتظار بعد الرفض
const pending = new Map() // id → { id, to, user, name, at }
const cooldown = new Map() // user → وقت انتهاء المنع

// هل المرسل مطور مُمكَّن؟ (البوت الأساسي فقط، ومش رسايل المالك نفسه)
export function isDev(sock, m, sender) {
  if (!isMainSock(sock) || m.key.fromMe) return false
  const ids = [sender, m.key.participant, m.key.participantAlt, m.key.remoteJid, m.key.remoteJidAlt]
  return ids.some((j) => j && !j.endsWith('@g.us') && db.devs?.[userOf(j)])
}

const prune = () => {
  const now = Date.now()
  for (const [id, p] of pending) if (now - p.at > TTL) pending.delete(id)
}

export function register(c) {
  const { cmd, P, T, getTarget } = c

  const mainOnly = (e) => {
    if (isMainSock(e.sock)) return true
    e.reply(`${T.warn} الأمر ده من البوت الأساسي بس: wa.me/${mainNumber()}`)
    return false
  }
  const phoneOf = (e) =>
    [e.m.key.participantAlt, e.m.key.remoteJidAlt, e.sender, e.jid]
      .find((j) => j && j.endsWith('@s.whatsapp.net'))
      ?.split(/[:@]/)[0]

  // ───── تمكين / إلغاء التمكين / المطورين ─────
  cmd(['تمكين'], 'owner', async (e, args) => {
    if (!mainOnly(e)) return
    if (!e.m.key.fromMe) return e.reply(`${T.warn} التمكين للمطور الأساسي بس.`)
    const t = getTarget(e, args)
    if (!t) return e.reply(`منشن الشخص أو ردّ على رسالته أو اكتب رقمه:\n${P}تمكين 201234567890`)
    const u = userOf(t)
    if (u === mainNumber()) return e.reply('ده رقم البوت الأساسي 😅')
    db.devs[u] = { jid: t, at: Date.now() }
    save()
    return e.reply(`✅ تم تمكين ${u} كمطور (صلاحيات المالك على البوت الأساسي).\nلإلغائه: ${P}الغاء تمكين ${u}`)
  }, { d: 'يخلي شخص مطور (للمطور الأساسي)', u: P + 'تمكين @شخص' })

  cmd(['الغاء تمكين'], 'owner', async (e, args) => {
    if (!mainOnly(e)) return
    if (!e.m.key.fromMe) return e.reply(`${T.warn} الإلغاء للمطور الأساسي بس.`)
    const t = getTarget(e, args)
    const u = t && userOf(t)
    if (!u || !db.devs[u]) return e.reply(`${T.err} الشخص ده مش في قايمة المطورين. شوفها بـ ${P}المطورين`)
    delete db.devs[u]
    save()
    return e.reply(`✅ تم إلغاء تمكين ${u}.`)
  }, { d: 'يشيل صلاحيات المطور من شخص' })

  cmd(['المطورين'], 'owner', async (e) => {
    if (!mainOnly(e)) return
    const l = Object.keys(db.devs)
    return e.reply(l.length ? `👨‍💻 المطورين:\n${l.map((u, i) => `${i + 1}. ${u}`).join('\n')}` : 'مفيش مطورين متمكّنين.')
  }, { d: 'قايمة المطورين المتمكّنين' })

  // ───── طلب نسخ ملف البوت ─────
  cmd(['نسخ'], 'all', async (e) => {
    if (!mainOnly(e)) return
    prune()
    const user = userOf(e.sender)
    const phone = phoneOf(e)
    const to = e.isGroup ? (phone ? phone + '@s.whatsapp.net' : e.sender) : e.jid

    if (e.isOwner) { // المطور مش محتاج موافقة
      await e.reply('⏳ جاري تجهيز الملف...')
      const f = await buildPackage(ROOT_DIR)
      await e.sock.sendMessage(to, { document: f.buffer, mimetype: f.mime, fileName: f.fileName, caption: '📦 ملف البوت (الكود فقط)' })
      return
    }
    if ((cooldown.get(user) || 0) > Date.now()) return e.reply(`${T.warn} اترفض طلبك قريب، جرّب بعد شوية.`)
    if ([...pending.values()].some((p) => p.user === user)) return e.reply(`${T.warn} طلبك لسه عند المطور، استنى الرد.`)
    if (pending.size >= 20) return e.reply(`${T.warn} فيه طلبات كتير معلّقة، جرّب بعدين.`)

    const id = crypto.randomBytes(2).toString('hex').toUpperCase()
    const req = { id, to, user, name: e.m.pushName || '', at: Date.now() }
    pending.set(id, req)

    const owners = new Set([e.sock.user?.id && userOf(e.sock.user.id) + '@s.whatsapp.net'])
    for (const d of Object.values(db.devs)) owners.add(d.jid)
    const text =
      `📥 *طلب نسخ ملف البوت*\n▸ الطالب: ${req.name || '—'} (${phone || user})\n▸ رقم الطلب: ${id}\n\n` +
      `✅ للموافقة: ${P}موافق ${id}\n❌ للرفض: ${P}مرفوض ${id}`
    let sent = 0
    for (const j of owners) {
      if (!j) continue
      try { await e.sock.sendMessage(j, { text }); sent++ } catch (err) { log('فشل إشعار المطور:', err.message) }
    }
    if (!sent) { pending.delete(id); return e.reply(`${T.err} ما قدرتش أوصل للمطور، جرّب بعدين.`) }
    return e.reply('⏳ تم إرسال طلبك للمطور. هيوصلك الملف هنا لو وافق.')
  }, { always: true, d: 'طلب نسخة من ملف البوت (بموافقة المطور)' })

  const resolve = (e, args) => {
    prune()
    const list = [...pending.values()]
    if (!list.length) { e.reply('مفيش طلبات نسخ معلّقة.'); return null }
    const id = args.trim().toUpperCase()
    if (id) {
      const p = pending.get(id)
      if (!p) e.reply(`${T.err} رقم الطلب غلط أو انتهى.`)
      return p || null
    }
    if (list.length === 1) return list[0]
    e.reply(`فيه ${list.length} طلبات، حدّد الرقم:\n` + list.map((p) => `▸ ${p.id} — ${p.name || p.user}`).join('\n'))
    return null
  }

  cmd(['موافق'], 'owner', async (e, args) => {
    if (!mainOnly(e)) return
    const p = resolve(e, args)
    if (!p) return
    await e.reply('⏳ جاري تجهيز الملف وإرساله...')
    const f = await buildPackage(ROOT_DIR)
    await e.sock.sendMessage(p.to, { document: f.buffer, mimetype: f.mime, fileName: f.fileName, caption: '✅ وافق المطور على طلبك.\n📦 ملف البوت (الكود فقط).' })
    pending.delete(p.id)
    return e.reply(`✅ تم إرسال الملف إلى ${p.name || p.user}.`)
  }, { d: 'يوافق على طلب نسخ ملف البوت' })

  cmd(['مرفوض'], 'owner', async (e, args) => {
    if (!mainOnly(e)) return
    const p = resolve(e, args)
    if (!p) return
    pending.delete(p.id)
    cooldown.set(p.user, Date.now() + COOL)
    await e.sock.sendMessage(p.to, { text: '❌ المطور رفض طلب نسخ ملف البوت.' }).catch(() => {})
    return e.reply(`❌ تم رفض طلب ${p.name || p.user}.`)
  }, { d: 'يرفض طلب نسخ ملف البوت' })
}
