// ═══════════ 6.2 — مكتبة السكربتات: ملف جاهز + شرح التشغيل (scripts-lib/) ═══════════
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { nm } from './core/names.js'

const DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'scripts-lib')
export const MANIFEST = JSON.parse(fs.readFileSync(path.join(DIR, 'manifest.json'), 'utf8'))
const CAT = { sec: '🛡️ أمن سيبراني', dev: '💻 برمجة وأتمتة' }

export function runSteps(m) {
  const f = m.file, ext = path.extname(f)
  const steps = []
  if (ext === '.py') steps.push('1) pkg update -y && pkg install python -y   (تيرمكس)', `2) احفظ الملف في ~/ (أو مجلد Downloads بعد termux-setup-storage ثم: cd ~/storage/downloads)`, '3) شغّله:')
  else if (ext === '.sh') steps.push('1) تأكد من bash (موجود افتراضياً)', '2) احفظ الملف في ~/ ثم: cd ~', '3) شغّله:')
  else if (ext === '.js') steps.push('1) pkg install nodejs -y   (تيرمكس) — أو node على جهازك', '2) احفظ الملف ثم:')
  else steps.push('ملف إعداد: ضعه في مكانه داخل مشروعك/سيرفرك ثم:')
  return steps
}

export function describe(m, P = '.') {
  const lines = [
    `📜 *${m.title}*`,
    `📁 ${CAT[m.cat]} · المستوى: ${m.level} · الملف: ${m.file}`,
    '',
    m.desc,
    '',
    `📦 المتطلبات: ${m.needs}`,
    '',
    '▶️ *طريقة التشغيل:*',
    ...runSteps(m),
    '```' + m.example + '```',
  ]
  if (m.warn) lines.push('', `⚠️ ${m.warn}`)
  return lines.join('\n')
}

const last = new Map()
export function register(c) {
  const { cmd, P, T, panel } = c
  const SEC = 'scripts6'
  for (const m of MANIFEST) {
    cmd(nm('سكربت ' + m.name), 'all', async (e) => {
      const k = e.sender || e.jid, now = Date.now()
      if (now - (last.get(k) || 0) < 4000) return e.reply(`${T.warn} استنى ثواني بين كل سكربت`)
      last.set(k, now)
      if (last.size > 2000) for (const [x, t] of last) if (now - t > 60_000) last.delete(x)
      await e.reply(describe(m, P))
      const buf = fs.readFileSync(path.join(DIR, m.file))
      return e.sock.sendMessage(e.jid, { document: buf, fileName: m.file, mimetype: 'text/plain', caption: `📎 ${m.file}` }, { quoted: e.m })
    }, { sec: SEC, d: m.title, u: 'سكربت ' + m.name })
  }
  cmd(nm('سكربتات'), 'all', (e, args) => {
    const a = args.trim()
    const want = /امن|sec|سيبر/i.test(a) ? 'sec' : /برمج|dev|اتمت/i.test(a) ? 'dev' : null
    const rows = MANIFEST.filter((m) => !want || m.cat === want)
    return e.reply(panel('📚 SCRIPTS', [
      ...['sec', 'dev'].filter((k) => !want || k === want).flatMap((k) => [`*${CAT[k]}*`, ...rows.filter((m) => m.cat === k).map((m) => `▸ ${P}سكربت ${m.name.replace(/ /g, '_')} — ${m.level}`), '']),
    ].slice(0, -1), `${P}سكربتات امن | ${P}سكربتات برمجة`))
  }, { sec: SEC, d: 'قائمة السكربتات الجاهزة', u: 'سكربتات امن' })
  cmd(nm('بحث سكربت'), 'all', (e, args) => {
    const q = args.trim().toLowerCase()
    if (q.length < 2) return e.reply(`${T.info} اكتب: ${P}بحث سكربت كلمة`)
    const hits = MANIFEST.filter((m) => (m.name + m.title + m.desc).toLowerCase().includes(q)).slice(0, 10)
    return e.reply(hits.length ? panel('🔎 SCRIPTS', hits.map((m) => `▸ ${P}سكربت ${m.name.replace(/ /g, '_')} — ${m.title}`)) : `${T.err} مفيش نتايج`)
  }, { sec: SEC, d: 'بحث في السكربتات', u: 'بحث سكربت تشفير' })
}
