// ═══════════════ الأسلوب السيبراني: واجهة موحدة للرسائل ═══════════════
export const VERSION = '4.0.0'

export const T = {
  ok: '⟦✔ OK⟧',
  err: '⟦✖ ERR⟧',
  warn: '⟦⚠ ALERT⟧',
  info: '⟦ℹ INFO⟧',
  ai: '⟦⌬ AI⟧',
  dl: '⟦⏬ DL⟧',
  ban: '⟦☠ BAN⟧',
  ping: '⟦⚡ PING⟧',
  time: '⟦⏱ TIME⟧',
  scan: '⟦◉ SCAN⟧',
}

// شريط تقدم: bar(3, 10) → ███░░░░░░░
export const bar = (v, max = 10, len = 10) => {
  const f = Math.max(0, Math.min(len, Math.round((v / (max || 1)) * len)))
  return '█'.repeat(f) + '░'.repeat(len - f)
}

export const banner = (name) => `░▒▓█ ${name} █▓▒░`

// لوحة بحدود على الشمال بس (عشان الحروف العربي ما تبوّظش الحدود اليمين)
export const panel = (title, rows = [], foot = '') =>
  [
    `┏━⟦ ${title} ⟧━━━━━━━━`,
    ...rows.flatMap((r) => String(r).split('\n')).map((r) => `┃ ${r}`),
    foot ? `┣ ${foot}` : '',
    '┗━━━━━━━━━━━━━━━━━━━━',
  ]
    .filter(Boolean)
    .join('\n')

export const kv = (k, v) => `▸ ${k}: ${v}`
export const dot = (v) => (v ? '🟢' : '🔴')
