import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'
import pino from 'pino'
import { downloadMediaMessage, normalizeMessageContent } from '@whiskeysockets/baileys'
import {
  CONFIG, db, save, gset, clean, log, uptime,
  getMeta, isAdmin, botIsAdmin, botJids,
  recent, forget, deleteKeys, warnUser, sleep,
} from './lib.js'
import { classifyMedia, getModel } from './nsfw.js'
import { explicit, BLOCKED_MSG } from './halal.js'
import { stickerToVideo } from './s2v.js'
import { hasAI, askAI, getAI, aiStatus, dmReady, dmPrivateOnly, lastUsedProvider } from './ai.js'
import { normWord } from './guards.js'
import { installSub, removeSub, listSubs, isMainSock, mainNumber } from './sessions.js'
import * as D from './data.js'
import { answer as brainAnswer } from './brain.js'
import { register as regText } from './cmds-text.js'
import { register as regMath } from './cmds-math.js'
import { register as regFun } from './cmds-fun.js'
import { register as regGames } from './cmds-games.js'
import { register as regEco } from './cmds-economy.js'
import { register as regGroup } from './cmds-group.js'
import { register as regNet } from './cmds-net.js'
import { register as regIslam } from './cmds-islamic.js'
import { register as regBrain } from './cmds-brain.js'
import { register as regDev } from './cmds-dev.js'
import { register as regMillion } from './cmds-million.js'
import { register as regAnime } from './cmds-anime.js'
import { register as regAntibot, autoScan } from './cmds-antibot.js'
import { register as regSecurity5 } from './cmds5-security.js'
import { register as regGroups5 } from './cmds5-groups.js'
import { register as regTools5 } from './cmds5-tools.js'
import { register as regAdmin5 } from './cmds5-admin.js'
import { register as regProt6 } from './cmds6-protect.js'
import { register as regCyber6 } from './cmds6-cyber.js'
import { register as regDev6 } from './cmds6-dev.js'
import { register as regGames6 } from './cmds6-games.js'
import { register as regTts6 } from './cmds6-tts.js'
import { register as regScripts6 } from './cmds6-scripts.js'
import { register as regLearn6 } from './cmds6-learn.js'
import { isMainOwner, needsMainOwner } from './core/perm.js'
import { logError } from './core/seclog.js'
import { loadPlugins } from './core/plugins.js'
import { startScheduler } from './core/scheduler.js'
import { scheduleAuto } from './core/backup.js'
import { register as regCompetition, pulseCompetitionScheduler } from './cmds-competition.js'
export { pulseCompetitionScheduler }
import { T, panel, kv, dot, VERSION } from './ui.js'
import {
  findSurah, getReciters, curated, defaultReciter, findReciter,
  bestMoshaf, fetchSurahFile, pad3,
} from './quran.js'

const P = CONFIG.PREFIX
const sh = promisify(execFile)
const silent = pino({ level: 'silent' })
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'waguard-'))

// ═══════════════ أدوات ═══════════════
const tmp = (ext) => path.join(TMP, crypto.randomBytes(6).toString('hex') + '.' + ext)
const rm = (...f) => f.forEach((x) => { try { fs.unlinkSync(x) } catch {} })
const pick = (a) => a[Math.floor(Math.random() * a.length)]
const shuffle = (a) => {
  const r = [...a]
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[r[i], r[j]] = [r[j], r[i]]
  }
  return r
}
const hash = (s) => {
  let h = 5381
  for (const ch of s) h = ((h << 5) + h + ch.charCodeAt(0)) >>> 0
  return h
}
const seeded = (seed) => () => {
  seed = (seed + 0x6d2b79f5) | 0
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296
}
const tag = (jid) => '@' + jid.split('@')[0]
const bar = (p) => '█'.repeat(Math.round(p / 10)) + '░'.repeat(10 - Math.round(p / 10))
const norm = (s) => s.replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي')
const onOff = (v) => (v ? '✅ شغال' : '❌ متوقف')
const normDomain = (d = '') =>
  d.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split(/[\/?#]/)[0]
const parseToggle = (a = '') =>
  ['تشغيل', 'تفعيل', 'on', '1'].includes(a.toLowerCase()) ? true
    : ['ايقاف', 'إيقاف', 'تعطيل', 'off', '0'].includes(a.toLowerCase()) ? false
    : null
const quotedText = (ctx) => {
  const q = ctx?.quotedMessage
  if (!q) return ''
  return q.conversation || q.extendedTextMessage?.text || q.imageMessage?.caption || q.videoMessage?.caption || ''
}

// الهدف: منشن ← رد على رسالة ← رقم
function getTarget(e, args = '') {
  const ment = e.ctx?.mentionedJid?.[0]
  if (ment) return ment
  if (e.ctx?.participant) return e.ctx.participant
  const d = args.replace(/\D/g, '')
  if (d.length >= 7) return d + '@s.whatsapp.net'
  return null
}

// ═══════════════ نظام الأوامر ═══════════════
const registry = []
// level: 'owner' (المالك) | 'admin' (أدمن أو المالك) | 'all' (الكل)
export const duplicates = [] // أسماء مسجّلة مرتين (الأول بيكسب) — بتظهر بـ .الاوامر المكررة
const cmd = (names, level, fn, opts = {}) => {
  const normed = names.map(norm)
  for (const n of normed) {
    const prev = registry.find((r) => r.names.includes(n))
    if (prev) { duplicates.push({ name: n, first: prev.orig[0], second: names[0] }); log(`⚠️ اسم أمر مكرر: «${n}» (الأول: ${prev.orig[0]})`) }
  }
  registry.push({ names: normed, orig: names, level, fn, opts })
}

// حد معدل الأوامر لكل مستخدم (يمنع الإغراق/DoS): 8 أوامر كل 10 ثواني
const rlMap = new Map()
function rateLimited(id) {
  const now = Date.now()
  const r = rlMap.get(id) || { n: 0, t: now }
  if (now - r.t > 10_000) { r.n = 0; r.t = now }
  r.n++
  rlMap.set(id, r)
  if (rlMap.size > 5000) for (const [k, v] of rlMap) if (now - v.t > 60_000) rlMap.delete(k)
  return r.n > 8
}
const MAX_IMG = 8 * 1024 * 1024
async function fetchCapped(url, max = MAX_IMG) {
  const res = await fetch(url, { signal: AbortSignal.timeout(15000) })
  const len = Number(res.headers.get('content-length') || 0)
  if (len > max) throw new Error('الملف أكبر من المسموح')
  const buf = Buffer.from(await res.arrayBuffer())
  if (buf.length > max) throw new Error('الملف أكبر من المسموح')
  return buf
}

export async function handleCommand(env) {
  const { sock, m, jid, text, isOwner, isGroup } = env
  const raw = text.slice(P.length).trim()
  const body = norm(raw)

  let best = null
  for (const c of registry)
    for (const n of c.names)
      if ((body === n || (body.startsWith(n) && /\s/.test(body[n.length]))) && (!best || n.length > best.n.length))
        best = { c, n }
  if (!best) return false
  const { c, n } = best
  if (process.env.DEBUG_MSGS === '1') log(`▶️ تنفيذ أمر: ${n} (isOwner=${isOwner})`)

  if (!isOwner && db.banned[clean(env.sender || '')]) return false
  if (!isOwner && rateLimited(clean(env.sender || jid))) return true // إغراق: تجاهل صامت
  if (!isOwner) {
    // الأوامر العامة تعمل في الخاص والجروبات؛ أوامر الأدمن/المالك تبقى مقيدة.
    if (c.level === 'owner' || (c.level !== 'all' && !isGroup && !c.opts.dm)) return false
    if (c.level === 'all' && !CONFIG.PUBLIC_COMMANDS && !c.opts.always) return false
  }

  env.content = normalizeMessageContent(m.message)
  env.reply = async (t, mentions) => {
    const dbg = process.env.DEBUG_MSGS === '1'
    const t0 = Date.now()
    const send = (opts) =>
      Promise.race([
        sock.sendMessage(jid, { text: t, mentions }, opts),
        new Promise((_, rej) => setTimeout(() => rej(new Error('انتهت مهلة الإرسال (25ث)')), 25_000)),
      ])
    try {
      const r = await send({ quoted: m })
      if (dbg) log(`✉️ تم إرسال الرد (${Date.now() - t0}ms) id=${r?.key?.id}`)
      return r
    } catch (err) {
      log(`⚠️ فشل إرسال الرد: ${err.message} — بجرب من غير اقتباس`)
      const r = await send(undefined)
      log(`✉️ اتبعت من غير اقتباس id=${r?.key?.id}`)
      return r
    }
  }
  const args = raw.slice(n.length).trim()

  try {
    if (c.opts.group && !isGroup) {
      await env.reply(`${T.warn} الأمر ده للجروبات بس.`)
      return true
    }
    if (needsMainOwner(c, norm) && !isMainOwner(env)) { // أوامر نطاقها كل الشبكة: المطور الأساسي بس (مش مالك بوت فرعي)
      await env.reply(`${T.warn} الأمر ده للمطور الأساسي بس (نطاقه كل البوتات).`)
      return true
    }
    if (isGroup && (c.level === 'admin' || c.opts.botAdmin)) {
      const meta = await getMeta(sock, jid)
      if (c.level === 'admin' && !isOwner && !isAdmin(meta, env.sender)) {
        await env.reply(`${T.warn} الأمر ده للأدمن بس.`)
        return true
      }
      if (c.opts.botAdmin && !botIsAdmin(sock, meta)) {
        await env.reply(`${T.warn} لازم رقم البوت يكون أدمن في الجروب.`)
        return true
      }
    }
    await c.fn(env, args)
  } catch (err) {
    log('خطأ أمر', n, err.message)
    logError('cmd:' + n, err)
    const msg = /fetch failed|ENOTFOUND|ETIMEDOUT|aborted/i.test(err.message)
      ? 'مفيش اتصال بالنت أو الخدمة مش متاحة دلوقتي، جرب تاني.'
      : err.message
    await env.reply(`${T.err} ${msg}`).catch(() => {})
  }
  return true
}

// ═══════════════════════════════════════════
// 1) أوامر الإدارة
// ═══════════════════════════════════════════
const G = { group: true }
const GA = { group: true, botAdmin: true }

cmd(['منشن', 'tagall'], 'admin', async (e, args) => {
  const meta = await getMeta(e.sock, e.jid)
  const ids = meta.participants.map((p) => p.id)
  const lines = ids.map((id) => '▫️ ' + tag(id))
  await e.sock.sendMessage(
    e.jid,
    { text: `📢 *${args || 'منشن للجميع'}*\n\n${lines.join('\n')}`, mentions: ids },
    { quoted: e.m }
  )
}, G)

cmd(['مخفي', 'hidetag'], 'admin', async (e, args) => {
  const meta = await getMeta(e.sock, e.jid)
  const ids = meta.participants.map((p) => p.id)
  const t = args || quotedText(e.ctx) || '📢'
  await e.sock.sendMessage(e.jid, { text: t, mentions: ids })
}, G)

cmd(['طرد', 'kick'], 'admin', async (e, args) => {
  const t = getTarget(e, args)
  if (!t) return e.reply(`ردّ على رسالة العضو أو منشنه: ${P}طرد @فلان`)
  const meta = await getMeta(e.sock, e.jid)
  if (botJids(e.sock).includes(clean(t))) return e.reply('😅 مش هطرد نفسي.')
  if (isAdmin(meta, t)) return e.reply('⚠️ ده أدمن، خفّض رتبته الأول بـ ' + P + 'تخفيض.')
  await e.sock.groupParticipantsUpdate(e.jid, [t], 'remove')
  await e.reply(`🚫 تم طرد ${tag(t)}`, [t])
}, GA)

cmd(['اضافة', 'إضافة', 'add'], 'admin', async (e, args) => {
  const d = args.replace(/\D/g, '')
  if (d.length < 7) return e.reply(`اكتب الرقم بالكود الدولي: ${P}اضافة 201xxxxxxxxx`)
  const res = await e.sock.groupParticipantsUpdate(e.jid, [d + '@s.whatsapp.net'], 'add')
  const st = String(res?.[0]?.status || '')
  const msg = {
    200: '✅ تمت الإضافة',
    409: 'ℹ️ العضو موجود بالفعل',
    403: '🔒 الرقم ده مقفل الإضافة (اتبعتله دعوة)',
    408: '⚠️ الرقم ساب الجروب قريب',
    401: '⚠️ الرقم عامل بلوك للبوت',
    404: '⚠️ الرقم مش على واتساب',
  }[st]
  await e.reply(msg || `⚠️ النتيجة: ${st || 'غير معروفة'}`)
}, GA)

for (const [names, action, label] of [
  [['ترقية', 'ترقيه', 'promote'], 'promote', '⬆️ تمت ترقية'],
  [['تخفيض', 'demote'], 'demote', '⬇️ تم تخفيض'],
]) {
  cmd(names, 'admin', async (e, args) => {
    const t = getTarget(e, args)
    if (!t) return e.reply(`ردّ على رسالة العضو أو منشنه: ${P}${names[0]} @فلان`)
    await e.sock.groupParticipantsUpdate(e.jid, [t], action)
    await e.reply(`${label} ${tag(t)}`, [t])
  }, GA)
}

cmd(['فتح الجروب', 'فتح'], 'admin', async (e) => {
  await e.sock.groupSettingUpdate(e.jid, 'not_announcement')
  await e.reply('🔓 تم فتح الجروب، الكل يقدر يكتب.')
}, GA)

cmd(['قفل الجروب', 'قفل'], 'admin', async (e) => {
  await e.sock.groupSettingUpdate(e.jid, 'announcement')
  await e.reply('🔒 تم قفل الجروب، الأدمنز بس يكتبوا.')
}, GA)

cmd(['الجروب', 'groupinfo'], 'admin', async (e) => {
  const meta = await e.sock.groupMetadata(e.jid)
  const admins = meta.participants.filter((p) => p.admin).length
  const created = meta.creation ? new Date(meta.creation * 1000).toLocaleDateString('ar-EG') : '—'
  const owner = (meta.ownerPn || meta.owner || '').split('@')[0]
  await e.reply(
    `📋 *معلومات الجروب*\n\n` +
      `🏷️ الاسم: ${meta.subject}\n` +
      `👥 الأعضاء: ${meta.participants.length}\n` +
      `👮 الأدمنز: ${admins}\n` +
      `👑 المنشئ: ${owner ? '+' + owner : '—'}\n` +
      `📅 تاريخ الإنشاء: ${created}\n` +
      `💬 الكتابة: ${meta.announce ? 'للأدمنز بس 🔒' : 'للكل 🔓'}\n\n` +
      `📝 الوصف:\n${meta.desc || 'لا يوجد'}`
  )
}, G)

cmd(['تغيير الاسم'], 'admin', async (e, args) => {
  if (!args) return e.reply(`اكتب الاسم الجديد: ${P}تغيير الاسم اسم الجروب`)
  await e.sock.groupUpdateSubject(e.jid, args)
  await e.reply('✅ تم تغيير اسم الجروب.')
}, GA)

cmd(['تغيير الوصف'], 'admin', async (e, args) => {
  if (!args) return e.reply(`اكتب الوصف الجديد: ${P}تغيير الوصف الوصف هنا`)
  await e.sock.groupUpdateDescription(e.jid, args)
  await e.reply('✅ تم تغيير وصف الجروب.')
}, GA)

cmd(['لينك الجروب', 'لينك'], 'admin', async (e) => {
  const code = await e.sock.groupInviteCode(e.jid)
  await e.reply(`🔗 لينك الجروب:\nhttps://chat.whatsapp.com/${code}`)
}, GA)

cmd(['الغاء اللينك', 'إلغاء اللينك'], 'admin', async (e) => {
  const code = await e.sock.groupRevokeInvite(e.jid)
  await e.reply(`♻️ تم إلغاء اللينك القديم.\n🔗 اللينك الجديد:\nhttps://chat.whatsapp.com/${code}`)
}, GA)

// ═══════════════════════════════════════════
// 2) الترفيه والألعاب
// ═══════════════════════════════════════════
async function fetchMedia(e) {
  const pickMedia = (msg) => {
    if (!msg) return null
    for (const t of ['imageMessage', 'videoMessage', 'stickerMessage'])
      if (msg[t]) return t
    return null
  }
  let holder = e.content
  let type = pickMedia(holder)
  let fake = e.m
  if (!type && e.ctx?.quotedMessage) {
    holder = e.ctx.quotedMessage
    type = pickMedia(holder)
    fake = {
      key: { remoteJid: e.jid, id: e.ctx.stanzaId, participant: e.ctx.participant, fromMe: false },
      message: e.ctx.quotedMessage,
    }
  }
  if (!type) return null
  const buffer = await downloadMediaMessage(fake, 'buffer', {}, {
    logger: silent,
    reuploadRequest: e.sock.updateMediaMessage,
  })
  return { buffer, type, animated: !!holder?.stickerMessage?.isAnimated }
}

async function toSticker(buffer, animated) {
  const inp = tmp(animated ? 'mp4' : 'jpg')
  const out = tmp('webp')
  const vf =
    'scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0'
  try {
    fs.writeFileSync(inp, buffer)
    const args = animated
      ? ['-y', '-i', inp, '-t', '8', '-vf', `fps=15,${vf}`, '-c:v', 'libwebp', '-loop', '0', '-an', '-q:v', '45', '-compression_level', '6', out]
      : ['-y', '-i', inp, '-vf', vf, '-c:v', 'libwebp', '-q:v', '75', out]
    await sh(CONFIG.FFMPEG, args, { timeout: 60000, windowsHide: true })
    return fs.readFileSync(out)
  } catch (err) {
    if (err.code === 'ENOENT') throw new Error('ffmpeg مش متثبت (pkg install ffmpeg)')
    throw err
  } finally {
    rm(inp, out)
  }
}

cmd(['استيكر', 'ملصق', 'sticker', 's'], 'all', async (e) => {
  const media = await fetchMedia(e)
  if (!media || media.type === 'stickerMessage')
    return e.reply(`ردّ على صورة أو فيديو واكتب ${P}استيكر`)
  const webp = await toSticker(media.buffer, media.type === 'videoMessage')
  await e.sock.sendMessage(e.jid, { sticker: webp }, { quoted: e.m })
})

cmd(['صورة', 'toimg'], 'all', async (e) => {
  const media = await fetchMedia(e)
  if (!media || media.type !== 'stickerMessage')
    return e.reply(`ردّ على استيكر واكتب ${P}صورة`)
  const inp = tmp('webp')
  const out = tmp('png')
  try {
    fs.writeFileSync(inp, media.buffer)
    await sh(CONFIG.FFMPEG, ['-y', '-i', inp, out], { timeout: 30000, windowsHide: true })
    await e.sock.sendMessage(e.jid, { image: fs.readFileSync(out) }, { quoted: e.m })
  } catch (err) {
    if (err.code === 'ENOENT') throw new Error('ffmpeg مش متثبت')
    throw new Error('مقدرتش أحول الاستيكر ده (غالباً متحرك)')
  } finally {
    rm(inp, out)
  }
})

cmd(['استيكر فديو', 'استيكر فيديو', 'ملصق فيديو', 'tovideo'], 'all', async (e) => {
  const media = await fetchMedia(e)
  if (!media || media.type !== 'stickerMessage')
    return e.reply(`ردّ على استيكر متحرك واكتب ${P}استيكر فديو`)
  if (!media.animated)
    return e.reply(`الاستيكر ده مش متحرك 🙂 لتحويله لصورة اكتب ${P}صورة`)
  await e.reply('⏳ جاري تحويل الاستيكر لفيديو...')
  try {
    const video = await stickerToVideo(media.buffer, { ffmpeg: CONFIG.FFMPEG, loadCanvas })
    await e.sock.sendMessage(e.jid, { video, mimetype: 'video/mp4' }, { quoted: e.m })
  } catch (err) {
    if (err.code === 'ENOENT') throw new Error('ffmpeg مش متثبت (pkg install ffmpeg)')
    if (err.message === 'STATIC') return e.reply(`الاستيكر ده مش متحرك 🙂 لتحويله لصورة اكتب ${P}صورة`)
    if (/Cannot find package/.test(err.message)) throw new Error('ثبّت المكتبات: npm install')
    throw new Error('مقدرتش أحول الاستيكر ده لفيديو')
  }
}, { sec: 'fun', d: 'رد على استيكر متحرك يحوله لفيديو', u: 'استيكر فديو' })

// كتابة على صورة (أو صورة جديدة لو مفيش صورة)
let canvasLib
async function loadCanvas() {
  if (!canvasLib) {
    try {
      canvasLib = await import('@napi-rs/canvas')
    } catch {
      throw new Error('ثبّت المكتبة الأول: npm i @napi-rs/canvas')
    }
    try {
      const f = fileURLToPath(new URL('./node_modules/@fontsource/noto-naskh-arabic/files/noto-naskh-arabic-arabic-700-normal.woff', import.meta.url))
      if (fs.existsSync(f)) canvasLib.GlobalFonts.registerFromPath(f, 'WaArabic')
      const lat = fileURLToPath(new URL('./node_modules/@fontsource/noto-sans/files/noto-sans-latin-700-normal.woff', import.meta.url))
      if (fs.existsSync(lat)) canvasLib.GlobalFonts.registerFromPath(lat, 'WaLatin')
      if (fs.existsSync('/system/fonts')) canvasLib.GlobalFonts.loadFontsFromDir('/system/fonts')
    } catch {}
  }
  return canvasLib
}

async function textImage(text, bg) {
  const { createCanvas, loadImage } = await loadCanvas()
  let W = 1024, H = 1024, img = null
  if (bg) {
    img = await loadImage(bg)
    const k = Math.min(1, 1080 / img.width)
    W = Math.round(img.width * k)
    H = Math.round(img.height * k)
  }
  const cv = createCanvas(W, H)
  const ctx = cv.getContext('2d')
  if (img) ctx.drawImage(img, 0, 0, W, H)
  else {
    const [a, b] = pick(D.GRADS)
    const g = ctx.createLinearGradient(0, 0, W, H)
    g.addColorStop(0, a)
    g.addColorStop(1, b)
    ctx.fillStyle = g
    ctx.fillRect(0, 0, W, H)
  }
  const size = Math.round(Math.min(W, H) / (img ? 11 : 9))
  ctx.font = `bold ${size}px WaArabic, WaLatin, Tahoma, Arial, "Noto Sans Arabic", "Noto Naskh Arabic", "Droid Arabic Naskh", sans-serif`
  ctx.direction = /[\u0600-\u06FF]/.test(text) ? 'rtl' : 'ltr'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'

  const maxW = W * 0.86
  const lines = []
  let line = ''
  for (const w of text.split(/\s+/)) {
    const t = line ? line + ' ' + w : w
    if (ctx.measureText(t).width > maxW && line) {
      lines.push(line)
      line = w
    } else line = t
  }
  if (line) lines.push(line)

  const lh = size * 1.35
  const total = lines.length * lh
  const startY = img ? H - total - size * 0.6 + lh / 2 : (H - total) / 2 + lh / 2
  ctx.lineJoin = 'round'
  ctx.lineWidth = size / 7
  ctx.strokeStyle = '#000'
  ctx.fillStyle = '#fff'
  lines.forEach((l, i) => {
    const y = startY + i * lh
    ctx.strokeText(l, W / 2, y)
    ctx.fillText(l, W / 2, y)
  })
  return cv.toBuffer('image/png')
}

cmd(['كتابة', 'write'], 'all', async (e, args) => {
  if (!args) return e.reply(`اكتب الكلام: ${P}كتابة كلامك هنا\n(أو ردّ على صورة عشان يكتب عليها)`)
  const media = await fetchMedia(e).catch(() => null)
  const bg = media?.type === 'imageMessage' ? media.buffer : null
  const png = await textImage(args, bg)
  await e.sock.sendMessage(e.jid, { image: png }, { quoted: e.m })
})

cmd(['هل'], 'all', async (e, args) => {
  if (!args) return e.reply(`اكتب سؤالك: ${P}هل أنا ذكي؟`)
  await e.reply(`❓ ${args}\n\n💬 ${pick(D.HAL)}`)
})

cmd(['توب', 'top'], 'all', async (e, args) => {
  if (!args) return e.reply(`اكتب التوب عن إيه: ${P}توب الكرماء`)
  if (/بنات|بنت|جمال|حلو|جميل|وسام|مثير|سكس|حب/.test(args)) return e.reply('🚫 ما بنعملش ترتيب بالشكل أو الجنس. جرّب: توب الكرماء · توب الطيبين · توب النشيطين')
  const meta = await getMeta(e.sock, e.jid)
  const ids = shuffle(meta.participants.map((p) => p.id)).slice(0, 10)
  const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟']
  await e.reply(
    `🏆 *توب ${ids.length} ${args}*\n\n` + ids.map((id, i) => `${medals[i]} ${tag(id)}`).join('\n'),
    ids
  )
}, G)

cmd(['لعبة الصراحة', 'صراحة'], 'all', (e) => e.reply(`🎯 *لعبة الصراحة*\n\n${pick(D.SAFRA)}`))
cmd(['كت', 'كت تويت'], 'all', (e) => e.reply(`🎤 *كت تويت*\n\n${pick(D.KAT)}`))

cmd(['شخصية', 'شخصيتي'], 'all', async (e) => {
  const id = clean(e.sender)
  const r = seeded(hash(id + new Date().toDateString()))
  const rows = D.TRAITS.map(([ic, name]) => {
    const p = 40 + Math.floor(r() * 61)
    return `${ic} ${name}: ${bar(p)} ${p}%`
  })
  const type = D.TYPES[Math.floor(r() * D.TYPES.length)]
  await e.reply(`🎭 *شخصية ${tag(id)}*\n\n${rows.join('\n')}\n\n✨ النوع: *${type}*`, [id])
})

// ═══════════════════════════════════════════
// 4) إسلاميات
// ═══════════════════════════════════════════
cmd(['اية', 'آية', 'ayah'], 'all', async (e) => {
  try {
    const n = 1 + Math.floor(Math.random() * 6236)
    const res = await fetch(`https://api.alquran.cloud/v1/ayah/${n}`, { signal: AbortSignal.timeout(8000) })
    const { data } = await res.json()
    return e.reply(`📖 *آية*\n\n﴿ ${data.text} ﴾\n\n📍 سورة ${data.surah.name.replace('سُورَةُ ', '')} - آية ${data.numberInSurah}`)
  } catch {
    const [t, s] = pick(D.AYAT)
    return e.reply(`📖 *آية*\n\n﴿ ${t} ﴾\n\n📍 ${s}`)
  }
})

cmd(['حديث', 'hadith'], 'all', (e) => {
  const [t, s] = pick(D.HADITHS)
  return e.reply(`📜 *حديث نبوي*\n\nقال رسول الله ﷺ:\n«${t}»\n\n📚 ${s}`)
})

cmd(['اذكار', 'أذكار'], 'all', (e) => {
  const h = new Date().getHours()
  return e.reply(D.adhkar(h >= 3 && h < 15 ? 'morning' : 'evening'))
})

cmd(['دعاء', 'ادعية'], 'all', (e) => e.reply(`🤲 *دعاء*\n\n${pick(D.DUAS)}`))

// ═══════════════════════════════════════════
// 5) أوامر عامة
// ═══════════════════════════════════════════
cmd(['الاوامر', 'menu', 'القائمة', 'أوامر'], 'all', (e) => e.reply(D.menu(P, CONFIG.BOT_NAME, realCount())))

cmd(['بوت', 'bot'], 'all', (e) => sendBotCard(e.sock, e.jid, e.m))

cmd(['سرعة', 'ping'], 'all', async (e) => {
  const t0 = Date.now()
  const sent = await e.reply(`${T.ping} ...`)
  const ms = Date.now() - t0
  await e.sock.sendMessage(e.jid, { text: `${T.ping} ${ms}ms`, edit: sent.key })
})

cmd(['المطور', 'dev'], 'all', async (e) => {
  await sendBotCard(e.sock, e.jid, e.m)
  const vcard =
    `BEGIN:VCARD\nVERSION:3.0\nFN:${CONFIG.DEV_NAME}\n` +
    `TEL;type=CELL;waid=${CONFIG.NUMBER}:+${CONFIG.NUMBER}\nEND:VCARD`
  await e.sock.sendMessage(e.jid, { contacts: { displayName: CONFIG.DEV_NAME, contacts: [{ vcard }] } }, { quoted: e.m })
})

// ═══════════════════════════════════════════
// 6) أوامر الحماية (المالك فقط)
// ═══════════════════════════════════════════

for (const [name, field, label] of [
  ['روابط', 'antilink', '🔗 مسح الروابط'],
  ['ادمن', 'exemptAdmins', '👮 استثناء الأدمنز من كل أنواع الحماية'],
]) {
  cmd([name], 'owner', async (e, args) => {
    const v = parseToggle(args.split(/\s+/)[0])
    if (v === null) return e.reply(`اكتب: ${P}${name} تشغيل أو ${P}${name} ايقاف`)
    gset(e.jid)[field] = v
    save()
    await e.reply(`${label}: ${onOff(v)}`)
  }, G)
}

cmd(['انذارات', 'ضبط التحذير', 'ضبط الانذارات'], 'owner', async (e, args) => {
  const n = parseInt(args)
  if (isNaN(n) || n < 0 || n > 20) return e.reply(`اكتب رقم من 0 لـ 20، مثال: ${P}انذارات 3`)
  gset(e.jid).warnLimit = n
  save()
  await e.reply(n ? `⚠️ هيتم الطرد بعد ${n} إنذارات` : '⚠️ الطرد متوقف (مسح فقط)')
}, G)

cmd(['تصفير'], 'owner', async (e) => {
  const t = e.ctx?.mentionedJid?.[0] || e.ctx?.participant
  if (!t) return e.reply(`منشن العضو أو ردّ على رسالته: ${P}تصفير @فلان`)
  delete gset(e.jid).warnings[clean(t)]
  save()
  await e.reply('✅ تم تصفير الإنذارات')
}, G)

cmd(['سماح'], 'owner', async (e, args) => {
  const d = normDomain(args)
  if (!d.includes('.')) return e.reply(`مثال: ${P}سماح youtube.com`)
  const g = gset(e.jid)
  if (!g.whitelist.includes(d)) g.whitelist.push(d)
  save()
  await e.reply(`✅ تم السماح بـ ${d}`)
}, G)

cmd(['الغاء_سماح'], 'owner', async (e, args) => {
  const d = normDomain(args)
  const g = gset(e.jid)
  g.whitelist = g.whitelist.filter((x) => x !== d)
  save()
  await e.reply(`🗑️ تم إلغاء السماح بـ ${d}`)
}, G)

// ═══════════════════════════════════════════
// 7) أوامر الحماية الجديدة (تفعيل/تعطيل)
// ═══════════════════════════════════════════
const FEATURES = [
  ['antilink', '🔗 مضاد الروابط', ['مضاد الروابط']],
  ['antisticker', '🔞 مضاد الملصقات الخادشة', ['مضاد الملصقات الخادشة', 'حذف الملصقات الاباحية تلقائي', 'مضاد الملصقات']],
  ['antiimage', '🔞 مضاد الصور الخادشة', ['مضاد الصور الخادشة', 'مضاد الصور']],
  ['antiprofanity', '🤬 مضاد الكلمات البذيئة', ['مضاد الكلمات البذيئة', 'مضاد الشتائم']],
  ['antiflood', '🌊 مضاد التكرار', ['مضاد التكرار', 'مضاد السبام']],
  ['antibot', '🤖 مضاد البوتات', ['مضاد البوتات']],
  ['aimod', '🧠 المراقبة الذكية للكلام', ['مضاد البذاءة الذكي', 'المراقبة الذكية']],
  ['welcome', '👋 الترحيب', ['الترحيب']],
  ['goodbye', '👋 الوداع', ['الوداع']],
  ['chat', '💬 الدردشة (بوت + كلامك)', ['الدردشة']],
  ['botcall', '🪪 بطاقة البوت عند كلمة بوت', ['بطاقة البوت']],
  ['levels', '⭐ رسالة رفع المستوى', ['المستويات']],
]

for (const [field, label, names] of FEATURES) {
  for (const on of [true, false]) {
    cmd(names.map((n) => (on ? 'تفعيل ' : 'تعطيل ') + n), 'owner', async (e) => {
      const nsfw = field === 'antisticker' || field === 'antiimage'
      if (on && nsfw) {
        await e.reply('⏳ جاري تجهيز نموذج الكشف (أول مرة بياخد ثواني)...')
        await loadCanvas()
        await getModel()
      }
      if (on && field === 'aimod' && !hasAI())
        return e.reply('⚠️ مفيش خدمة ذكاء متظبطة. حط مفتاح مجاني (Gemini أو Groq) في ملف .env وأعد تشغيل البوت (شوف .env.example).')
      const g = gset(e.jid)
      g[field] = on
      save()
      let note = ''
      if (on && !['welcome', 'goodbye', 'chat', 'botcall', 'levels'].includes(field)) {
        const meta = await getMeta(e.sock, e.jid)
        if (!botIsAdmin(e.sock, meta)) note += '\n⚠️ رقم البوت مش أدمن في الجروب، فالمسح مش هيشتغل.'
      }
      if (on && nsfw)
        note += `\n🔞 هيحذف الخادش + إنذار، والطرد بعد ${g.warnLimit || 3} إنذارات. الفحص بياخد كام ثانية، جرّبه بـ ${P}فحص.`
      if (on && field === 'antibot')
        note += `\n🤖 النظام بيجمع نقاط اشتباه (بصمات المكتبات، رسايل الأزرار والقوائم، الرد الفوري على الأوامر، اسم المرسل) ولو وصلت الحد: بيمسح رسايل البوت ويطرده ويحظره من الرجوع.\n▸ أقوى: ${P}مضاد البوتات صارم\n▸ بوت سليم؟ ${P}سماح بوت @\n▸ السجل: ${P}سجل البوتات\n▸ فحص نشط بأوامر فخ: ${P}فحص البوتات (بيتعمل أوتوماتيك دلوقتي)\n▸ ليه بوت معيّن ماتكشفش؟ ${P}حالة مضاد البوتات`
      if (on && field === 'aimod')
        note += '\nℹ️ نص الرسايل بيتبعت لخدمة الذكاء للفحص (والخدمات المجانية ممكن تستخدم البيانات لتحسين منتجاتها)، وبيفرق بين الشتيمة والهزار والكلام العادي.'
      await e.reply(`${label}: ${onOff(on)}${note}`)
      if (on && field === 'antibot' && !note.includes('مش أدمن')) autoScan(e) // فحص أولي بأوامر فخ
    }, G)
  }
}

cmd(['ضبط الترحيب'], 'owner', async (e, args) => {
  if (!args)
    return e.reply(
      `اكتب نص الترحيب، واستخدم {user} للعضو و {group} للجروب و {desc} للوصف.\n` +
        `مثال: ${P}ضبط الترحيب نورت {user} في {group} 🌹\n` +
        `ولإرجاع الافتراضي: ${P}ضبط الترحيب افتراضي`
    )
  gset(e.jid).welcomeText = args === 'افتراضي' ? '' : args
  save()
  await e.reply('✅ تم ضبط نص الترحيب')
}, G)

cmd(['منع كلمة'], 'owner', async (e, args) => {
  const w = args.trim()
  if (!w) return e.reply(`مثال: ${P}منع كلمة كلمة`)
  const g = gset(e.jid)
  if (!g.badwords.some((x) => normWord(x) === normWord(w))) g.badwords.push(w)
  save()
  await e.reply(`🚫 تم منع الكلمة. (فعّلها بـ ${P}تفعيل مضاد الكلمات البذيئة)`)
}, G)

cmd(['الغاء منع كلمة'], 'owner', async (e, args) => {
  const g = gset(e.jid)
  g.badwords = g.badwords.filter((x) => normWord(x) !== normWord(args.trim()))
  save()
  await e.reply('✅ تم إلغاء منع الكلمة')
}, G)

cmd(['الكلمات الممنوعة'], 'owner', async (e) => {
  const g = gset(e.jid)
  await e.reply(
    `🚫 *الكلمات الممنوعة الإضافية:*\n${g.badwords.length ? g.badwords.join('، ') : 'لا يوجد'}\n\n` +
      `(غير القائمة الأساسية الجاهزة)`
  )
}, G)

cmd(['حالة', 'status'], 'owner', async (e) => {
  const g = gset(e.jid)
  const meta = await getMeta(e.sock, e.jid)
  await e.reply(
    panel(`STATUS · ${meta.subject}`, [
      `${dot(g.antilink)} مضاد الروابط`,
      `${dot(g.antisticker)} مضاد الملصقات الخادشة`,
      `${dot(g.antiimage)} مضاد الصور الخادشة`,
      `${dot(g.antiprofanity)} مضاد الكلمات البذيئة`,
      `${dot(g.antiflood)} مضاد التكرار`,
      `${dot(g.antibot)} مضاد البوتات`,
      `${dot(g.aimod)} المراقبة الذكية`,
      `${dot(g.welcome)} الترحيب`,
      '',
      kv('استثناء الأدمنز', onOff(g.exemptAdmins)),
      kv('حد الإنذارات', `${g.warnLimit || 3}${g.warnLimit ? '' : ' (افتراضي، والروابط مسح فقط)'}`),
      kv('المكتومين', Object.keys(g.muted).length),
      kv('مواقع مسموحة', g.whitelist.length ? g.whitelist.join(', ') : 'لا يوجد'),
      kv('البوت أدمن', botIsAdmin(e.sock, meta) ? 'نعم ✅' : 'لا ❌'),
      '',
      kv('المحذوف', db.stats.deleted),
      kv('المطرودين', db.stats.kicked),
      kv('التشغيل', uptime()),
    ])
  )
}, G)

cmd(['إعدادات', 'اعدادات', 'config'], 'owner', async (e) => {
  const g = gset(e.jid)
  await e.reply(
    `⚙️ *إعدادات الحماية السريعة*\n\n` +
      `الروابط: ${onOff(g.antilink)} | الشتائم: ${onOff(g.antiprofanity)}\n` +
      `التكرار: ${onOff(g.antiflood)} | البوتات: ${onOff(g.antibot)}\n` +
      `الصور الخادشة: ${onOff(g.antiimage)} | الملصقات الخادشة: ${onOff(g.antisticker)}\n` +
      `المراقبة الذكية: ${onOff(g.aimod)} | الترحيب: ${onOff(g.welcome)}\n` +
      `استثناء الأدمنز: ${onOff(g.exemptAdmins)} | حد الطرد: ${g.warnLimit || 'متوقف'}\n\n` +
      `للتعديل: ${P}تفعيل مضاد الروابط أو ${P}تعطيل مضاد الروابط\n` +
      `للقائمة الكاملة: ${P}الاوامر`
  )
}, G)

cmd(['إحصائيات', 'احصائيات', 'stats'], 'owner', async (e) => {
  const g = gset(e.jid)
  const warnings = Object.values(g.warnings).reduce((sum, n) => sum + Number(n || 0), 0)
  await e.reply(
    `📈 *إحصائيات البوت والجروب*\n\n` +
      `🗑️ الرسائل المحذوفة: ${db.stats.deleted}\n` +
      `🚫 حالات الطرد: ${db.stats.kicked}\n` +
      `⚠️ إنذارات نشطة: ${warnings}\n` +
      `🔇 مكتومون: ${Object.keys(g.muted).length}\n` +
      `⏱️ التشغيل: ${uptime()}`
  )
}, G)

cmd(['فحص', 'nsfwcheck'], 'owner', async (e) => {
  const media = await fetchMedia(e)
  if (!media) return e.reply(`ردّ على صورة أو ملصق (حتى المتحرك) أو فيديو قصير واكتب ${P}فحص`)
  await loadCanvas()
  const kind =
    media.type === 'videoMessage' ? 'video'
    : media.type === 'stickerMessage' ? (media.animated ? 'animated' : 'sticker')
    : 'image'
  const r = await classifyMedia(media.buffer, kind, CONFIG.NSFW_THRESHOLD)
  const pc = (k) => Math.round((r.p[k] || 0) * 100)
  await e.reply(
    `🔎 *نتيجة الفحص*\n\nعادي: ${pc('Neutral')}%\nرسم: ${pc('Drawing')}%\nمثير: ${pc('Sexy')}%\n` +
      `إباحي: ${pc('Porn')}%\nهنتاي: ${pc('Hentai')}%\n\n` +
      `📊 الدرجة: ${Math.round(r.score * 100)}% (الحد ${Math.round(CONFIG.NSFW_THRESHOLD * 100)}%)\n` +
      `${r.flagged ? '🚫 هيتمسح' : '✅ مقبول'}`
  )
})

// ═══════════════════════════════════════════
// 8) أوامر الطرد والتحكم الجديدة
// ═══════════════════════════════════════════
const noTarget = (e, name) => e.reply(`ردّ على رسالة العضو أو منشنه: ${P}${name} @فلان`)

async function protectedTarget(e, args, name) {
  const t = getTarget(e, args)
  if (!t) return void (await noTarget(e, name))
  const meta = await getMeta(e.sock, e.jid)
  if (botJids(e.sock).includes(clean(t))) return void (await e.reply('😅 مش هينفع على البوت.'))
  if (isAdmin(meta, t)) return void (await e.reply('⚠️ ده أدمن، مينفعش.'))
  return { t, meta }
}

cmd(['تحذير', 'warn'], 'admin', async (e, args) => {
  const r = await protectedTarget(e, args, 'تحذير')
  if (!r) return
  await warnUser(e.sock, e.jid, gset(e.jid), r.t, r.meta, '⚠️ تحذير من الإدارة')
}, GA)

cmd(['الغاء التحذير'], 'admin', async (e, args) => {
  const t = getTarget(e, args)
  if (!t) return noTarget(e, 'الغاء التحذير')
  const g = gset(e.jid)
  const id = clean(t)
  const n = g.warnings[id] || 0
  if (!n) return e.reply('✅ مفيش تحذيرات على العضو ده.')
  if (n <= 1) delete g.warnings[id]
  else g.warnings[id] = n - 1
  save()
  await e.reply(`✅ تم إلغاء تحذير ${tag(t)} (المتبقي ${n - 1})`, [t])
}, G)

cmd(['كتم', 'mute'], 'admin', async (e, args) => {
  const r = await protectedTarget(e, args, 'كتم')
  if (!r) return
  gset(e.jid).muted[clean(r.t)] = Date.now()
  save()
  await e.reply(`🔇 تم كتم ${tag(r.t)}، أي رسالة منه هتتمسح.`, [r.t])
}, GA)

cmd(['الغاء الكتم', 'unmute'], 'admin', async (e, args) => {
  const t = getTarget(e, args)
  if (!t) return noTarget(e, 'الغاء الكتم')
  delete gset(e.jid).muted[clean(t)]
  save()
  await e.reply(`🔊 تم إلغاء كتم ${tag(t)}`, [t])
}, G)

cmd(['المكتومين'], 'admin', async (e) => {
  const ids = Object.keys(gset(e.jid).muted)
  await e.reply(ids.length ? `🔇 *المكتومين:*\n${ids.map(tag).join('\n')}` : '🔊 مفيش حد مكتوم.', ids)
}, G)

cmd(['طرد2'], 'admin', async (e, args) => {
  const r = await protectedTarget(e, args, 'طرد2')
  if (!r) return
  const id = clean(r.t)
  const mine = recent(e.jid).filter((x) => x.sender === id)
  const n = await deleteKeys(e.sock, mine.map((x) => x.key), 200)
  forget(e.jid, mine.map((x) => x.key.id))
  await e.sock.groupParticipantsUpdate(e.jid, [r.t], 'remove')
  db.stats.kicked++
  save()
  await e.reply(`🚫 تم طرد ${tag(r.t)} وحذف ${n} رسالة (اللي البوت شافها من وقت تشغيله).`, [r.t])
}, GA)

cmd(['تنضيف', 'clear'], 'admin', async (e, args) => {
  const n = Math.min(Math.max(parseInt(args) || 20, 1), 200)
  const items = recent(e.jid).slice(-n).reverse()
  const deleted = await deleteKeys(e.sock, items.map((x) => x.key), 250)
  forget(e.jid, items.map((x) => x.key.id))
  await e.sock.sendMessage(e.jid, {
    text: `🧹 تم حذف ${deleted} رسالة\n(البوت بيمسح بس الرسايل اللي شافها من وقت تشغيله)`,
  })
}, GA)

cmd(['حذف', 'del'], 'admin', async (e) => {
  if (!e.ctx?.stanzaId) return e.reply('ردّ على الرسالة اللي عايز تمسحها.')
  const fromMe = botJids(e.sock).includes(clean(e.ctx.participant || ''))
  await e.sock.sendMessage(e.jid, {
    delete: { remoteJid: e.jid, id: e.ctx.stanzaId, participant: e.ctx.participant, fromMe },
  })
  await e.sock.sendMessage(e.jid, { delete: e.m.key }).catch(() => {})
}, GA)

cmd(['حظر', 'ban'], 'owner', async (e, args) => {
  const t = getTarget(e, args)
  if (!t) return noTarget(e, 'حظر')
  if (botJids(e.sock).includes(clean(t))) return e.reply('😅 مش هينفع.')
  db.banned[clean(t)] = { at: Date.now() }
  save()
  await e.reply(`⛔ تم حظر ${tag(t)} من استخدام البوت.`, [t])
})

cmd(['الغاء الحظر', 'unban'], 'owner', async (e, args) => {
  const t = getTarget(e, args)
  if (!t) return noTarget(e, 'الغاء الحظر')
  delete db.banned[clean(t)]
  save()
  await e.reply(`✅ تم إلغاء حظر ${tag(t)}`, [t])
})

cmd(['المحظورين'], 'owner', async (e) => {
  const ids = Object.keys(db.banned)
  await e.reply(ids.length ? `⛔ *المحظورين من البوت:*\n${ids.map(tag).join('\n')}` : '✅ مفيش محظورين.', ids)
})

// ═══════════════════════════════════════════
// 9) بروفايل / تصميم / بحث / ترجمة
// ═══════════════════════════════════════════
cmd(['بروفايل', 'profile'], 'all', async (e, args) => {
  const t = getTarget(e, args) || e.sender
  let url = null
  try {
    url = await e.sock.profilePictureUrl(t, 'image')
  } catch {}
  let bio = ''
  try {
    const st = await e.sock.fetchStatus(t)
    bio = st?.[0]?.status?.status || st?.status?.status || st?.status || ''
    if (typeof bio !== 'string') bio = ''
  } catch {}
  if (!url) return e.reply(`🖼️ مفيش صورة بروفايل متاحة لـ ${tag(t)} (مخفية أو غير موجودة).`, [t])
  const buffer = await fetchCapped(url)
  await e.sock.sendMessage(
    e.jid,
    { image: buffer, caption: `👤 ${tag(t)}${bio ? '\n📝 ' + bio : ''}`, mentions: [t] },
    { quoted: e.m }
  )
})

function wrapLines(ctx, text, maxW) {
  const lines = []
  let line = ''
  for (const w of text.split(/\s+/)) {
    const t = line ? line + ' ' + w : w
    if (ctx.measureText(t).width > maxW && line) {
      lines.push(line)
      line = w
    } else line = t
  }
  if (line) lines.push(line)
  return lines
}

async function logoImage(text, style = Math.floor(Math.random() * 4)) {
  const { createCanvas } = await loadCanvas()
  const W = 1024, H = 512
  const cv = createCanvas(W, H)
  const ctx = cv.getContext('2d')
  const font = (px) => `bold ${px}px WaArabic, WaLatin, Tahoma, Arial, "Noto Sans Arabic", sans-serif`
  ctx.direction = /[\u0600-\u06FF]/.test(text) ? 'rtl' : 'ltr'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'

  let size = 170
  let lines
  for (;;) {
    ctx.font = font(size)
    lines = wrapLines(ctx, text, W * 0.84)
    if (lines.length * size * 1.25 <= H * 0.72 || size <= 40) break
    size -= 8
  }
  const lh = size * 1.25
  const y0 = H / 2 - ((lines.length - 1) * lh) / 2
  const each = (fn) => lines.forEach((l, i) => fn(l, W / 2, y0 + i * lh))

  if (style === 0) {
    // نيون
    const [c1, c2] = pick([['#00f0ff', '#0077ff'], ['#ff2bd6', '#9d00ff'], ['#39ff14', '#00c853'], ['#ffb300', '#ff3d00']])
    ctx.fillStyle = '#07070f'
    ctx.fillRect(0, 0, W, H)
    ctx.strokeStyle = c1
    ctx.lineWidth = 6
    ctx.shadowColor = c1
    ctx.shadowBlur = 30
    ctx.strokeRect(28, 28, W - 56, H - 56)
    ctx.font = font(size)
    ctx.lineWidth = 8
    ctx.strokeStyle = c2
    each((l, x, y) => ctx.strokeText(l, x, y))
    ctx.shadowBlur = 45
    ctx.shadowColor = c1
    ctx.fillStyle = '#ffffff'
    each((l, x, y) => ctx.fillText(l, x, y))
  } else if (style === 1) {
    // ذهبي ثلاثي الأبعاد
    const bg = ctx.createRadialGradient(W / 2, H / 2, 40, W / 2, H / 2, W * 0.7)
    bg.addColorStop(0, '#2b2b2b')
    bg.addColorStop(1, '#0a0a0a')
    ctx.fillStyle = bg
    ctx.fillRect(0, 0, W, H)
    ctx.font = font(size)
    ctx.fillStyle = '#4a3000'
    for (let i = 10; i > 0; i--) each((l, x, y) => ctx.fillText(l, x + i, y + i))
    const g = ctx.createLinearGradient(0, y0 - size / 2, 0, y0 + lines.length * lh)
    g.addColorStop(0, '#fff6b7')
    g.addColorStop(0.5, '#f5b400')
    g.addColorStop(1, '#8a5a00')
    ctx.fillStyle = g
    each((l, x, y) => ctx.fillText(l, x, y))
  } else if (style === 2) {
    // جليتش
    ctx.fillStyle = '#0a0a0a'
    ctx.fillRect(0, 0, W, H)
    ctx.font = font(size)
    ctx.globalAlpha = 0.85
    ctx.fillStyle = '#ff0040'
    each((l, x, y) => ctx.fillText(l, x - 8, y))
    ctx.fillStyle = '#00e5ff'
    each((l, x, y) => ctx.fillText(l, x + 8, y))
    ctx.globalAlpha = 1
    ctx.fillStyle = '#ffffff'
    each((l, x, y) => ctx.fillText(l, x, y))
  } else {
    // غروب
    const g = ctx.createLinearGradient(0, 0, W, H)
    g.addColorStop(0, '#ff512f')
    g.addColorStop(1, '#6a11cb')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, W, H)
    ctx.font = font(size)
    ctx.lineJoin = 'round'
    ctx.lineWidth = size / 6
    ctx.strokeStyle = 'rgba(0,0,0,0.55)'
    each((l, x, y) => ctx.strokeText(l, x + 6, y + 8))
    ctx.fillStyle = '#ffffff'
    each((l, x, y) => ctx.fillText(l, x, y))
  }
  return cv.toBuffer('image/png')
}

cmd(['تصميم', 'logo'], 'all', async (e, args) => {
  if (!args) return e.reply(`اكتب الاسم: ${P}تصميم اسمك`)
  if (args.length > 60) return e.reply('الكلام طويل، اختصره لـ 60 حرف.')
  const png = await logoImage(args)
  await e.sock.sendMessage(e.jid, { image: png, caption: '🎨' }, { quoted: e.m })
})

const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36'

// ── ترجمة ──
async function translate(text, tl) {
  try {
    const r = await fetch(
      `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${tl}&dt=t&q=${encodeURIComponent(text)}`,
      { headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(10000) }
    )
    const j = await r.json()
    const out = j[0].map((x) => x[0]).join('')
    if (out) return out
  } catch {}
  const src = tl === 'ar' ? 'en' : 'ar'
  const r = await fetch(
    `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text.slice(0, 450))}&langpair=${src}|${tl}`,
    { signal: AbortSignal.timeout(10000) }
  )
  const out = (await r.json())?.responseData?.translatedText
  if (!out) throw new Error('الترجمة فشلت، جرب بعد شوية.')
  return out
}

const LANGS = 'ar|en|fr|de|es|it|tr|ru|ja|ko|pt|zh|hi|ur|fa'
cmd(['ترجمة', 'ترجم', 'tr'], 'all', async (e, args) => {
  if (explicit(args)) return e.reply(BLOCKED_MSG)
  let tl = null
  let text = args
  const m1 = args.match(new RegExp(`^(${LANGS})\\s+([\\s\\S]+)`, 'i'))
  if (m1) {
    tl = m1[1].toLowerCase()
    text = m1[2]
  } else if (new RegExp(`^(${LANGS})$`, 'i').test(args)) {
    tl = args.toLowerCase()
    text = quotedText(e.ctx)
  } else if (!args) text = quotedText(e.ctx)
  if (!text) return e.reply(`اكتب الكلام أو ردّ على رسالة: ${P}ترجمة hello`)
  text = text.slice(0, 1500)
  if (!tl) tl = (text.match(/[\u0600-\u06FF]/g) || []).length > text.length * 0.3 ? 'en' : 'ar'
  await e.reply(`🌐 *الترجمة (${tl})*\n\n${await translate(text, tl)}`)
})

// ═══════════════════════════════════════════
// فنش: طرد كل الأعضاء (المالك بس + تأكيد)
// ═══════════════════════════════════════════
const finishPending = new Map() // jid → وقت الطلب

cmd(['فنش', 'finish'], 'owner', async (e, args) => {
  const meta = await e.sock.groupMetadata(e.jid) // بيانات حديثة مش من الكاش
  const me = botJids(e.sock)
  const targets = meta.participants
    .filter((p) => !p.admin && !me.includes(clean(p.id)))
    .map((p) => p.id)
  const confirm = ['تاكيد', 'تأكيد', 'confirm', 'yes'].map(norm).includes(norm(args))

  if (!confirm) {
    if (!targets.length) return e.reply('مفيش أعضاء عاديين يتطردوا (الأدمنز بيتخطوا).')
    finishPending.set(e.jid, Date.now())
    return e.reply(
      `⚠️ *تحذير*\nهيتم طرد *${targets.length}* عضو من "${meta.subject}".\n` +
        `الأدمنز والبوت مش هيتطردوا.\n\nللتأكيد خلال دقيقة اكتب:\n${P}فنش تأكيد`
    )
  }

  const t = finishPending.get(e.jid)
  if (!t || Date.now() - t > 60_000)
    return e.reply(`اكتب ${P}فنش الأول، وبعدها ${P}فنش تأكيد خلال دقيقة.`)
  finishPending.delete(e.jid)
  if (!targets.length) return e.reply('مفيش أعضاء يتطردوا.')

  await e.reply(`🧹 بدأ الطرد (${targets.length} عضو)، ممكن ياخد شوية وقت...`)
  let removed = 0
  for (let i = 0; i < targets.length; i += 5) {
    try {
      const res = await e.sock.groupParticipantsUpdate(e.jid, targets.slice(i, i + 5), 'remove')
      removed += res.filter((r) => String(r.status) === '200').length
    } catch (err) {
      log('فنش:', err.message)
    }
    await sleep(2000) // فاصل عشان واتساب ما يعتبرهاش هجوم
  }
  db.stats.kicked += removed
  save()
  await e.reply(`✅ تم طرد ${removed} من ${targets.length}.`)
}, GA)

// ═══════════════════════════════════════════
// 10) التنصيب (بوت فرعي برقم العضو)
// ═══════════════════════════════════════════
const phoneOf = (e) =>
  [e.m.key.participantAlt, e.m.key.remoteJidAlt, e.sender, e.jid]
    .find((j) => j && j.endsWith('@s.whatsapp.net'))
    ?.split(/[:@]/)[0]

const DM = { dm: true }

cmd(['تنصيب', 'install', 'jadibot'], 'all', async (e, args) => {
  if (!CONFIG.ALLOW_INSTALL) return e.reply('⚠️ التنصيب مقفول حالياً.')
  if (!isMainSock(e.sock))
    return e.reply(`ابعت ${P}تنصيب في خاص البوت الأساسي: wa.me/${mainNumber()}`)

  let number = args.replace(/\D/g, '')
  const mine = phoneOf(e)
  if (!e.isOwner && mine) number = mine // العضو العادي بيتنصب برقمه هو بس
  if (!number)
    return e.reply(`اكتب رقمك بالكود الدولي:\n${P}تنصيب 201234567890`)

  const dm = number + '@s.whatsapp.net'
  const pending = installSub(number, {
    onLinked: () =>
      e.sock.sendMessage(dm, {
        text: `✅ *تم ربط البوت برقمك!*\nاكتب ${P}الاوامر في أي جروب أنت فيه، ولو أدمن اكتب ${P}حالة وفعّل الحماية.\nلإلغاء التنصيب: ${P}الغاء التنصيب`,
      }).catch(() => {}),
    onExpire: () =>
      e.sock.sendMessage(dm, { text: `⌛ انتهت مهلة الكود. اكتب ${P}تنصيب تاني لو لسه عايز.` }).catch(() => {}),
  })
  await e.reply('⏳ جاري إنشاء الكود...')
  const code = await pending
  const text =
    `🔑 *كود ربط البوت برقمك (${number}):*\n\n*${code.replace(/(.{4})(.{4})/, '$1-$2')}*\n\n` +
    `1️⃣ افتح واتساب ← *الأجهزة المرتبطة* ← *ربط جهاز*\n` +
    `2️⃣ اختار *الربط برقم الهاتف بدلاً من ذلك*\n` +
    `3️⃣ اكتب الكود (صالح دقيقتين تقريباً)\n\n` +
    `⚠️ *تنبيه:* البوت هيشتغل بحسابك وبيقدر يقرا رسايلك ويبعت منها. ` +
    `لو عايز تلغي اكتب ${P}الغاء التنصيب أو امسح الجهاز من الأجهزة المرتبطة.`
  if (e.isGroup) {
    try {
      await e.sock.sendMessage(dm, { text })
      await e.reply('📩 بعتلك الكود في الخاص.')
    } catch {
      await e.reply(text)
    }
  } else await e.reply(text)
}, DM)

cmd(['الغاء التنصيب', 'uninstall'], 'all', async (e, args) => {
  const main = isMainSock(e.sock)
  const number = main
    ? args.replace(/\D/g, '') || phoneOf(e)
    : (e.sock.user?.id || '').split(/[:@]/)[0]
  const allowed = e.isOwner || (main && number && number === phoneOf(e))
  if (!allowed) return e.reply('⚠️ مش مسموحلك تلغي التنصيب ده.')
  if (!number) return e.reply(`اكتب الرقم: ${P}الغاء التنصيب 201234567890`)
  if (!main) {
    await e.reply('✅ تم إلغاء التنصيب، البوت هيفصل من رقمك.')
    return void setTimeout(() => removeSub(number), 1500)
  }
  await e.reply((await removeSub(number)) ? '✅ تم إلغاء التنصيب.' : 'ℹ️ الرقم ده مش منصب.')
}, DM)

cmd(['المنصبين'], 'owner', async (e) => {
  const l = listSubs()
  await e.reply(
    l.length
      ? `🤖 *البوتات الفرعية (${l.length}/${CONFIG.MAX_SUBBOTS}):*\n\n` +
          l.map((x) => `• +${x.number} ${x.online ? '🟢' : x.linked ? '🟡 بيتصل' : '⏳ منتظر الربط'}`).join('\n')
      : 'مفيش بوتات فرعية.'
  )
})

// ═══════════════════════════════════════════
// 11) الذكاء الاصطناعي
// ═══════════════════════════════════════════
const aiUse = new Map()

cmd(['ذكاء', 'اسال', 'ai'], 'all', async (e, args) => {
  const q = (args || quotedText(e.ctx)).trim()
  if (!q) return e.reply(`اسألني أي حاجة: ${P}ذكاء سؤالك`)
  if (!e.isOwner) {
    const k = clean(e.sender || '')
    const day = new Date().toDateString()
    const u = aiUse.get(k)
    if (u && Date.now() - u.t < 20_000) return e.reply('⏳ استنى شوية قبل السؤال الجاي.')
    if (u?.day === day && u.n >= 15) return e.reply('وصلت للحد اليومي للأسئلة (15).')
    aiUse.set(k, { t: Date.now(), day, n: u?.day === day ? u.n + 1 : 1 })
  }
  let out = ''
  if (hasAI()) {
    try {
      out = await askAI({
        system:
          'أنت مساعد ذكي في جروب واتساب. جاوب باختصار (٦ أسطر كحد أقصى) وبنفس لغة ولهجة السائل. ارفض بأدب أي طلب جنسي أو ضار أو مخالف للقانون.',
        messages: [{ role: 'user', content: q.slice(0, 1500) }],
        maxTokens: 500,
      })
    } catch {}
  }
  if (!out) {
    const r = brainAnswer(q, { jid: e.jid, vars: { count: String(realCount()) }, threshold: 0.5 })
    out = r ? r.reply : `🤔 مش عارف أجاوب على ده. علّمني: ${P}علمني ${q.slice(0, 25)} = الجواب`
  }
  await e.reply(`🧠 ${out}`)
})

cmd(['رد الي', 'autoreply'], 'owner', async (e, args) => {
  const conf = getAI(e.sock)
  const [sub = '', ...rest] = args.trim().split(/\s+/)
  const val = rest.join(' ').trim()
  const s = norm(sub)
  const isOn = ['تشغيل', 'تفعيل', 'on'].map(norm).includes(s)
  const isOff = ['ايقاف', 'تعطيل', 'off'].map(norm).includes(s)

  if (isOn) {
    conf.enabled = true
    save()
    return e.reply(
      `✅ *الرد الآلي شغال*\n\n` +
        `• بيرد على أي حد يكتبلك خاص (مش الجروبات) برسالة معنونة 🤖 إنها من مساعد ذكاء اصطناعي.\n` +
        `• بيقف ${CONFIG.AI_PAUSE_MIN} دقيقة في أي شات لو انت رديت بنفسك.\n` +
        `• أقصى ${CONFIG.AI_REPLY_PER_DAY} رد في اليوم لكل شخص.\n` +
        `• بيرد بالذكاء المحلي (على جهازك، من غير API)${dmReady() ? ' وبخدمة ذكاء خاصة لو متظبطة' : ''}. درّبه بـ ${P}علمني و${P}تدريب تلقائي.\n\n` +
        `ظبط اسمك: ${P}رد آلي اسم مصطفى\nوتعليماتك: ${P}رد آلي تعليمات أنا مشغول لحد الساعة 5`
    )
  }
  if (isOff) {
    conf.enabled = false
    save()
    return e.reply('⏹️ تم إيقاف الرد الآلي.')
  }
  if (s === norm('تعليمات')) {
    if (!val) return e.reply(`اكتب التعليمات: ${P}رد آلي تعليمات أنا مشغول لحد الساعة 5`)
    conf.instructions = val.slice(0, 600)
    save()
    return e.reply('✅ تم حفظ التعليمات.')
  }
  if (s === norm('اسم')) {
    if (!val) return e.reply(`اكتب اسمك: ${P}رد آلي اسم مصطفى`)
    conf.ownerName = val.slice(0, 40)
    save()
    return e.reply('✅ تم حفظ الاسم.')
  }
  await e.reply(
    `🤖 *الرد الآلي على الخاص*\n\n` +
      `الحالة: ${onOff(conf.enabled)}\n` +
      `الاسم: ${conf.ownerName || e.sock.user?.name || '—'}\n` +
      `التعليمات: ${conf.instructions || 'لا يوجد'}\n` +
      `الخدمات: ${aiStatus().map((x) => `${x.name}${x.ready ? (x.cooling ? '⏳' : '✅') : '❌'}`).join(' ')}\n` +
      `آخر خدمة اشتغلت: ${lastUsedProvider() || '—'}\n` +
      `الرد على الخاص: ${dmReady() ? '✅ جاهز' : '❌ محتاج خدمة خاصة (شوف .env.example)'}${dmPrivateOnly() ? '' : ' (المجانية مسموحة)'}\n\n` +
      `الأوامر: ${P}رد آلي تشغيل | ايقاف | تعليمات + نص | اسم + اسمك`
  )
})

// ═══════════════════════════════════════════
// 12) القرآن: تحميل التلاوات 
// ═══════════════════════════════════════════
let quranActive = 0
const mb = (b) => (b / 1e6).toFixed(1)

cmd(['سورة', 'سوره', 'قران', 'قرآن', 'quran'], 'all', async (e, args) => {
  const a = args.trim()
  if (!a)
    return e.reply(
      panel('📖 QURAN', [
        kv('تحميل', `${P}سورة الكهف`),
        kv('بقارئ من القايمة', `${P}سورة الكهف 3`),
        kv('باسم القارئ', `${P}سورة يس السديس`),
        kv('القوايم', `${P}سور  |  ${P}قراء`),
      ])
    )
  const tokens = a.split(/\s+/)
  let surah = 0
  let rest = []
  for (let k = tokens.length; k >= 1 && !surah; k--) {
    surah = findSurah(tokens.slice(0, k).join(' '))
    if (surah) rest = tokens.slice(k)
  }
  if (!surah) return e.reply(`${T.err} مش لاقي السورة دي. اكتب ${P}سور لقايمة السور.`)

  const spec = rest.join(' ').trim()
  let rec
  if (spec) {
    rec = /^\d+$/.test(spec) ? (await curated())[Number(spec) - 1] : findReciter(await getReciters(), spec)
    if (!rec) return e.reply(`${T.err} مش لاقي القارئ ده. اكتب ${P}قراء لقايمة القراء.`)
  } else rec = await defaultReciter(e.jid)
  const mo = bestMoshaf(rec, surah)
  if (!mo) return e.reply(`${T.err} ${rec.name} ملوش السورة دي في المصحف المتاح، جرب قارئ تاني.`)

  if (quranActive >= 2) return e.reply(`${T.warn} في تحميلات شغالة دلوقتي، جرب بعد شوية.`)
  const sname = D.SURAHS[surah - 1]
  const url = `${mo.server}${pad3(surah)}.mp3`
  await e.reply(`${T.dl} جاري تجهيز *سورة ${sname}* بصوت *${rec.name}*...`)
  quranActive++
  let file
  try {
    const r = await fetchSurahFile(url, CONFIG.MAX_MB * 1e6)
    if (r.tooBig)
      return void (await e.reply(
        panel('📖 QURAN', [
          `سورة ${sname} · ${rec.name}`,
          `الحجم ${r.size ? mb(r.size) + ' MB' : 'كبير'} (أكبر من حد التحميل ${CONFIG.MAX_MB} MB)`,
          'حمّلها من الرابط:',
          url,
        ])
      ))
    file = r.file
    await e.sock.sendMessage(
      e.jid,
      { audio: { url: file }, mimetype: 'audio/mpeg', fileName: `${sname} - ${rec.name}.mp3` },
      { quoted: e.m }
    )
  } finally {
    quranActive--
    if (file) rm(file)
  }
})

cmd(['سور', 'السور', 'surahs'], 'all', (e) => {
  const rows = []
  for (let i = 0; i < 114; i += 2)
    rows.push(`${pad3(i + 1)} ${D.SURAHS[i]}  ┃  ${pad3(i + 2)} ${D.SURAHS[i + 1]}`)
  return e.reply(panel('📖 SURAHS', rows, `${P}سورة + الاسم أو الرقم`))
})

cmd(['قراء', 'القراء', 'reciters'], 'all', async (e, args) => {
  const cur = await curated()
  const n = parseInt(args)
  if (n) {
    const rec = cur[n - 1]
    if (!rec) return e.reply(`${T.err} اكتب رقم من 1 لـ ${cur.length}.`)
    if (e.isGroup && !e.isOwner) {
      const meta = await getMeta(e.sock, e.jid)
      if (!isAdmin(meta, e.sender)) return e.reply(`${T.err} تغيير القارئ الافتراضي للأدمن بس.`)
    }
    db.quran[e.jid] = rec.id
    save()
    return e.reply(`${T.ok} القارئ الافتراضي هنا: *${rec.name}*`)
  }
  const def = await defaultReciter(e.jid)
  await e.reply(
    panel(
      '🎙 RECITERS',
      cur.map((r, i) => `[${i + 1}] ${r.name}${r.id === def.id ? '  ◀ افتراضي' : ''}`),
      `${P}قراء 3 لتثبيت قارئ  |  ${P}سورة الكهف 3`
    )
  )
})

// ── مواقيت الصلاة ──
const h12 = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number)
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'م' : 'ص'}`
}

cmd(['صلاة', 'صلاه', 'مواقيت', 'prayer'], 'all', async (e, args) => {
  const [c, k] = args.split(/[,،]/).map((x) => x.trim())
  const city = c || CONFIG.CITY
  const country = k || CONFIG.COUNTRY
  const res = await fetch(
    `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=${CONFIG.PRAYER_METHOD}`,
    { signal: AbortSignal.timeout(15_000) }
  )
  const j = await res.json().catch(() => ({}))
  if (!res.ok || !j.data?.timings)
    return e.reply(`${T.err} مش لاقي المدينة. اكتبها بالإنجليزي: ${P}صلاة Cairo,Egypt`)
  const t = j.data.timings
  const hj = j.data.date?.hijri
  const names = [['الفجر', 'Fajr'], ['الشروق', 'Sunrise'], ['الظهر', 'Dhuhr'], ['العصر', 'Asr'], ['المغرب', 'Maghrib'], ['العشاء', 'Isha']]
  await e.reply(
    panel(`🕌 PRAYER · ${city}`, [
      ...names.map(([ar, en]) => kv(ar, h12(String(t[en]).split(' ')[0]))),
      ...(hj ? ['', `📅 ${hj.day} ${hj.month?.ar || ''} ${hj.year} هـ`] : []),
    ])
  )
})

// ── أدوات سريعة ──
function calc(expr) {
  const t = expr
    .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[×xX]/g, '*')
    .replace(/÷/g, '/')
    .replace(/٫/g, '.')
    .replace(/[،,]/g, '')
    .replace(/\s+/g, '')
  if (!t || t.length > 80 || !/^[0-9+\-*/().%^]+$/.test(t))
    throw new Error('تعبير غير صالح (أرقام وعمليات + - * / % ^ وأقواس بس)')
  let i = 0
  const peek = () => t[i]
  const prim = () => {
    if (peek() === '(') {
      i++
      const v = add()
      if (peek() !== ')') throw new Error('قوس ناقص')
      i++
      return v
    }
    const m = /^(\d+(\.\d+)?|\.\d+)/.exec(t.slice(i))
    if (!m) throw new Error('تعبير غير صالح')
    i += m[0].length
    return parseFloat(m[0])
  }
  const pow = () => {
    const b = prim()
    if (peek() === '^') {
      i++
      return Math.pow(b, un())
    }
    return b
  }
  const un = () => {
    if (peek() === '-') { i++; return -un() }
    if (peek() === '+') { i++; return un() }
    return pow()
  }
  const mul = () => {
    let v = un()
    while (peek() && '*/%'.includes(peek())) {
      const o = t[i++]
      const r = un()
      v = o === '*' ? v * r : o === '/' ? v / r : v % r
    }
    return v
  }
  const add = () => {
    let v = mul()
    while (peek() && '+-'.includes(peek())) {
      const o = t[i++]
      const r = mul()
      v = o === '+' ? v + r : v - r
    }
    return v
  }
  const v = add()
  if (i < t.length) throw new Error('تعبير غير صالح')
  if (!Number.isFinite(v)) throw new Error('الناتج مش رقم صالح (قسمة على صفر؟)')
  return Math.round(v * 1e10) / 1e10
}

cmd(['حاسبة', 'حاسبه', 'احسب', 'calc'], 'all', async (e, args) => {
  if (!args) return e.reply(`اكتب العملية: ${P}حاسبة 2+3*4`)
  await e.reply(panel('🧮 CALC', [kv('المعادلة', args), kv('الناتج', calc(args))]))
})

cmd(['وقت', 'الوقت', 'تاريخ', 'time'], 'all', async (e) => {
  const now = new Date()
  const opt = { timeZone: CONFIG.TZ }
  let greg
  let hijri = ''
  try {
    greg =
      now.toLocaleDateString('ar-EG', { ...opt, dateStyle: 'full' }) + ' · ' +
      now.toLocaleTimeString('ar-EG', { ...opt, hour: 'numeric', minute: '2-digit' })
  } catch {
    greg = now.toISOString()
  }
  try {
    hijri = now.toLocaleDateString('ar-SA-u-ca-islamic-umalqura', { ...opt, dateStyle: 'long' })
  } catch {}
  await e.reply(
    panel('⏱ TIME', [kv('ميلادي', greg), ...(hijri ? [kv('هجري', hijri)] : []), kv('المنطقة', CONFIG.TZ)])
  )
})

const reminders = new Map()
cmd(['ذكرني', 'منبه', 'remind'], 'all', async (e, args) => {
  const m = args.match(/^(\d+(?:\.\d+)?)\s*(س|ساعه|ساعة|ساعات|د|دقيقه|دقيقة|دقايق)?\s+([\s\S]+)$/)
  if (!m) return e.reply(`اكتب: ${P}ذكرني 10 شراء حاجة (الوقت بالدقايق، أو 2س للساعات)`)
  const hours = /^(س|ساع)/.test(m[2] || '')
  const mins = Number(m[1]) * (hours ? 60 : 1)
  if (!(mins >= 1 && mins <= 1440)) return e.reply(`${T.err} الوقت من دقيقة لـ 24 ساعة.`)
  const who = clean(e.sender || '')
  const count = reminders.get(who) || 0
  if (count >= 5) return e.reply(`${T.err} عندك 5 تذكيرات شغالة بالفعل.`)
  reminders.set(who, count + 1)
  const text = m[3].trim().slice(0, 200)
  const { sock, jid, sender } = e
  setTimeout(async () => {
    reminders.set(who, Math.max(0, (reminders.get(who) || 1) - 1))
    try {
      await sock.sendMessage(jid, { text: `${T.time} ⏰ تذكير ${tag(sender)}\n┃ ▸ ${text}`, mentions: [sender] })
    } catch {}
  }, mins * 60_000)
  await e.reply(
    `${T.ok} تمام، هفكرك بعد ${hours ? mins / 60 + ' ساعة' : mins + ' دقيقة'}.\n(التذكير بيتلغي لو البوت اتقفل)`
  )
})

cmd(['ايدي', 'id'], 'all', (e) =>
  e.reply(
    panel('🪪 ID', [
      kv('الشات', e.jid),
      kv('أنت', e.sender),
      kv('النوع', e.isGroup ? 'جروب' : 'خاص'),
      kv('البوت', (e.sock.user?.id || '').split(':')[0]),
    ])
  )
)

cmd(['مساعدة', 'شرح', 'help'], 'all', (e, args) => {
  if (!args.trim()) return e.reply(D.menu(P, CONFIG.BOT_NAME, realCount()))
  const hits = D.findHelp(P, args)
  if (!hits.length) return e.reply(`${T.err} مفيش أمر بالاسم ده. اكتب ${P}الاوامر.`)
  return e.reply(
    panel('❔ HELP', hits.flatMap((h) => [`▸ ${h.usage}`, `   ↳ ${h.desc || '—'}`, `   ⌁ ${h.section} · ${h.who}`]))
  )
})

// ═══════════════════════════════════════════
// 13) الوحدات الإضافية + بطاقة البوت + فهرس الأقسام
// ═══════════════════════════════════════════
const ctx = {
  cmd, P, CONFIG, T, panel, kv, dot, db, save, gset, clean, tag, pick, shuffle, hash, seeded, bar, norm, onOff,
  getTarget, quotedText, fetchMedia, getMeta, isAdmin, botIsAdmin, botJids, D, log, sleep, uptime, registry, duplicates,
}
for (const r of [regText, regMath, regFun, regGames, regEco, regGroup, regNet, regIslam, regBrain, regCompetition, regDev, regMillion, regAnime, regAntibot, regSecurity5, regGroups5, regTools5, regAdmin5, regProt6, regCyber6, regDev6, regGames6, regTts6, regScripts6, regLearn6]) r(ctx)
loadPlugins(ctx).catch((e) => log('تعذر تحميل الإضافات:', e.message)) // الإضافات (بدون انتظار عشان ما نعطّلش الاستيراد)
startScheduler()
scheduleAuto(24) // نسخ احتياطي يومي لو BACKUP_KEY متظبط

const AUTO = {
  text: ['🔤', 'TEXT', 'النصوص والترميز والخطوط'],
  math: ['🧮', 'MATH', 'الحساب والأرقام والتواريخ'],
  conv: ['🔁', 'CONVERT', 'التحويلات'],
  fun: ['🎭', 'FUN', 'التسلية والمحتوى'],
  vibes: ['💞', 'SOCIAL', 'النسب والتفاعل'],
  games: ['🎮', 'GAMES', 'الألعاب'],
  eco: ['💰', 'ECONOMY', 'الاقتصاد والمستويات'],
  group: ['🛠', 'GROUP', 'أدوات الجروب'],
  net: ['🌐', 'NET', 'خدمات الإنترنت والقرآن النصي'],
  islam: ['🕌', 'ISLAM+', 'إسلاميات إضافية'],
  brain: ['🧠', 'BRAIN', 'الذكاء المحلي والتدريب'],
  competition: ['🏆', 'COMPETITIONS', 'المسابقات والتحديات'],
  sec5: ['🛡️', 'CYBERSEC', 'الأمن السيبراني والحماية المتقدمة'],
  grp5: ['👥', 'GROUPS+', 'إدارة الجروبات المتقدمة'],
  tools5: ['🧰', 'TOOLS+', 'أدوات وخدمات تقنية'],
  dev5: ['🧑‍💻', 'DEV', 'المطور والنظام'],
  prot6: ['🧱', 'RULES', 'قواعد الحماية (منع ...)'],
  cyber6: ['🔐', 'CYBER+', 'موسوعة الأمن السيبراني'],
  code6: ['👨‍💻', 'CODE', 'موسوعة البرمجة'],
  games6: ['🎮', 'GAMES+', 'ألعاب وأسئلة جديدة'],
  scripts6: ['📜', 'SCRIPTS', 'سكربتات جاهزة + شرح التشغيل'],
  learn6: ['🎓', 'LEARN', 'أسئلة ومهام ومسارات تعلم'],
}
for (const [key, [icon, en, title]] of Object.entries(AUTO)) {
  const items = registry.filter((c) => c.opts.sec === key).map((c) => [c.opts.u || c.orig[0], c.opts.d || ''])
  if (items.length) D.SECTIONS.push({ icon, en, title, who: 'للكل', compact: true, items })
}

for (let i = 1; i <= D.SECTIONS.length; i++)
  cmd([String(i)], 'all', (e, args) => e.reply(D.section(P, i, parseInt(args))), { hidden: true })
cmd(['قسم', 'section'], 'all', (e, args) => {
  const [n, pg] = args.trim().split(/\s+/).map(Number)
  return e.reply(D.section(P, n, pg) || `${T.err} اكتب رقم القسم من 1 لـ ${D.SECTIONS.length}.`)
}, { hidden: true })

// عدد الأوامر الفعلي (من غير اختصارات الأرقام .1 .2 ...)
export const realCount = () => registry.filter((c) => !c.opts.hidden).length
cmd(['عدد الاوامر'], 'all', (e) => {
  const real = registry.filter((c) => !c.opts.hidden)
  const by = (l) => real.filter((c) => c.level === l).length
  return e.reply(panel('📊 COMMANDS', [
    kv('الأوامر الفعلية', real.length), kv('بالأسماء البديلة', real.reduce((n, c) => n + c.names.length, 0)),
    kv('للكل', by('all')), kv('للأدمن', by('admin')), kv('للمالك', by('owner')), kv('الأقسام', D.SECTIONS.length),
  ], 'بدون اختصارات الأرقام .1 .2 ...'))
}, { sec: 'tools', d: 'عدد الأوامر' })

// ═══ بطاقة البوت (تتبعت لما حد يكتب "بوت") ═══
const CARD_PATH = fileURLToPath(new URL('./assets/bot.jpg', import.meta.url))
let cardBuf
export function botCardText() {
  return [
    D.menu === undefined ? '' : `░▒▓█ ${CONFIG.BOT_NAME} █▓▒░`,
    '┏━⟦ BOT INFO ⟧━━━━━━━━',
    '┃ ▸ الحالة: 🟢 شغال',
    `┃ ▸ الإصدار: ${VERSION}`,
    `┃ ▸ مدة التشغيل: ${uptime()}`,
    `┃ ▸ الأوامر: ${realCount()} أمر (جروب وخاص)`,
    `┃ ▸ جروبات متسجلة: ${Object.keys(db.groups).length}`,
    `┃ ▸ الذكاء: ${hasAI() ? 'محلي + سحابي' : 'محلي بدون API'} 🧠`,
    '┣━⟦ HOW TO USE ⟧━━━━━━━',
    `┃ 1) ${P}الاوامر ← فهرس الأقسام`,
    `┃ 2) ${P}1 … ${P}${D.SECTIONS.length} ← افتح قسم`,
    `┃ 3) ${P}مساعدة طرد ← شرح أي أمر`,
    '┃ 4) بوت + كلامك ← دردشة (مثال: بوت ازيك)',
    `┃ 5) ${P}سورة الكهف ← تحميل القرآن`,
    `┃ 6) ${P}تنصيب ← ركّب البوت على رقمك`,
    '┣━⟦ DEVELOPER ⟧━━━━━━━',
    `┃ ▸ ${CONFIG.DEV_NAME}`,
    `┃ ▸ wa.me/${CONFIG.NUMBER}`,
    ...(CONFIG.DEV_LINK ? [`┃ ▸ ${CONFIG.DEV_LINK}`] : []),
    '┗━━━━━━━━━━━━━━━━━━━━',
  ].filter(Boolean).join('\n')
}
export async function sendBotCard(sock, jid, quoted) {
  try { cardBuf ??= fs.readFileSync(CARD_PATH) } catch { cardBuf = null }
  const caption = botCardText()
  const content = cardBuf ? { image: cardBuf, caption } : { text: caption }
  try {
    return await sock.sendMessage(jid, content, quoted ? { quoted } : undefined)
  } catch (err) {
    if (!quoted) throw err
    log(`⚠️ فشل إرسال البطاقة: ${err.message} — بجرب من غير اقتباس`)
    return sock.sendMessage(jid, content)
  }
}

export { textImage, logoImage, registry }
