// تحويل الاستيكر المتحرك (WebP متحرك) إلى فيديو MP4
// الخطوات: فك الإطارات (node-webpmux) ← تركيبها على كانفاس لو متاح (عشان الإطارات الجزئية) ← ffmpeg يجمعها بتوقيتاتها
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'

const sh = promisify(execFile)

export async function stickerToVideo(buf, { ffmpeg = 'ffmpeg', loadCanvas } = {}) {
  const { default: webp } = await import('node-webpmux')
  const img = new webp.Image()
  await img.load(buf)
  if (!img.hasAnim || !img.frames?.length) throw new Error('STATIC')
  const frames = img.frames
  const W = img.width || 512
  const H = img.height || 512
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 's2v-'))
  try {
    await img.demux({ path: work, prefix: 'f' })
    const files = []
    const durs = frames.map((f) => Math.min(Math.max(f.delay || 80, 20), 1000) / 1000)

    let canvas = null
    try { canvas = loadCanvas ? await loadCanvas() : null } catch {}
    if (canvas) {
      // تركيب الإطارات: بعض الاستيكرات بتخزّن الفرق بس (x,y,blend,dispose)
      const { createCanvas, loadImage } = canvas
      const cv = createCanvas(W, H), ctx = cv.getContext('2d')
      const outCv = createCanvas(W, H), octx = outCv.getContext('2d')
      let prev = null
      for (let i = 0; i < frames.length; i++) {
        const fr = frames[i]
        if (prev?.dispose) ctx.clearRect(prev.x, prev.y, prev.w, prev.h)
        const im = await loadImage(fs.readFileSync(path.join(work, `f_${i}.webp`)))
        const x = fr.x ?? 0, y = fr.y ?? 0
        if (fr.blend === false) ctx.clearRect(x, y, im.width, im.height)
        ctx.drawImage(im, x, y)
        octx.fillStyle = '#ffffff'
        octx.fillRect(0, 0, W, H)
        octx.drawImage(cv, 0, 0)
        const p = path.join(work, `c_${i}.png`)
        fs.writeFileSync(p, outCv.toBuffer('image/png'))
        files.push(p)
        prev = { x, y, w: im.width, h: im.height, dispose: !!fr.dispose }
      }
    } else {
      for (let i = 0; i < frames.length; i++) files.push(path.join(work, `f_${i}.webp`))
    }

    const list = path.join(work, 'list.txt')
    const lines = ['ffconcat version 1.0']
    files.forEach((f, i) => { lines.push(`file '${path.basename(f)}'`, `duration ${durs[i].toFixed(3)}`) })
    lines.push(`file '${path.basename(files[files.length - 1])}'`) // سطر أخير بدون مدة (شرط في concat)
    fs.writeFileSync(list, lines.join('\n'))

    const out = path.join(work, 'out.mp4')
    // نلصق الإطارات على خلفية بيضا (الشفاف كان بيطلع أسود في الفيديو)
    const fc = `[0:v]scale=${W}:${H}:force_original_aspect_ratio=decrease,format=rgba[fg];[1:v][fg]overlay=(W-w)/2:(H-h)/2:shortest=1,fps=25,scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p`
    const base = ['-y', '-f', 'concat', '-safe', '0', '-i', list, '-f', 'lavfi', '-i', `color=c=white:s=${W}x${H}:r=25`, '-filter_complex', fc, '-an']
    try {
      await sh(ffmpeg, [...base, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '27', '-movflags', '+faststart', out], { timeout: 90_000, windowsHide: true })
    } catch (err) {
      if (err.code === 'ENOENT') throw err
      await sh(ffmpeg, [...base, '-c:v', 'mpeg4', '-q:v', '5', '-movflags', '+faststart', out], { timeout: 90_000, windowsHide: true })
    }
    return fs.readFileSync(out)
  } finally {
    fs.rmSync(work, { recursive: true, force: true })
  }
}
