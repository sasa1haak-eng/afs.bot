import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { T, bar } from './ui.js'

// كل المسارات تصبح مرتبطة بمجلد المشروع، حتى لو شُغّل البوت من systemd أو PM2
export const ROOT_DIR = path.dirname(fileURLToPath(import.meta.url))
// مجلد البيانات (الجلسات/db/.env/الإضافات). الافتراضي = مجلد المشروع؛ في تطبيق أندرويد بيتحدد WA_STATE_DIR عشان تحديث الكود ما يمسحش البيانات
export const STATE_DIR = path.resolve(process.env.WA_STATE_DIR || ROOT_DIR)
const loadEnv = () => {
  for (const dir of new Set([STATE_DIR, ROOT_DIR])) {
    try {
      for (const line of fs.readFileSync(path.join(dir, '.env'), 'utf8').split(/\r?\n/)) {
        const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/)
        if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/\s+#.*$/, '').replace(/^['"]|['"]$/g, '')
      }
    } catch {}
  }
}
loadEnv()
const env = (k, fallback) => process.env[k] ?? fallback
const boolEnv = (k, fallback) => ['1', 'true', 'yes', 'on'].includes(String(env(k, fallback)).toLowerCase())
const numEnv = (k, fallback, min = 0) => {
  const n = Number(env(k, fallback))
  return Number.isFinite(n) && n >= min ? n : fallback
}

// ═══════════════ الإعدادات ═══════════════
export const CONFIG = {
  NUMBER: env('BOT_NUMBER', ''), // رقمك بدون + (الأفضل وضعه في .env)
  PREFIX: env('BOT_PREFIX', '.'),
  BOT_NAME: env('BOT_NAME', 'CYBER·GUARD'),
  PUBLIC_COMMANDS: boolEnv('PUBLIC_COMMANDS', true),
  FFMPEG: env('FFMPEG_BIN', 'ffmpeg'),
  MAX_MB: numEnv('MAX_DOWNLOAD_MB', 50, 1),
  AI_MODEL: env('ANTHROPIC_MODEL', 'claude-haiku-5-5'),
  AI_MOD_PER_MIN: numEnv('AI_MOD_PER_MIN', 8, 1),
  AI_MOD_PER_DAY: numEnv('AI_MOD_PER_DAY', 700, 1),
  AI_PAUSE_MIN: numEnv('AI_PAUSE_MIN', 30, 0),
  AI_REPLY_PER_DAY: numEnv('AI_REPLY_PER_DAY', 20, 1),
  ALLOW_INSTALL: boolEnv('ALLOW_INSTALL', true),
  MAX_SUBBOTS: numEnv('MAX_SUBBOTS', 5, 0),
  NSFW_THRESHOLD: Math.min(1, Math.max(0.1, numEnv('NSFW_THRESHOLD', 0.6, 0.1))),
  DEV_NAME: env('DEV_NAME', 'SASA HACK'), // اسم المطور في بطاقة البوت
  DEV_LINK: env('DEV_LINK', ''), // رابط إضافي (قناة/حساب) اختياري
  CARD_COOLDOWN_S: numEnv('CARD_COOLDOWN_S', 20, 0), // أقل فاصل بين بطاقات التعريف في نفس الشات
  QURAN_DEFAULT: env('QURAN_RECITER', 'ماهر المعيقلي'), // القارئ الافتراضي لأمر سورة
  CITY: env('BOT_CITY', 'Cairo'), // مدينة مواقيت الصلاة الافتراضية
  COUNTRY: env('BOT_COUNTRY', 'Egypt'),
  TZ: env('BOT_TZ', 'Africa/Cairo'),
  PRAYER_METHOD: numEnv('PRAYER_METHOD', 5, 0), // 5 = الهيئة المصرية
  DEFAULT: {
    antilink: true, // مسح الروابط
    exemptAdmins: false, // false = يمسح من الكل حتى الأدمنز
    warnLimit: 0, // 0 = مسح فقط | رقم = طرد بعد العدد ده من الإنذارات
    whitelist: [], // مواقع مسموحة
    antisticker: false, // مضاد الملصقات الخادشة
    antiimage: false, // مضاد الصور الخادشة
    antiprofanity: false, // مضاد الكلمات البذيئة
    antiflood: false, // مضاد التكرار
    antibot: false, // مضاد البوتات
    antibotStrict: false, // وضع صارم (حساسية أعلى)
    botBan: {}, // أرقام البوتات المحظورة (ممنوعة من الرجوع)
    botAllow: [], // بوتات مسموحة (استثناء)
    aimod: false, // المراقبة الذكية للكلام (Claude)
    chat: true, // دردشة 'بوت + كلامك' بالذكاء المحلي
    botcall: true, // كلمة 'بوت' ترسل بطاقة التعريف
    levels: false, // رسالة عند رفع المستوى
    goodbye: false,
    goodbyeText: '',
    rules: '',
    notes: {},
    welcome: false, // الترحيب
    welcomeText: '',
    badwords: [], // كلمات ممنوعة إضافية
    muted: {}, // المكتومين
  },
}

// ═══════════════ قاعدة البيانات ═══════════════
const DB_FILE = path.resolve(env('DB_FILE', path.join(STATE_DIR, 'db.json')))
export const db = { groups: {}, marriages: {}, banned: {}, ai: {}, stats: { deleted: 0, kicked: 0 } }
export const DB_PATH = DB_FILE
// تحميل آمن: لو db.json فاسد منرجعش نبدأ من الصفر ونمسحه بالحفظ الجاي؛ بننقله ونحمّل آخر نسخة سليمة (db.json.bak)
try {
  Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')))
} catch (e) {
  if (fs.existsSync(DB_FILE)) {
    const bad = `${DB_FILE}.corrupt-${Date.now()}`
    try { fs.renameSync(DB_FILE, bad) } catch {}
    console.log(`⚠️ ملف البيانات فاسد (${e.message}) — اتنقل إلى ${path.basename(bad)}`)
    try { Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE + '.bak', 'utf8'))); console.log('♻️ اتحمّلت آخر نسخة سليمة (db.json.bak)') } catch { console.log('⚠️ مفيش نسخة سليمة، بداية من الصفر') }
  }
}
// القيم الافتراضية (بتتنادى عند التحميل وبعد الاستعادة من نسخة احتياطية)
export function ensureDb() {
  db.groups ??= {}
  db.marriages ??= {}
  db.banned ??= {}
  db.ai ??= {}
  db.devs ??= {}
  db.seen ??= {}
  db.quran ??= {}
  db.eco ??= {}
  db.xp ??= {}
  db.modlog ??= {}
  db.plugins ??= {}
  db.brain ??= { taught: [], learned: [], autolearn: false }
  db.brain.taught ??= []
  db.brain.learned ??= []
  db.stats ??= { deleted: 0, kicked: 0 }
}
ensureDb()

let saveTimer
let lastBak = 0
export const save = () => {
  clearTimeout(saveTimer)
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(path.dirname(DB_FILE), { recursive: true })
      if (Date.now() - lastBak > 600_000 && fs.existsSync(DB_FILE)) { try { fs.copyFileSync(DB_FILE, DB_FILE + '.bak'); lastBak = Date.now() } catch {} } // لقطة سليمة كل 10 دقايق
      fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db, null, 2), { mode: 0o600 })
      fs.renameSync(DB_FILE + '.tmp', DB_FILE)
    } catch (e) {
      console.log('خطأ حفظ:', e.message)
    }
  }, 500)
}

export const gset = (jid) => {
  const g = (db.groups[jid] ??= {})
  for (const [k, v] of Object.entries(CONFIG.DEFAULT)) g[k] ??= structuredClone(v)
  g.warnings ??= {}
  return g
}

// ═══════════════ أدوات مساعدة ═══════════════
export const clean = (j = '') => j.replace(/:\d+@/, '@')
export const log = (...a) => console.log(new Date().toLocaleTimeString('ar-EG'), ...a)
export const startedAt = Date.now()

export function uptime() {
  const s = Math.floor((Date.now() - startedAt) / 1000)
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  return `${d}ي ${h}س ${m}د`
}

const metaCache = new Map()
export const invalidateMeta = (jid) => metaCache.delete(jid)
export async function getMeta(sock, jid) {
  const c = metaCache.get(jid)
  if (c && Date.now() - c.t < 300_000) return c.meta
  const meta = await sock.groupMetadata(jid)
  metaCache.set(jid, { meta, t: Date.now() })
  return meta
}

export const isAdmin = (meta, jid) => {
  const j = clean(jid || '')
  return meta.participants.some(
    (p) =>
      p.admin &&
      [p.id, p.lid, p.phoneNumber].filter(Boolean).map(clean).includes(j)
  )
}

export const botJids = (sock) =>
  [sock.user?.id, sock.user?.lid].filter(Boolean).map(clean)

export const botIsAdmin = (sock, meta) =>
  botJids(sock).some((j) => isAdmin(meta, j))

// ═══════════════ كاش الرسائل (للتنضيف وطرد2) ═══════════════
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const rec = new Map()
export function recordMsg(jid, key, sender) {
  const a = rec.get(jid) ?? []
  if (a.some((x) => x.key.id === key.id)) return // نفس الرسالة من جلسة تانية
  a.push({ key, sender: clean(sender || ''), t: Date.now() })
  if (a.length > 400) a.shift()
  rec.set(jid, a)
}
export const recent = (jid) => rec.get(jid) ?? []
export function forget(jid, ids) {
  const set = new Set(ids)
  rec.set(jid, recent(jid).filter((x) => !set.has(x.key.id)))
}

export async function deleteKeys(sock, keys, delay = 350) {
  let n = 0
  for (const k of keys) {
    try {
      await sock.sendMessage(k.remoteJid, { delete: k })
      n++
    } catch {}
    if (delay) await sleep(delay)
  }
  return n
}

// إنذار: لو وصل الحد يتطرد (الأدمنز مبيتطردوش)
// سجل عمليات الإشراف (آخر 40 عملية لكل جروب)
export function modlog(jid, text) {
  const a = (db.modlog[jid] ??= [])
  a.push({ t: Date.now(), text: String(text).slice(0, 160) })
  if (a.length > 40) a.shift()
}

export async function warnUser(sock, jid, g, sender, meta, line, limit) {
  limit = limit || g.warnLimit || 3
  const id = clean(sender)
  const tag = '@' + id.split('@')[0]
  g.warnings[id] = (g.warnings[id] || 0) + 1
  const n = g.warnings[id]
  modlog(jid, `${tag}: ${String(line).replace(/^⚠️\s*/, '')} (${n}/${limit})`)
  if (n >= limit) {
    delete g.warnings[id]
    save()
    if (isAdmin(meta, sender)) {
      await sock.sendMessage(jid, {
        text: `${T.warn} ${tag} وصل الحد الأقصى للإنذارات (أدمن، مش هيتطرد).`,
        mentions: [sender],
      })
      return 'admin'
    }
    await sock.groupParticipantsUpdate(jid, [sender], 'remove')
    db.stats.kicked++
    await sock.sendMessage(jid, {
      text: `${T.ban} تم طرد ${tag}\n┃ ▸ السبب: استنفد ${limit} إنذارات`,
      mentions: [sender],
    })
    return 'kicked'
  }
  save()
  await sock.sendMessage(jid, {
    text: `${T.warn} ${String(line).replace(/^⚠️\s*/, '')}\n┃ ▸ المستخدم: ${tag}\n┃ ▸ الإنذارات: [${bar(n, limit, Math.min(limit, 10))}] ${n}/${limit}`,
    mentions: [sender],
  })
  return 'warned'
}
