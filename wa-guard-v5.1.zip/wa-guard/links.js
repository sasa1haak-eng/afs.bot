// ═══════════════ كشف الروابط ═══════════════
const TLDS = new Set(
  ('com net org io me app xyz info ly gl co tv cc link site online gg to tk ml ga cf gq top club vip shop store live pro dev ai us uk eg sa ae kr ru de fr in biz cloud page click fun icu cyou sbs lol one ws sh is it ac id ir tr ps cn jp br es nl pl ua be ch se no fi dk cz ro gr pt mx ar ca au nz za ng ke pk bd iq jo lb kw qa om bh ye sy ma dz tn sd').split(' ')
)
const URL_RE = /\b(?:https?|ftp):\/\/\S+/gi
const DOMAIN_RE = /((?:[a-z0-9-]+\.)+[a-z]{2,24})(?::\d+)?(?:[\/?#]\S*)?/gi

const normalizeText = (s) =>
  s
    .normalize('NFKC')
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, '')
    .replace(/\[\s*\.\s*\]|\(\s*\.\s*\)|\s*\(dot\)\s*/gi, '.')

export function findLinks(raw) {
  const t = normalizeText(raw)
  const hits = []
  for (const m of t.matchAll(URL_RE)) {
    try {
      hits.push(new URL(m[0]).hostname.toLowerCase())
    } catch {
      hits.push(m[0].toLowerCase())
    }
  }
  for (const m of t.matchAll(DOMAIN_RE)) {
    if (t[m.index - 1] === '@') continue // إيميل
    const host = m[1].toLowerCase()
    if (TLDS.has(host.split('.').pop()) || host.startsWith('www.')) hits.push(host)
  }
  return hits
}
