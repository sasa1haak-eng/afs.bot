// ═══════════ 4.8 — أدوات وخدمات تقنية (كلها محلية بدون إنترنت أو ذكاء اصطناعي) ═══════════
import { nm } from './core/names.js'
import * as X from './core/tools.js'

export function register(c) {
  const { cmd, P, T, panel, kv, quotedText, norm } = c
  const SEC = 'tools5'
  const O = { sec: SEC }
  const text = (e, args) => (args.trim() || quotedText(e.ctx) || '').trim()
  const nums = (args) => (args.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).match(/-?\d+(?:\.\d+)?/g) || []).map(Number)
  const need = (e, s, usage) => { if (!s) { e.reply(`${T.info} ${usage}`); return false } return true }
  const f = (n) => (Number.isInteger(n) ? n.toLocaleString('en-US') : +n.toFixed(4)).toString()

  cmd(['هاش'], 'all', (e, args) => {
    const m = args.trim().match(/^(md5|sha1|sha256|sha512)\s+([\s\S]+)$/i)
    const [algo, t] = m ? [m[1].toLowerCase(), m[2]] : ['sha256', text(e, args)]
    if (!need(e, t, `اكتب: ${P}هاش [md5|sha1|sha256|sha512] النص`)) return
    return e.reply(`🔐 ${algo.toUpperCase()}:\n${X.hash(algo, t)}`)
  }, { ...O, d: 'بصمة هاش للنص (MD5/SHA)', u: 'هاش sha256 نص' })
  cmd(nm('ترميز hex'), 'all', (e, args) => { const t = text(e, args); if (need(e, t, `اكتب: ${P}ترميز hex النص`)) return e.reply(X.hexEnc(t)) }, O)
  cmd(nm('فك hex'), 'all', (e, args) => { const t = text(e, args); if (!need(e, t, `اكتب: ${P}فك hex 48 65 6c`)) return; try { return e.reply(X.hexDec(t)) } catch (er) { return e.reply(`${T.err} ${er.message}`) } }, O)
  cmd(nm('ارقام انجليزية'), 'all', (e, args) => { const t = text(e, args); if (need(e, t, `اكتب: ${P}ارقام انجليزية ٢٠٢٦`)) return e.reply(X.toWestern(t)) }, O)
  cmd(nm('رقم الى كلمات'), 'all', (e, args) => {
    const n = nums(args)[0]
    if (n === undefined) return e.reply(`${T.info} اكتب: ${P}رقم الى كلمات 1250`)
    try { return e.reply(`🔢 ${f(n)} = *${X.numToWords(n)}*`) } catch (er) { return e.reply(`${T.err} ${er.message}`) }
  }, O)

  // ── التواريخ ──
  const today = () => { const n = new Date(); return new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate())) }
  cmd(['هجري'], 'all', (e, args) => {
    const a = args.trim()
    try {
      if (!a) { const h = X.toHijri(new Date()); return e.reply(`🌙 ${h.text}\n📅 ${X.iso(today())} (${X.dayName(today())})`) }
      const m = a.match(/^(\d{3,4})[-/](\d{1,2})[-/](\d{1,2})$/)
      if (!m) return e.reply(`${T.info} اكتب: ${P}هجري (النهارده) | ${P}هجري 1447-09-01 (هجري ← ميلادي) | ${P}هجري 2026-03-01 (ميلادي ← هجري)`)
      const y = +m[1]
      if (y < 1700) { const g = X.fromHijri(y, +m[2], +m[3]); return e.reply(`🌙 ${a} هـ ← 📅 ${X.iso(g)} (${X.dayName(g)})`) }
      const g = X.parseDate(a), h = X.toHijri(new Date(g.getUTCFullYear(), g.getUTCMonth(), g.getUTCDate()))
      return e.reply(`📅 ${a} ← 🌙 ${h.text}`)
    } catch (er) { return e.reply(`${T.err} ${er.message}`) }
  }, { ...O, d: 'التاريخ الهجري والتحويل بين الهجري والميلادي', u: 'هجري' })
  cmd(['عمري'], 'all', (e, args) => {
    try {
      const b = X.parseDate(args), a = X.age(b, today())
      if (b > today()) return e.reply(`${T.err} تاريخ الميلاد في المستقبل.`)
      return e.reply(panel('🎂 AGE', [kv('العمر', `${a.y} سنة و${a.m} شهر و${a.d} يوم`), kv('عدد الأيام', a.totalDays.toLocaleString('en-US')), kv('عيد ميلادك الجاي بعد', `${a.nextBirthday} يوم`)]))
    } catch (er) { return e.reply(`${T.err} ${er.message}\n${P}عمري 2000-05-17`) }
  }, O)
  cmd(nm('فرق تاريخين'), 'all', (e, args) => {
    const m = args.trim().split(/\s+/)
    try {
      const a = X.parseDate(m[0] || ''), b = X.parseDate(m[1] || '')
      const d = X.daysBetween(a, b)
      return e.reply(`📆 الفرق: *${Math.abs(d)} يوم* (≈ ${(Math.abs(d) / 7).toFixed(1)} أسبوع، ${(Math.abs(d) / 30.4375).toFixed(1)} شهر)${d < 0 ? ' — التاريخ الأول بعد التاني' : ''}`)
    } catch (er) { return e.reply(`${T.err} ${er.message}\n${P}فرق تاريخين 2026-01-01 2026-12-31`) }
  }, O)
  cmd(nm('بعد ايام'), 'all', (e, args) => {
    const n = nums(args)[0]
    if (n === undefined || Math.abs(n) > 100000) return e.reply(`${T.info} اكتب: ${P}بعد ايام 90 (أو سالب للماضي)`)
    const d = X.addDays(today(), n)
    return e.reply(`📅 بعد ${n} يوم: *${X.iso(d)}* (${X.dayName(d)})\n🌙 ${X.toHijri(new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())).text}`)
  }, O)
  cmd(nm('العد التنازلي'), 'all', (e, args) => {
    try {
      const t = X.parseDate(args), d = X.daysBetween(today(), t)
      return e.reply(d >= 0 ? `⏳ باقي *${d} يوم* على ${X.iso(t)} (${X.dayName(t)})` : `⌛ فات على ${X.iso(t)} حوالي ${-d} يوم`)
    } catch (er) { return e.reply(`${T.err} ${er.message}\n${P}العد التنازلي 2026-12-31`) }
  }, O)
  cmd(nm('باقي على رمضان'), 'all', (e) => {
    const h = X.toHijri(new Date())
    let target = X.fromHijri(h.y, 9, 1)
    if (target < today()) target = X.fromHijri(h.y + 1, 9, 1)
    const d = X.daysBetween(today(), target)
    return e.reply(d === 0 ? '🌙 النهارده أول يوم رمضان، رمضان كريم!' : `🌙 باقي *${d} يوم* على رمضان (تقريباً ${X.iso(target)} — حسب تقويم أم القرى، والرؤية الفعلية قد تختلف يوم)`)
  }, O)
  cmd(['تقويم'], 'all', (e, args) => {
    const n = nums(args), now = new Date()
    const month = n[0] || now.getMonth() + 1, year = n[1] || now.getFullYear()
    if (month < 1 || month > 12 || year < 1600 || year > 3000) return e.reply(`${T.info} اكتب: ${P}تقويم 5 2026`)
    const names = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    return e.reply(`📅 *${names[month - 1]} ${year}*\n\`\`\`\n${X.calendar(year, month)}\n\`\`\``)
  }, O)

  // ── أعداد وحسابات ──
  cmd(nm('تحويل وحدة'), 'all', (e, args) => {
    const m = args.trim().match(/^(-?[\d.٠-٩]+)\s*(\S+)\s+(?:الى|إلى|to|->|=)\s*(\S+)$/i)
    if (!m) return e.reply(`${T.info} اكتب: ${P}تحويل وحدة 10 كم الى ميل\n▸ الوحدات: ${X.unitList().slice(0, 28).join('، ')}`)
    try { const v = +X.toWestern(m[1]), r = X.convertUnits(v, m[2], m[3]); return e.reply(`🔁 ${f(v)} ${m[2]} = *${f(r)} ${m[3]}*`) } catch (er) { return e.reply(`${T.err} ${er.message}`) }
  }, O)
  cmd(nm('تحليل عدد'), 'all', (e, args) => {
    const n = nums(args)[0]
    if (n === undefined) return e.reply(`${T.info} اكتب: ${P}تحليل عدد 360`)
    try {
      const r = X.factorize(n)
      const fx = Object.entries(r.factors).map(([p, k]) => (k > 1 ? `${p}^${k}` : p)).join(' × ')
      return e.reply(panel('🔬 NUMBER', [kv('العدد', f(n)), kv('أولي؟', r.prime ? 'نعم ✅' : 'لا'), kv('التحليل', fx), kv('عدد القواسم', r.divisors)]))
    } catch (er) { return e.reply(`${T.err} ${er.message}`) }
  }, O)
  const list = (args, min = 2) => nums(args).filter((x) => Number.isInteger(x) && x !== 0).slice(0, 30)
  cmd(nm('قاسم مشترك'), 'all', (e, args) => { const l = list(args); if (l.length < 2) return e.reply(`${T.info} اكتب: ${P}قاسم مشترك 48 36 60`); return e.reply(`🧮 القاسم المشترك الأكبر (ق.م.أ): *${X.gcdAll(l)}*`) }, O)
  cmd(nm('مضاعف مشترك'), 'all', (e, args) => { const l = list(args); if (l.length < 2) return e.reply(`${T.info} اكتب: ${P}مضاعف مشترك 4 6 10`); const r = X.lcmAll(l.map(Math.abs)); return e.reply(Number.isSafeInteger(r) ? `🧮 المضاعف المشترك الأصغر (م.م.أ): *${r}*` : `${T.err} الناتج أكبر من المسموح`) }, O)
  cmd(['احصاء'], 'all', (e, args) => {
    const l = nums(args).slice(0, 500)
    if (l.length < 2) return e.reply(`${T.info} اكتب: ${P}احصاء 4 8 15 16 23 42`)
    const s = X.stats(l)
    return e.reply(panel('📈 STATS', [kv('العدد', s.n), kv('المجموع', f(s.sum)), kv('المتوسط', f(s.mean)), kv('الوسيط', f(s.median)), kv('المنوال', s.mode.length ? s.mode.join('، ') : 'لا يوجد'), kv('أصغر / أكبر', `${f(s.min)} / ${f(s.max)}`), kv('المدى', f(s.range)), kv('الانحراف المعياري', `${f(s.sd)} (عينة: ${f(s.sdSample)})`)]))
  }, O)
  cmd(nm('حساب الزكاة'), 'all', (e, args) => {
    const n = nums(args)[0]
    if (n === undefined || n < 0) return e.reply(`${T.info} اكتب: ${P}حساب الزكاة 100000 (قيمة المال الذي مرّ عليه الحول)`)
    return e.reply(panel('🕌 ZAKAT', [kv('المال', f(n)), kv('الزكاة 2.5%', f(n * 0.025)), '', 'ℹ️ تجب بشرط بلوغ النصاب (ما يعادل 85 جرام ذهب عيار 24 أو 595 جرام فضة) ومرور حول هجري كامل.', 'تأكد من سعر الذهب الحالي، واسأل أهل العلم في الحالات الخاصة.']))
  }, O)

  // ── مراجع تقنية ──
  cmd(nm('رمز استجابة'), 'all', (e, args) => {
    const n = nums(args)[0]
    if (n === undefined) return e.reply(`${T.info} اكتب: ${P}رمز استجابة 404`)
    return e.reply(X.HTTP[n] ? `🌐 HTTP ${n}: *${X.HTTP[n]}*` : `${T.info} الرمز ${n} مش في الجدول (المتاح: ${Object.keys(X.HTTP).join('، ')})`)
  }, O)
  cmd(['منفذ'], 'all', (e, args) => {
    const a = args.trim()
    if (!a) return e.reply(`${T.info} اكتب: ${P}منفذ 443 أو ${P}منفذ ssh`)
    if (/^\d+$/.test(a)) return e.reply(X.PORTS[a] ? `🔌 المنفذ ${a}: *${X.PORTS[a]}*` : `${T.info} المنفذ ${a} مش في الجدول.`)
    const r = X.portByName(a)
    return e.reply(r.length ? `🔌 ${r.join('\n🔌 ')}` : `${T.info} ما لقيتش خدمة بالاسم ده.`)
  }, O)
  cmd(nm('معلومات الرابط'), 'all', (e, args) => {
    const s = text(e, args)
    if (!need(e, s, `اكتب: ${P}معلومات الرابط https://example.com/a?x=1`)) return
    try {
      const u = X.parseUrl(s.split(/\s+/)[0])
      return e.reply(panel('🔗 URL', [kv('البروتوكول', u.protocol), kv('الدومين', u.host), u.port && kv('المنفذ', u.port), kv('المسار', u.path), ...(u.query.length ? [kv('الباراميترات', u.query.join(' · '))] : []), u.hash && kv('الجزء #', u.hash), u.user && '⚠️ فيه اسم مستخدم في الرابط (مشبوه)'].filter(Boolean)))
    } catch { return e.reply(`${T.err} الرابط غير صالح.`) }
  }, O)
  cmd(nm('معلومات الملف'), 'all', (e) => {
    const info = X.fileInfo(e.ctx?.quotedMessage) || X.fileInfo(e.content)
    if (!info) return e.reply(`${T.info} ردّ على صورة/فيديو/ملف/صوت/استيكر واكتب ${P}معلومات الملف`)
    return e.reply(panel('📎 FILE INFO', Object.entries(info).map(([k, v]) => kv(k.replace(/_/g, ' '), v))))
  }, O)
  cmd(['تلخيص'], 'all', (e, args) => {
    const t = text(e, args)
    if (t.length < 200) return e.reply(`${T.info} ردّ على نص طويل (200 حرف على الأقل) واكتب ${P}تلخيص [عدد الجمل].`)
    const n = Math.min(Math.max(parseInt(args) || 3, 1), 8)
    const s = X.summarize(t, n)
    return e.reply(`📝 *ملخص (${n} جمل من ${t.length} حرف — استخراجي بدون ذكاء اصطناعي):*\n${s}`)
  }, O)
  cmd(nm('قوة كلمة السر'), 'all', (e, args) => {
    const pw = args.trim()
    if (!pw) return e.reply(`${T.info} اكتب: ${P}قوة كلمة السر Abc@1234\n⚠️ لا تكتب كلمة سر حقيقية في جروب. جرّب نمط شبيه بكلمتك.`)
    const r = X.passwordStrength(pw)
    return e.reply(panel('🔐 PASSWORD', [kv('القوة', `${r.level} (${r.bits} بت)`), ...(r.issues.length ? ['', ...r.issues.map((x) => `▸ ${x}`)] : ['✨ مفيش ملاحظات'])]))
  }, O)
}
