// ═══════════ 4.8 — المطور والنظام ═══════════
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { createRequire } from 'node:module'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { nm, digitsOf, cairo, ago } from './core/names.js'
import { snapshot, verdict, fmtDur, mb, startedAt } from './core/health.js'
import { events, counts, logFileBytes, TYPE_AR, sec } from './core/seclog.js'
import { listBackups, keyReady, BACKUP_DIR } from './core/backup.js'
import { loaded as pluginsLoaded } from './core/plugins.js'
import { STATE_DIR } from './lib.js'
import { user } from './eco.js'
import { listSubs, mainNumber } from './sessions.js'

const sh = promisify(execFile)
const req = createRequire(import.meta.url)

export function register(c) {
  const { cmd, P, T, CONFIG, panel, kv, getTarget, db, save, registry, duplicates, norm } = c
  const SEC = 'dev5'
  const OWN = { global: true, sec: SEC, dm: true }
  const confirmed = (a) => /(^|\s)(تاكيد|تأكيد|confirm|yes)(\s|$)/i.test(norm(a))
  const big = (n) => (Math.abs(n) >= 1e12 ? n.toExponential(2) : Math.round(n).toLocaleString('en-US'))
  const lockState = () => { try { const l = JSON.parse(fs.readFileSync(path.join(STATE_DIR, 'lockdown.json'), 'utf8')); return l.locked ? '🔒 متوقف' : '🔓 شغال' } catch { return 'غير مركّب' } }

  cmd(nm('لوحة المطور'), 'owner', (e) => {
    const s = snapshot(), v = verdict(s), h = Date.now() - 3600_000, d = Date.now() - 86400_000
    const subs = listSubs(), inc = Object.entries(counts({ since: d })).filter(([t]) => t !== 'error').reduce((a, [, n]) => a + n, 0)
    const bk = listBackups(), plug = pluginsLoaded
    return e.reply(panel('🧑‍💻 DEV DASHBOARD', [
      kv('الحالة', v.level === 'ok' ? '🟢 سليمة' : v.level === 'warn' ? '🟡 تنبيه' : '🔴 مشاكل'), ...v.issues.map((x) => `   ⚠️ ${x}`),
      kv('وقت التشغيل', fmtDur(s.uptimeMs)), kv('الذاكرة', mb(s.rss)), kv('تأخر الحلقة', `${s.lagMax}ms`),
      kv('الجروبات / الحسابات', `${s.groups} / ${s.users}`), kv('بوتات فرعية', subs.length), kv('المطورين', Object.keys(db.devs).length),
      kv('الأوامر', `${registry.length} (${registry.reduce((a, r) => a + r.names.length, 0)} اسم)`), kv('إضافات', `${plug.filter((x) => x.status === 'loaded').length}/${plug.length}`),
      kv('أخطاء آخر ساعة', counts({ since: h }).error || 0), kv('حوادث أمنية 24س', inc), kv('وضع الإيقاف', lockState()),
      kv('نسخ احتياطية', `${bk.length}${bk[0] ? ' (آخرها ' + ago(bk[0].mtime) + ')' : ''}${keyReady() ? '' : ' ⚠️ BACKUP_KEY ناقص'}`),
    ], `${P}حالة النظام · ${P}تشخيص · ${P}السجلات`))
  }, OWN)

  cmd(nm('حالة النظام'), 'owner', (e) => {
    const s = snapshot(), v = verdict(s)
    return e.reply(panel('🖥️ SYSTEM', [
      kv('الذاكرة (RSS)', mb(s.rss)), kv('Heap', `${mb(s.heapUsed)} / ${mb(s.heapTotal)}`), kv('ذاكرة الجهاز', `${mb(s.freeMem)} فاضية من ${mb(s.totalMem)}`),
      kv('الحمل (CPU load)', `${s.load.toFixed(2)} على ${s.cores} نواة`), kv('تأخر حلقة الأحداث', `${s.lagNow}ms (أقصى ${s.lagMax}ms)`),
      kv('Node / النظام', `${s.node} · ${s.platform}${s.termux ? ' · Termux' : ''}`), kv('ملف البيانات', mb(s.dbBytes)), kv('سجل الأمان', `${(logFileBytes() / 1024).toFixed(0)} KB`),
      '', v.issues.length ? v.issues.map((x) => `⚠️ ${x}`).join('\n') : '✅ مفيش مشاكل ظاهرة',
    ]))
  }, OWN)

  cmd(nm('وقت التشغيل'), 'owner', (e) => e.reply(`⏱️ البوت شغال من *${fmtDur(Date.now() - startedAt)}*\n🚀 بدأ: ${cairo(startedAt)}`), OWN)

  cmd(['السجلات'], 'owner', (e) => {
    const l = events({ type: 'error', limit: 10 })
    if (!l.length) return e.reply(`${T.ok} مفيش أخطاء مسجّلة.`)
    return e.reply(panel('⚠️ ERROR LOG', l.map((x) => `${cairo(x.t)} · ${x.where} · ${x.msg.slice(0, 60)}`), `الأخطاء الكاملة في data/security.log`))
  }, OWN)

  cmd(['تشخيص'], 'owner', async (e) => {
    const rows = []
    const add = (ok, label, fix) => rows.push(`${ok ? '✅' : '❌'} ${label}${!ok && fix ? `\n   ↳ ${fix}` : ''}`)
    add(parseInt(process.version.slice(1)) >= 18, `Node ${process.version}`, 'محتاج Node 18 أو أحدث')
    try { await sh(CONFIG.FFMPEG || 'ffmpeg', ['-version'], { timeout: 4000 }); add(true, 'ffmpeg') } catch { add(false, 'ffmpeg', 'pkg install ffmpeg (للاستيكرات والفيديو)') }
    for (const [mod, why] of [['node-webpmux', 'الاستيكرات المتحركة'], ['@napi-rs/canvas', 'الصور المكتوبة'], ['@tensorflow/tfjs', 'كاشف الصور الخادشة'], ['nsfwjs', 'كاشف الصور الخادشة']]) {
      let ok = true; try { req.resolve(mod) } catch { ok = false }
      add(ok, `مكتبة ${mod}`, `npm install (${why})`)
    }
    try { const f = path.join(os.tmpdir(), `wa-diag-${Date.now()}`); fs.writeFileSync(f, 'x'); fs.rmSync(f); add(true, 'الكتابة على التخزين') } catch { add(false, 'الكتابة على التخزين', 'تأكد من صلاحيات المجلد') }
    add(keyReady(), 'BACKUP_KEY (النسخ المشفّرة)', 'ضيف BACKUP_KEY=كلمة_سر_قوية في .env')
    try { const ac = new AbortController(), t = setTimeout(() => ac.abort(), 4000); const r = await fetch('https://api.alquran.cloud/v1/meta', { method: 'HEAD', signal: ac.signal }); clearTimeout(t); add(r.ok, 'الاتصال بالإنترنت') } catch { add(false, 'الاتصال بالإنترنت', 'تأكد من النت (القرآن والترجمة والطقس بتحتاجه)') }
    add(duplicates.length === 0, `أسماء الأوامر (${duplicates.length} مكرر)`, `${P}الاوامر المكررة`)
    const perr = pluginsLoaded.filter((x) => x.status === 'error')
    add(perr.length === 0, `الإضافات (${pluginsLoaded.length})`, perr.map((x) => `${x.file}: ${x.error}`).join(' | '))
    add(CONFIG.PUBLIC_COMMANDS, 'الأوامر العامة للأعضاء (PUBLIC_COMMANDS)', 'لو الأعضاء مش بيستخدموا الأوامر: PUBLIC_COMMANDS=1 في .env')
    return e.reply(panel('🩺 DIAGNOSTICS', rows))
  }, OWN)

  // ── الإضافات ──
  cmd(['الاضافات'], 'owner', (e) => e.reply(pluginsLoaded.length ? panel('🔌 PLUGINS', pluginsLoaded.map((x) => `${x.status === 'loaded' ? '✅' : x.status === 'disabled' ? '⏸️' : '❌'} ${x.name} v${x.version} — ${x.status === 'error' ? x.error : x.status === 'disabled' ? 'معطّلة' : x.commands + ' أمر'}`), `ملفات الإضافات في plugins/ (شوف _example.js)`) : `${T.info} مفيش إضافات. انسخ plugins/_example.js باسم جديد.`), OWN)
  const plugToggle = (off) => (e, args) => {
    const name = args.trim(), p = pluginsLoaded.find((x) => x.name === name || x.file === name)
    if (!p) return e.reply(`${T.err} الإضافة مش موجودة. شوف ${P}الاضافات`)
    ;(db.plugins[p.name] ??= {}).disabled = off; save(); sec('perm', { actor: digitsOf(e.sender), what: `${off ? 'تعطيل' : 'تفعيل'} إضافة ${p.name}` })
    return e.reply(`${T.ok} الإضافة «${p.name}» ${off ? 'اتعطّلت' : 'اتفعّلت'} (يسري بعد إعادة التشغيل).`)
  }
  cmd(nm('تعطيل اضافة'), 'owner', plugToggle(true), OWN)
  cmd(nm('تفعيل اضافة'), 'owner', plugToggle(false), OWN)

  // ── الأوامر نفسها ──
  cmd(nm('الاوامر المكررة'), 'owner', (e) => e.reply(duplicates.length ? panel('♊ DUPLICATES', duplicates.slice(0, 15).map((d) => `«${d.name}»: ${d.first} ← ${d.second} (المهمل)`)) : `${T.ok} مفيش أي اسم أمر متكرر بين ${registry.length} أمر.`), OWN)
  cmd(nm('فهرس الاوامر'), 'owner', (e) => {
    const by = { owner: 0, admin: 0, all: 0 }, sec2 = {}
    for (const r of registry) { by[r.level] = (by[r.level] || 0) + 1; const k = r.opts.sec || '—'; sec2[k] = (sec2[k] || 0) + 1 }
    const top = Object.entries(sec2).sort((a, b) => b[1] - a[1]).slice(0, 10)
    return e.reply(panel('🗂️ COMMAND CATALOG', [kv('الأوامر', registry.length), kv('الأسماء (مع البدائل)', registry.reduce((a, r) => a + r.names.length, 0)), kv('للكل', by.all), kv('أدمن', by.admin), kv('مطور', by.owner), '', 'أكبر الأقسام:', ...top.map(([k, n]) => `▸ ${k}: ${n}`)]))
  }, OWN)
  cmd(nm('بحث امر'), 'all', (e, args) => {
    const q = norm(args.trim())
    if (!q) return e.reply(`${T.info} اكتب: ${P}بحث امر كلمة`)
    const hits = registry.filter((r) => r.level !== 'owner' && (r.names.some((n) => n.includes(q)) || norm(r.opts.d || '').includes(q))).slice(0, 12)
    return e.reply(hits.length ? panel('🔎 SEARCH', hits.map((r) => `${r.level === 'admin' ? '🛡️' : '👥'} ${P}${r.orig[0]}${r.opts.d ? ' — ' + r.opts.d : ''}`)) : `${T.info} مفيش أمر مطابق.`)
  }, { sec: SEC })

  // ── بث للجروبات (بتأكيد وبفاصل بين الرسايل) ──
  cmd(['بث'], 'owner', async (e, args) => {
    const msg = args.replace(/(^|\s)(تاكيد|تأكيد)(?=\s|$)/g, ' ').trim()
    if (!msg || msg.length > 800) return e.reply(`${T.info} اكتب: ${P}بث النص (حتى 800 حرف)`)
    const groups = Object.keys((await e.sock.groupFetchAllParticipating()) || {})
    if (!confirmed(args)) return e.reply(`📣 *معاينة البث*\n┃ ▸ هيتبعت لـ ${groups.length} جروب (بفاصل ${Math.round((+process.env.BROADCAST_GAP_MS || 3000) / 1000)} ث بين كل جروب)\n┃ ▸ النص:\n${msg}\n┃ ▸ البث الكتير ممكن يسبب حظر الرقم، استخدمه بحذر.\n┃ ▸ للتأكيد: ${P}بث ${msg} تأكيد`)
    await e.reply(`📣 بدأ البث على ${groups.length} جروب...`)
    let ok = 0, fail = 0
    for (const jid of groups) {
      try { await e.sock.sendMessage(jid, { text: `📣 ${msg}` }); ok++ } catch { fail++ }
      await new Promise((r) => setTimeout(r, +process.env.BROADCAST_GAP_MS || 3000))
    }
    sec('perm', { actor: digitsOf(e.sender), what: `بث لـ ${ok} جروب` })
    return e.reply(`${T.ok} انتهى البث: نجح ${ok} · فشل ${fail}`)
  }, OWN)

  // ── الاقتصاد (إدارة وفحص) ──
  const protectedIds = () => new Set([mainNumber(), ...Object.keys(db.devs)].filter(Boolean))
  const flagged = () => Object.entries(db.eco).filter(([id, u]) => !protectedIds().has(digitsOf(id)) && Math.max(u.wallet || 0, u.bank || 0) > 1e12)
  cmd(nm('خصم رصيد'), 'owner', (e, args) => {
    const t = getTarget(e, args), n = Number((args.replace(/@\S+/g, '').match(/\d+/g) || []).filter((x) => x.length < 9).pop()) // آخر رقم قصير = المبلغ (الأرقام الطويلة = رقم العضو)
    if (!t || !(n > 0)) return e.reply(`${T.info} اكتب: ${P}خصم رصيد @فلان 500`)
    const u = user(t), cut = Math.min(n, u.wallet)
    u.wallet -= cut; save(); sec('perm', { actor: digitsOf(e.sender), what: `خصم ${cut} من ${digitsOf(t)}` })
    return e.reply(`${T.ok} اتخصم ${cut.toLocaleString('en-US')} من @${digitsOf(t)} (رصيده الآن ${u.wallet.toLocaleString('en-US')})`, [t])
  }, OWN)
  cmd(nm('فحص الاقتصاد'), 'owner', (e) => {
    const bad = new Set(flagged().map(([id]) => id)), prot = protectedIds()
    const rows = Object.entries(db.eco).filter(([id]) => !bad.has(id) && !prot.has(digitsOf(id))).map(([id, u]) => [id, (u.wallet || 0) + (u.bank || 0)])
    const sum = rows.reduce((a, [, b]) => a + b, 0), sorted = rows.map((x) => x[1]).sort((a, b) => a - b)
    const med = sorted.length ? sorted[Math.floor(sorted.length / 2)] : 0
    const top = [...rows].sort((a, b) => b[1] - a[1]).slice(0, 5)
    return e.reply(panel('💹 ECONOMY AUDIT', [
      kv('الحسابات', rows.length), kv('إجمالي المتداول', big(sum)), kv('المتوسط / الوسيط', `${big(rows.length ? sum / rows.length : 0)} / ${big(med)}`),
      '', 'الأغنى:', ...top.map(([id, b], i) => `${i + 1}. ${digitsOf(id)} — ${big(b)}`), '',
      bad.size ? `🚨 ${bad.size} حساب أرصدته مشبوهة (>1 تريليون):\n${[...bad].slice(0, 8).map((id) => `▸ ${digitsOf(id)} — ${big(Math.max(db.eco[id].wallet, db.eco[id].bank))}`).join('\n')}\nللتنظيف: ${P}تنظيف الاقتصاد` : '✅ مفيش أرصدة مشبوهة',
    ]))
  }, OWN)
  cmd(nm('تنظيف الاقتصاد'), 'owner', (e, args) => {
    const bad = flagged()
    if (!bad.length) return e.reply(`${T.ok} مفيش أرصدة مشبوهة.`)
    if (!confirmed(args)) return e.reply(`⚠️ هيتصفّر رصيد ${bad.length} حساب (أكتر من تريليون، غالباً من ثغرة قديمة لمالكي البوتات الفرعية). حسابك وحسابات المطورين مستثناة.\nللتأكيد: ${P}تنظيف الاقتصاد تأكيد`)
    for (const [, u] of bad) { u.wallet = 0; u.bank = 0 }
    save(); sec('perm', { actor: digitsOf(e.sender), what: `تنظيف اقتصاد: ${bad.length} حساب` })
    return e.reply(`${T.ok} اتصفّر ${bad.length} حساب مشبوه.`)
  }, OWN)
}
