// جلب صورة الشخصية من AniList وفحصها بكاشف الصور الخادشة قبل الإرسال (لو الفحص فشل أو مش متاح: من غير صورة)
import { enqueue, classifyMedia } from './nsfw.js'

const API = 'https://graphql.anilist.co'
const QUERY = `query($s:String){Page(perPage:6){characters(search:$s){name{full alternative} image{large} media(perPage:5){nodes{title{romaji english}}}}}}`
const STOP = new Set(['the', 'and', 'no', 'wa', 'ga', 'ko', 'wo', 'of', 'to', 'more', 'extras'])
// عناوين مش بتمثل أنمي واحد: بنتحقق من الاسم بس
const UMBRELLA = /^(studio ghibli|world masterpiece theater|digimon|pokemon|yo-kai|lupin|gundam|alice|pinocchio|hamtaro|beyblade)/i

const alnum = (s = '') => s.toLowerCase().replace(/[^a-z0-9]/g, '')
const words = (s = '') => s.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length >= 3 && !STOP.has(w))

export function seriesOk(series, titles) {
  if (UMBRELLA.test(series)) return true
  const hay = titles.map(alnum).join('|')
  return series.split(' / ').some((alt) => {
    const t = words(alt.replace(/\((more|extras?)\)/gi, ''))
    if (!t.length) return false
    return t.filter((w) => hay.includes(alnum(w))).length >= Math.ceil(t.length / 2)
  })
}
export function nameOk(en, names) {
  const want = words(en)
  if (!want.length) return false
  const have = names.flatMap(words)
  const hit = want.filter((w) => have.some((h) => h === w || (w.length >= 4 && h.startsWith(w.slice(0, 4)))))
  return hit.length >= Math.ceil(want.length / 2)
}

const cache = new Map() // en → { buf, at } (بنخزّن الفشل كمان ساعة)
const TTL_FAIL = 3600_000
const timeout = (ms) => new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms).unref?.())

async function getJson(fetchFn, body, ms) {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), ms)
  try {
    const r = await fetchFn(API, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body), signal: ac.signal })
    if (!r.ok) return null
    return await r.json()
  } finally { clearTimeout(t) }
}
async function getBuf(fetchFn, url, ms) {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), ms)
  try {
    const r = await fetchFn(url, { signal: ac.signal })
    if (!r.ok || !/^image\//.test(r.headers.get('content-type') || '')) return null
    const buf = Buffer.from(await r.arrayBuffer())
    return buf.length > 0 && buf.length <= 4 * 1024 * 1024 ? buf : null
  } finally { clearTimeout(t) }
}

export async function characterImage(ch, { fetchFn = globalThis.fetch, classify = (b) => enqueue(() => classifyMedia(b, 'image', 0.5)) } = {}) {
  const hit = cache.get(ch.en)
  if (hit && (hit.buf || Date.now() - hit.at < TTL_FAIL)) return hit.buf
  let buf = null
  try {
    const terms = [ch.en, ch.en.split(' ').slice(0, 2).join(' ')]
    for (const s of [...new Set(terms)]) {
      const j = await getJson(fetchFn, { query: QUERY, variables: { s } }, 7000)
      const list = j?.data?.Page?.characters || []
      const m = list.find((c) => c?.image?.large
        && nameOk(ch.en, [c.name?.full || '', ...(c.name?.alternative || [])])
        && seriesOk(ch.series, (c.media?.nodes || []).flatMap((n) => [n?.title?.romaji || '', n?.title?.english || ''])))
      if (!m) continue
      const img = await getBuf(fetchFn, m.image.large, 8000)
      if (!img) continue
      // فحص أمان: لو الكاشف مش متاح أو اتأخر أو شك في الصورة نرجع من غير صورة
      const r = await Promise.race([classify(img), timeout(25000)])
      if (r && r.flagged === false) { buf = img; break }
    }
  } catch { buf = null }
  cache.set(ch.en, { buf, at: Date.now() })
  if (cache.size > 80) cache.delete(cache.keys().next().value)
  return buf
}
