import pino from 'pino'
import { downloadMediaMessage } from '@whiskeysockets/baileys'
import {
  CONFIG, db, save, gset, clean, log,
  getMeta, isAdmin, botIsAdmin, warnUser, deleteKeys, forget,
} from './lib.js'
import { findLinks } from './links.js'
import { BADWORDS } from './data.js'
import { classifyMedia, enqueue } from './nsfw.js'
import { classifyText, modAllowed } from './ai.js'
import { score as botScore, punish as botPunish, isExempt as botExempt, setOwnNumbers, noteSkip as botNote } from './antibot.js'
import { listSubs, mainNumber } from './sessions.js'
import { checkRules, anyRuleOn } from './cmds6-protect.js'

setOwnNumbers(() => [mainNumber(), ...listSubs().map((x) => x.number)])

const silent = pino({ level: 'silent' })

// ═══════════════ الكلمات البذيئة ═══════════════
export const normWord = (s) =>
  s
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/(.)\1+/g, '$1') // كسسسمك → كسمك

export function hasBadWord(text, extra = []) {
  const toks = normWord(text).split(/[^a-z\u0621-\u064a0-9]+/).filter(Boolean)
  const hay = ' ' + toks.join(' ') + ' '
  for (const w of [...BADWORDS, ...extra]) {
    const nw = normWord(w).trim()
    if (!nw) continue
    for (const p of ['', 'و', 'ف', 'ب', 'ل'])
      if (hay.includes(' ' + p + nw + ' ')) return true
  }
  return false
}

// ═══════════════ التكرار ═══════════════
const bursts = new Map()
function floodKeys(jid, sender, key, text) {
  if (bursts.size > 5000) bursts.clear()
  const k = jid + '|' + sender
  const now = Date.now()
  const arr = (bursts.get(k) ?? []).filter((x) => now - x.t < 8000)
  arr.push({ t: now, key, text })
  bursts.set(k, arr)
  const same = text ? arr.filter((x) => x.text === text).length : 0
  if (arr.length >= 7 || same >= 4) {
    bursts.delete(k)
    return arr.map((x) => x.key)
  }
  return null
}

// ═══════════════ الحماية ═══════════════
const warnedNoAdmin = new Map()

// ترجع true لو الرسالة اتمسحت
export async function runGuards(env) {
  const { sock, m, jid, key, text, hasInvite, content, sender, edited } = env
  const g = gset(jid)
  const muted = Object.keys(g.muted).length > 0
  if (!(g.antilink || g.antibot || g.antiprofanity || g.antiflood || g.antisticker || g.antiimage || muted || anyRuleOn(g)))
    return false

  let meta
  try {
    meta = await getMeta(sock, jid)
  } catch (e) {
    log(`تعذر قراءة بيانات الجروب ${jid}:`, e.message)
    return false
  }
  if (!botIsAdmin(sock, meta)) {
    if (Date.now() - (warnedNoAdmin.get(jid) || 0) > 600_000) {
      warnedNoAdmin.set(jid, Date.now())
      log(`⚠️ لازم تبقى أدمن في: ${meta.subject}`)
    }
    return false
  }

  const s = clean(sender || '')
  const senderAdmin = isAdmin(meta, sender)
  if (g.exemptAdmins && senderAdmin) {
    if (g.antibot && !edited) botNote(jid, sender, m, key, 'أدمن (مستثنى)')
    return false
  }

  const drop = async () => {
    await sock.sendMessage(jid, { delete: key })
    db.stats.deleted++
    forget(jid, [key.id])
  }

  // 1) المكتومين
  if (g.muted[s] && !senderAdmin) {
    await drop()
    return true
  }

  // 1b) قواعد الحماية 6.0 (أكتر من 130 قاعدة بتتفعّل بالأمر .منع ...)
  if (anyRuleOn(g)) {
    const hit = checkRules(g, { text, c: content, raw: m.message, ctx: env.ctx, edited })
    if (hit) {
      await drop()
      log(`🛡️ قاعدة «${hit.ar}» | ${meta.subject}`)
      await warnUser(sock, jid, g, sender, meta, `⚠️ تم حذف الرسالة: مخالفة قاعدة «${hit.ar}»`)
      save()
      return true
    }
  }

  // 2) مضاد البوتات: نظام نقاط (بصمات + رسايل أزرار + ردود فورية على الأوامر + اسم) وعقوبة رادعة
  if (g.antibot && !senderAdmin && !edited && botExempt(g, sender)) botNote(jid, sender, m, key, 'بوت مسموح/بوتك (مستثنى)')
  if (g.antibot && !senderAdmin && !edited && !botExempt(g, sender)) {
    const r = botScore(g, { jid, sender: s, key, m, content, text })
    if (r.trigger) {
      await botPunish({ sock, jid, meta, sender, key, reasons: r.reasons, total: r.total })
      return true
    }
  }

  // 3) الروابط
  if (g.antilink && text) {
    let hits = findLinks(text)
    if (hasInvite) hits.push('chat.whatsapp.com')
    hits = hits.filter((h) => !g.whitelist.some((d) => h === d || h.endsWith('.' + d)))
    if (hits.length) {
      await drop()
      log(`🗑️ لينك اتمسح | ${meta.subject}`)
      if (g.warnLimit > 0 && sender)
        await warnUser(sock, jid, g, sender, meta, '⚠️ ممنوع إرسال الروابط!', g.warnLimit)
      save()
      return true
    }
  } else if (g.antilink && hasInvite) {
    await drop()
    save()
    return true
  }

  // 4) الكلمات البذيئة
  if (g.antiprofanity && text && hasBadWord(text, g.badwords)) {
    await drop()
    await warnUser(sock, jid, g, sender, meta, '⚠️ تم حذف رسالة فيها ألفاظ بذيئة')
    return true
  }

  // 4b) المراقبة الذكية (Claude) — بتشتغل في الخلفية
  if (g.aimod && text && !edited && text.length >= 4 && !text.startsWith(CONFIG.PREFIX)) {
    aiModerate({ sock, jid, key, sender, text }).catch((e) => log('مراقبة ذكية:', e.message))
  }

  // 5) التكرار
  if (g.antiflood && !edited) {
    const keys = floodKeys(jid, s, key, text)
    if (keys) {
      await deleteKeys(sock, keys, 120)
      db.stats.deleted += keys.length
      forget(jid, keys.map((k) => k.id))
      await warnUser(sock, jid, g, sender, meta, '⚠️ مضاد التكرار: تم حذف الرسائل المتكررة')
      return true
    }
  }

  // 6) الصور والملصقات (حتى المتحركة) والفيديو/GIF القصير — بتتفحص في الخلفية
  if (!edited) {
    const st = content?.stickerMessage
    const im = content?.imageMessage
    const vd = content?.videoMessage
    let job = null
    if (st && g.antisticker)
      job = st.isAnimated ? { kind: 'animated', label: 'ملصق متحرك' } : { kind: 'sticker', label: 'ملصق' }
    else if (im && g.antiimage) job = { kind: 'image', label: 'صورة' }
    else if (vd && g.antiimage && Number(vd.seconds || 0) <= 20 && Number(vd.fileLength || 0) <= 8_000_000)
      job = { kind: 'video', label: vd.gifPlayback ? 'GIF' : 'فيديو' }
    if (job) scanMedia({ sock, m, jid, key, sender, ...job }).catch((e) => log('فحص الصور:', e.message))
  }
  return false
}

const CATS = { profanity: 'ألفاظ بذيئة', sexual: 'محتوى جنسي', harassment: 'إساءة لشخص', hate: 'خطاب كراهية' }

async function aiModerate({ sock, jid, key, sender, text }) {
  if (!modAllowed(jid)) return
  const r = await classifyText(text)
  if (!r.flag) return
  const meta = await getMeta(sock, jid)
  const g = gset(jid)
  await sock.sendMessage(jid, { delete: key })
  db.stats.deleted++
  forget(jid, [key.id])
  log(`🧠 رسالة مسيئة اتمسحت (${r.category}) | ${meta.subject}`)
  await warnUser(sock, jid, g, sender, meta, `⚠️ تم حذف رسالة مسيئة (${CATS[r.category] || 'مخالفة'})`)
}

async function scanMedia({ sock, m, jid, key, sender, kind, label }) {
  await enqueue(async () => {
    const buf = await downloadMediaMessage(m, 'buffer', {}, {
      logger: silent,
      reuploadRequest: sock.updateMediaMessage,
    })
    const r = await classifyMedia(buf, kind, CONFIG.NSFW_THRESHOLD)
    if (!r.flagged) return
    const meta = await getMeta(sock, jid)
    const g = gset(jid)
    await sock.sendMessage(jid, { delete: key })
    db.stats.deleted++
    forget(jid, [key.id])
    log(`🔞 ${label} خادش اتمسح (${r.score.toFixed(2)}, ${r.frames} إطار) | ${meta.subject}`)
    await warnUser(sock, jid, g, sender, meta, `⚠️ تم حذف ${label} خادش`)
  })
}
