// ═══════════════ الذكاء المحلي (بدون API) ═══════════════
// نظام استرجاع ذكي: بيطبّع الكلام العربي، ويقارن السؤال بكل اللي اتعلمه
// (TF-IDF على الكلمات + تشابه المقاطع الحرفية للأخطاء الإملائية)، ويرد بأقرب إجابة.
// بيتدرب بـ .علمني و.درب، ومن ردودك لو فعّلت التدريب التلقائي.
import { CONFIG, db, save } from './lib.js'
import { VERSION } from './ui.js'
import { SEED } from './brain-data.js'

const STOP = new Set(['يا', 'ده', 'دي', 'دا', 'في', 'من', 'علي', 'انا', 'انت', 'هو', 'هي', 'ان', 'لو', 'هل', 'ما', 'بس', 'كده', 'و', 'ف', 'ب', 'ل', 'عن', 'مع', 'يعني', 'طيب', 'طب'])

export function normalize(s = '') {
  return String(s)
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[^a-z0-9\u0621-\u064a\s]/g, ' ')
    .replace(/(.)\1{2,}/g, '$1')
    .replace(/\s+/g, ' ')
    .trim()
}

const stem = (w) => (w.length > 4 ? w.replace(/^(وال|بال|كال|فال|لل|ال)/, '') : w)
export function tokens(s) {
  const all = normalize(s).split(' ').filter(Boolean).map(stem)
  const keep = all.filter((t) => !STOP.has(t))
  return keep.length ? keep : all
}
const grams = (s) => {
  const t = ` ${normalize(s).replace(/\s+/g, ' ')} `
  const out = new Set()
  for (let i = 0; i < t.length - 2; i++) out.add(t.slice(i, i + 3))
  return out
}
const dice = (a, b) => {
  if (!a.size || !b.size) return 0
  let n = 0
  for (const x of a) if (b.has(x)) n++
  return (2 * n) / (a.size + b.size)
}

// ───────── الفهرس ─────────
let index = null
let sig = ''
function build() {
  const entries = []
  for (const [qs, as] of SEED) for (const q of qs) entries.push({ q, a: as, scope: '*', src: 'seed' })
  for (const t of db.brain.taught) entries.push({ q: t.q, a: t.a, scope: t.scope || '*', src: 'taught' })
  for (const t of db.brain.learned) entries.push({ q: t.q, a: t.a, scope: '*', src: 'learned' })
  for (const e of entries) {
    e.n = normalize(e.q)
    e.tok = tokens(e.q)
    e.gr = grams(e.q)
  }
  const df = new Map()
  for (const e of entries) for (const t of new Set(e.tok)) df.set(t, (df.get(t) || 0) + 1)
  const N = entries.length
  const idf = (t) => Math.log((N + 1) / ((df.get(t) || 0) + 1)) + 1
  for (const e of entries) {
    const tf = new Map()
    for (const t of e.tok) tf.set(t, (tf.get(t) || 0) + 1)
    e.vec = new Map([...tf].map(([t, c]) => [t, c * idf(t)]))
    e.norm = Math.sqrt([...e.vec.values()].reduce((s, v) => s + v * v, 0)) || 1
  }
  return { entries, idf }
}
function get() {
  const s = `${db.brain.taught.length}:${db.brain.learned.length}:${db.brain.taught.at(-1)?.q || ''}`
  if (!index || s !== sig) {
    index = build()
    sig = s
  }
  return index
}

const fill = (text, vars = {}) =>
  text.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined ? vars[k] : m))

export function defaultVars() {
  const now = new Date()
  let time = '', date = ''
  try {
    time = now.toLocaleTimeString('ar-EG', { timeZone: CONFIG.TZ, hour: 'numeric', minute: '2-digit' })
    date = now.toLocaleDateString('ar-EG', { timeZone: CONFIG.TZ, dateStyle: 'full' })
  } catch {}
  return { bot: CONFIG.BOT_NAME, prefix: CONFIG.PREFIX, version: VERSION, count: '300+', dev: CONFIG.DEV_NAME, time, date }
}

// بترجع { reply, score, src } أو null لو مش واثق
export function answer(text, { jid = '', vars = {}, threshold = 0.55 } = {}) {
  const qn = normalize(text)
  if (!qn) return null
  const { entries, idf } = get()
  const qt = tokens(text)
  const qtf = new Map()
  for (const t of qt) qtf.set(t, (qtf.get(t) || 0) + 1)
  const qvec = new Map([...qtf].map(([t, c]) => [t, c * idf(t)]))
  const qnorm = Math.sqrt([...qvec.values()].reduce((s, v) => s + v * v, 0)) || 1
  const qg = grams(text)

  let best = null
  for (const e of entries) {
    if (e.scope !== '*' && e.scope !== jid) continue
    let score
    if (e.n === qn) score = 1 + (e.src === 'taught' ? 0.2 : 0) // اللي اتعلمه المالك أولى
    else {
      let dot = 0
      for (const [t, w] of qvec) if (e.vec.has(t)) dot += w * e.vec.get(t)
      const cos = dot / (qnorm * e.norm)
      score = 0.65 * cos + 0.35 * dice(qg, e.gr)
      if (e.src === 'taught') score += 0.03
    }
    if (!best || score > best.score) best = { score, e }
  }
  if (!best || best.score < threshold) return null
  const a = best.e.a[Math.floor(Math.random() * best.e.a.length)]
  return { reply: fill(a, { ...defaultVars(), ...vars }), score: best.score, src: best.e.src }
}

// ───────── التدريب ─────────
export function teach(q, a, scope = '*') {
  const qn = normalize(q)
  if (!qn || !a.trim()) return false
  const ex = db.brain.taught.find((t) => normalize(t.q) === qn && (t.scope || '*') === scope)
  if (ex) {
    if (!ex.a.includes(a)) ex.a.push(a.slice(0, 500))
  } else db.brain.taught.push({ q: q.trim().slice(0, 200), a: [a.trim().slice(0, 500)], scope })
  if (db.brain.taught.length > 3000) db.brain.taught.shift()
  save()
  return true
}

export function forget(q, scope = '*') {
  const qn = normalize(q)
  const before = db.brain.taught.length + db.brain.learned.length
  db.brain.taught = db.brain.taught.filter((t) => !(normalize(t.q) === qn && (scope === 'all' || (t.scope || '*') === scope)))
  db.brain.learned = db.brain.learned.filter((t) => normalize(t.q) !== qn)
  save()
  return before - (db.brain.taught.length + db.brain.learned.length)
}

// التعلم من ردود المالك (اختياري): بنتجاهل الأرقام الطويلة والروابط والإيميلات
const SENSITIVE = /(\d[\s-]?){6,}|https?:\/\/|www\.|@\S+\.\S+|\bpassword\b|باسورد|كلمة السر|كلمه السر/i
export function learnPair(q, a) {
  q = String(q || '').trim()
  a = String(a || '').trim()
  if (q.length < 2 || q.length > 200 || a.length < 1 || a.length > 200) return false
  if (SENSITIVE.test(q) || SENSITIVE.test(a)) return false
  const qn = normalize(q)
  if (!qn) return false
  const ex = db.brain.learned.find((t) => normalize(t.q) === qn)
  if (ex) {
    if (!ex.a.includes(a)) ex.a.push(a)
  } else db.brain.learned.push({ q, a: [a] })
  if (db.brain.learned.length > 500) db.brain.learned.shift()
  save()
  return true
}

export function stats() {
  return { seed: SEED.reduce((n, [qs]) => n + qs.length, 0), taught: db.brain.taught.length, learned: db.brain.learned.length, autolearn: !!db.brain.autolearn }
}
export const listTaught = (scope) => db.brain.taught.filter((t) => !scope || (t.scope || '*') === scope || (t.scope || '*') === '*')
