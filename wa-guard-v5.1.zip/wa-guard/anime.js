// ═══════════ محرّك لعبة تخمين شخصيات الأنمي (بيانات + مطابقة الأسماء) ═══════════
import { MALE_RAW } from './data-anime-male.js'
import { FEMALE_RAW } from './data-anime-female.js'
import { CHILD_RAW } from './data-anime-child.js'
import { extra } from './data-extra.js'

export const CATS = {
  girl: { label: 'بنت', words: ['بنت', 'بنات', 'girl', 'girls', 'f'] },
  boy: { label: 'ولد', words: ['ولد', 'اولاد', 'أولاد', 'boy', 'boys', 'm'] },
  kid: { label: 'طفل', words: ['طفل', 'اطفال', 'أطفال', 'kid', 'kids', 'child', 'children'] },
}

function parse(raw, cat) {
  const out = []
  let series = ''
  for (const line of raw.split('\n')) {
    if (line.startsWith('# ')) { series = line.slice(2).trim(); continue }
    if (!line.includes('|') || !series) continue
    const [ar, en] = line.split('|')
    const names = ar.split('/').map((x) => x.trim()).filter(Boolean)
    if (names.length && en?.trim()) out.push({ ar: names, en: en.trim(), series, cat })
  }
  return out
}

// ترتيب الأولوية عند تكرار الاسم الإنجليزي: طفل ثم بنت ثم ولد
const seen = new Set()
const dedupe = (list) => list.filter((c) => (seen.has(c.en.toLowerCase()) ? false : (seen.add(c.en.toLowerCase()), true)))
export const KIDS = dedupe(parse(CHILD_RAW, 'kid'))
export const GIRLS = dedupe(parse(FEMALE_RAW, 'girl'))
export const BOYS = dedupe(parse(MALE_RAW, 'boy'))
// شخصيات إضافية من extra-questions.json: { "anime": [{"cat":"girl","ar":["اسم"],"en":"Name","series":"Anime"}] }
for (const x of extra('anime')) {
  if (CATS[x?.cat] && x.en && x.series && Array.isArray(x.ar) && x.ar.length && !seen.has(x.en.toLowerCase())) {
    seen.add(x.en.toLowerCase())
    ;({ girl: GIRLS, boy: BOYS, kid: KIDS })[x.cat].push({ ar: x.ar, en: x.en, series: x.series, cat: x.cat })
  }
}
export const POOLS = { girl: GIRLS, boy: BOYS, kid: KIDS }
export const ALL = [...GIRLS, ...BOYS, ...KIDS]

// ── تطبيع الأسماء: العربي (يوحّد اختلافات الكتابة للأسماء اليابانية) والإنجليزي ──
const AR_MAP = { أ: 'ا', إ: 'ا', آ: 'ا', ى: 'ي', ة: 'ه', ؤ: 'و', ئ: 'ي', غ: 'ج', ث: 'س', ص: 'س', ذ: 'ز', ظ: 'ز', ض: 'د', ط: 'ت', ح: 'ه', ق: 'ك' }
export const normAr = (s = '') =>
  s.replace(/[\u064B-\u065F\u0670\u0640]/g, '').toLowerCase().replace(/[أإآىةؤئغثصذظضطحق]/g, (c) => AR_MAP[c])
    .replace(/[^\p{L}\p{N}\s]/gu, '').replace(/(.)\1+/g, '$1').replace(/\s+/g, ' ').trim()
export const normEn = (s = '') => s.toLowerCase().replace(/[^a-z0-9]/g, '')

function lev(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i)
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]
    let rowMin = i
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1))
      rowMin = Math.min(rowMin, cur[j])
    }
    if (rowMin > max) return max + 1
    prev = cur
  }
  return prev[b.length]
}

// كل الصيغ المقبولة لشخصية: الاسم كامل + أي كلمة منه (٣ حروف+) بالعربي والإنجليزي
const cache = new WeakMap()
function forms(ch) {
  if (cache.has(ch)) return cache.get(ch)
  const f = new Set()
  for (const a of ch.ar) {
    const n = normAr(a)
    if (n) f.add(n.replace(/ /g, ''))
    for (const w of n.split(' ')) if (w.length >= 3) f.add(w)
  }
  const en = normEn(ch.en)
  if (en) f.add(en)
  for (const w of ch.en.toLowerCase().split(/[^a-z0-9]+/)) if (w.length >= 3) f.add(normEn(w))
  const arr = [...f]
  cache.set(ch, arr)
  return arr
}

const tolerance = (len) => (len >= 9 ? 2 : len >= 5 ? 1 : 0)
export function isMatch(ch, answer) {
  const raw = answer.trim()
  if (raw.length < 2) return false
  const isLatin = /[a-z]/i.test(raw)
  const a = isLatin ? normEn(raw) : normAr(raw).replace(/ /g, '')
  if (a.length < 2) return false
  for (const f of forms(ch)) {
    const fLatin = /^[a-z0-9]+$/.test(f)
    if (fLatin !== isLatin) continue
    if (a === f) return true
    if (f.length >= 5 && a.length >= 4 && lev(a, f, tolerance(f.length)) <= tolerance(f.length)) return true
  }
  return false
}

export function pick(cat, seenIdx = []) {
  const pool = cat ? POOLS[cat] : ALL
  let idx = Math.floor(Math.random() * pool.length)
  for (let i = 0; i < 60 && seenIdx.includes(`${cat || 'all'}:${idx}`); i++) idx = Math.floor(Math.random() * pool.length)
  return { ch: pool[idx], key: `${cat || 'all'}:${idx}` }
}

export function parseCat(arg = '') {
  const t = arg.trim().toLowerCase()
  if (!t) return null
  for (const [k, v] of Object.entries(CATS)) if (v.words.includes(t)) return k
  return undefined // وسيط غير معروف
}

// تلميحات
export const hintSeries = (ch) => ch.series.replace(/\s*\((more|extras?)\)\s*$/i, '').replace(/ extras$/i, '')
export const hintLetters = (ch) => {
  const n = ch.ar[0].replace(/\s+/g, ' ')
  const first = n[0]
  const words = n.split(' ').length
  return `الاسم (${n.replace(/\s/g, '').length} حرف${words > 1 ? `، ${words} كلمات` : ''}) يبدأ بحرف «${first}»`
}
