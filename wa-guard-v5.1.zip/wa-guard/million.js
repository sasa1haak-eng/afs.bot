// ═══════════ محرّك لعبة «من سيربح المليون» (منطق صافي بدون واتساب) ═══════════
import { MILLION_BASE } from './data-million.js'
import { extra } from './data-extra.js'
import { GEN } from './gen-bank.js'

export const LADDER = [100, 200, 300, 500, 1000, 1500, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
export const SAFE = [5, 10] // مستويات الأمان (لو غلطت بعدها بترجع لآخر مستوى أمان)
export const LETTERS = ['أ', 'ب', 'ج', 'د']
export const LIFELINES = {
  fifty: 'حذف اجابتين',
  poll: 'سؤال الجمهور',
  phone: 'الاتصال بصديق',
  swap: 'تبديل السؤال',
}
export const tierOf = (lvl) => (lvl <= 5 ? 1 : lvl <= 10 ? 2 : 3)

// بنك الأسئلة النهائي = الأساسي + اللي في extra-questions.json
export const BANK = (() => {
  const b = { 1: [...MILLION_BASE[1]], 2: [...MILLION_BASE[2]], 3: [...MILLION_BASE[3]] }
  const ex = extra('million', {})
  for (const t of [1, 2, 3]) for (const q of ex[t] || []) if (q?.q && q?.ok && q?.bad?.length === 3) b[t].push(q)
  for (const t of [1, 2, 3]) b[t].push(...GEN.million[t])
  // شيل أي سؤال مكرر (نفس النص) سواء في نفس المستوى أو بين المستويات، وخلّي الأول (المكتوب يدوياً)
  const seenQ = new Set()
  for (const t of [1, 2, 3]) b[t] = b[t].filter((q) => (seenQ.has(q.q) ? false : (seenQ.add(q.q), true)))
  for (const t of [1, 2, 3]) b[t].forEach((q, i) => (q.id = `${t}-${i}`))
  return b
})()

const shuffle = (a) => { const x = [...a]; for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]] } return x }
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1))

// بيجيب سؤال جديد من نفس الصعوبة بعيد عن اللي ظهر قبل كده (seen = قايمة ids)
export function drawQuestion(lvl, seen = [], exclude = []) {
  const pool = BANK[tierOf(lvl)]
  let fresh = pool.filter((q) => !seen.includes(q.id) && !exclude.includes(q.id))
  if (!fresh.length) fresh = pool.filter((q) => !exclude.includes(q.id)) // خلصوا كلهم: نبدأ من الأول
  // نص الأسئلة من البنك المكتوب يدوياً ونصها من المولَّد من الجداول (عشان الأسئلة المتخصصة ما تغلبش على العامة)
  const hand = fresh.filter((q) => !q.gen), gen = fresh.filter((q) => q.gen)
  const from = hand.length && (!gen.length || Math.random() < 0.5) ? hand : gen.length ? gen : fresh
  const q = from[Math.floor(Math.random() * from.length)]
  const opts = shuffle([q.ok, ...q.bad])
  return { id: q.id, q: q.q, opts, ok: opts.indexOf(q.ok), tier: tierOf(lvl) }
}

export function newGame(seen = []) {
  const g = { lvl: 1, used: {}, removed: [], seen: [...seen], at: Date.now(), last: Date.now() }
  g.cur = drawQuestion(1, g.seen)
  g.seen.push(g.cur.id)
  return g
}

// الفلوس اللي بياخدها اللاعب: لو غلط / لو انسحب
export const prizeOnWrong = (lvl) => (lvl > SAFE[1] ? LADDER[SAFE[1] - 1] : lvl > SAFE[0] ? LADDER[SAFE[0] - 1] : 0)
export const prizeOnWithdraw = (lvl) => (lvl > 1 ? LADDER[lvl - 2] : 0)

// حرف الإجابة → رقم الاختيار (يقبل أ/ا/إ/آ, ب, ج, د, a-d, 1-4)
export function parseChoice(s = '') {
  const t = s.trim().toLowerCase().replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
  if (/^[أاإآa1]$/.test(t)) return 0
  if (/^[بb2]$/.test(t)) return 1
  if (/^[جc3]$/.test(t)) return 2
  if (/^[دd4]$/.test(t)) return 3
  return -1
}

// اختيار الإجابة. يرجع { result: 'correct'|'win'|'wrong'|'removed', ... }
export function answer(g, idx) {
  if (g.removed.includes(idx)) return { result: 'removed' }
  g.last = Date.now()
  if (idx === g.cur.ok) {
    if (g.lvl === LADDER.length) return { result: 'win', prize: LADDER[LADDER.length - 1] }
    const reached = g.lvl
    g.lvl++
    g.removed = []
    g.cur = drawQuestion(g.lvl, g.seen)
    g.seen.push(g.cur.id)
    return { result: 'correct', reached, safe: SAFE.includes(reached) ? LADDER[reached - 1] : 0 }
  }
  return { result: 'wrong', prize: prizeOnWrong(g.lvl), correct: g.cur.ok }
}

// ── المساعدات ──
// احتمال إن الصديق/الجمهور يعرف الإجابة بيقل مع صعوبة السؤال
const knowChance = { audience: [0.95, 0.85, 0.7], friend: [0.97, 0.85, 0.65] }

export function fifty(g) {
  const wrong = [0, 1, 2, 3].filter((i) => i !== g.cur.ok && !g.removed.includes(i))
  const kill = shuffle(wrong).slice(0, 2)
  g.removed.push(...kill)
  return kill
}

export function poll(g) {
  const alive = [0, 1, 2, 3].filter((i) => !g.removed.includes(i))
  const t = g.cur.tier - 1
  const knows = Math.random() < knowChance.audience[t]
  // الجمهور ممكن يتلخبط: لو "مش عارف" بيميل لاختيار غلط
  const lead = knows ? g.cur.ok : shuffle(alive.filter((i) => i !== g.cur.ok))[0] ?? g.cur.ok
  const pct = {}
  let left = 100
  const leadShare = knows ? rnd(48 - t * 8, 78 - t * 10) : rnd(38, 55)
  pct[lead] = leadShare; left -= leadShare
  const others = alive.filter((i) => i !== lead)
  others.forEach((i, k) => {
    const share = k === others.length - 1 ? left : rnd(0, Math.floor(left * (others.length - k > 1 ? 0.7 : 1)))
    pct[i] = share; left -= share
  })
  return alive.map((i) => ({ i, pct: pct[i] || 0 }))
}

export function phone(g) {
  const alive = [0, 1, 2, 3].filter((i) => !g.removed.includes(i))
  const t = g.cur.tier - 1
  const knows = Math.random() < knowChance.friend[t]
  if (knows) {
    const sure = Math.random() < (t === 2 ? 0.55 : 0.85)
    return { i: g.cur.ok, sure, knows }
  }
  // مش عارف: يخمّن من الاختيارات المتاحة
  return { i: shuffle(alive)[0], sure: false, knows }
}

export function swap(g) {
  const old = g.cur.id
  g.cur = drawQuestion(g.lvl, g.seen, [old])
  g.seen.push(g.cur.id)
  g.removed = []
  return g.cur
}
