// ═══════════ 4.6 — إدارة الجروبات المتقدمة ═══════════
import { nm, digitsOf, cairo } from './core/names.js'
import { nextCairoTime } from './core/scheduler.js'
import { recentJoins } from './core/shield.js'

export function register(c) {
  const { cmd, P, T, panel, kv, tag, getMeta, botIsAdmin, gset, save, db, norm } = c
  const SEC = 'grp5'
  const GA = { group: true, sec: SEC }
  const GAB = { group: true, botAdmin: true, sec: SEC }
  const toggleArg = (a) => (['تشغيل', 'تفعيل', 'on'].map(norm).includes(norm(a)) ? 'on' : ['ايقاف', 'تعطيل', 'off'].map(norm).includes(norm(a)) ? 'off' : '')

  cmd(nm('وضع الموافقة'), 'admin', async (e, args) => {
    const a = toggleArg(args.trim())
    if (!a) { const m = await getMeta(e.sock, e.jid); return e.reply(`🚪 موافقة الأدمن على الانضمام: ${m?.joinApprovalMode ? '✅ شغالة' : '❌ مقفولة'}\nللتغيير: ${P}وضع الموافقة تشغيل | ايقاف`) }
    await e.sock.groupJoinApprovalMode(e.jid, a)
    return e.reply(`🚪 موافقة الأدمن على الانضمام: ${a === 'on' ? '✅ اتفعّلت (كل طلب انضمام محتاج موافقتك)' : '❌ اتقفلت'}`)
  }, GAB)

  cmd(nm('طلبات الانضمام'), 'admin', async (e) => {
    const l = (await e.sock.groupRequestParticipantsList(e.jid)) || []
    if (!l.length) return e.reply(`${T.info} مفيش طلبات انضمام معلّقة.`)
    return e.reply(panel('🚪 JOIN REQUESTS', [kv('العدد', l.length), ...l.slice(0, 15).map((x) => `▸ ${digitsOf(x.jid || x.id)}`)], `${P}قبول الطلبات · ${P}رفض الطلبات`))
  }, GAB)
  const decide = (action, label) => async (e, args) => {
    const l = (await e.sock.groupRequestParticipantsList(e.jid)) || []
    const want = args.match(/\d{8,15}/g)
    const jids = l.map((x) => x.jid || x.id).filter((j) => !want || want.includes(digitsOf(j)))
    if (!jids.length) return e.reply(`${T.info} مفيش طلبات ${want ? 'مطابقة' : 'معلّقة'}.`)
    await e.sock.groupRequestParticipantsUpdate(e.jid, jids, action)
    return e.reply(`${T.ok} ${label} ${jids.length} طلب.`)
  }
  cmd(nm('قبول الطلبات'), 'admin', decide('approve', 'تم قبول'), GAB)
  cmd(nm('رفض الطلبات'), 'admin', decide('reject', 'تم رفض'), GAB)

  cmd(nm('رابط الدعوة'), 'admin', async (e) => {
    const code = await e.sock.groupInviteCode(e.jid)
    return e.reply(`🔗 رابط الدعوة:\nhttps://chat.whatsapp.com/${code}\n${T.warn} لو اتسرّب: ${P}تجديد الرابط`)
  }, GAB)
  cmd(nm('تجديد الرابط'), 'admin', async (e) => {
    const code = await e.sock.groupRevokeInvite(e.jid)
    return e.reply(`🔄 اتلغى الرابط القديم. الجديد:\nhttps://chat.whatsapp.com/${code}`)
  }, GAB)

  cmd(nm('معلومات الجروب'), 'admin', async (e) => {
    const m = await getMeta(e.sock, e.jid), g = gset(e.jid)
    const parts = m.participants || []
    const prot = ['antilink', 'antiprofanity', 'antiflood', 'antibot'].filter((k) => g[k]).length
    return e.reply(panel('👥 GROUP INFO', [
      kv('الاسم', m.subject), kv('الأعضاء', parts.length), kv('الأدمنز', parts.filter((p) => p.admin).length),
      kv('أُنشئ', m.creation ? cairo(m.creation * 1000) : '—'), kv('الإرسال', m.announce ? 'الأدمن بس' : 'الكل'), kv('تعديل المعلومات', m.restrict ? 'الأدمن بس' : 'الكل'),
      kv('موافقة الانضمام', m.joinApprovalMode ? 'شغالة' : 'مقفولة'), kv('رسائل مؤقتة', m.ephemeralDuration ? `${Math.round(m.ephemeralDuration / 86400)} يوم` : 'مقفولة'),
      kv('الحماية الشغالة', `${prot}/4${g.raid?.on ? ' + كشف هجمات' : ''}${g.emergency ? ' 🆘 طوارئ' : ''}`),
      kv('انضموا آخر ساعة', recentJoins(e.jid, 60).filter((x) => Date.now() - x.t < 3600_000).length),
    ]))
  }, GA)

  cmd(nm('الرسائل المؤقتة'), 'admin', async (e, args) => {
    const a = norm(args.trim())
    const map = { 24: 86400, 7: 604800, 90: 7776000 }
    const n = parseInt(a)
    const secs = toggleArg(a) === 'off' ? 0 : map[n]
    if (secs === undefined) {
      const hint = a ? `\n${T.warn} واتساب بيدعم 3 مدد بس: 24 ساعة أو 7 أيام أو 90 يوم (مفيش ساعة واحدة).` : ''
      return e.reply(`${T.info} اكتب: ${P}الرسائل المؤقتة 24 (ساعة) | 7 (أيام) | 90 (يوم) | ايقاف${hint}`)
    }
    await e.sock.groupToggleEphemeral(e.jid, secs)
    return e.reply(secs ? `⏳ الرسائل المؤقتة: بتختفي بعد ${n === 24 ? '24 ساعة' : n === 7 ? '7 أيام' : '90 يوم'}` : '⏳ الرسائل المؤقتة اتقفلت')
  }, GAB)

  // تثبيت / إلغاء تثبيت رسالة (بالرد عليها)
  const keyOf = (e) => (e.ctx?.stanzaId ? { remoteJid: e.jid, id: e.ctx.stanzaId, participant: e.ctx.participant, fromMe: false } : null)
  cmd(['تثبيت'], 'admin', async (e, args) => {
    const key = keyOf(e)
    if (!key) return e.reply(`${T.info} ردّ على الرسالة اللي عايز تثبّتها واكتب ${P}تثبيت [24 | 7 | 30] (بالأيام، الافتراضي 7)`)
    const days = { 1: 86400, 24: 86400, 7: 604800, 30: 2592000 }[parseInt(args)] || 604800
    await e.sock.sendMessage(e.jid, { pin: key, type: 1, time: days })
    return e.reply(`📌 اتثبتت الرسالة ${days === 86400 ? 'يوم' : days === 604800 ? '7 أيام' : '30 يوم'}.`)
  }, GAB)
  cmd(nm('الغاء التثبيت'), 'admin', async (e) => {
    const key = keyOf(e)
    if (!key) return e.reply(`${T.info} ردّ على الرسالة المثبّتة واكتب ${P}الغاء التثبيت`)
    await e.sock.sendMessage(e.jid, { pin: key, type: 2 })
    return e.reply('📌 اتلغى التثبيت.')
  }, GAB)

  cmd(['الخاملين'], 'admin', async (e) => {
    const m = await getMeta(e.sock, e.jid)
    const xp = db.xp?.[e.jid] || {}
    const idle = (m.participants || []).filter((p) => !p.admin && !((xp[p.id] || xp[digitsOf(p.id)])?.msgs > 0))
    if (!idle.length) return e.reply(`${T.ok} كل الأعضاء متفاعلين (من لحظة بدء تسجيل النشاط).`)
    const shown = idle.slice(0, 15)
    return e.reply(`😴 *الخاملين (بدون أي رسالة مسجّلة):* ${idle.length} من ${m.participants.length}\n${shown.map((p) => '▫️ ' + tag(p.id)).join('\n')}${idle.length > 15 ? `\n… و${idle.length - 15} كمان` : ''}\n${T.info} التسجيل بيبدأ من أول ما البوت شاف الجروب.`, shown.map((p) => p.id))
  }, GA)

  // ── إعلانات مجدولة ──
  const MAX_SCHED = 10
  cmd(nm('جدولة اعلان'), 'admin', (e, args) => {
    const g = gset(e.jid)
    let rest = args.trim(), daily = false
    if (/^(يوميا|يومياً|كل يوم)\s+/.test(rest)) { daily = true; rest = rest.replace(/^(يوميا|يومياً|كل يوم)\s+/, '') }
    const m = rest.match(/^(\d{1,2}):(\d{2})\s+([\s\S]+)$/) || rest.match(/^(\d{1,4})\s+([\s\S]+)$/)
    if (!m) return e.reply(`${T.info} الصيغة:\n▸ ${P}جدولة اعلان 30 النص (بعد 30 دقيقة)\n▸ ${P}جدولة اعلان 21:30 النص (الساعة 9:30 م بتوقيت القاهرة)\n▸ ${P}جدولة اعلان يوميا 21:30 النص`)
    const timed = m.length === 4
    const text = (timed ? m[3] : m[2]).trim()
    if (text.length > 500) return e.reply(`${T.err} النص أطول من 500 حرف.`)
    if ((g.schedules ||= []).length >= MAX_SCHED) return e.reply(`${T.err} أقصى عدد ${MAX_SCHED} إعلانات مجدولة. الغي واحد بـ ${P}الغاء جدولة`)
    let at, every = 0
    if (timed) { const hh = +m[1], mi = +m[2]; if (hh > 23 || mi > 59) return e.reply(`${T.err} وقت غير صالح.`); at = nextCairoTime(hh, mi); if (daily) every = 1440 }
    else { const mins = +m[1]; if (mins < 1 || mins > 10080) return e.reply(`${T.err} المدة من 1 إلى 10080 دقيقة.`); at = Date.now() + mins * 60_000; if (daily) every = mins }
    g.schedSeq = (g.schedSeq || 0) + 1
    g.schedules.push({ id: g.schedSeq, text, at, every, num: digitsOf(e.sock.user?.id) })
    save()
    return e.reply(`⏰ اتجدول الإعلان #${g.schedSeq} — أول إرسال: ${cairo(at)}${every ? ' (متكرر)' : ''}`)
  }, GA)
  cmd(nm('الاعلانات المجدولة'), 'admin', (e) => {
    const l = gset(e.jid).schedules || []
    return e.reply(l.length ? panel('⏰ SCHEDULED', l.map((s) => `#${s.id} · ${cairo(s.at)}${s.every ? ' 🔁' : ''} · ${s.text.slice(0, 30)}`), `${P}الغاء جدولة رقم`) : `${T.info} مفيش إعلانات مجدولة.`)
  }, GA)
  cmd(nm('الغاء جدولة'), 'admin', (e, args) => {
    const g = gset(e.jid), id = parseInt(args)
    const i = (g.schedules || []).findIndex((s) => s.id === id)
    if (i < 0) return e.reply(`${T.err} رقم غلط. شوف ${P}الاعلانات المجدولة`)
    g.schedules.splice(i, 1); save()
    return e.reply(`${T.ok} اتلغى الإعلان المجدول #${id}.`)
  }, GA)
}
