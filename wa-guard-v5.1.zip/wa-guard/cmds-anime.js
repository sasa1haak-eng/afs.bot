// ═══════════ لعبة تخمين شخصيات الأنمي ═══════════
// .تخمين انمي [بنت|ولد|طفل] · .اجابة الانمي الاسم · .الغاء لعبة الانمي
import { CATS, POOLS, ALL, pick, parseCat, isMatch, hintSeries, hintLetters } from './anime.js'
import { characterImage } from './anime-img.js'
import { user, addCoins, addPts, money, track } from './eco.js'

const HINT1 = +process.env.ANIME_HINT1_MS || 25_000 // تلميح 1: اسم الأنمي
const HINT2 = +process.env.ANIME_HINT2_MS || 50_000 // تلميح 2: الحروف
const END = +process.env.ANIME_END_MS || 85_000
const MAX_TRIES = 4
const sleep = (ms) => new Promise((r) => setTimeout(r, ms).unref?.())

export function register(c) {
  const { cmd, P, T, panel, kv, tag, clean, getMeta, isAdmin, db, save } = c
  const SEC = 'games'
  const rounds = new Map() // الشات → الجولة الحالية
  const me = (e) => clean(e.sender)

  const reveal = (ch) => `*${ch.ar[0]}* (${ch.en}) — من أنمي «${hintSeries(ch)}»`
  const stop = (jid) => { const r = rounds.get(jid); if (r) { r.timers.forEach(clearTimeout); rounds.delete(jid) } return r }

  const say = (r, text) => r.sock.sendMessage(r.jid, { text }).catch(() => {})

  cmd(['تخمين انمي', 'تخمين أنمي', 'تخمين شخصيات انمي'], 'all', async (e, args) => {
    if (rounds.has(e.jid)) return e.reply(`${T.warn} فيه جولة شغالة! جاوب بـ ${P}اجابة الانمي الاسم أو الغيها بـ ${P}الغاء لعبة الانمي`)
    const cat = parseCat(args)
    if (cat === undefined) return e.reply(`${T.info} اكتب: ${P}تخمين انمي أو ${P}تخمين انمي بنت / ولد / طفل`)

    const seenKey = `${e.jid}:anime:${cat || 'all'}`
    const seen = ((db.seen ??= {})[seenKey] ??= [])
    const { ch, key } = pick(cat, seen)
    seen.push(key)
    const limit = Math.floor((cat ? POOLS[cat].length : ALL.length) * 0.7)
    while (seen.length > limit) seen.shift()

    const round = { ch, jid: e.jid, sock: e.sock, starter: me(e), started: Date.now(), tries: new Map(), timers: [], hints: 0 }
    rounds.set(e.jid, round)

    // الصورة هي التخمين الأساسي؛ لو ماقدرناش نجيبها (أو اتأخرت) بنكمّل بالتلميحات
    const img = await Promise.race([characterImage(ch), sleep(12_000).then(() => null)]).catch(() => null)
    if (rounds.get(e.jid) !== round) return // اتلغت أثناء التحميل
    const lines = [kv('الفئة', CATS[ch.cat].label), '', img ? '🎌 مين الشخصية دي؟' : '🎌 مين الشخصية؟ (من غير صورة)']
    if (!img) lines.push(`💡 من أنمي «${hintSeries(ch)}»`, `💡 ${hintLetters(ch)}`)
    lines.push('', `⏱ ${Math.round(END / 1000)} ثانية · جاوب بـ ${P}اجابة الانمي الاسم`)
    const caption = panel('🎌 ANIME', lines)
    if (img) await e.sock.sendMessage(e.jid, { image: img, caption }, { quoted: e.m })
    else await e.reply(caption)

    round.hints = img ? 0 : 2
    if (img) {
      round.timers.push(setTimeout(() => { round.hints = 1; say(round, `💡 تلميح: من أنمي «${hintSeries(ch)}»`) }, HINT1))
      round.timers.push(setTimeout(() => { round.hints = 2; say(round, `💡 تلميح 2: ${hintLetters(ch)}`) }, HINT2))
    }
    round.timers.push(setTimeout(() => {
      if (rounds.get(e.jid) !== round) return
      stop(e.jid)
      say(round, `⏰ انتهى الوقت! الشخصية كانت: ${reveal(ch)}`)
    }, END))
  }, { sec: SEC, d: 'تخمين شخصيات الأنمي (بنت/ولد/طفل)', u: 'تخمين انمي' })

  cmd(['اجابة الانمي', 'جواب الانمي', 'اجابه الانمي'], 'all', async (e, args) => {
    const r = rounds.get(e.jid)
    if (!r) return e.reply(`${T.info} مفيش جولة شغالة. ابدأ بـ ${P}تخمين انمي`)
    const ans = args.trim()
    if (!ans) return e.reply(`${T.info} اكتب: ${P}اجابة الانمي لوفي`)
    const who = me(e)
    const used = r.tries.get(who) || 0
    if (used >= MAX_TRIES) return e.reply(`${T.warn} خلصت محاولاتك (${MAX_TRIES}) في الجولة دي، استنى غيرك`)
    if (!isMatch(r.ch, ans)) {
      r.tries.set(who, used + 1)
      return e.reply(`❌ مش هي يا ${tag(who)} (باقي ${MAX_TRIES - used - 1} محاولات)`, [who])
    }
    stop(e.jid)
    const bonus = r.hints === 0 ? 40 : r.hints === 1 ? 20 : 0
    const prize = 80 + bonus
    addCoins(e.sender, prize)
    addPts(e.sender, 15, true)
    track(e.sender, 'quiz'); track(e.sender, 'win')
    return e.reply(`${T.ok} ${tag(who)} جاوب صح! 🎉\nالشخصية: ${reveal(r.ch)}\n+${money(prize)}${bonus ? ` (منها ${bonus} بونص سرعة)` : ''} | +15 نقطة`, [who])
  }, { sec: SEC, d: 'جاوب على لعبة الأنمي باسم الشخصية', u: 'اجابة الانمي لوفي' })

  cmd(['الغاء لعبة الانمي', 'الغاء الانمي', 'انهاء لعبة الانمي'], 'all', async (e) => {
    const r = rounds.get(e.jid)
    if (!r) return e.reply(`${T.info} مفيش جولة أنمي شغالة`)
    if (r.starter !== me(e) && !e.isOwner) {
      const m = e.isGroup ? await getMeta(e.sock, e.jid) : null
      if (!(m && isAdmin(m, e.sender))) return e.reply(`${T.warn} الإلغاء لمن بدأ اللعبة أو للأدمن بس`)
    }
    stop(e.jid)
    return e.reply(`${T.ok} اتلغت لعبة الأنمي. الشخصية كانت: ${reveal(r.ch)}`)
  }, { sec: SEC, d: 'يلغي جولة تخمين الأنمي', u: 'الغاء لعبة الانمي' })
}
