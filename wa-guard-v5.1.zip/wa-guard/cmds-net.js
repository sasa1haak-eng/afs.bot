// ═══════════ خدمات الإنترنت (مجانية بدون مفاتيح) ═══════════
import { explicit, BLOCKED_MSG } from './halal.js'
import dns from 'node:dns/promises'
import net from 'node:net'
import http from 'node:http'
import https from 'node:https'
import { findSurah } from './quran.js'
import { SURAHS } from './data.js'

const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'
const get = async (url, opts = {}) => {
  const res = await fetch(url, { headers: { 'user-agent': UA, ...(opts.headers || {}) }, signal: AbortSignal.timeout(opts.timeout || 15_000), redirect: opts.redirect })
  return res
}
const getJson = async (url) => {
  const res = await get(url)
  if (!res.ok) throw Object.assign(new Error(`الخدمة رجعت ${res.status}`), { status: res.status })
  return res.json()
}

// حماية SSRF: ممنوع العناوين الداخلية والمحلية
export function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b, c] = ip.split('.').map(Number)
    return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || (a === 192 && b === 0 && (c === 0 || c === 2)) ||
      (a === 198 && (b === 18 || b === 19)) || (a === 198 && b === 51 && c === 100) || (a === 203 && b === 0 && c === 113)
  }
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase()
    return l === '::1' || l === '::' || /^f[cd]/.test(l) || /^fe[89abc]/.test(l) || l.startsWith('::ffff:') || l.startsWith('64:ff9b:') ||
      l.startsWith('2001:db8') || l.startsWith('2002:') || l.startsWith('100::')
  }
  return true
}
// ثغرة DNS rebinding: التحقق ثم fetch بيعملوا حلّين منفصلين للدومين. الحل: التحقق جوه الـ lookup نفسه اللي بيتصل بيه الـ socket
function guardedLookup(hostname, opts, cb) {
  dns.lookup(hostname, { all: true }).then((addrs) => {
    if (!addrs.length || addrs.some((a) => isPrivateIp(a.address))) return cb(new Error('العنوان ده غير مسموح (داخلي/محلي)'))
    if (opts?.all) return cb(null, addrs)
    cb(null, addrs[0].address, addrs[0].family)
  }, cb)
}
export function pinnedGet(href, timeout = 10_000) {
  return new Promise((resolve, reject) => {
    const u = new URL(href)
    const lib = u.protocol === 'https:' ? https : http
    const req = lib.request(u, { method: 'GET', lookup: guardedLookup, timeout, headers: { 'user-agent': UA } }, (res) => {
      res.destroy() // محتاجين الهيدرز بس، مش الجسم
      resolve({ status: res.statusCode, headers: { get: (k) => { const v = res.headers[k.toLowerCase()]; return Array.isArray(v) ? v[0] : v ?? null } } })
    })
    req.on('timeout', () => req.destroy(new Error('انتهت المهلة')))
    req.on('error', reject)
    req.end()
  })
}
export async function safeUrl(input) {
  let url
  try { url = new URL(/^https?:\/\//i.test(input) ? input : 'https://' + input) } catch { throw new Error('رابط غير صالح') }
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('بس http/https')
  if (url.port && !['80', '443'].includes(url.port)) throw new Error('البورت ده غير مسموح')
  if (url.username || url.password) throw new Error('الرابط فيه بيانات دخول')
  const addrs = await dns.lookup(url.hostname, { all: true }).catch(() => [])
  if (!addrs.length) throw new Error('الدومين مش موجود')
  if (addrs.some((a) => isPrivateIp(a.address))) throw new Error('العنوان ده غير مسموح (داخلي/محلي)')
  return url
}

const CUR = { دولار: 'USD', يورو: 'EUR', جنيه: 'EGP', ريال: 'SAR', درهم: 'AED', دينار: 'KWD', استرليني: 'GBP', ين: 'JPY', ليرة: 'TRY' }
const toCode = (s) => { const t = s.trim(); if (/^[A-Za-z]{3}$/.test(t)) return t.toUpperCase(); const k = Object.keys(CUR).find((x) => t.includes(x)); return k ? CUR[k] : null }

export function register(c) {
  const { cmd, P, T, panel, kv, norm } = c
  const SEC = 'net'

  cmd(['طقس'], 'all', async (e, args) => {
    const city = args.trim() || c.CONFIG.CITY
    const j = await getJson(`https://wttr.in/${encodeURIComponent(city)}?format=j1&lang=ar`)
    const cur = j.current_condition?.[0]
    if (!cur) throw new Error('مش لاقي المدينة (اكتبها بالإنجليزي)')
    const desc = cur.lang_ar?.[0]?.value || cur.weatherDesc?.[0]?.value || ''
    return e.reply(panel(`🌤 WEATHER · ${city}`, [
      kv('الحالة', desc), kv('الحرارة', `${cur.temp_C}° (تحس بـ ${cur.FeelsLikeC}°)`), kv('الرطوبة', `${cur.humidity}%`), kv('الرياح', `${cur.windspeedKmph} كم/س`),
      '', ...(j.weather || []).slice(0, 3).map((d) => `📅 ${d.date}: ${d.mintempC}° ← ${d.maxtempC}°`),
    ]))
  }, { sec: SEC, d: 'حالة الطقس (باسم المدينة بالإنجليزي)', u: 'طقس Cairo' })

  // بحث في آيات القرآن بكلمة (alquran.cloud)
  cmd(['بحث قرآن', 'بحث في القرآن'], 'all', async (e, args) => {
    const q = args.trim()
    if (!q) return e.reply(`${T.info} اكتب: ${P}بحث قرآن الصبر`)
    if (explicit(q)) return e.reply(BLOCKED_MSG)
    const j = await getJson(`https://api.alquran.cloud/v1/search/${encodeURIComponent(q)}/all/quran-simple`)
    const ms = j?.data?.matches || []
    if (!ms.length) return e.reply(`${T.info} مفيش آيات فيها «${q}»`)
    const rows = ms.slice(0, 5).map((m) => `▸ ﴿${m.text}﴾\n   [${m.surah?.name || ''} : ${m.numberInSurah}]`)
    return e.reply(panel('📖 QURAN SEARCH', [`النتائج: ${j.data.count} آية (أول ${rows.length})`, '', ...rows]))
  }, { sec: SEC, d: 'يدوّر على كلمة في آيات القرآن', u: 'بحث قرآن الصبر' })

  cmd(['ويكي'], 'all', async (e, args) => {
    const q = args.trim()
    if (!q) return e.reply(`${T.info} اكتب: ${P}ويكي الأهرامات`)
    if (explicit(q)) return e.reply(BLOCKED_MSG)
    const summary = async (t) => get(`https://ar.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(t.replace(/ /g, '_'))}`)
    let res = await summary(q)
    if (!res.ok) {
      const s = await getJson(`https://ar.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=1&format=json`)
      const title = s?.[1]?.[0]
      if (!title) throw new Error('مفيش نتيجة في ويكيبيديا')
      res = await summary(title)
    }
    const j = await res.json()
    if (!j.extract) throw new Error('مفيش ملخص للموضوع ده')
    return e.reply(panel(`📚 ${j.title}`, [j.extract.slice(0, 700) + (j.extract.length > 700 ? '…' : ''), '', j.content_urls?.desktop?.page || '']))
  }, { sec: SEC, d: 'ملخص من ويكيبيديا', u: 'ويكي الأهرامات' })

  cmd(['عملة'], 'all', async (e, args) => {
    const m = args.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).match(/^\s*([\d.]+)\s+(\S+)\s+(?:ل|الى|إلى|to)?\s*(\S+)\s*$/)
    const from = m && toCode(m[2]), to = m && toCode(m[3])
    if (!m || !from || !to) return e.reply(`${T.info} اكتب: ${P}عملة 100 USD EGP (أو دولار جنيه)`)
    const j = await getJson(`https://open.er-api.com/v6/latest/${from}`)
    const r = j.rates?.[to]
    if (!r) throw new Error('عملة غير مدعومة')
    return e.reply(panel('💱 CURRENCY', [`${m[1]} ${from} = *${(Number(m[1]) * r).toFixed(2)} ${to}*`, kv('السعر', `1 ${from} = ${r.toFixed(4)} ${to}`)], 'أسعار استرشادية'))
  }, { sec: SEC, d: 'تحويل عملات', u: 'عملة 100 USD EGP' })

  cmd(['اسعار'], 'all', async (e) => {
    const j = await getJson('https://open.er-api.com/v6/latest/USD')
    const r = j.rates
    if (!r?.EGP) throw new Error('الخدمة مش متاحة')
    return e.reply(panel('💹 RATES (مقابل الجنيه المصري)', ['USD', 'EUR', 'GBP', 'SAR', 'AED', 'KWD'].map((k) => kv(k, (r.EGP / r[k]).toFixed(2))), 'أسعار استرشادية'))
  }, { sec: SEC, d: 'أسعار العملات مقابل الجنيه' })

  cmd(['باركود', 'qr'], 'all', async (e, args) => {
    const t = args.trim() || c.quotedText(e.ctx)
    if (!t) return e.reply(`${T.info} اكتب: ${P}باركود نص أو رابط`)
    let QR
    try { QR = (await import('qrcode')).default } catch { throw new Error('ثبّت المكتبة: npm i qrcode') }
    const buf = await QR.toBuffer(t.slice(0, 500), { width: 512, margin: 2 })
    return e.sock.sendMessage(e.jid, { image: buf, caption: '🔳 QR' }, { quoted: e.m })
  }, { sec: SEC, d: 'يعمل QR Code', u: 'باركود نص' })

  cmd(['فحص موقع'], 'all', async (e, args) => {
    if (!args.trim()) return e.reply(`${T.info} اكتب: ${P}فحص موقع example.com`)
    let url = await safeUrl(args.trim().split(/\s+/)[0])
    const t0 = Date.now()
    let res
    for (let hop = 0; hop < 4; hop++) {
      res = await pinnedGet(url.href, 10_000)
      if (res.status >= 300 && res.status < 400 && res.headers.get('location')) { url = await safeUrl(new URL(res.headers.get('location'), url).href); continue }
      break
    }
    return e.reply(panel('🌐 SITE CHECK', [kv('الرابط', url.href.slice(0, 80)), kv('الحالة', `${res.status} ${res.status < 400 ? '🟢' : '🔴'}`), kv('الزمن', `${Date.now() - t0}ms`), kv('السيرفر', res.headers.get('server') || '—'), kv('النوع', (res.headers.get('content-type') || '—').split(';')[0])]))
  }, { sec: SEC, d: 'فحص حالة موقع (آمن: بدون عناوين داخلية)', u: 'فحص موقع example.com' })

  // ── القرآن من alquran.cloud ──
  const parseRef = (args) => {
    const t = args.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).trim()
    let m = t.match(/^(\d{1,3})\s*[:\s]\s*(\d{1,3})$/)
    if (m) return { s: Number(m[1]), a: Number(m[2]) }
    const tok = t.split(/\s+/)
    const last = tok.at(-1)
    if (tok.length > 1 && /^\d+$/.test(last)) { const s = findSurah(tok.slice(0, -1).join(' ')); if (s) return { s, a: Number(last) } }
    return null
  }
  const ayah = (names, edition, title, d) =>
    cmd(names, 'all', async (e, args) => {
      const r = parseRef(args)
      if (!r || r.s < 1 || r.s > 114) return e.reply(`${T.info} اكتب: ${P}${names[0]} 2:255 أو ${P}${names[0]} الكهف 10`)
      const j = await getJson(`https://api.alquran.cloud/v1/ayah/${r.s}:${r.a}/${edition}`)
      if (!j.data?.text) throw new Error('الآية دي مش موجودة')
      return e.reply(panel(`${title} · ${SURAHS[r.s - 1]} ${r.a}`, [j.data.text]))
    }, { sec: SEC, d, u: `${names[0]} 2:255` })
  ayah(['تفسير'], 'ar.muyassar', '📖 التفسير الميسر', 'تفسير آية (الميسر)')
  ayah(['اية رقم'], 'quran-uthmani', '﴿ ﴾', 'نص آية محددة')

  cmd(['نص سورة'], 'all', async (e, args) => {
    const tok = args.trim().split(/\s+/).filter(Boolean)
    let s = 0, from = 1
    for (let k = tok.length; k >= 1 && !s; k--) { s = findSurah(tok.slice(0, k).join(' ')); if (s) { const rest = tok[k]; if (rest && /^\d+$/.test(rest)) from = Number(rest) } }
    if (!s) return e.reply(`${T.info} اكتب: ${P}نص سورة الاخلاص (أو ${P}نص سورة البقرة 50 للبداية من آية)`)
    const j = await getJson(`https://api.alquran.cloud/v1/surah/${s}/quran-uthmani`)
    const ays = (j.data?.ayahs || []).filter((a) => a.numberInSurah >= from)
    if (!ays.length) throw new Error('الآية دي بعد نهاية السورة')
    let out = '', last = from - 1
    for (const a of ays) { const line = `${a.text} ﴿${a.numberInSurah}﴾ `; if ((out + line).length > 3200) break; out += line; last = a.numberInSurah }
    const more = last < j.data.numberOfAyahs ? `\n\n▸ للمتابعة: ${P}نص سورة ${SURAHS[s - 1]} ${last + 1}` : ''
    return e.reply(panel(`📜 سورة ${SURAHS[s - 1]}`, [out.trim() + more]))
  }, { sec: SEC, d: 'نص السورة مكتوب (والمتابعة بالرقم)', u: 'نص سورة الاخلاص' })
}
