// جسر JNI: بيشغّل Node.js (libnode.so) جوه العملية. Node ما يتشغلش مرتين في نفس العملية؛ التطبيق بيعيد تشغيل عملية الخدمة بدل كده.
#include <jni.h>
#include <android/log.h>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <string>
#include <vector>
#include "node.h"

static std::string toStr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_sasa_waguard_NodeBridge_start(JNIEnv *env, jobject /*thiz*/, jobjectArray jargs, jobjectArray jenv,
                                       jstring jcwd, jstring jlog) {
    // 1) تحويل stdout/stderr لملف السجل (الواجهة بتقراه)
    std::string logPath = toStr(env, jlog);
    int fd = open(logPath.c_str(), O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd >= 0) {
        dup2(fd, STDOUT_FILENO);
        dup2(fd, STDERR_FILENO);
        if (fd > STDERR_FILENO) close(fd);
    }
    // 2) متغيرات البيئة
    jsize ne = env->GetArrayLength(jenv);
    for (jsize i = 0; i < ne; i++) {
        std::string kv = toStr(env, (jstring) env->GetObjectArrayElement(jenv, i));
        size_t p = kv.find('=');
        if (p != std::string::npos && p > 0) setenv(kv.substr(0, p).c_str(), kv.substr(p + 1).c_str(), 1);
    }
    // 3) مجلد العمل
    std::string cwd = toStr(env, jcwd);
    if (!cwd.empty() && chdir(cwd.c_str()) != 0)
        __android_log_print(ANDROID_LOG_WARN, "WAGuard", "chdir failed: %s", cwd.c_str());
    // 4) Node بيطلب argv في ذاكرة متصلة
    jsize argc = env->GetArrayLength(jargs);
    std::vector<std::string> a;
    size_t total = 0;
    for (jsize i = 0; i < argc; i++) {
        a.push_back(toStr(env, (jstring) env->GetObjectArrayElement(jargs, i)));
        total += a.back().size() + 1;
    }
    char *buf = (char *) calloc(total + 1, 1);
    std::vector<char *> argv(argc + 1, nullptr);
    char *cur = buf;
    for (jsize i = 0; i < argc; i++) {
        memcpy(cur, a[i].c_str(), a[i].size());
        argv[i] = cur;
        cur += a[i].size() + 1;
    }
    return (jint) node::Start((int) argc, argv.data());
}
