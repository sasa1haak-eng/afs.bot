cmake_minimum_required(VERSION 3.18)
project("nodebridge")

# libnode (من nodejs-mobile) — بيجهّزه سكربت CI داخل app/libnode
set(LIBNODE_DIR ${CMAKE_SOURCE_DIR}/../../../libnode)
add_library(libnode SHARED IMPORTED)
set_target_properties(libnode PROPERTIES IMPORTED_LOCATION ${LIBNODE_DIR}/bin/${ANDROID_ABI}/libnode.so)
include_directories(${LIBNODE_DIR}/include/node)

add_library(nodebridge SHARED native-lib.cpp)
target_link_libraries(nodebridge libnode log)
