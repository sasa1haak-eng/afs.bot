package com.sasa.waguard

/** جسر JNI لتشغيل Node.js. start بيرجع لما Node يخلص (ما بيتشغلش مرتين في نفس العملية). */
object NodeBridge {
    init {
        System.loadLibrary("node")
        System.loadLibrary("nodebridge")
    }

    external fun start(args: Array<String>, env: Array<String>, cwd: String, logPath: String): Int
}
