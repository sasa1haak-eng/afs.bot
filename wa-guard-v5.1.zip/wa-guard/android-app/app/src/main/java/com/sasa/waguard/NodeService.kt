package com.sasa.waguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import org.json.JSONArray
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * خدمة أمامية بتشغّل Node.js في عملية منفصلة (:node).
 * لو Node وقع/خرج: العملية بتتقفل والنظام بيعيد تشغيل الخدمة (START_STICKY) طالما "تشغيل البوت" مفعّل.
 */
class NodeService : Service() {
    companion object {
        const val ACTION_START = "com.sasa.waguard.START"
        const val ACTION_STOP = "com.sasa.waguard.STOP"
        private const val CH = "bot"
        private const val NID = 1
        private val BLOCKED = setOf("WA_STATE_DIR", "DATA_DIR", "HOME", "TMPDIR", "PATH", "LD_LIBRARY_PATH", "LD_PRELOAD", "NODE_OPTIONS", "BOT_NUMBER")
    }

    private var started = false
    private var wake: PowerManager.WakeLock? = null
    private val beat = Executors.newSingleThreadScheduledExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                AppSettings.update(this) { it.wantRunning = false }
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                P.crashes(this).delete()
                AppSettings.update(this) { it.wantRunning = true }
            }
        }
        goForeground("البوت يعمل")
        val st = AppSettings.load(this)
        if (!st.wantRunning) {
            shutdown()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            begin(st)
        }
        return START_STICKY
    }

    private fun goForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "تشغيل البوت", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, NodeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("WA-Guard")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(0, "إيقاف", stop).build())
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NID, n)
        } catch (_: Exception) { /* قيود تشغيل الخدمات من الخلفية */ }
    }

    private fun fail(msg: String) {
        appendLog("[app] $msg")
        AppSettings.update(this) { it.wantRunning = false }
        shutdown()
    }

    private fun begin(st: BotSettings) {
        val app = P.app(this)
        val index = File(app, "index.js")
        if (!index.exists()) return fail("الموارد غير مثبّتة — نزّلها وفك ضغطها أولاً")
        if (!Regex("^[1-9]\\d{7,14}$").matches(st.number)) return fail("رقم الواتساب غير مضبوط")
        if (crashLoop()) return fail("البوت بيتعطل باستمرار (أكتر من 5 مرات في دقيقتين) — راجع السجل ثم اضغط تشغيل")
        val state = P.state(this)
        File(state, "data").mkdirs()
        trimLog()

        wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "waguard:node").apply { acquire() }
        beat.scheduleAtFixedRate({
            try { P.heartbeat(this).writeText(System.currentTimeMillis().toString()) } catch (_: Exception) {}
        }, 0, 5, TimeUnit.SECONDS)

        val env = buildEnv(st, state)
        val args = arrayOf("node", "--max-old-space-size=${st.heapMb}", index.path)
        appendLog("[app] تشغيل Node (${Build.SUPPORTED_ABIS.firstOrNull()}) — الرقم ${st.number.take(3)}****${st.number.takeLast(3)}")
        Thread(null, {
            val code = try {
                NodeBridge.start(args, env, state.path, P.log(this).path)
            } catch (t: Throwable) {
                appendLog("[app] فشل تشغيل Node: ${t.message}")
                -1
            }
            appendLog("[app] Node خرج بكود $code")
            // Node ما ينفعش يتشغل مرتين في نفس العملية: نقفل العملية والنظام يعيد الخدمة (START_STICKY)
            android.os.Process.killProcess(android.os.Process.myPid())
        }, "node", 4L * 1024 * 1024).start()
    }

    private fun buildEnv(st: BotSettings, state: File): Array<String> {
        val m = LinkedHashMap<String, String>()
        for (line in st.extraEnv.lines()) {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            val i = t.indexOf('=')
            if (i <= 0) continue
            val k = t.substring(0, i).trim()
            if (!Regex("^[A-Z_][A-Z0-9_]*$").matches(k) || k in BLOCKED) continue
            m[k] = t.substring(i + 1).trim().trim('"', '\'')
        }
        m["WA_STATE_DIR"] = state.path
        m["DATA_DIR"] = File(state, "data").path
        m["HOME"] = filesDir.path
        m["TMPDIR"] = cacheDir.path
        m["BOT_NUMBER"] = st.number
        if (st.botName.isNotBlank()) m["BOT_NAME"] = st.botName
        m["TZ"] = TimeZone.getDefault().id
        m["NODE_ENV"] = "production"
        return m.map { "${it.key}=${it.value}" }.toTypedArray()
    }

    private fun crashLoop(): Boolean {
        val f = P.crashes(this)
        val now = System.currentTimeMillis()
        val old = try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
        val recent = (0 until old.length()).map { old.getLong(it) }.filter { now - it < 120_000 }.toMutableList()
        recent.add(now)
        f.writeText(JSONArray(recent).toString())
        return recent.size > 5
    }

    private fun trimLog() {
        val f = P.log(this)
        if (!f.exists() || f.length() < 3L * 1024 * 1024) return
        try {
            val keep = 512 * 1024
            val bytes = ByteArray(keep)
            RandomAccessFile(f, "r").use { it.seek(f.length() - keep); it.readFully(bytes) }
            f.writeBytes(bytes)
        } catch (_: Exception) {}
    }

    private fun appendLog(msg: String) {
        try {
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            P.log(this).appendText("$t $msg\n")
        } catch (_: Exception) {}
    }

    private fun shutdown() {
        try { beat.shutdownNow() } catch (_: Exception) {}
        try { wake?.takeIf { it.isHeld }?.release() } catch (_: Exception) {}
        P.heartbeat(this).delete()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Handler(Looper.getMainLooper()).postDelayed({ android.os.Process.killProcess(android.os.Process.myPid()) }, 500)
    }
}
