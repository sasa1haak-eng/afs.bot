package com.sasa.waguard

import android.content.Context
import org.json.JSONObject
import java.io.File

/** مسارات التطبيق. الكود (app) منفصل عن البيانات (state) عشان تحديث الموارد ما يمسحش الجلسات. */
object P {
    fun app(c: Context) = File(c.filesDir, "app")
    fun state(c: Context) = File(c.filesDir, "state").apply { mkdirs() }
    fun log(c: Context) = File(state(c), "bot.log")
    fun zip(c: Context) = File(File(c.filesDir, "dl").apply { mkdirs() }, "resources.zip")
    fun heartbeat(c: Context) = File(c.filesDir, "service.heartbeat")
    fun crashes(c: Context) = File(c.filesDir, "crashes.json")
    fun installed(c: Context) = File(app(c), "index.js").exists()
}

data class BotSettings(
    var resourcesUrl: String = BuildConfig.RESOURCES_URL,
    var number: String = "",
    var botName: String = "",
    var extraEnv: String = "",
    var wantRunning: Boolean = false,
    var heapMb: Int = 384,
)

/** إعدادات في ملف JSON صغير (بيتقرا من عمليتين: الواجهة وخدمة Node). */
object AppSettings {
    private fun file(c: Context) = File(c.filesDir, "settings.json")

    @Synchronized
    fun load(c: Context): BotSettings {
        val d = BotSettings()
        return try {
            val j = JSONObject(file(c).readText())
            BotSettings(
                j.optString("resourcesUrl", d.resourcesUrl).ifBlank { d.resourcesUrl },
                j.optString("number", ""), j.optString("botName", ""), j.optString("extraEnv", ""),
                j.optBoolean("wantRunning", false), j.optInt("heapMb", 384),
            )
        } catch (e: Exception) { d }
    }

    @Synchronized
    fun save(c: Context, s: BotSettings) {
        val j = JSONObject()
            .put("resourcesUrl", s.resourcesUrl).put("number", s.number).put("botName", s.botName)
            .put("extraEnv", s.extraEnv).put("wantRunning", s.wantRunning).put("heapMb", s.heapMb)
        val tmp = File(c.filesDir, "settings.json.tmp")
        tmp.writeText(j.toString())
        tmp.renameTo(file(c))
    }

    fun update(c: Context, f: (BotSettings) -> Unit) { val s = load(c); f(s); save(c, s) }
}
