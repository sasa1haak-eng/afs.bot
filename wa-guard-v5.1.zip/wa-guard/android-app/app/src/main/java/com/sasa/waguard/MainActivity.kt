package com.sasa.waguard

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.RandomAccessFile
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var tvRes: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var tvCode: TextView
    private lateinit var etUrl: EditText
    private lateinit var etNumber: EditText
    private lateinit var etName: EditText
    private lateinit var etEnv: EditText
    private lateinit var pbRes: ProgressBar
    private lateinit var svLog: ScrollView
    private lateinit var cardCode: LinearLayout
    private lateinit var btnDownload: Button
    private lateinit var btnExtract: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnWipeRes: Button
    private lateinit var btnWipeData: Button

    private var busy = false
    private var lastLogLen = -1L
    private var logText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvRes = findViewById(R.id.tvRes); tvStatus = findViewById(R.id.tvStatus); tvLog = findViewById(R.id.tvLog)
        tvCode = findViewById(R.id.tvCode); etUrl = findViewById(R.id.etUrl); etNumber = findViewById(R.id.etNumber)
        etName = findViewById(R.id.etName); etEnv = findViewById(R.id.etEnv); pbRes = findViewById(R.id.pbRes)
        svLog = findViewById(R.id.svLog); cardCode = findViewById(R.id.cardCode)
        btnDownload = findViewById(R.id.btnDownload); btnExtract = findViewById(R.id.btnExtract)
        btnStart = findViewById(R.id.btnStart); btnStop = findViewById(R.id.btnStop)
        btnWipeRes = findViewById(R.id.btnWipeRes); btnWipeData = findViewById(R.id.btnWipeData)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val s = AppSettings.load(this)
        etUrl.setText(s.resourcesUrl); etNumber.setText(s.number); etName.setText(s.botName); etEnv.setText(s.extraEnv)

        btnDownload.setOnClickListener { onDownload() }
        btnExtract.setOnClickListener { onExtract() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveSettings() }
        btnStart.setOnClickListener { onStart() }
        btnStop.setOnClickListener { onStop() }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { onBattery() }
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val code = tvCode.text.toString().replace("-", "")
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code))
            toast("تم نسخ الكود")
        }
        btnWipeRes.setOnClickListener { confirm("حذف الموارد (الكود وملفات التشغيل)؟ بيانات البوت والجلسة مش هتتأثر.") { ResourceManager.wipeResources(this); toast("تم الحذف"); refresh() } }
        btnWipeData.setOnClickListener { confirm("حذف بيانات البوت والجلسة؟ هتحتاج تربط الواتساب من جديد.") { ResourceManager.wipeData(this); lastLogLen = -1; toast("تم الحذف"); refresh() } }
        h.post(tick)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    // ───────── أدوات ─────────
    private fun ui(f: () -> Unit) = runOnUiThread { f() }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun mb(n: Long) = String.format(java.util.Locale.US, "%.1f MB", n / 1048576.0)
    private fun isRunning(): Boolean {
        val f = P.heartbeat(this)
        return f.exists() && System.currentTimeMillis() - f.lastModified() < 15_000
    }
    private fun confirm(msg: String, ok: () -> Unit) {
        if (isRunning()) return toast("أوقف البوت أولاً")
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("نعم") { _, _ -> ok() }.setNegativeButton("إلغاء", null).show()
    }

    private fun runTask(label: String, block: () -> Unit) {
        if (busy) return
        busy = true
        tvRes.text = label
        refresh()
        thread {
            try { block() } catch (e: Exception) { ui { tvRes.text = "❌ ${e.message ?: e.javaClass.simpleName}"; pbRes.progress = 0 } }
            finally { ui { busy = false; refresh() } }
        }
    }

    // ───────── الموارد ─────────
    private fun onDownload() {
        val url = etUrl.text.toString().trim()
        if (url.isEmpty()) return toast("اكتب رابط الموارد أولاً")
        AppSettings.update(this) { it.resourcesUrl = url }
        runTask("جاري التحميل…") {
            val size = ResourceManager.download(this, url) { d, t ->
                ui {
                    pbRes.progress = if (t > 0) (d * 100 / t).toInt() else 0
                    tvRes.text = "تحميل الموارد… ${mb(d)}" + if (t > 0) " / ${mb(t)}" else ""
                }
            }
            ui { pbRes.progress = 100; tvRes.text = "✅ تم التحميل (${mb(size)}) — اضغط «فك ضغط الموارد»" }
        }
    }

    private fun onExtract() {
        if (isRunning()) return toast("أوقف البوت أولاً")
        runTask("جاري فك الضغط…") {
            ResourceManager.extract(this) { i, n ->
                ui { pbRes.progress = if (n > 0) i * 100 / n else 0; tvRes.text = "فك ضغط الموارد… $i / $n" }
            }
            ui { pbRes.progress = 100; tvRes.text = "✅ تم تثبيت الموارد" }
        }
    }

    // ───────── الإعدادات والتشغيل ─────────
    private fun saveSettings(): Boolean {
        val num = etNumber.text.toString().filter { it.isDigit() }
        if (!Regex("^[1-9]\\d{7,14}$").matches(num)) { toast("رقم غير صحيح: اكتبه بالكود الدولي بدون + أو 00"); return false }
        val env = etEnv.text.toString()
        for (l in env.lines()) {
            val t = l.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            if (!Regex("^[A-Z_][A-Z0-9_]*\\s*=.*$").matches(t)) { toast("سطر متغيرات غير صالح: $t"); return false }
        }
        val name = etName.text.toString().trim()
        val url = etUrl.text.toString().trim()
        AppSettings.update(this) { s ->
            s.number = num; s.botName = name; s.extraEnv = env
            if (url.isNotEmpty()) s.resourcesUrl = url
        }
        toast("تم حفظ الإعدادات")
        return true
    }

    private fun onStart() {
        if (!P.installed(this)) return toast("نزّل الموارد وفك ضغطها أولاً")
        if (!saveSettings()) return
        startForegroundService(Intent(this, NodeService::class.java).setAction(NodeService.ACTION_START))
        toast("جاري تشغيل البوت…")
    }

    private fun onStop() {
        AppSettings.update(this) { it.wantRunning = false }
        startService(Intent(this, NodeService::class.java).setAction(NodeService.ACTION_STOP))
        toast("تم الإيقاف")
    }

    private fun onBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) toast("متفعّل بالفعل ✅")
        else startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    // ───────── تحديث الواجهة كل ثانية ─────────
    private fun refresh() {
        val s = AppSettings.load(this)
        val installed = P.installed(this)
        val hasZip = P.zip(this).exists()
        val running = isRunning()

        if (!busy) tvRes.text = when {
            installed -> "✅ الموارد مثبّتة (تقدر تحدّثها بتحميل جديد)"
            hasZip -> "⬇️ الموارد اتحمّلت — اضغط «فك ضغط الموارد»"
            else -> "لم يتم تحميل الموارد بعد — اضغط «تحميل الموارد»"
        }
        btnDownload.isEnabled = !busy && !running
        btnExtract.isEnabled = !busy && !running && hasZip
        btnStart.isEnabled = !busy && !running && installed
        btnStop.isEnabled = running || s.wantRunning
        btnWipeRes.isEnabled = !busy && !running
        btnWipeData.isEnabled = !busy && !running

        val text = tailLog()
        if (text != tvLog.text.toString()) {
            tvLog.text = text
            svLog.post { svLog.fullScroll(android.view.View.FOCUS_DOWN) }
        }
        val idxCode = text.lastIndexOf("كود الربط:")
        val idxOk = text.lastIndexOf("✅ البوت الأساسي شغال")
        val connected = running && idxOk >= 0 && idxOk > idxCode
        var code: String? = null
        if (running && idxCode >= 0 && idxCode > idxOk) {
            code = Regex("كود الربط:\\s*([A-Za-z0-9]{4})-?([A-Za-z0-9]{4})").find(text, idxCode)?.let { it.groupValues[1] + "-" + it.groupValues[2] }
        }
        cardCode.visibility = if (code != null) android.view.View.VISIBLE else android.view.View.GONE
        if (code != null) tvCode.text = code
        tvStatus.text = when {
            running && connected -> "🟢 يعمل ومتصل بواتساب"
            running -> "🟡 يعمل — في انتظار الاتصال/الربط"
            s.wantRunning -> "🟠 جاري (إعادة) التشغيل…"
            else -> "⚪ متوقف"
        }
    }

    private fun tailLog(): String {
        val f = P.log(this)
        if (!f.exists()) return ""
        val len = f.length()
        if (len == lastLogLen) return logText
        lastLogLen = len
        try {
            RandomAccessFile(f, "r").use { r ->
                val keep = minOf(len, 24L * 1024).toInt()
                val b = ByteArray(keep)
                r.seek(len - keep)
                r.readFully(b)
                var t = String(b, Charsets.UTF_8)
                if (len > keep) t = t.substringAfter('\n', t)
                logText = t.lines().takeLast(120).joinToString("\n")
            }
        } catch (_: Exception) {}
        return logText
    }
}
