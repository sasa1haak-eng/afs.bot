package com.sasa.waguard

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile

/** تحميل الموارد وفك ضغطها داخل التطبيق. */
object ResourceManager {
    class Err(msg: String) : Exception(msg)

    private const val MAX_DOWNLOAD = 600L * 1024 * 1024
    private const val MAX_UNPACKED = 1_800L * 1024 * 1024
    private const val MAX_ENTRIES = 200_000

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "WA-Guard-App")
        return c
    }

    /** بيرجّع حجم الملف. onProgress(المحمّل, الإجمالي أو -1) */
    fun download(ctx: Context, url: String, onProgress: (Long, Long) -> Unit): Long {
        if (!url.startsWith("https://")) throw Err("الرابط لازم يبدأ بـ https://")
        val out = P.zip(ctx)
        val part = File(out.parentFile, "resources.zip.part")
        part.delete()
        val conn = open(url)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw Err("فشل التحميل (HTTP $code) — اتأكد من الرابط ومن إن المستودع عام")
            val total = conn.contentLengthLong
            if (total > MAX_DOWNLOAD) throw Err("الملف أكبر من المسموح")
            val md = MessageDigest.getInstance("SHA-256")
            var done = 0L
            var lastTick = 0L
            conn.inputStream.use { ins ->
                part.outputStream().use { os ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        md.update(buf, 0, n)
                        done += n
                        if (done > MAX_DOWNLOAD) throw Err("الملف أكبر من المسموح")
                        val now = System.currentTimeMillis()
                        if (now - lastTick > 250) { lastTick = now; onProgress(done, total) }
                    }
                }
            }
            onProgress(done, total)
            val actual = md.digest().joinToString("") { "%02x".format(it) }
            val expected = fetchSha(url + ".sha256")
            if (expected != null && !expected.equals(actual, ignoreCase = true)) {
                part.delete()
                throw Err("بصمة الملف غير مطابقة (التحميل تالف). حاول تاني.")
            }
            out.delete()
            if (!part.renameTo(out)) throw Err("تعذّر حفظ الملف")
            return out.length()
        } finally {
            conn.disconnect()
            if (part.exists() && !P.zip(ctx).exists()) part.delete()
        }
    }

    private fun fetchSha(url: String): String? = try {
        val c = open(url)
        try {
            if (c.responseCode !in 200..299) null
            else c.inputStream.bufferedReader().readText().trim().split(Regex("\\s+")).firstOrNull()?.takeIf { it.length == 64 }
        } finally { c.disconnect() }
    } catch (e: Exception) { null }

    /** فك الضغط في مجلد مؤقت ثم تبديل مجلد app بشكل ذري. بيانات البوت (state) ما بتتأثرش. */
    fun extract(ctx: Context, onProgress: (Int, Int) -> Unit) {
        val zip = P.zip(ctx)
        if (!zip.exists()) throw Err("نزّل الموارد أولاً")
        val target = File(ctx.filesDir, "app.new")
        target.deleteRecursively()
        target.mkdirs()
        val root = target.canonicalPath
        var total = 0L
        try {
            ZipFile(zip).use { zf ->
                val n = zf.size()
                if (n > MAX_ENTRIES) throw Err("الأرشيف فيه ملفات كتير بشكل غير طبيعي")
                var i = 0
                for (e in zf.entries()) {
                    i++
                    val f = File(target, e.name)
                    val canon = f.canonicalPath
                    if (canon != root && !canon.startsWith(root + File.separator)) throw Err("ملف مشبوه داخل الأرشيف: ${e.name}")
                    if (e.isDirectory) {
                        f.mkdirs()
                    } else {
                        f.parentFile?.mkdirs()
                        zf.getInputStream(e).use { ins ->
                            f.outputStream().use { os ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    val r = ins.read(buf)
                                    if (r < 0) break
                                    total += r
                                    if (total > MAX_UNPACKED) throw Err("حجم الأرشيف بعد الفك كبير بشكل غير طبيعي")
                                    os.write(buf, 0, r)
                                }
                            }
                        }
                    }
                    if (i % 100 == 0 || i == n) onProgress(i, n)
                }
            }
            if (!File(target, "index.js").exists()) throw Err("الأرشيف مش فيه index.js (ملف موارد غلط)")
            val app = P.app(ctx)
            val old = File(ctx.filesDir, "app.old")
            old.deleteRecursively()
            if (app.exists() && !app.renameTo(old)) throw Err("تعذّر استبدال الموارد القديمة (البوت شغال؟ أوقفه أولاً)")
            if (!target.renameTo(app)) {
                old.renameTo(app)
                throw Err("فشل تثبيت الموارد الجديدة")
            }
            old.deleteRecursively()
            zip.delete()
        } catch (e: Exception) {
            target.deleteRecursively()
            throw e
        }
    }

    fun wipeResources(ctx: Context) {
        P.app(ctx).deleteRecursively(); File(ctx.filesDir, "app.new").deleteRecursively()
        File(ctx.filesDir, "app.old").deleteRecursively(); File(ctx.filesDir, "dl").deleteRecursively()
    }

    fun wipeData(ctx: Context) { P.state(ctx).deleteRecursively(); P.crashes(ctx).delete() }
}
