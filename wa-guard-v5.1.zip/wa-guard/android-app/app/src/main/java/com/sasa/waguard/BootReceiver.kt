package com.sasa.waguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!AppSettings.load(c).wantRunning || !P.installed(c)) return
        try { c.startForegroundService(Intent(c, NodeService::class.java)) } catch (_: Exception) {}
    }
}
