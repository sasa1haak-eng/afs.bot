plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// بيتمرر من CI: -PRESOURCES_URL=https://github.com/<user>/<repo>/releases/latest/download/resources.zip
val resUrl = (project.findProperty("RESOURCES_URL") as String?) ?: ""
val verCode = (project.findProperty("VERSION_CODE") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.sasa.waguard"
    compileSdk = 34
    ndkVersion = "26.1.10909125"

    defaultConfig {
        applicationId = "com.sasa.waguard"
        minSdk = 26
        targetSdk = 34 // 34 عشان خدمة dataSync الأمامية ما يطبّقش عليها حد الـ6 ساعات بتاع أندرويد 15
        versionCode = verCode
        versionName = "1.0.$verCode"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild { cmake { arguments += listOf("-DANDROID_STL=c++_shared") } }
        buildConfigField("String", "RESOURCES_URL", "\"$resUrl\"")
    }

    // مفتاح توقيع ثابت: عشان تحديث التطبيق فوق القديم يحافظ على الجلسات (بدون إلغاء تثبيت)
    signingConfigs {
        create("fixed") {
            storeFile = file("waguard.jks")
            storePassword = "waguard123"
            keyAlias = "waguard"
            keyPassword = "waguard123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("fixed") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    // libnode.so (من nodejs-mobile) بيتحط في app/libnode/bin/<abi>/ بواسطة CI
    sourceSets { getByName("main") { jniLibs.srcDirs("libnode/bin") } }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
