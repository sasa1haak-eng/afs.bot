#!/usr/bin/env bash
# يبني حزمة "الموارد" (resources.zip) اللي التطبيق بينزّلها: كود البوت + node_modules (جافاسكريبت فقط).
#   bash android-app/tools/make-resources.sh <مجلد-البوت> <مجلد-الإخراج>
# يستبعد: الأسرار والجلسات و.env وقاعدة البيانات، والمكتبات الثقيلة/الأصلية غير المناسبة للموبايل (tfjs/nsfwjs/canvas).
set -euo pipefail
SRC="${1:?مسار مصدر البوت}"; OUT="${2:?مجلد الإخراج}"
mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT

tar -C "$SRC" \
  --exclude=./node_modules --exclude=./.git --exclude=./.github --exclude=./android-app --exclude=./tests \
  --exclude=./.env --exclude=./auth --exclude=./sessions --exclude=./data --exclude=./bot.lock \
  --exclude='./db.json*' --exclude=./lockdown.json --exclude='*.zip' --exclude=__pycache__ --exclude='*.log' \
  -cf - . | tar -C "$WORK" -xf -
cd "$WORK"

# حذف المكتبات الثقيلة/الأصلية (الميزات المرتبطة بيها بتتعطل بشكل لطيف جوه البوت)
node -e '
const fs=require("fs"); const p=JSON.parse(fs.readFileSync("package.json","utf8"));
for (const k of ["@tensorflow/tfjs","nsfwjs"]) delete (p.dependencies||{})[k];
delete p.optionalDependencies;
fs.writeFileSync("package.json", JSON.stringify(p,null,2));'

if [ "${SKIP_NPM:-0}" != "1" ]; then
  npm install --omit=dev --omit=optional --no-audit --no-fund --ignore-scripts
  find node_modules \( -name '*.md' -o -name '*.map' -o -name '*.ts' -o -name 'LICENSE*' -o -name 'CHANGELOG*' -o -name '.github' -o -name test -o -name tests -o -name __tests__ \) -prune -exec rm -rf {} + 2>/dev/null || true
  rm -rf node_modules/.bin node_modules/.cache
fi

# فحص توافق (Smoke test) تحت نفس إصدار Node اللي بيبني (الأفضل Node 18 زي nodejs-mobile): بيحمّل الوحدات الأساسية كلها.
# لو فشل = البوت هيقع عند التشغيل على الموبايل. بنكمّل البناء (عشان تقدر تجرّب) لكن بنطلّع تحذير واضح.
SMOKE="skipped"
if [ "${SKIP_NPM:-0}" != "1" ] || [ "${FORCE_SMOKE:-0}" = "1" ]; then
  echo "🧪 فحص التوافق على Node $(node -v) ..."
  if SMOKE_OUT="$(node --input-type=module -e "
    await import('./core/compat.js');
    await import('@whiskeysockets/baileys');
    await import('./sessions.js');
    await import('./commands.js');
    console.log('smoke ok');" 2>&1)"; then
    SMOKE="ok"; echo "✅ الوحدات اتحمّلت بنجاح على Node $(node -v)"
  else
    SMOKE="fail"
    echo "$SMOKE_OUT" | tail -25
    echo "::warning title=فحص التوافق فشل::البوت مش هيشتغل على Node $(node -v) — شوف سجل الخطوة (آخر 25 سطر فوق). غالباً مكتبة محتاجة Node أحدث."
  fi
fi

VER="$(node -p 'require("./package.json").version')"
printf '{"name":"wa-guard-resources","version":"%s","builtAt":"%s","nodeBuild":"%s","smoke":"%s"}\n' "$VER" "$(date -u +%FT%TZ)" "$(node -v)" "$SMOKE" > resources.json

rm -f "$OUT/resources.zip" "$OUT/resources.zip.sha256"
zip -qr9 "$OUT/resources.zip" .
( cd "$OUT" && sha256sum resources.zip > resources.zip.sha256 )
echo "✅ $OUT/resources.zip ($(du -h "$OUT/resources.zip" | cut -f1))"
