// ═══════════ مضاد البوتات (نظام نقاط + عقوبة رادعة) ═══════════
// بدل الاعتماد على بصمة واحدة، بنجمع إشارات من الرسالة وسلوك المرسل، ولو النقاط وصلت الحد:
// بنمسح رسايله ونطرده ونحطه في قايمة حظر دايمة (لو اتضاف تاني بيتطرد فوراً).
import { CONFIG, gset, clean, save, log, modlog, recent, deleteKeys, forget, db } from './lib.js'

// أنواع رسائل (أزرار/قوائم/قوالب) الحسابات العادية مبتقدرش تبعتها، يعني بوت أكيد
const HARD_TYPES = ['buttonsMessage', 'listMessage', 'templateMessage', 'interactiveMessage', 'highlyStructuredMessage']
const PREFIXES = [...new Set(['.', '!', '#', '/', '$', CONFIG.PREFIX].filter(Boolean))] // شكل أوامر البوتات
const isCmd = (t = '') => PREFIXES.some((p) => t.startsWith(p) && t.length > p.length && !/\s/.test(t[p.length]) && !PREFIXES.includes(t[p.length]))
const THRESH = { normal: 6, strict: 4 }
const WINDOW = 10 * 60_000 // مدة الذاكرة للنقاط
const REPLY_MS = 3000 // رد على أمر في أقل من كده = بوت غالباً

const evals = new Map() // جروب → آخر 20 تقييم (للتشخيص)
export const idKind = (id = '') =>
  /^BAE5[0-9A-F]{8,}$/.test(id) ? 'Baileys قديم'
    : /^3EB0[0-9A-F]{36}$/.test(id) ? 'مكتبة بوتات (طويل)'
      : /^3EB0[0-9A-F]{18}$/.test(id) ? 'حديث 3EB0 (22)'
        : /^[0-9A-F]{32}$/.test(id) || /^3A[0-9A-F]{16,30}$/.test(id) ? 'تطبيق رسمي'
          : `غير معروف (${id.slice(0, 4)}…${id.length})`
function note(jid, rec) {
  const a = evals.get(jid) ?? []
  a.push({ t: Date.now(), ...rec })
  if (a.length > 20) a.shift()
  evals.set(jid, a)
}
export const noteSkip = (jid, sender, m, key, why) => note(jid, { n: digits(sender), name: m?.pushName || '', id: idKind(key?.id), total: 0, reasons: [], skip: why })
export const recentEvals = (jid) => evals.get(jid) ?? []

const state = new Map() // "جروب|مرسل" → { score, last, once:Set, hits:Map }
const cmdLog = new Map() // جروب → Map(messageId → { t, sender })
const times = new Map() // "جروب|مرسل" → [timestamps]
const busy = new Set()

export const digits = (j = '') => clean(j).split('@')[0].split(':')[0]
// أرقام بوتاتنا (الأساسي والفرعية) ما بتتحسبش بوتات؛ guards.js بيحدد المصدر
let ownFn = () => []
export const setOwnNumbers = (fn) => { ownFn = fn }
const ownNumbers = () => new Set(ownFn().map(digits).filter(Boolean))

// نقاط الرسالة الواحدة: بترجّع { add: [[سبب، نقاط، مرة_واحدة؟]], hard }
export function signals({ key, m, content, text, strict, now = Date.now(), jid, sender }) {
  const out = []
  const id = key?.id || ''
  const types = content ? Object.keys(content) : []
  const first = types[0]
  const ci = first && content[first] && typeof content[first] === 'object' ? content[first].contextInfo : null

  if (types.some((t) => HARD_TYPES.includes(t))) out.push(['رسالة أزرار/قوائم (بوتات بس بتبعتها)', 20, true])
  if (/^BAE5[0-9A-F]{8,}$/.test(id)) out.push(['بصمة Baileys القديمة', 10, true])
  else if (/^3EB0[0-9A-F]{36}$/.test(id)) out.push(['بصمة مكتبة بوتات (معرّف طويل)', 6, true])
  else if (/^3EB0[0-9A-F]{18}$/.test(id)) out.push(['بصمة معرّف مكتبات البوتات الحديثة', strict ? 3 : 2, true])
  else if (/^[0-9A-F]{32}$/.test(id) || /^3A[0-9A-F]{16,30}$/.test(id)) out.push(['معرّف تطبيق رسمي', -6, true])

  if (ci?.externalAdReply) out.push(['إعلان مزيّف مرفق بالرسالة', 4, true])
  if ((ci?.mentionedJid?.length || 0) >= 15) out.push(['منشن جماعي', 3, false])

  const name = m?.pushName || ''
  if (/(^|[\s\-_|.])(bot|بوت)([\s\-_|.0-9]|$)/i.test(name) || /[a-z]Bot\d*$/.test(name) || /بوت$/.test(name))
    out.push([`الاسم بيدل على بوت («${name.slice(0, 20)}»)`, 2, true])

  // رد سريع على أمر (البوتات بترد على الأوامر في ثانية)
  const stanza = ci?.stanzaId
  const cmds = cmdLog.get(jid)
  const c = stanza && cmds?.get(stanza)
  if (c && c.sender !== sender && now - c.t <= REPLY_MS) out.push(['رد فوري على أمر', 2, false])

  // رسايل متتالية بسرعة غير بشرية
  const tk = jid + '|' + sender
  const arr = (times.get(tk) ?? []).filter((t) => now - t < 4000)
  arr.push(now)
  times.set(tk, arr)
  if (arr.length >= 5) { out.push(['رسايل متتالية بسرعة غير بشرية', 2, false]); times.set(tk, []) }
  if (times.size > 4000) times.clear()

  // تسجيل الأوامر العادية (بعد الفحص عشان رسالة الأمر نفسها ما تتحسبش ردّ)
  if (isCmd(text)) {
    const mp = cmdLog.get(jid) ?? new Map()
    mp.set(id, { t: now, sender })
    if (mp.size > 60) mp.delete(mp.keys().next().value)
    cmdLog.set(jid, mp)
  }
  return out
}

// بيحدّث نقاط المرسل ويرجّع { total, reasons, trigger }
export function score(g, env, now = Date.now()) {
  const strict = !!g.antibotStrict
  const k = env.jid + '|' + env.sender
  let s = state.get(k)
  if (!s || now - s.last > WINDOW) s = { score: 0, last: now, once: new Set(), hits: new Map() }
  s.last = now
  for (const [why, pts, once] of signals({ ...env, strict, now })) {
    if (once) { if (s.once.has(why)) continue; s.once.add(why) }
    else { const n = (s.hits.get(why) || 0) + 1; s.hits.set(why, n); if (n > 2) continue } // الإشارات المتكررة بتتحسب مرتين بس (عشان الإنسان ما يتطردش من سلوك سريع)
    s.score += pts
  }
  state.set(k, s)
  if (state.size > 4000) state.clear()
  const reasons = [...s.once, ...s.hits.keys()]
  note(env.jid, { n: digits(env.sender), name: env.m?.pushName || '', id: idKind(env.key?.id), total: s.score, reasons })
  const hard = s.score >= 10
  return { total: s.score, reasons, trigger: s.score >= (strict ? THRESH.strict : THRESH.normal), hard }
}

export const isExempt = (g, sender) => {
  const n = digits(sender)
  return ownNumbers().has(n) || (g.botAllow || []).includes(n)
}

// العقوبة الرادعة
export async function punish({ sock, jid, meta, sender, key, reasons, total }) {
  const g = gset(jid)
  const n = digits(sender)
  const k = jid + '|' + clean(sender)
  if (busy.has(k)) return
  busy.add(k)
  try {
    // 1) نمسح كل رسايله الأخيرة (مش الرسالة دي بس)
    const mine = recent(jid).filter((x) => digits(x.sender) === n).map((x) => x.key)
    const keys = key && !mine.some((x) => x.id === key.id) ? [key, ...mine] : mine
    await deleteKeys(sock, keys.slice(-40), 100)
    forget(jid, keys.map((x) => x.id))
    db.stats.deleted += keys.length
    // 2) نطرده
    let kicked = true
    try { await sock.groupParticipantsUpdate(jid, [sender], 'remove') } catch (e) { kicked = false; log('تعذر طرد البوت:', e.message) }
    if (kicked) db.stats.kicked++
    // 3) حظر دايم: لو اتضاف تاني بيتطرد فوراً
    g.botBan ??= {}
    g.botBan[n] = { t: Date.now(), why: reasons.slice(0, 3).join('، ') }
    modlog(jid, `🤖 بوت اتطرد: ${n} (${reasons.slice(0, 2).join('، ')})`)
    state.delete(k)
    save()
    await sock.sendMessage(jid, {
      text: `🤖🚫 *تم رصد بوت وطرده*\n┃ ▸ الرقم: @${n}\n┃ ▸ نقاط الاشتباه: ${total}\n┃ ▸ الأسباب: ${reasons.slice(0, 3).join(' · ')}\n┃ ▸ اتمسحت رسايله واتحظر من الرجوع للجروب.\n┃ ▸ لو ده خطأ، الأدمن يكتب: .سماح بوت @${n}`,
      mentions: [sender],
    }).catch(() => {})
    log(`🤖 بوت اتطرد | ${meta?.subject} | ${n} | ${reasons.join(' / ')}`)
  } finally {
    setTimeout(() => busy.delete(k), 5000)
  }
}

// عند إضافة عضو جديد: لو هو محظور كبوت بيتطرد فوراً
export async function onJoinCheck(sock, { id, participants, action }) {
  if (action !== 'add') return
  const g = gset(id)
  if (!g.antibot) return
  for (const p of participants) {
    const jid = typeof p === 'string' ? p : p.id
    if (!jid) continue
    const n = digits(jid)
    if (g.botBan?.[n] && !isExempt(g, jid)) {
      try { await sock.groupParticipantsUpdate(id, [jid], 'remove') } catch (e) { log('تعذر طرد بوت محظور:', e.message); continue }
      db.stats.kicked++
      modlog(id, `🤖 بوت محظور اتطرد عند الدخول: ${n}`)
      save()
      await sock.sendMessage(id, { text: `🤖🚫 @${n} محظور كبوت وتم طرده عند الدخول.`, mentions: [jid] }).catch(() => {})
    }
  }
}

// ═══════════ الفحص النشط: نبعت أوامر فخ ونشوف مين بيرد (البوتات بترد على الأوامر، البشر لأ) ═══════════
const TRAPS = ['.menu', '.help', '.ping', '.اوامر', '!help', '/menu']
const GAP = +process.env.ANTIBOT_GAP_MS || 2800
const WAIT = +process.env.ANTIBOT_WAIT_MS || 6000
const SOFT_MS = 3500
const FAST_MS = 2500 // رد طويل/ميديا في أقل من ده بعد فخ = غالباً بوت
const MEDIA = ['imageMessage', 'videoMessage', 'documentMessage', 'audioMessage', 'stickerMessage', 'locationMessage', 'contactMessage', 'pollCreationMessage']
const traps = new Map() // معرّف رسالة الفخ → وقت الإرسال (عشان بوتاتنا تتجاهلها)
const scans = new Map() // جروب → { hits, trapTimes }
const nap = (ms) => new Promise((r) => setTimeout(r, ms))
export const isTrap = (id) => traps.has(id)

// بيتنادى على كل رسالة جروب؛ بيشتغل بس أثناء الفحص
export function observe({ jid, sender, m, content, text = '' }) {
  const sc = scans.get(jid)
  if (!sc) return
  const now = Date.now()
  const n = digits(sender)
  const first = content && Object.keys(content)[0]
  const ci = first && content[first] && typeof content[first] === 'object' ? content[first].contextInfo : null
  const h = sc.hits.get(n) ?? { sender, name: m?.pushName || '', quoted: new Set(), soft: new Set(), fast: new Set() }
  if (ci?.stanzaId && traps.has(ci.stanzaId)) h.quoted.add(ci.stanzaId)
  const last = sc.trapTimes.filter((t) => now - t >= 0).pop()
  if (last != null) {
    if (now - last <= SOFT_MS) h.soft.add(last)
    // قايمة أوامر (نص طويل) أو ميديا في ثانيتين = سرعة غير بشرية
    if (now - last <= FAST_MS && ((text || '').length >= 40 || (first && MEDIA.includes(first)))) h.fast.add(last)
  }
  if (h.quoted.size || h.fast.size) sc.hits.set(n, h)
}

export async function scanBots({ sock, jid, meta, g, kick = false, adminFn = () => false }) {
  if (scans.has(jid)) return { busy: true }
  const sc = { hits: new Map(), trapTimes: [] }
  scans.set(jid, sc)
  try {
    for (const text of TRAPS) {
      const sent = await sock.sendMessage(jid, { text })
      const id = sent?.key?.id
      if (id) traps.set(id, Date.now())
      sc.trapTimes.push(Date.now())
      await nap(GAP)
    }
    await nap(WAIT)
  } finally {
    scans.delete(jid)
    if (traps.size > 300) for (const k of [...traps.keys()].slice(0, 150)) traps.delete(k)
  }
  const suspects = [], admins = []
  for (const [n, h] of sc.hits) {
    const strong = h.quoted.size >= 2 || (h.quoted.size >= 1 && (h.soft.size >= 2 || h.fast.size >= 1)) || h.fast.size >= 2
    if (!strong || isExempt(g, h.sender)) continue
    ;(adminFn(meta, h.sender) ? admins : suspects).push({ n, name: h.name, sender: h.sender, quoted: h.quoted.size, soft: h.soft.size, fast: h.fast.size })
  }
  if (kick) for (const x of suspects) await punish({ sock, jid, meta, sender: x.sender, key: null, reasons: [`رد على أوامر الفحص (${Math.max(x.quoted, x.fast)} مرة)`], total: 10 })
  return { suspects, admins, seen: sc.hits.size }
}

export const _test = { state, cmdLog, times }
