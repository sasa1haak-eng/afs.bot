// فلتر بسيط للبحث والترجمة: يمنع الاستعلامات الإباحية الصريحة (مطابقة كلمة كاملة بعد تطبيع الحروف، عشان "مصر" و"جنسية" ما يتحجبوش)
const norm = (s = '') => s.toLowerCase().replace(/[\u064B-\u065F\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
const WORDS = [
  'سكس', 'جنسي', 'جنسيه', 'جنسيا', 'نيك', 'اباحي', 'اباحيه', 'اباحيات', 'عاري', 'عاريه', 'عاريات', 'فاضح', 'بورن', 'شرموطه', 'قحبه', 'متناك', 'زب', 'كس', 'طيز', 'مص', 'لحس', 'ممحون', 'ممحونه',
  'sex', 'sexy', 'porn', 'porno', 'xxx', 'nude', 'nudes', 'naked', 'hentai', 'xnxx', 'xvideos', 'pornhub', 'onlyfans', 'nsfw', 'erotic', 'milf', 'boobs', 'fuck', 'pussy', 'dick',
].filter((w) => w !== 'جنسيه') // "جنسية" بمعنى الجنسية (نationality) كلمة عادية
const RE = new RegExp(`(^|[^\\p{L}])(?:ال|وال|بال|لل|و|ب|ل)?(${WORDS.map((w) => norm(w)).join('|')})(?![\\p{L}])`, 'iu')
export const explicit = (q = '') => RE.test(norm(q))
export const BLOCKED_MSG = '🚫 البوت ما بيبحثش ولا بيترجم المحتوى ده. جرّب موضوع تاني نافع 🌿'
