// ═══════════ مخزن الاقتصاد والنقاط والـ XP (مشترك بين الألعاب والاقتصاد) ═══════════
import { db, save, clean } from './lib.js'

export const user = (id) => {
  const u = (db.eco[clean(id || '')] ??= { wallet: 0, bank: 0, pts: 0, wins: 0, job: '', shield: 0 })
  u.last ??= {}
  u.inv ??= {}
  return u
}
export const addCoins = (id, n) => {
  const u = user(id)
  u.wallet = Math.max(0, Math.round(u.wallet + n))
  save()
  return u.wallet
}
export const addPts = (id, n, win = false) => {
  const u = user(id)
  u.pts = (u.pts || 0) + n
  if (win) u.wins = (u.wins || 0) + 1
  save()
}
export const cooldownLeft = (u, key, ms) => Math.max(0, (u.last[key] || 0) + ms - Date.now())
export const fmtMs = (ms) => {
  const s = Math.ceil(ms / 1000)
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60
  return [h && `${h} ساعة`, m && `${m} دقيقة`, !h && r && `${r} ثانية`].filter(Boolean).join(' و') || 'لحظات'
}
export const money = (n) => `${Number(n).toLocaleString('en-US')} 🪙`

// ── المستويات (لكل جروب) ──
export const levelOf = (xp) => Math.floor(Math.sqrt(xp / 100))
export function bumpXP(jid, sender) {
  const g = (db.xp[jid] ??= {})
  const u = (g[clean(sender)] ??= { xp: 0, msgs: 0, t: 0 })
  u.msgs++
  if (Date.now() - u.t < 30_000) return { up: false, level: levelOf(u.xp), xp: u.xp }
  const before = levelOf(u.xp)
  u.xp += 5 + Math.floor(Math.random() * 11)
  u.t = Date.now()
  if (u.msgs % 10 === 0) save()
  const level = levelOf(u.xp)
  return { up: level > before, level, xp: u.xp }
}

// ═══════════ الوظائف (مشتركة بين الاقتصاد والألعاب) ═══════════
// tier: 0 = متاحة للكل · 1 = بعد 20 مرة عمل · 2 = بعد 60 مرة عمل
export const JOBS = {
  فلاح: { icon: '🌾', tier: 0, pay: [80, 220], perk: 'محصول إضافي (+2) في كل زراعة' },
  نجار: { icon: '🔨', tier: 0, pay: [100, 250], perk: 'خام إضافي (+1) في كل تعدين' },
  طباخ: { icon: '🍳', tier: 0, pay: [90, 240], perk: 'بيع السمك والمحاصيل بزيادة 15%' },
  سواق: { icon: '🚕', tier: 0, pay: [100, 260], cd: 20, perk: 'استراحة أقصر: شغل كل 20 دقيقة بدل 30' },
  صياد: { icon: '🎣', tier: 0, pay: [90, 230], perk: 'سمكة إضافية (+1) في كل صيدة' },
  مدرس: { icon: '📚', tier: 1, pay: [150, 330], perk: 'جوايز الأسئلة والألعاب ×1.25' },
  مصور: { icon: '📸', tier: 1, pay: [150, 340], perk: '12% فرصة بقشيش 250 🪙 بعد كل شغل' },
  تاجر: { icon: '🏪', tier: 1, pay: [160, 330], perk: 'بيع كل حاجة بزيادة 10% وخصم 10% في المتجر' },
  مبرمج: { icon: '💻', tier: 2, pay: [220, 460], perk: 'دخل الشغل ×1.25' },
  طبيب: { icon: '🩺', tier: 2, pay: [230, 450], perk: 'مدة الدرع ×2' },
  مهندس: { icon: '📐', tier: 2, pay: [230, 450], perk: 'الراتب اليومي ×1.3' },
  // وظائف إضافية 6.0 (دخل أعلى حسب المستوى، بدون ميزات خاصة)
  حداد: { icon: '⚒️', tier: 0, pay: [90, 230], perk: 'دخل فقط' },
  خباز: { icon: '🥖', tier: 0, pay: [85, 225], perk: 'دخل فقط' },
  راعي: { icon: '🐑', tier: 0, pay: [80, 210], perk: 'دخل فقط' },
  نادل: { icon: '🍽️', tier: 0, pay: [85, 220], perk: 'دخل فقط' },
  بائع: { icon: '🛒', tier: 0, pay: [90, 230], perk: 'دخل فقط' },
  عامل: { icon: '👷', tier: 0, pay: [95, 235], perk: 'دخل فقط' },
  ميكانيكي: { icon: '🔧', tier: 0, pay: [100, 250], perk: 'دخل فقط' },
  كهربائي: { icon: '💡', tier: 0, pay: [100, 255], perk: 'دخل فقط' },
  سباك: { icon: '🚰', tier: 0, pay: [100, 250], perk: 'دخل فقط' },
  حلاق: { icon: '💈', tier: 0, pay: [90, 235], perk: 'دخل فقط' },
  ساعي: { icon: '📦', tier: 0, pay: [85, 225], perk: 'دخل فقط' },
  بستاني: { icon: '🌳', tier: 0, pay: [85, 225], perk: 'دخل فقط' },
  كاتب: { icon: '✍️', tier: 1, pay: [140, 320], perk: 'دخل فقط' },
  محاسب: { icon: '🧾', tier: 1, pay: [150, 335], perk: 'دخل فقط' },
  صيدلي: { icon: '💊', tier: 1, pay: [155, 340], perk: 'دخل فقط' },
  ممرض: { icon: '🩹', tier: 1, pay: [150, 335], perk: 'دخل فقط' },
  شرطي: { icon: '👮', tier: 1, pay: [150, 330], perk: 'دخل فقط' },
  اطفائي: { icon: '🧯', tier: 1, pay: [150, 335], perk: 'دخل فقط' },
  طيار: { icon: '✈️', tier: 2, pay: [230, 460], perk: 'دخل فقط' },
  محامي: { icon: '⚖️', tier: 2, pay: [225, 450], perk: 'دخل فقط' },
  مصمم: { icon: '🎨', tier: 1, pay: [150, 335], perk: 'دخل فقط' },
  مونتير: { icon: '🎬', tier: 1, pay: [150, 335], perk: 'دخل فقط' },
  'محلل امن': { icon: '🛡️', tier: 2, pay: [230, 460], perk: 'دخل فقط' },
  'مهندس شبكات': { icon: '🌐', tier: 2, pay: [225, 450], perk: 'دخل فقط' },
  'محلل بيانات': { icon: '📊', tier: 2, pay: [225, 450], perk: 'دخل فقط' },
  'مطور ويب': { icon: '🖥️', tier: 2, pay: [225, 455], perk: 'دخل فقط' },
  'مدير مشروع': { icon: '📋', tier: 2, pay: [225, 450], perk: 'دخل فقط' },
  'عالم': { icon: '🔬', tier: 2, pay: [230, 455], perk: 'دخل فقط' },
}
export const TIER_NEED = [0, 20, 60]
export const RANKS = [
  { at: 0, name: 'متدرب', mult: 1 },
  { at: 10, name: 'موظف', mult: 1.2 },
  { at: 30, name: 'محترف', mult: 1.5 },
  { at: 70, name: 'خبير', mult: 1.9 },
  { at: 150, name: 'مدير', mult: 2.5 },
]
export const jobOf = (u) => (u.job && JOBS[u.job] ? { name: u.job, ...JOBS[u.job] } : null)
export const rankOf = (u) => [...RANKS].reverse().find((r) => (u.jobWorks || 0) >= r.at) || RANKS[0]
export const hasJob = (id, name) => user(id).job === name

// ═══════════ المهام اليومية ═══════════
const cairoDay = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Africa/Cairo' })
export const MISSIONS = [
  { id: 'work', key: 'work', goal: 3, reward: 300, text: 'اشتغل 3 مرات (عمل)' },
  { id: 'fish', key: 'fish', goal: 3, reward: 350, text: 'اصطد 3 مرات (صيد)' },
  { id: 'mine', key: 'mine', goal: 2, reward: 320, text: 'استخرج معادن مرتين (تعدين)' },
  { id: 'farm', key: 'farm', goal: 2, reward: 320, text: 'ازرع واحصد مرتين (زراعة)' },
  { id: 'sold', key: 'sold', goal: 500, reward: 280, text: 'بيع حاجات بقيمة 500 🪙' },
  { id: 'quiz', key: 'quiz', goal: 3, reward: 400, text: 'جاوب 3 أسئلة صح (سؤال، لغز، عواصم...)' },
  { id: 'win', key: 'win', goal: 2, reward: 350, text: 'اكسب لعبتين (أي لعبة)' },
  { id: 'million', key: 'million_q', goal: 5, reward: 500, text: 'جاوب 5 أسئلة صح في «مليون»' },
  { id: 'deposit', key: 'deposit', goal: 1000, reward: 250, text: 'ودّع 1000 🪙 في البنك' },
  { id: 'salary', key: 'salary', goal: 1, reward: 150, text: 'استلم راتبك اليومي' },
  { id: 'buy', key: 'buy', goal: 1, reward: 200, text: 'اشتري أي حاجة من المتجر' },
  { id: 'sadaqa', key: 'sadaqa', goal: 1, reward: 250, text: 'تصدّق بأي مبلغ (صدقة)' },
  { id: 'trade', key: 'trade', goal: 1, reward: 300, text: 'بيع بضاعة في السوق (سوق)' },
  { id: 'daily', key: 'quest', goal: 1, reward: 200, text: 'خلّص مهمة سريعة (مهمة)' },
]
export function missionsOf(id) {
  const u = user(id)
  const day = cairoDay()
  if (!u.mq || u.mq.day !== day) {
    const list = [...MISSIONS].sort(() => Math.random() - 0.5).slice(0, 3).map((m) => m.id)
    u.mq = { day, list, prog: {}, claimed: [], bonus: false }
    save()
  }
  return u.mq
}
export function track(id, key, n = 1) {
  if (!id) return
  const q = missionsOf(id)
  q.prog[key] = (q.prog[key] || 0) + n
}
