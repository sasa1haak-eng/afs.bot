#!/usr/bin/env python3
"""مراقب نظام خفيف (لينكس/تيرمكس) بالمكتبة القياسية: حمل المعالج، الذاكرة، القرص، مع تنبيه بحدود.

  python3 sysmon.py                 # قراءة واحدة
  python3 sysmon.py -i 5            # كل 5 ثواني (Ctrl+C للإيقاف)
  python3 sysmon.py --mem 85 --disk 90
"""
import argparse, os, shutil, time


def mem_percent():
    info = {}
    with open("/proc/meminfo") as f:
        for line in f:
            k, v = line.split(":")
            info[k] = int(v.split()[0])
    total, avail = info["MemTotal"], info.get("MemAvailable", info["MemFree"])
    return 100 * (total - avail) / total, total / 1024


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-i", "--interval", type=float, default=0)
    ap.add_argument("--mem", type=float, default=90); ap.add_argument("--disk", type=float, default=90)
    ap.add_argument("--path", default=os.path.expanduser("~"))
    a = ap.parse_args()
    cores = os.cpu_count() or 1
    while True:
        l1, l5, l15 = os.getloadavg()
        mp, mt = mem_percent()
        du = shutil.disk_usage(a.path)
        dp = 100 * du.used / du.total
        alerts = []
        if l1 > cores * 1.5: alerts.append("حمل المعالج عالي")
        if mp > a.mem: alerts.append("الذاكرة ممتلئة")
        if dp > a.disk: alerts.append("القرص ممتلئ")
        print(f"[{time.strftime('%H:%M:%S')}] load {l1:.2f}/{cores}c | RAM {mp:.0f}% of {mt:.0f}MB | disk {dp:.0f}% ({du.free / 1e9:.1f}GB free)" + (("  🚨 " + "، ".join(alerts)) if alerts else ""))
        if not a.interval:
            break
        time.sleep(a.interval)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
