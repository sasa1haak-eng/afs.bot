#!/usr/bin/env python3
"""حساب بصمة الملفات والتحقق منها (للتأكد إن التحميل سليم ومتعدّلش).

  python3 hash_tool.py file.zip                         # SHA-256
  python3 hash_tool.py file.zip -a sha512
  python3 hash_tool.py file.zip --verify <البصمة المنشورة>
"""
import argparse, hashlib, hmac, sys


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+")
    ap.add_argument("-a", "--algo", default="sha256", choices=["md5", "sha1", "sha256", "sha512"])
    ap.add_argument("--verify", help="البصمة المتوقعة (ملف واحد)")
    a = ap.parse_args()
    bad = 0
    for path in a.files:
        h = hashlib.new(a.algo)
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        digest = h.hexdigest()
        if a.verify:
            ok = hmac.compare_digest(digest, a.verify.strip().lower())
            print(("✅ متطابقة" if ok else "❌ غير متطابقة — لا تستخدم الملف"), path)
            bad += 0 if ok else 1
        else:
            print(f"{digest}  {path}")
    if a.algo in ("md5", "sha1"):
        print("ملاحظة: MD5/SHA-1 ضعيفين ضد التلاعب المتعمّد؛ فضّل SHA-256.", file=sys.stderr)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
