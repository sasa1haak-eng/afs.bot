#!/usr/bin/env python3
"""فاحص روابط التصيّد (تقديري، بدون إنترنت): يعطي نقاط خطورة بناءً على علامات شائعة في الروابط المزيفة.

  python3 phish_url_check.py "http://paypa1-secure-login.xyz/verify?acc=1"
مش بديل لفحص حقيقي (Safe Browsing/VirusTotal)، لكنه بيعلّمك تقرأ الرابط صح.
"""
import ipaddress, re, sys, urllib.parse

SHORTENERS = {"bit.ly", "tinyurl.com", "cutt.ly", "is.gd", "rb.gy", "t.ly", "goo.gl", "ow.ly", "shorturl.at"}
BAD_TLDS = {"xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "link", "icu", "buzz", "zip", "mov", "work"}
BRANDS = ["paypal", "google", "facebook", "instagram", "whatsapp", "apple", "microsoft", "amazon", "netflix", "binance", "bank"]
WORDS = ["login", "signin", "verify", "secure", "account", "update", "confirm", "wallet", "suspend", "gift", "free", "claim"]


def analyze(url):
    u = urllib.parse.urlparse(url if "://" in url else "http://" + url)
    host = (u.hostname or "").lower()
    score, why = 0, []

    def add(n, msg):
        nonlocal score
        score += n
        why.append(msg)

    try:
        ipaddress.ip_address(host)
        add(3, "الدومين عنوان IP")
    except ValueError:
        pass
    if u.scheme == "http":
        add(1, "بدون HTTPS")
    if "@" in u.netloc:
        add(3, "فيه @ لإخفاء الوجهة الحقيقية")
    if host.startswith("xn--") or ".xn--" in host:
        add(3, "دومين punycode (حروف مموّهة)")
    if host in SHORTENERS:
        add(2, "رابط مختصر يخفي الوجهة")
    tld = host.rsplit(".", 1)[-1]
    if tld in BAD_TLDS:
        add(2, f"امتداد مشبوه .{tld}")
    if host.count(".") >= 4:
        add(2, "عدد كبير من النطاقات الفرعية")
    if host.count("-") >= 3:
        add(1, "شرطات كتير في الدومين")
    base = ".".join(host.split(".")[-2:])
    norm = host.translate(str.maketrans("0135@$", "oleasS".lower()[:5] + "s"))
    for b in BRANDS:
        if b in norm:
            if b not in host:
                add(3, f"استبدال حروف بأرقام لتقليد «{b}»")
            elif not base.startswith(b + "."):
                add(3, f"اسم علامة «{b}» داخل دومين مش تابع لها")
            break
    hits = [w for w in WORDS if w in (host + u.path).lower()]
    if hits:
        add(min(3, len(hits)), "كلمات استدراج: " + ", ".join(hits[:4]))
    if len(url) > 100:
        add(1, "رابط طويل جداً")
    return score, why, host


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    score, why, host = analyze(sys.argv[1])
    level = "🟢 منخفضة" if score < 3 else "🟡 متوسطة" if score < 6 else "🔴 عالية"
    print(f"الدومين: {host}\nالخطورة: {level} ({score} نقطة)")
    for w in why:
        print("  -", w)
    print("\nقبل ما تدخل أي بيانات: افتح الموقع الرسمي بنفسك من المتصفح.")


if __name__ == "__main__":
    main()
