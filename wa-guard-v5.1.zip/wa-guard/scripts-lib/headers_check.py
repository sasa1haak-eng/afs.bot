#!/usr/bin/env python3
"""فحص هيدرات الأمان وكوكيز موقعك (HTTP security headers) وإعطاء تقييم.

  python3 headers_check.py https://example.com
افحص مواقعك أنت فقط. الأداة بتعمل طلب GET واحد عادي.
"""
import sys, urllib.request, urllib.error

CHECKS = [
    ("Strict-Transport-Security", "HSTS: يجبر HTTPS", 2),
    ("Content-Security-Policy", "CSP: يقلل ضرر XSS", 3),
    ("X-Content-Type-Options", "يمنع تخمين نوع الملف (nosniff)", 1),
    ("X-Frame-Options", "يمنع التضمين في iframe (أو CSP frame-ancestors)", 1),
    ("Referrer-Policy", "يتحكم في تسريب الـ Referer", 1),
    ("Permissions-Policy", "يقيّد صلاحيات المتصفح", 1),
]


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith(("http://", "https://")):
        sys.exit(__doc__)
    opener = urllib.request.build_opener(NoRedirect)
    try:
        r = opener.open(urllib.request.Request(sys.argv[1], headers={"User-Agent": "headers-check/1.0"}), timeout=10)
    except urllib.error.HTTPError as e:
        r = e
    h = {k.lower(): v for k, v in r.headers.items()}
    print(f"الحالة: {r.status if hasattr(r, 'status') else r.code}")
    if r.headers.get("Location"):
        print("↪ تحويل إلى:", r.headers["Location"])
    score = total = 0
    for name, why, w in CHECKS:
        total += w
        ok = name.lower() in h or (name == "X-Frame-Options" and "frame-ancestors" in h.get("content-security-policy", ""))
        score += w if ok else 0
        print(f"  {'✅' if ok else '❌'} {name:<28} {why}")
    for banner in ("server", "x-powered-by"):
        if banner in h:
            print(f"  ⚠️ إفصاح عن التقنية: {banner}: {h[banner]} (يُفضّل إخفاؤه)")
    for c in r.headers.get_all("Set-Cookie") or []:
        low = c.lower()
        miss = [f for f, k in (("Secure", "secure"), ("HttpOnly", "httponly"), ("SameSite", "samesite")) if k not in low]
        print(f"  🍪 {c.split('=')[0]}: {'ناقص ' + ', '.join(miss) if miss else 'سليم'}")
    print(f"\nالتقييم: {score}/{total}")


if __name__ == "__main__":
    main()
