// هيكل API بسيط وآمن بـ Express: هيدرات أمان، حد معدل، حجم جسم محدود، تحقق مدخلات، ومعالج أخطاء لا يسرّب التفاصيل.
// التشغيل:
//   mkdir api && cd api && npm init -y && npm pkg set type=module
//   npm i express helmet express-rate-limit
//   (انسخ الملف هنا باسم server.js)   ثم:   node server.js
// جرّب: curl -s localhost:3000/users/42  |  curl -s -X POST localhost:3000/notes -H 'content-type: application/json' -d '{"title":"مرحبا"}'
import express from 'express'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'

const app = express()
app.disable('x-powered-by')
app.use(helmet())
app.use(express.json({ limit: '10kb' }))
app.use(rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }))

const notes = []

app.get('/users/:id', (req, res) => {
  const id = Number(req.params.id)
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'id غير صالح' })
  res.json({ id }) // في تطبيق حقيقي: تحقق إن المستخدم الحالي له حق على هذا المورد (منع IDOR)
})

app.post('/notes', (req, res) => {
  const { title } = req.body ?? {}
  if (typeof title !== 'string' || title.length < 1 || title.length > 100) return res.status(400).json({ error: 'title لازم نص من 1 لـ 100 حرف' })
  const note = { id: notes.length + 1, title }
  notes.push(note)
  res.status(201).json(note)
})

app.use((req, res) => res.status(404).json({ error: 'غير موجود' }))
app.use((err, req, res, _next) => {
  console.error(err) // السجل داخلي فقط
  res.status(err.status === 413 || err.status === 400 ? err.status : 500).json({ error: 'خطأ في الطلب' })
})

const port = Number(process.env.PORT) || 3000
app.listen(port, '127.0.0.1', () => console.log(`API على http://127.0.0.1:${port}`)) // اربط على localhost خلف nginx
