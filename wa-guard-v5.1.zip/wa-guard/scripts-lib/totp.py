#!/usr/bin/env python3
"""مولّد أكواد TOTP (RFC 6238) بالمكتبة القياسية — علشان تفهم إزاي بيشتغل التحقق بخطوتين.

  python3 totp.py --selftest        # اختبار بمتجه RFC الرسمي
  python3 totp.py JBSWY3DPEHPK3PXP  # السر Base32 (جرّب بسر تجريبي، مش سر حسابك الحقيقي)
للاستخدام الفعلي فضّل تطبيق مصادقة موثوق أو مفتاح FIDO2.
"""
import base64, hashlib, hmac, struct, sys, time


def totp(secret_b32, t=None, step=30, digits=6, algo=hashlib.sha1):
    key = base64.b32decode(secret_b32.upper().replace(" ", "") + "=" * (-len(secret_b32.replace(" ", "")) % 8))
    counter = int((time.time() if t is None else t) // step)
    mac = hmac.new(key, struct.pack(">Q", counter), algo).digest()
    off = mac[-1] & 0x0F
    code = (struct.unpack(">I", mac[off:off + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return str(code).zfill(digits)


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    if sys.argv[1] == "--selftest":
        secret = base64.b32encode(b"12345678901234567890").decode()
        got = totp(secret, t=59, digits=8)
        print("RFC 6238 (t=59):", got, "✅" if got == "94287082" else "❌")
        sys.exit(0 if got == "94287082" else 1)
    print(totp(sys.argv[1]), f"(باقي {30 - int(time.time()) % 30} ثانية)")


if __name__ == "__main__":
    main()
