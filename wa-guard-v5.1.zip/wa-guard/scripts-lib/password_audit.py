#!/usr/bin/env python3
"""تدقيق كلمة السر: قوة + هل ظهرت في تسريبات (عبر Have I Been Pwned بطريقة k-anonymity).

  python3 password_audit.py          (بتكتب الباسورد مخفي، مش في سطر الأوامر)
بيبعت أول 5 خانات من SHA-1 فقط للسيرفر؛ كلمة السر نفسها ما بتخرجش من جهازك.
"""
import getpass, hashlib, math, re, sys, urllib.request

COMMON = {"password", "123456", "12345678", "qwerty", "111111", "iloveyou", "admin", "welcome", "letmein", "abc123", "000000", "password1", "ahmed123", "محمد123"}


def entropy_bits(pw):
    pool = 0
    pool += 26 if re.search(r"[a-z]", pw) else 0
    pool += 26 if re.search(r"[A-Z]", pw) else 0
    pool += 10 if re.search(r"\d", pw) else 0
    pool += 33 if re.search(r"[^\w\s]", pw) else 0
    pool += 40 if re.search(r"[\u0600-\u06ff]", pw) else 0
    return len(pw) * math.log2(pool) if pool else 0


def pwned_count(pw):
    sha = hashlib.sha1(pw.encode()).hexdigest().upper()
    prefix, suffix = sha[:5], sha[5:]
    req = urllib.request.Request(f"https://api.pwnedpasswords.com/range/{prefix}", headers={"User-Agent": "password-audit", "Add-Padding": "true"})
    with urllib.request.urlopen(req, timeout=10) as r:
        for line in r.read().decode().splitlines():
            h, _, c = line.partition(":")
            if h == suffix:
                return int(c)
    return 0


def main():
    pw = getpass.getpass("كلمة السر: ")
    if not pw:
        sys.exit("فاضية")
    bits = entropy_bits(pw)
    notes = []
    if len(pw) < 12:
        notes.append("قصيرة: استخدم 14 حرف أو أكتر")
    if pw.lower() in COMMON:
        notes.append("من أشهر كلمات السر")
    if re.search(r"(.)\1{2,}", pw):
        notes.append("فيها تكرار حروف")
    if re.search(r"(012|123|234|345|456|567|678|789|abc|qwe)", pw.lower()):
        notes.append("فيها تسلسل سهل")
    level = "ضعيفة 🔴" if bits < 45 else "متوسطة 🟡" if bits < 70 else "قوية 🟢"
    print(f"الطول: {len(pw)} | الإنتروبيا التقريبية: {bits:.0f} بت → {level}")
    for n in notes:
        print("  -", n)
    try:
        c = pwned_count(pw)
        print(f"🚨 ظهرت في تسريبات {c:,} مرة: غيّرها فوراً" if c else "✅ مش موجودة في التسريبات المعروفة")
    except Exception as e:
        print("تعذّر فحص التسريبات (محتاج إنترنت):", e)


if __name__ == "__main__":
    main()
