#!/usr/bin/env python3
"""فحص شهادة TLS لموقعك: المُصدر، تاريخ الانتهاء، البروتوكول، ومتبقي كام يوم.

  python3 tls_check.py example.com [443]
خرج 1 لو الشهادة قاربت تنتهي (أقل من 14 يوم) أو فشل التحقق — مناسب لـ cron وتنبيه.
"""
import datetime, socket, ssl, sys


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    host, port = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 443
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((host, port), timeout=10) as s, ctx.wrap_socket(s, server_hostname=host) as t:
            cert, ver, cipher = t.getpeercert(), t.version(), t.cipher()
    except ssl.SSLCertVerificationError as e:
        print("❌ فشل التحقق من الشهادة:", e.verify_message)
        sys.exit(1)
    except OSError as e:
        sys.exit(f"تعذّر الاتصال: {e}")
    exp = datetime.datetime.fromtimestamp(ssl.cert_time_to_seconds(cert["notAfter"]), datetime.timezone.utc)
    days = (exp - datetime.datetime.now(datetime.timezone.utc)).days
    dn = lambda x: ", ".join("=".join(i) for r in x for i in r)
    print(f"الموقع:     {host}\nالمُصدر:    {dn(cert['issuer'])}\nالموضوع:    {dn(cert['subject'])}")
    print(f"ينتهي:      {exp:%Y-%m-%d} (متبقي {days} يوم)\nالبروتوكول: {ver} | التشفير: {cipher[0]}")
    if ver in ("TLSv1", "TLSv1.1"):
        print("⚠️ بروتوكول قديم")
    if days < 14:
        print("🚨 الشهادة قاربت تنتهي: جدّدها")
        sys.exit(1)
    print("✅ سليمة")


if __name__ == "__main__":
    main()
