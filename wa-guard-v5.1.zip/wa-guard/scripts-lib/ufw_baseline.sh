#!/usr/bin/env bash
# إعداد جدار حماية ufw أساسي: امنع الداخل افتراضياً، اسمح بـ SSH (مع حد للمحاولات) والويب لو عايز.
# افتراضياً بيعرض الأوامر بس (Dry-run). للتنفيذ الفعلي أضف --apply وشغّله بـ sudo.
#   bash ufw_baseline.sh --ssh-port 22 --web            # عرض
#   sudo bash ufw_baseline.sh --ssh-port 22 --web --apply
# ⚠️ لو بتشتغل عن بعد: تأكد من منفذ SSH الصحيح قبل --apply وإلا هتقفل على نفسك.
set -euo pipefail
SSH_PORT=22; WEB=0; APPLY=0
while [ $# -gt 0 ]; do case "$1" in
  --ssh-port) SSH_PORT="$2"; shift 2;;
  --web) WEB=1; shift;;
  --apply) APPLY=1; shift;;
  *) echo "خيار غير معروف: $1"; exit 1;; esac; done
[[ "$SSH_PORT" =~ ^[0-9]+$ ]] || { echo "منفذ SSH غير صالح"; exit 1; }
CMDS=("ufw default deny incoming" "ufw default allow outgoing" "ufw limit ${SSH_PORT}/tcp")
[ "$WEB" -eq 1 ] && CMDS+=("ufw allow 80/tcp" "ufw allow 443/tcp")
CMDS+=("ufw --force enable" "ufw status verbose")
if [ "$APPLY" -ne 1 ]; then echo "# Dry-run — الأوامر اللي هتتنفّذ:"; printf '%s\n' "${CMDS[@]}"; exit 0; fi
[ "$(id -u)" -eq 0 ] || { echo "شغّله بـ sudo"; exit 1; }
command -v ufw >/dev/null || { echo "ثبّت ufw الأول: apt install ufw"; exit 1; }
for c in "${CMDS[@]}"; do echo "+ $c"; $c; done
