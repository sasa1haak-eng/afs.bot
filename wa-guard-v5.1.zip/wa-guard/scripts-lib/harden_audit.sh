#!/usr/bin/env bash
# تدقيق أمني للقراءة فقط على لينكس/VPS: بيفحص إعدادات شائعة ويقولك إيه اللي محتاج تحسين. مش بيغيّر أي حاجة.
#   bash harden_audit.sh        (الأفضل بـ sudo لنتائج أكمل)
set -u
ok()   { printf '  ✅ %s\n' "$1"; }
warn() { printf '  ⚠️  %s\n' "$1"; WARN=$((WARN+1)); }
WARN=0

echo "== SSH =="
CFG=/etc/ssh/sshd_config
if [ -r "$CFG" ]; then
  grep -Eiq '^\s*PermitRootLogin\s+(no|prohibit-password)' "$CFG" && ok "دخول root مقيّد" || warn "PermitRootLogin مش مقفول (اضبطه no)"
  grep -Eiq '^\s*PasswordAuthentication\s+no' "$CFG" && ok "دخول الباسورد معطّل (مفاتيح فقط)" || warn "PasswordAuthentication مفعّل: استخدم مفاتيح SSH"
else echo "  (sshd_config مش متاح)"; fi

echo "== جدار الحماية =="
if command -v ufw >/dev/null; then ufw status 2>/dev/null | grep -q "Status: active" && ok "ufw شغّال" || warn "ufw موجود بس مش مفعّل"
else warn "ufw مش متثبت (أو استخدم nftables/iptables)"; fi

echo "== الحسابات =="
if [ -r /etc/shadow ]; then
  EMPTY=$(awk -F: '($2=="" ){print $1}' /etc/shadow)
  [ -z "$EMPTY" ] && ok "مفيش حسابات بباسورد فاضي" || warn "حسابات بباسورد فاضي: $EMPTY"
else echo "  (محتاج sudo لفحص shadow)"; fi
UID0=$(awk -F: '($3==0 && $1!="root"){print $1}' /etc/passwd)
[ -z "$UID0" ] && ok "root هو الحساب الوحيد UID 0" || warn "حسابات UID=0 إضافية: $UID0"

echo "== الملفات =="
WW=$(find / -xdev -type f -perm -0002 -not -path '/proc/*' -not -path '/sys/*' -not -path '/tmp/*' -not -path '/var/tmp/*' -not -path '/dev/*' 2>/dev/null | head -5)
[ -z "$WW" ] && ok "مفيش ملفات قابلة للكتابة من الجميع (عينة)" || warn "ملفات قابلة للكتابة من الجميع:"$'\n'"$WW"
SUID=$(find / -xdev -perm -4000 -type f 2>/dev/null | wc -l)
echo "  ℹ️  ملفات SUID: $SUID (راجع القائمة بـ: find / -xdev -perm -4000 -type f)"

echo "== التحديثات =="
if command -v apt >/dev/null; then
  N=$(apt list --upgradable 2>/dev/null | grep -c upgradable)
  [ "$N" -eq 0 ] && ok "مفيش تحديثات معلّقة" || warn "$N تحديث معلّق: sudo apt update && sudo apt upgrade"
  dpkg -s unattended-upgrades >/dev/null 2>&1 && ok "التحديث التلقائي الأمني متثبت" || warn "فعّل unattended-upgrades"
fi

echo "== المنافذ المفتوحة =="
command -v ss >/dev/null && ss -tulpn 2>/dev/null | awk 'NR>1{print "  "$1" "$5}' | head -15

echo; echo "النتيجة: $WARN تحذير"
