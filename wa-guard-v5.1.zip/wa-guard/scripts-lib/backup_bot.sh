#!/usr/bin/env bash
# نسخ احتياطي مضغوط لبيانات البوت (db.json, auth, sessions, .env, data) مع بصمة SHA-256 وتدوير النسخ القديمة.
#   bash backup_bot.sh                       # من مجلد ~/wa-guard
#   BOT_DIR=~/wa-guard KEEP=10 bash backup_bot.sh
# الاسترجاع:  tar -xzf wa-guard-YYYY-MM-DD_HHMMSS.tar.gz -C ~/wa-guard
# ⚠️ النسخة فيها جلسة واتساب وأسرار: اتحفظ في مكان خاص ومتتشاركش.
set -euo pipefail
BOT_DIR="${BOT_DIR:-$HOME/wa-guard}"
KEEP="${KEEP:-7}"
DEST="${DEST:-}"
if [ -z "$DEST" ]; then
  if [ -d "$HOME/storage/shared" ]; then DEST="$HOME/storage/shared/wa-guard-backups"; else DEST="$HOME/wa-guard-backups"; fi
fi
mkdir -p "$DEST"; chmod 700 "$DEST" 2>/dev/null || true
cd "$BOT_DIR"
ITEMS=()
for x in db.json auth sessions .env data; do [ -e "$x" ] && ITEMS+=("$x"); done
[ "${#ITEMS[@]}" -gt 0 ] || { echo "مفيش بيانات للنسخ في $BOT_DIR"; exit 1; }
OUT="$DEST/wa-guard-$(date +%F_%H%M%S).tar.gz"
tar -czf "$OUT" "${ITEMS[@]}"
chmod 600 "$OUT" 2>/dev/null || true
( cd "$DEST" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256" )
echo "✅ $OUT ($(du -h "$OUT" | cut -f1))"
# تدوير: احتفظ بآخر $KEEP نسخ
ls -1t "$DEST"/wa-guard-*.tar.gz 2>/dev/null | tail -n +$((KEEP+1)) | while read -r old; do rm -f "$old" "$old.sha256"; echo "🗑️ حذف قديم: $(basename "$old")"; done
