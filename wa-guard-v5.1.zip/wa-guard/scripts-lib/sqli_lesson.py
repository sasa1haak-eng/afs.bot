#!/usr/bin/env python3
"""درس تطبيقي: ليه حقن SQL بيحصل وإزاي استعلام مهيّأ بيمنعه (على قاعدة بيانات تجريبية في الذاكرة).

  python3 sqli_lesson.py
بيشتغل على sqlite داخل الذاكرة ببيانات وهمية؛ مفيش أي اتصال بالخارج.
"""
import sqlite3

db = sqlite3.connect(":memory:")
db.executescript("""
CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, password_hash TEXT, is_admin INTEGER);
INSERT INTO users VALUES (1, 'sara', 'hash-aaa', 0), (2, 'admin', 'hash-bbb', 1);
""")


def login_vulnerable(name):
    q = f"SELECT name, is_admin FROM users WHERE name = '{name}'"      # ❌ دمج مباشر
    return q, db.execute(q).fetchall()


def login_safe(name):
    q = "SELECT name, is_admin FROM users WHERE name = ?"            # ✅ استعلام مهيّأ
    return q, db.execute(q, (name,)).fetchall()


for payload in ["sara", "x' OR '1'='1"]:
    print(f"\nالمدخل: {payload!r}")
    for label, fn in (("غير آمن", login_vulnerable), ("آمن   ", login_safe)):
        q, rows = fn(payload)
        print(f"  [{label}] {q}\n            → {rows}")

print("\nالدرس: المدخل الخبيث اتعامل معاه كـ SQL في النسخة الأولى (رجّع كل المستخدمين)، وكنص عادي في الثانية.")
print("القواعد: استعلامات مهيّأة دايماً، أقل صلاحيات لحساب القاعدة، تحقق من المدخلات، ومتعرضش رسائل الخطأ للمستخدم.")
