#!/usr/bin/env python3
"""اكتشاف الأجهزة المتصلة بشبكتك المحلية (ping sweep) — شبكات خاصة فقط.

مثال:  python3 lan_sweep.py 192.168.1.0/24
الفائدة: تعرف مين على شبكتك وتكتشف أي جهاز غريب. (بعض الأجهزة تتجاهل ping)
"""
import ipaddress, socket, subprocess, sys
from concurrent.futures import ThreadPoolExecutor


def ping(ip):
    try:
        r = subprocess.run(["ping", "-c", "1", "-W", "1", str(ip)], capture_output=True, timeout=4)
        return str(ip) if r.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def name(ip):
    try:
        return socket.gethostbyaddr(ip)[0]
    except OSError:
        return "-"


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    net = ipaddress.ip_network(sys.argv[1], strict=False)
    if not net.is_private:
        sys.exit("الشبكة لازم تكون خاصة (192.168.x.x أو 10.x.x.x أو 172.16-31.x.x).")
    if net.num_addresses > 1024:
        sys.exit("النطاق كبير؛ الحد /22 (1024 عنوان).")
    with ThreadPoolExecutor(64) as ex:
        alive = [ip for ip in ex.map(ping, net.hosts()) if ip]
    print(f"الأجهزة النشطة في {net}: {len(alive)}")
    for ip in alive:
        print(f"  {ip:<16} {name(ip)}")


if __name__ == "__main__":
    main()
