#!/usr/bin/env bash
# يكتب إعداد fail2ban بسيط لحماية SSH من القوة الغاشمة (حجب ساعة بعد 5 محاولات).
# Dry-run افتراضياً: بيطبع الملف. للتنفيذ:  sudo bash fail2ban_setup.sh --apply
set -euo pipefail
read -r -d '' JAIL <<'CFG' || true
[DEFAULT]
bantime  = 1h
findtime = 10m
maxretry = 5
backend  = auto

[sshd]
enabled = true
CFG
if [ "${1:-}" != "--apply" ]; then echo "# /etc/fail2ban/jail.local (Dry-run)"; echo "$JAIL"; exit 0; fi
[ "$(id -u)" -eq 0 ] || { echo "شغّله بـ sudo"; exit 1; }
command -v fail2ban-client >/dev/null || { apt-get install -y fail2ban; }
[ -f /etc/fail2ban/jail.local ] && cp /etc/fail2ban/jail.local "/etc/fail2ban/jail.local.bak.$(date +%s)"
printf '%s\n' "$JAIL" > /etc/fail2ban/jail.local
systemctl enable --now fail2ban && fail2ban-client status sshd
