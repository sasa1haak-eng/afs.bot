#!/usr/bin/env python3
"""ترتيب مجلد فوضوي: ينقل الملفات لمجلدات حسب النوع (صور/مستندات/فيديو/...).

  python3 file_organizer.py ~/Downloads            # معاينة فقط
  python3 file_organizer.py ~/Downloads --apply    # تنفيذ
مش بيستبدل ملفات موجودة؛ لو الاسم متكرر بيضيف رقم.
"""
import argparse, os, shutil

TYPES = {
    "صور": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"},
    "فيديو": {".mp4", ".mkv", ".avi", ".mov", ".webm"},
    "صوت": {".mp3", ".wav", ".ogg", ".m4a", ".opus", ".flac"},
    "مستندات": {".pdf", ".doc", ".docx", ".txt", ".odt", ".ppt", ".pptx", ".xls", ".xlsx", ".csv"},
    "أرشيف": {".zip", ".rar", ".7z", ".tar", ".gz"},
    "أكواد": {".py", ".js", ".ts", ".sh", ".json", ".html", ".css", ".md"},
    "برامج": {".apk", ".exe", ".msi", ".deb"},
}


def category(ext):
    for name, exts in TYPES.items():
        if ext in exts:
            return name
    return "أخرى"


def unique(path):
    base, ext = os.path.splitext(path)
    n = 1
    while os.path.exists(path):
        path = f"{base} ({n}){ext}"
        n += 1
    return path


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    moved = 0
    for fn in sorted(os.listdir(a.folder)):
        src = os.path.join(a.folder, fn)
        if not os.path.isfile(src) or fn.startswith("."):
            continue
        dst_dir = os.path.join(a.folder, category(os.path.splitext(fn)[1].lower()))
        dst = unique(os.path.join(dst_dir, fn))
        print(f"{'نقل' if a.apply else 'سيُنقل'}: {fn} → {os.path.basename(dst_dir)}/")
        if a.apply:
            os.makedirs(dst_dir, exist_ok=True)
            shutil.move(src, dst)
        moved += 1
    print(f"\n{moved} ملف" + ("" if a.apply else " (معاينة — أضف --apply للتنفيذ)"))


if __name__ == "__main__":
    main()
