#!/usr/bin/env python3
"""فاحص منافذ TCP — للأجهزة التي تملكها أو لديك إذن كتابي بفحصها فقط.

أمثلة:
  python3 port_scanner.py 192.168.1.1                 # أشهر المنافذ
  python3 port_scanner.py 127.0.0.1 -p 1-1024 --banner
  python3 port_scanner.py 203.0.113.5 --authorized    # عنوان عام: لازم تأكيد الإذن
"""
import argparse, ipaddress, json, socket, sys, time
from concurrent.futures import ThreadPoolExecutor

COMMON = {21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http", 110: "pop3",
          143: "imap", 443: "https", 445: "smb", 993: "imaps", 995: "pop3s", 1433: "mssql",
          3306: "mysql", 3389: "rdp", 5432: "postgres", 5900: "vnc", 6379: "redis",
          8080: "http-alt", 8443: "https-alt", 9200: "elasticsearch", 27017: "mongodb"}
RISKY = {23, 445, 3389, 5900, 6379, 9200, 27017, 3306, 5432, 1433}


def parse_ports(spec):
    ports = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            ports.update(range(int(a), int(b) + 1))
        elif part:
            ports.add(int(part))
    bad = [p for p in ports if not 1 <= p <= 65535]
    if bad:
        raise ValueError(f"منفذ غير صالح: {bad[0]}")
    return sorted(ports)


def check(ip, port, timeout, banner):
    try:
        with socket.create_connection((ip, port), timeout=timeout) as s:
            info = ""
            if banner:
                s.settimeout(timeout)
                try:
                    if port in (80, 8080, 8443):
                        s.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                    info = s.recv(120).decode("utf-8", "replace").strip().splitlines()[0][:100]
                except Exception:
                    pass
            return port, True, info
    except OSError:
        return port, False, ""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("host")
    ap.add_argument("-p", "--ports", default=",".join(map(str, COMMON)))
    ap.add_argument("-t", "--timeout", type=float, default=1.0)
    ap.add_argument("-w", "--workers", type=int, default=100)
    ap.add_argument("--banner", action="store_true", help="محاولة قراءة سطر ترحيب الخدمة")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--authorized", action="store_true", help="أؤكد أن عندي إذن بفحص هذا العنوان العام")
    a = ap.parse_args()

    try:
        ip = socket.gethostbyname(a.host)
        addr = ipaddress.ip_address(ip)
        ports = parse_ports(a.ports)
    except (socket.gaierror, ValueError) as e:
        sys.exit(f"خطأ: {e}")
    if not (addr.is_private or addr.is_loopback) and not a.authorized:
        sys.exit("العنوان عام. افحص أجهزتك المحلية أو أضف --authorized لو عندك إذن كتابي.")
    workers = max(1, min(a.workers, 300))

    t0 = time.time()
    with ThreadPoolExecutor(workers) as ex:
        results = list(ex.map(lambda p: check(ip, p, a.timeout, a.banner), ports))
    open_ports = [(p, b) for p, ok, b in results if ok]

    if a.json:
        print(json.dumps({"host": a.host, "ip": ip, "open": [{"port": p, "service": COMMON.get(p, "?"), "banner": b} for p, b in open_ports]}, ensure_ascii=False, indent=2))
        return
    print(f"الهدف: {a.host} ({ip}) | فُحص {len(ports)} منفذ في {time.time() - t0:.1f}ث")
    if not open_ports:
        print("لا توجد منافذ مفتوحة ضمن النطاق.")
    for p, b in open_ports:
        flag = "  ⚠️ منفذ حساس: اقفله أو قيّده بجدار حماية" if p in RISKY else ""
        print(f"  {p:>5}/tcp  {COMMON.get(p, '?'):<14}{b}{flag}")


if __name__ == "__main__":
    main()
