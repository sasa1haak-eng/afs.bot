#!/usr/bin/env python3
"""ماسح أسرار: يدوّر على مفاتيح API وتوكنات وباسوردات اتنسّت داخل الكود قبل ما ترفعه على Git.

  python3 secrets_scan.py ~/wa-guard
خرج 1 لو لقى حاجة (مناسب كـ pre-commit hook). النتائج بتتعرض مقنّعة.
لو لقيت سر: غيّره فوراً من مصدره، ومسحه من الكود مش كفاية لو اترفع.
"""
import os, re, sys

RULES = {
    "AWS Access Key": r"AKIA[0-9A-Z]{16}",
    "GitHub token": r"gh[pousr]_[A-Za-z0-9]{36,}",
    "Slack token": r"xox[baprs]-[A-Za-z0-9-]{10,}",
    "Private key": r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----",
    "Google API key": r"AIza[0-9A-Za-z_\-]{35}",
    "JWT": r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}",
    "كلمة سر في الكود": r"(?i)(?:password|passwd|secret|api[_-]?key|token)\s*[:=]\s*['\"][^'\"\s]{8,}['\"]",
}
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv"}
SKIP_EXT = {".png", ".jpg", ".jpeg", ".gif", ".zip", ".gz", ".mp3", ".mp4", ".pdf", ".woff", ".woff2", ".ttf", ".lock"}
COMPILED = {k: re.compile(v) for k, v in RULES.items()}


def mask(s):
    return s[:4] + "…" + s[-2:] if len(s) > 8 else "***"


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    found = 0
    for base, dirs, files in os.walk(sys.argv[1]):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fn in files:
            p = os.path.join(base, fn)
            if os.path.splitext(fn)[1].lower() in SKIP_EXT or os.path.getsize(p) > 2_000_000:
                continue
            try:
                lines = open(p, encoding="utf-8", errors="ignore").read().splitlines()
            except OSError:
                continue
            for i, line in enumerate(lines, 1):
                for name, rx in COMPILED.items():
                    m = rx.search(line)
                    if m:
                        found += 1
                        print(f"🚨 {name}: {os.path.relpath(p, sys.argv[1])}:{i}  {mask(m.group(0))}")
    if fn_env := [f for f in os.listdir(sys.argv[1]) if f == ".env"]:
        print("ℹ️ فيه ملف .env — تأكد إنه في .gitignore")
    print("✅ نظيف" if not found else f"\nإجمالي: {found}")
    sys.exit(1 if found else 0)


if __name__ == "__main__":
    main()
