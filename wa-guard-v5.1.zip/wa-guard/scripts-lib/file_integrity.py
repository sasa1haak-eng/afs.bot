#!/usr/bin/env python3
"""مراقب سلامة الملفات (FIM): يحفظ بصمة SHA-256 لكل ملف ثم يكشف أي إضافة/تعديل/حذف.

  python3 file_integrity.py init  ~/wa-guard  -b base.json     # أول مرة
  python3 file_integrity.py check ~/wa-guard  -b base.json     # كل فترة (cron)
خرج الأمر = 1 لو في تغيير، فتقدر تربطه بتنبيه.
"""
import argparse, hashlib, json, os, sys

SKIP_DIRS = {".git", "node_modules", "__pycache__"}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def snapshot(root, ignore):
    out = {}
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fn in files:
            p = os.path.join(base, fn)
            rel = os.path.relpath(p, root)
            if any(rel.endswith(x) for x in ignore) or os.path.islink(p):
                continue
            try:
                out[rel] = sha256(p)
            except OSError:
                pass
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("mode", choices=["init", "check"])
    ap.add_argument("root")
    ap.add_argument("-b", "--baseline", default="baseline.json")
    ap.add_argument("-i", "--ignore", nargs="*", default=[".log", "db.json"], help="لواحق ملفات بتتغير طبيعي")
    a = ap.parse_args()
    cur = snapshot(a.root, a.ignore)
    if a.mode == "init":
        with open(a.baseline, "w") as f:
            json.dump(cur, f, indent=1)
        os.chmod(a.baseline, 0o600)
        print(f"تم حفظ {len(cur)} بصمة في {a.baseline}")
        return
    with open(a.baseline) as f:
        base = json.load(f)
    added = sorted(set(cur) - set(base))
    removed = sorted(set(base) - set(cur))
    changed = sorted(k for k in cur if k in base and cur[k] != base[k])
    for tag, items in (("➕ جديد", added), ("✏️ معدّل", changed), ("➖ محذوف", removed)):
        for k in items:
            print(f"{tag}: {k}")
    if not (added or removed or changed):
        print("✅ لا تغييرات.")
        return
    sys.exit(1)


if __name__ == "__main__":
    main()
