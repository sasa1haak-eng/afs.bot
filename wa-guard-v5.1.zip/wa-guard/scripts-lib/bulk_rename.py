#!/usr/bin/env python3
r"""إعادة تسمية جماعية بالـ regex مع معاينة.

  python3 bulk_rename.py ./photos '^IMG_(\d+)' 'رحلة_\1'          # معاينة
  python3 bulk_rename.py ./photos '\s+' '_' --apply
بيرفض لو الاسم الجديد هيتعارض مع ملف موجود أو فيه مسارات.
"""
import argparse, os, re


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder"); ap.add_argument("pattern"); ap.add_argument("repl")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    rx = re.compile(a.pattern)
    names = sorted(os.listdir(a.folder))
    plan = {}
    for n in names:
        new = rx.sub(a.repl, n)
        if new != n:
            if os.sep in new or new in ("", ".", ".."):
                raise SystemExit(f"اسم غير صالح: {new!r}")
            plan[n] = new
    targets = list(plan.values())
    clash = [t for t in targets if targets.count(t) > 1 or (t in names and t not in plan)]
    if clash:
        raise SystemExit(f"تعارض أسماء: {clash[0]!r} — عدّل النمط")
    for old, new in plan.items():
        print(f"{old}  →  {new}")
        if a.apply:
            os.rename(os.path.join(a.folder, old), os.path.join(a.folder, new))
    print(f"\n{len(plan)} ملف" + ("" if a.apply else " (معاينة — أضف --apply)"))


if __name__ == "__main__":
    main()
