#!/usr/bin/env python3
"""جامع بيانات صفحات ويب مؤدّب: يحترم robots.txt، يضيف تأخير بين الطلبات، ويطلّع العنوان والعناوين والروابط JSON.

  python3 polite_scraper.py https://example.com --delay 2 --out page.json
بالمكتبة القياسية فقط. افحص شروط استخدام الموقع قبل الجمع، ومتجمعش بيانات شخصية.
"""
import argparse, json, sys, time, urllib.parse, urllib.request, urllib.robotparser
from html.parser import HTMLParser

UA = "polite-scraper/1.0 (+contact: you@example.com)"


class Page(HTMLParser):
    def __init__(self):
        super().__init__(); self.title = ""; self.h = []; self.links = []; self._in = None
    def handle_starttag(self, tag, attrs):
        if tag in ("title", "h1", "h2", "h3"): self._in = tag
        if tag == "a":
            href = dict(attrs).get("href")
            if href: self.links.append(href)
    def handle_endtag(self, tag):
        if tag == self._in: self._in = None
    def handle_data(self, data):
        d = data.strip()
        if not d or not self._in: return
        if self._in == "title": self.title += d
        else: self.h.append({"tag": self._in, "text": d})


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("url"); ap.add_argument("--delay", type=float, default=2.0); ap.add_argument("--out")
    a = ap.parse_args()
    u = urllib.parse.urlparse(a.url)
    if u.scheme not in ("http", "https"):
        sys.exit("http/https فقط")
    rp = urllib.robotparser.RobotFileParser(f"{u.scheme}://{u.netloc}/robots.txt")
    try:
        rp.read()
    except Exception:
        pass
    if not rp.can_fetch(UA, a.url):
        sys.exit("robots.txt بيمنع الجمع من الصفحة دي — احترم ده.")
    time.sleep(a.delay)
    req = urllib.request.Request(a.url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=15) as r:
        html = r.read(2_000_000).decode(r.headers.get_content_charset() or "utf-8", "replace")
    p = Page(); p.feed(html)
    data = {"url": a.url, "title": p.title, "headings": p.h[:50], "links": sorted({urllib.parse.urljoin(a.url, l) for l in p.links})[:100]}
    out = json.dumps(data, ensure_ascii=False, indent=2)
    if a.out:
        open(a.out, "w", encoding="utf-8").write(out); print("تم:", a.out)
    else:
        print(out)


if __name__ == "__main__":
    main()
