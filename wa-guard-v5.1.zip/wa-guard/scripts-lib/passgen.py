#!/usr/bin/env python3
"""مولّد كلمات سر وعبارات مرور باستخدام secrets (عشوائية آمنة للتشفير).

  python3 passgen.py                     # كلمة سر 20 حرف
  python3 passgen.py -n 24 --no-symbols
  python3 passgen.py --phrase 6          # عبارة من 6 كلمات
  python3 passgen.py --phrase 6 --wordlist words.txt   # قائمة كلمات كبيرة (أفضل)
"""
import argparse, math, secrets, string

BUILTIN = ("شجرة قطار ملح نهر جبل بحر قمر نجمة سحابة مطر رمل حجر ورقة قلم كتاب باب نافذة سيارة طائرة ساعة مفتاح "
           "حديقة وردة عصفور سمكة حصان نمر أسد غزال صقر تفاحة برتقال عنب زيتون عسل خبز شاي قهوة حليب جبنة "
           "مدينة قرية طريق جسر ميناء مطار مدرسة جامعة مكتبة مصنع مزرعة غابة صحراء واحة بركان شلال كهف "
           "ذهب فضة نحاس حديد زجاج خشب قماش حرير صوف ثلج نار ريح رعد برق ضباب فجر ظهر عصر مغرب ليل").split()


def password(n, symbols):
    chars = string.ascii_letters + string.digits + ("!@#$%^&*()-_=+[]{}?" if symbols else "")
    while True:
        pw = "".join(secrets.choice(chars) for _ in range(n))
        if any(c.islower() for c in pw) and any(c.isupper() for c in pw) and any(c.isdigit() for c in pw) and (not symbols or any(c in "!@#$%^&*()-_=+[]{}?" for c in pw)):
            return pw, n * math.log2(len(chars))


def phrase(n, words):
    return "-".join(secrets.choice(words) for _ in range(n)), n * math.log2(len(words))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-n", type=int, default=20)
    ap.add_argument("--no-symbols", action="store_true")
    ap.add_argument("--phrase", type=int, metavar="WORDS")
    ap.add_argument("--wordlist")
    ap.add_argument("--count", type=int, default=1)
    a = ap.parse_args()
    words = BUILTIN
    if a.wordlist:
        words = [w.strip() for w in open(a.wordlist, encoding="utf-8") if w.strip()]
    for _ in range(max(1, min(a.count, 20))):
        if a.phrase:
            out, bits = phrase(a.phrase, words)
        else:
            if a.n < 8:
                raise SystemExit("الحد الأدنى 8")
            out, bits = password(a.n, not a.no_symbols)
        print(out, f"   (~{bits:.0f} بت)")
    if a.phrase and not a.wordlist:
        print("ملاحظة: القائمة المدمجة صغيرة؛ استخدم --wordlist بقائمة 5000+ كلمة أو زوّد عدد الكلمات.")


if __name__ == "__main__":
    main()
