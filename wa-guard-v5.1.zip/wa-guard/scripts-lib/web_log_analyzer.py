#!/usr/bin/env python3
"""محلل سجلات nginx/apache (صيغة combined): يكشف محاولات الحقن والمسح الآلي وأكتر العناوين نشاطاً.

  python3 web_log_analyzer.py /var/log/nginx/access.log
مفيد لموقعك أنت: يوريك إيه اللي بيحاول يدخل عليه، وتضيف لها قواعد حجب (WAF/Rate limit).
"""
import collections, re, sys, urllib.parse

LINE = re.compile(r'^(\S+) \S+ \S+ \[[^\]]+\] "(\S+) (\S+) [^"]*" (\d{3}) \S+')
PATTERNS = {
    "SQLi": re.compile(r"(union(\s|\+|%20)+select|or(\s|\+|%20)+1=1|information_schema|sleep\(\d)", re.I),
    "XSS": re.compile(r"(<script|javascript:|onerror=|onload=)", re.I),
    "Path traversal": re.compile(r"(\.\./|%2e%2e%2f|/etc/passwd)", re.I),
    "ملفات حساسة": re.compile(r"(/\.env|/\.git/|wp-config|phpmyadmin|/backup\.(zip|sql))", re.I),
    "مسح لوحات إدارة": re.compile(r"(wp-login|/xmlrpc\.php|/admin(\.php)?$|/cgi-bin/)", re.I),
}


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    ips, status, hits = collections.Counter(), collections.Counter(), collections.defaultdict(collections.Counter)
    total = 0
    with open(sys.argv[1], errors="replace") as f:
        for line in f:
            m = LINE.match(line)
            if not m:
                continue
            ip, _method, path, code = m.groups()
            total += 1
            ips[ip] += 1
            status[code[0] + "xx"] += 1
            decoded = urllib.parse.unquote(path)
            for name, rx in PATTERNS.items():
                if rx.search(decoded) or rx.search(path):
                    hits[name][ip] += 1
    print(f"طلبات: {total} | حالات: {dict(status)}")
    print("\nأكتر العناوين طلباً:")
    for ip, n in ips.most_common(5):
        print(f"  {ip:<40} {n}")
    for name, c in hits.items():
        print(f"\n🚩 {name}: {sum(c.values())} محاولة من {len(c)} عنوان")
        for ip, n in c.most_common(3):
            print(f"    {ip}  ({n})")
    if not hits:
        print("\n✅ لا أنماط هجوم واضحة.")


if __name__ == "__main__":
    main()
