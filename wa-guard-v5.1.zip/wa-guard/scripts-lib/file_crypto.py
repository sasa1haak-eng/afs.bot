#!/usr/bin/env python3
"""تشفير وفك تشفير الملفات بكلمة سر (AES عبر Fernet + اشتقاق مفتاح PBKDF2-SHA256).

  pip install cryptography
  python3 file_crypto.py enc secret.pdf        → secret.pdf.enc
  python3 file_crypto.py dec secret.pdf.enc    → secret.pdf
كلمة السر بتتكتب مخفية. لو ضاعت، الملف مش بيرجع. الملف الأصلي بيفضل زي ما هو (احذفه بنفسك بعد التأكد).
"""
import base64, getpass, os, sys

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
except ImportError:
    sys.exit("ثبّت المكتبة: pip install cryptography")

MAGIC = b"WGC1"
ITER = 600_000


def key_from(password, salt):
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITER)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ("enc", "dec"):
        sys.exit(__doc__)
    mode, path = sys.argv[1], sys.argv[2]
    data = open(path, "rb").read()
    if mode == "enc":
        pw = getpass.getpass("كلمة السر: ")
        if len(pw) < 10 or pw != getpass.getpass("أعد كتابتها: "):
            sys.exit("كلمة السر لازم 10 أحرف على الأقل ومتطابقة")
        salt = os.urandom(16)
        out = path + ".enc"
        if os.path.exists(out):
            sys.exit(f"{out} موجود بالفعل")
        with open(out, "wb") as f:
            f.write(MAGIC + salt + Fernet(key_from(pw, salt)).encrypt(data))
        os.chmod(out, 0o600)
        print("تم:", out)
    else:
        if data[:4] != MAGIC:
            sys.exit("الملف مش من الأداة دي")
        salt, token = data[4:20], data[20:]
        try:
            plain = Fernet(key_from(getpass.getpass("كلمة السر: "), salt)).decrypt(token)
        except InvalidToken:
            sys.exit("كلمة سر غلط أو الملف تالف")
        out = path[:-4] if path.endswith(".enc") else path + ".dec"
        if os.path.exists(out):
            sys.exit(f"{out} موجود بالفعل")
        with open(out, "wb") as f:
            f.write(plain)
        print("تم:", out)


if __name__ == "__main__":
    main()
