#!/usr/bin/env python3
"""كاشف الملفات المكررة: يجمّع حسب الحجم ثم SHA-256 (دقيق 100%). مش بيحذف — بيعرض بس.

  python3 dup_finder.py ~/Pictures
  python3 dup_finder.py ~/Pictures --move-to ~/dups     # ينقل النسخ الزايدة (يسيب أول ملف)
"""
import argparse, collections, hashlib, os, shutil


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder"); ap.add_argument("--move-to")
    a = ap.parse_args()
    by_size = collections.defaultdict(list)
    for base, _d, files in os.walk(a.folder):
        for fn in files:
            p = os.path.join(base, fn)
            if not os.path.islink(p):
                try: by_size[os.path.getsize(p)].append(p)
                except OSError: pass
    groups, saved = [], 0
    for size, paths in by_size.items():
        if len(paths) < 2 or size == 0:
            continue
        by_hash = collections.defaultdict(list)
        for p in paths:
            by_hash[sha(p)].append(p)
        for ps in by_hash.values():
            if len(ps) > 1:
                groups.append(sorted(ps)); saved += size * (len(ps) - 1)
    for g in groups:
        print(f"\n🔁 {len(g)} نسخ:")
        for p in g: print("   ", p)
        if a.move_to:
            os.makedirs(a.move_to, exist_ok=True)
            for p in g[1:]:
                dst = os.path.join(a.move_to, hashlib.md5(p.encode()).hexdigest()[:8] + "_" + os.path.basename(p))
                shutil.move(p, dst)
    print(f"\nمجموعات: {len(groups)} | مساحة ممكن توفّرها: {saved / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
