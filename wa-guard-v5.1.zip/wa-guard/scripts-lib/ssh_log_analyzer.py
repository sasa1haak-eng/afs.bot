#!/usr/bin/env python3
"""محلل محاولات دخول SSH الفاشلة من سجل auth.log وكشف عناوين القوة الغاشمة.

  sudo python3 ssh_log_analyzer.py /var/log/auth.log --threshold 10
  journalctl -u ssh --no-pager | python3 ssh_log_analyzer.py -
يقترح حجب العناوين (للتنفيذ اليدوي بعد مراجعتها) ويوصي بـ fail2ban.
"""
import argparse, collections, re, sys

FAILED = re.compile(r"Failed (?:password|publickey) for (?:invalid user )?(\S+) from (\S+)")
INVALID = re.compile(r"Invalid user (\S*) from (\S+)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("log")
    ap.add_argument("--threshold", type=int, default=10)
    a = ap.parse_args()
    src = sys.stdin if a.log == "-" else open(a.log, errors="replace")
    ips, users = collections.Counter(), collections.Counter()
    with src:
        for line in src:
            m = FAILED.search(line) or INVALID.search(line)
            if m:
                users[m.group(1)] += 1
                ips[m.group(2)] += 1
    print(f"إجمالي المحاولات الفاشلة: {sum(ips.values())} من {len(ips)} عنوان")
    print("\nأكتر العناوين:")
    for ip, n in ips.most_common(10):
        print(f"  {ip:<40} {n}")
    print("\nأكتر أسماء المستخدمين تجريباً:")
    for u, n in users.most_common(10):
        print(f"  {u:<20} {n}")
    bad = [ip for ip, n in ips.items() if n >= a.threshold]
    if bad:
        print(f"\n⚠️ {len(bad)} عنوان تجاوز {a.threshold} محاولة. للمراجعة ثم الحجب:")
        for ip in bad[:20]:
            print(f"  sudo ufw deny from {ip}")
        print("\nالأفضل: ثبّت fail2ban، وعطّل دخول الباسورد واستخدم مفاتيح SSH.")


if __name__ == "__main__":
    main()
