#!/usr/bin/env bash
# حارس تشغيل البوت: يعيد تشغيله لو وقع، مع تأخير متصاعد وحد لعدد إعادات التشغيل، وسجل في watchdog.log.
#   bash bot_watchdog.sh              (من مجلد البوت)
#   nohup bash bot_watchdog.sh &      (يفضل شغال بعد قفل الشاشة)
# تيرمكس: termux-wake-lock بيمنع الموبايل من إيقاف العملية.
BOT_CMD="${BOT_CMD:-npm start}"
LOG="${LOG:-watchdog.log}"
MAX_FAST=5          # أقصى عدد انهيارات سريعة (أقل من 60ث) قبل التوقف
command -v termux-wake-lock >/dev/null && termux-wake-lock
delay=3; fast=0
while true; do
  start=$(date +%s)
  echo "[$(date '+%F %T')] تشغيل: $BOT_CMD" >> "$LOG"
  $BOT_CMD
  code=$?
  up=$(( $(date +%s) - start ))
  echo "[$(date '+%F %T')] خرج بكود $code بعد ${up}ث" >> "$LOG"
  [ "$code" -eq 0 ] && { echo "خروج نظيف؛ إيقاف الحارس." >> "$LOG"; break; }
  if [ "$up" -lt 60 ]; then fast=$((fast+1)); delay=$((delay*2)); [ "$delay" -gt 120 ] && delay=120; else fast=0; delay=3; fi
  [ "$fast" -ge "$MAX_FAST" ] && { echo "[$(date '+%F %T')] انهيارات متكررة؛ توقف. راجع السجل." >> "$LOG"; exit 1; }
  sleep "$delay"
done
