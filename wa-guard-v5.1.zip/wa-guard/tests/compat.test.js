import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'

// نحذف الدوال الأصلية الأول عشان نختبر إن طبقة التوافق بتعوّضها (محاكاة Node 18)
const saved = []
const kill = (o, n) => { saved.push([o, n, Object.getOwnPropertyDescriptor(o, n)]); delete o[n] }
for (const n of ['toSorted', 'toReversed', 'toSpliced', 'with']) kill(Array.prototype, n)
for (const [o, n] of [[Array, 'fromAsync'], [Object, 'groupBy'], [Map, 'groupBy'], [Promise, 'withResolvers'], [String.prototype, 'isWellFormed'], [String.prototype, 'toWellFormed'], [AbortSignal, 'any']]) kill(o, n)
for (const n of ['union', 'intersection', 'difference', 'symmetricDifference', 'isSubsetOf', 'isSupersetOf', 'isDisjointFrom']) kill(Set.prototype, n)
await import('../core/compat.js')

test('Array ES2023', () => {
  const a = [3, 1, 2]
  assert.deepEqual(a.toSorted(), [1, 2, 3]); assert.deepEqual(a, [3, 1, 2])
  assert.deepEqual(a.toReversed(), [2, 1, 3]); assert.deepEqual(a.with(-1, 9), [3, 1, 9]); assert.deepEqual(a.toSpliced(1, 1), [3, 2])
  assert.throws(() => a.with(5, 1), RangeError)
})
test('groupBy / withResolvers / fromAsync', async () => {
  assert.deepEqual({ ...Object.groupBy([1, 2, 3, 4], (x) => (x % 2 ? 'odd' : 'even')) }, { odd: [1, 3], even: [2, 4] })
  assert.equal(Map.groupBy([1, 2, 3], (x) => x % 2).get(1).length, 2)
  const { promise, resolve } = Promise.withResolvers(); resolve(5); assert.equal(await promise, 5)
  assert.deepEqual(await Array.fromAsync((async function* () { yield 1; yield 2 })()), [1, 2])
  assert.deepEqual(await Array.fromAsync([Promise.resolve(1), 2], (x) => x * 2), [2, 4])
})
test('String well-formed + Set methods + AbortSignal.any', () => {
  assert.equal('a\uD800'.isWellFormed(), false); assert.equal('ab'.isWellFormed(), true); assert.equal('a\uD800'.toWellFormed(), 'a\uFFFD')
  const a = new Set([1, 2, 3]), b = new Set([2, 3, 4])
  assert.deepEqual([...a.union(b)], [1, 2, 3, 4]); assert.deepEqual([...a.intersection(b)], [2, 3]); assert.deepEqual([...a.difference(b)], [1])
  assert.deepEqual([...a.symmetricDifference(b)].sort(), [1, 4]); assert.ok(new Set([2]).isSubsetOf(a)); assert.ok(a.isSupersetOf(new Set([1]))); assert.ok(a.isDisjointFrom(new Set([9])))
  const c = new AbortController(); const s = AbortSignal.any([c.signal]); c.abort('x'); assert.equal(s.aborted, true)
})
test('على Node 20+ ما بتغيّرش سلوك الدوال الأصلية', () => { assert.equal(typeof [].toSorted, 'function') })
