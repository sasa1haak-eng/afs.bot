// بيئة معزولة للاختبارات: قاعدة بيانات ومجلد بيانات مؤقتين
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'waguard-test-'))
process.env.DB_FILE = path.join(dir, 'db.json')
process.env.DATA_DIR = path.join(dir, 'data')
process.env.BACKUP_KEY = 'test-key-123456'
export const TMP = dir
