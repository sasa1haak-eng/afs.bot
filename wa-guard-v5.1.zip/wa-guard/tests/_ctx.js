// سياق أوامر مصغّر للاختبارات (بدل ما نشغّل البوت كله)
import { db, save, clean, gset, getMeta, isAdmin, botIsAdmin, CONFIG } from '../lib.js'
import { panel, kv, T } from '../ui.js'

export function makeCtx(extra = {}) {
  const registry = []
  const duplicates = []
  const ctx = {
    registry, duplicates, CONFIG, db, save, clean, gset, panel, kv, T, P: '.',
    cmd: (names, level, fn, opts = {}) => registry.push({ names, orig: names, level, fn, opts }),
    tag: (x) => '@' + String(x).split('@')[0], norm: (s) => s.replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي'),
    getTarget: (e, args) => e.__target || ((args || '').match(/\d{9,15}/)?.[0] ? (args.match(/\d{9,15}/)[0] + '@s.whatsapp.net') : null),
    getMeta: async (sock, jid) => sock.__meta || { participants: [], subject: 'Test' }, isAdmin: (m, s) => !!m.participants?.find((p) => p.id === s && p.admin), botIsAdmin: () => true,
    quotedText: () => '', bar: () => '', ...extra,
  }
  return ctx
}
export const run = async (ctx, name, e, args = '') => {
  const out = []
  const c = ctx.registry.find((x) => x.names.includes(name))
  if (!c) throw new Error('no command ' + name)
  const env = { jid: 'g@g.us', sender: '201111111111@s.whatsapp.net', isGroup: true, isOwner: false, sock: {}, m: { key: {} }, ctx: {}, content: {}, ...e, reply: async (t, m) => { out.push(t); return {} } }
  await c.fn(env, args)
  return out.join('\n')
}
