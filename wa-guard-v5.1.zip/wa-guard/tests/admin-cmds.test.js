import './_env.js'
process.env.BROADCAST_GAP_MS = '1'
import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
const { db } = await import('../lib.js')
const { makeCtx, run } = await import('./_ctx.js')
const { register } = await import('../cmds5-admin.js')
const sessions = await import('../sessions.js')
const { loaded } = await import('../core/plugins.js')
const ctx = makeCtx(); ctx.registry.push({ names: ['a'], orig: ['a'], level: 'all', opts: { sec: 'x' }, fn() {} }, { names: ['بحث تجريبي'], orig: ['بحث تجريبي'], level: 'all', opts: { d: 'اختبار البحث' }, fn() {} }); register(ctx)
sessions._testSetMain({ id: 'm' })
const OWN = { isOwner: true, sock: sessions ? {} : {} }

test('لوحة المطور وحالة النظام ووقت التشغيل والسجلات', async () => {
  assert.match(await run(ctx, 'لوحة المطور', OWN), /DEV DASHBOARD/)
  assert.match(await run(ctx, 'حالة النظام', OWN), /الذاكرة/)
  assert.match(await run(ctx, 'وقت التشغيل', OWN), /شغال من/)
  assert.match(await run(ctx, 'السجلات', OWN), /مفيش أخطاء|ERROR LOG/)
})
test('التشخيص بيرجّع قايمة فحوصات (ومش بيقع لو حاجة ناقصة)', async () => {
  const o = await run(ctx, 'تشخيص', OWN); assert.match(o, /DIAGNOSTICS/); assert.match(o, /Node v/); assert.match(o, /BACKUP_KEY/)
})
test('الإضافات: تعطيل/تفعيل', async () => {
  loaded.push({ file: 'demo.js', name: 'demo', version: '1', status: 'loaded', commands: 2 })
  assert.match(await run(ctx, 'الاضافات', OWN), /demo/)
  assert.match(await run(ctx, 'تعطيل اضافة', OWN, 'demo'), /اتعطّلت/); assert.equal(db.plugins.demo.disabled, true)
  assert.match(await run(ctx, 'تفعيل اضافة', OWN, 'demo'), /اتفعّلت/); assert.equal(db.plugins.demo.disabled, false)
  assert.match(await run(ctx, 'تعطيل اضافة', OWN, 'nope'), /مش موجودة/)
})
test('الأوامر المكررة والفهرس وبحث الأوامر', async () => {
  assert.match(await run(ctx, 'الاوامر المكررة', OWN), /مفيش أي اسم/)
  ctx.duplicates.push({ name: 'x', first: 'a', second: 'b' }); assert.match(await run(ctx, 'الاوامر المكررة', OWN), /«x»/); ctx.duplicates.length = 0
  assert.match(await run(ctx, 'فهرس الاوامر', OWN), /COMMAND CATALOG/)
  assert.match(await run(ctx, 'بحث امر', {}, 'تجريبي'), /بحث تجريبي/); assert.match(await run(ctx, 'بحث امر', {}, 'zzz'), /مفيش أمر/)
})
test('خصم رصيد وفحص/تنظيف الاقتصاد (المطورين مستثنين)', async () => {
  db.eco['201111@s.whatsapp.net'] = { wallet: 1000, bank: 0 }
  assert.match(await run(ctx, 'خصم رصيد', { ...OWN, __target: '201111@s.whatsapp.net' }, '201111 300'), /اتخصم 300/); assert.equal(db.eco['201111@s.whatsapp.net'].wallet, 700)
  await run(ctx, 'خصم رصيد', { ...OWN, __target: '201111@s.whatsapp.net' }, '201111 99999'); assert.equal(db.eco['201111@s.whatsapp.net'].wallet, 0, 'مش بيخصم أكتر من الرصيد')
  db.eco['201666@s.whatsapp.net'] = { wallet: 9e15, bank: 9e15 }; db.devs['201777'] = { jid: '201777@s.whatsapp.net' }; db.eco['201777@s.whatsapp.net'] = { wallet: 9e15, bank: 9e15 }
  assert.match(await run(ctx, 'فحص الاقتصاد', OWN), /1 حساب أرصدته مشبوهة/)
  assert.match(await run(ctx, 'تنظيف الاقتصاد', OWN), /للتأكيد/); assert.equal(db.eco['201666@s.whatsapp.net'].wallet, 9e15)
  assert.match(await run(ctx, 'تنظيف الاقتصاد', OWN, 'تأكيد'), /اتصفّر 1/); assert.equal(db.eco['201666@s.whatsapp.net'].wallet, 0); assert.equal(db.eco['201777@s.whatsapp.net'].wallet, 9e15, 'المطور مستثنى')
})
test('البث: معاينة أولاً ولا يرسل إلا بتأكيد', async () => {
  const sent = []; const sock = { groupFetchAllParticipating: async () => ({ 'a@g.us': {}, 'b@g.us': {} }), sendMessage: async (j, c) => sent.push([j, c.text]) }
  assert.match(await run(ctx, 'بث', { ...OWN, sock }, 'اجتماع الليلة'), /هيتبعت لـ 2 جروب/); assert.equal(sent.length, 0)
  assert.match(await run(ctx, 'بث', { ...OWN, sock }, 'اجتماع الليلة تأكيد'), /نجح 2/); assert.deepEqual(sent.map((x) => x[0]), ['a@g.us', 'b@g.us'])
  assert.match(await run(ctx, 'بث', { ...OWN, sock }, 'x'.repeat(900)), /اكتب/)
})
