import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
const { db } = await import('../lib.js')
const { tick, nextCairoTime } = await import('../core/scheduler.js')

test('أقرب وقت بتوقيت القاهرة', () => {
  const now = Date.parse('2026-06-01T10:00:00Z') // القاهرة صيفاً UTC+3 → 13:00
  assert.equal(new Date(nextCairoTime(14, 30, now)).toISOString(), '2026-06-01T11:30:00.000Z')
  assert.equal(new Date(nextCairoTime(12, 0, now)).toISOString(), '2026-06-02T09:00:00.000Z', 'الوقت فات النهارده: بكره')
  const w = Date.parse('2026-01-15T10:00:00Z') // شتاءً UTC+2
  assert.equal(new Date(nextCairoTime(14, 0, w)).toISOString(), '2026-01-15T12:00:00.000Z')
})
test('المجدول: إرسال مرة واحدة، تكرار، تأجيل لو البوت مش متصل، وإلغاء المتأخر', async () => {
  const sent = []
  const sock = { sendMessage: async (jid, c) => sent.push([jid, c.text]) }
  const now = 1_000_000_000_000
  db.groups['s@g.us'] = { schedules: [
    { id: 1, text: 'مرة', at: now - 1000, every: 0, num: '201' },
    { id: 2, text: 'يومي', at: now - 1000, every: 1440, num: '201' },
    { id: 3, text: 'مش متصل', at: now - 1000, every: 0, num: '999' },
    { id: 4, text: 'متأخر', at: now - 7 * 3600_000, every: 0, num: '201' },
    { id: 5, text: 'لسه', at: now + 60_000, every: 0, num: '201' },
  ] }
  const n = await tick(now, (num) => (num === '201' ? sock : null))
  assert.equal(n, 2); assert.deepEqual(sent.map((x) => x[1]).sort(), ['مرة', 'يومي'].sort())
  const left = db.groups['s@g.us'].schedules.map((s) => s.id).sort()
  assert.deepEqual(left, [2, 3, 5], 'المرة الواحدة اتشالت، اليومي فضل، المش متصل فضل، المتأخر اتلغى')
  assert.equal(db.groups['s@g.us'].schedules.find((s) => s.id === 2).at, now - 1000 + 1440 * 60_000)
  assert.equal(await tick(now, (num) => (num === '201' ? sock : null)), 0, 'ما بيبعتش تاني في نفس اللحظة')
})
