import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
const { gset } = await import('../lib.js')
const S = await import('../core/shield.js')
const { events, counts } = await import('../core/seclog.js')

const mkSock = () => { const log = { removed: [], settings: [], said: [] }; return { log, groupParticipantsUpdate: async (j, ps, a) => log.removed.push([ps[0], a]), groupSettingUpdate: async (j, s) => log.settings.push(s), sendMessage: async (j, c) => log.said.push(c) } }
const deps = { getMeta: async () => ({ announce: false, participants: [] }), botIsAdmin: () => true }

test('الطوارئ: تحفظ الإعدادات القديمة وتفعّل الحماية وتقفل الجروب ثم ترجّع كل حاجة', async () => {
  const jid = 'em@g.us', g = gset(jid), sock = mkSock()
  Object.assign(g, { antilink: false, antiflood: true, antibot: false })
  const r = await S.startEmergency({ sock, jid, meta: { announce: false }, g, reason: 'يدوي', by: '201', canLock: true })
  assert.equal(r.locked, true); assert.deepEqual(sock.log.settings, ['announcement'])
  assert.ok(g.antilink && g.antiflood && g.antibot && g.antibotStrict && g.antiprofanity)
  assert.equal((await S.startEmergency({ sock, jid, meta: {}, g })).already, true)
  const e = await S.endEmergency({ sock, jid, g, canUnlock: true })
  assert.equal(e.unlocked, true); assert.deepEqual(sock.log.settings, ['announcement', 'not_announcement'])
  assert.deepEqual([g.antilink, g.antiflood, g.antibot, !!g.emergency], [false, true, false, false], 'رجعت الإعدادات الأصلية')
})
test('الطوارئ لو الجروب كان مقفول أصلاً: ما بنفتحوش بعد الإنهاء', async () => {
  const jid = 'em2@g.us', g = gset(jid), sock = mkSock()
  await S.startEmergency({ sock, jid, meta: { announce: true }, g, canLock: true })
  const e = await S.endEmergency({ sock, jid, g, canUnlock: true })
  assert.equal(e.unlocked, false); assert.deepEqual(sock.log.settings, ['announcement'])
})
test('كشف الهجمات: دخول جماعي سريع يفعّل الطوارئ ويسجّل حادثة', async () => {
  const jid = 'raid@g.us', g = gset(jid), sock = mkSock()
  g.raid = { on: true, limit: 5, window: 60 }
  await S.onParticipants(sock, { id: jid, participants: ['2011@s.whatsapp.net', '2012@s.whatsapp.net'], action: 'add' }, deps)
  assert.ok(!g.emergency, 'تحت الحد: مفيش طوارئ')
  const r = await S.onParticipants(sock, { id: jid, participants: ['2013@s.whatsapp.net', '2014@s.whatsapp.net', '2015@s.whatsapp.net'], action: 'add' }, deps)
  assert.equal(r.raid, true); assert.ok(g.emergency); assert.deepEqual(sock.log.settings, ['announcement'])
  assert.ok(sock.log.said.some((m) => /هجوم جماعي/.test(m.text)))
  assert.ok(events({ jid, type: 'raid' }).length === 1)
  assert.equal(S.recentJoins(jid, 10).length, 5)
})
test('كشف الهجمات مقفول: مفيش تدخل', async () => {
  const jid = 'noraid@g.us', g = gset(jid), sock = mkSock()
  g.raid = { on: false, limit: 2, window: 60 }
  await S.onParticipants(sock, { id: jid, participants: ['1@s.whatsapp.net', '2@s.whatsapp.net', '3@s.whatsapp.net'], action: 'add' }, deps)
  assert.ok(!g.emergency)
})
test('القائمة السوداء: الرقم بيتطرد فور الدخول (وبس لو البوت أدمن)', async () => {
  const jid = 'bl@g.us', g = gset(jid), sock = mkSock()
  g.blacklist = { 201099999999: { t: Date.now(), by: '1' } }
  await S.onParticipants(sock, { id: jid, participants: ['201099999999@s.whatsapp.net', '201000000001@s.whatsapp.net'], action: 'add' }, deps)
  assert.deepEqual(sock.log.removed, [['201099999999@s.whatsapp.net', 'remove']])
  const s2 = mkSock()
  await S.onParticipants(s2, { id: jid, participants: ['201099999999@s.whatsapp.net'], action: 'add' }, { ...deps, botIsAdmin: () => false })
  assert.equal(s2.log.removed.length, 0)
  const s3 = mkSock(); const r = await S.onParticipants(s3, { id: jid, participants: ['x@s.whatsapp.net'], action: 'remove' }, deps)
  assert.equal(r.count, 0)
})
