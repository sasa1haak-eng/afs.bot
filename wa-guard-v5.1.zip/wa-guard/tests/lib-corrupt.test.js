import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

test('ملف البيانات الفاسد: بيتنقل وبيتحمّل آخر نسخة .bak سليمة (بدل البدء من صفر)', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'waguard-corrupt-'))
  const file = path.join(dir, 'db.json')
  fs.writeFileSync(file, '{"groups": {"g@g.us": {"antilink": tru')           // فاسد (مقطوع)
  fs.writeFileSync(file + '.bak', JSON.stringify({ groups: { 'saved@g.us': { antilink: true } } }))
  process.env.DB_FILE = file
  const lib = await import('../lib.js?corrupt')
  assert.ok(lib.db.groups['saved@g.us'], 'اتحمّلت اللقطة السليمة')
  assert.ok(fs.readdirSync(dir).some((f) => f.startsWith('db.json.corrupt-')), 'الملف الفاسد اتنقل مش اتمسح')
  assert.ok(lib.db.devs && lib.db.eco, 'القيم الافتراضية موجودة')
})
