import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
import * as X from '../core/tools.js'

test('رقم → كلمات', () => {
  assert.equal(X.numToWords(0), 'صفر')
  assert.equal(X.numToWords(21), 'واحد وعشرون')
  assert.equal(X.numToWords(1250), 'ألف ومائتان وخمسون')
  assert.equal(X.numToWords(2000003), 'مليونان وثلاثة')
  assert.equal(X.numToWords(-5), 'سالب خمسة')
  assert.throws(() => X.numToWords(1e13))
})
test('تحويل الأرقام العربية/الإنجليزية', () => {
  assert.equal(X.toIndic('2026'), '٢٠٢٦')
  assert.equal(X.toWestern('٢٠٢٦ و ۱۲'), '2026 و 12')
})
test('هاش وhex', () => {
  assert.equal(X.hash('sha256', 'abc').slice(0, 16), 'ba7816bf8f01cfea')
  assert.equal(X.hexDec(X.hexEnc('مرحبا')), 'مرحبا')
  assert.throws(() => X.hexDec('zz'))
})
test('هجري ↔ ميلادي (ذهاب وإياب)', () => {
  const g = X.fromHijri(1448, 9, 1)
  const h = X.toHijri(new Date(g.getUTCFullYear(), g.getUTCMonth(), g.getUTCDate()))
  assert.deepEqual([h.y, h.m, h.d], [1448, 9, 1])
  assert.throws(() => X.fromHijri(1000, 1, 1))
})
test('التواريخ', () => {
  assert.equal(X.daysBetween(X.parseDate('2026-01-01'), X.parseDate('2026-12-31')), 364)
  assert.equal(X.iso(X.addDays(X.parseDate('2026-02-27'), 3)), '2026-03-02')
  assert.throws(() => X.parseDate('2026-02-30'))
  assert.deepEqual(X.parseDate('17/5/2000'), X.parseDate('2000-05-17'))
  const a = X.age(X.parseDate('2000-05-17'), X.parseDate('2026-05-16'))
  assert.deepEqual([a.y, a.m, a.d], [25, 11, 29])
  assert.equal(a.nextBirthday, 1)
})
test('تقويم: عدد الأيام والمحاذاة', () => {
  const rows = X.calendar(2026, 11).split('\n')
  assert.match(rows[1], /^\s{4}1/) // 1 نوفمبر 2026 = الأحد (العمود التاني بعد السبت)
  assert.ok(rows.join(' ').includes('30'))
})
test('تحويل الوحدات', () => {
  assert.ok(Math.abs(X.convertUnits(10, 'كم', 'ميل') - 6.2137) < 1e-3)
  assert.equal(X.convertUnits(100, 'مئوية', 'فهرنهايت'), 212)
  assert.equal(X.convertUnits(1, 'جيجا', 'ميجا'), 1024)
  assert.throws(() => X.convertUnits(1, 'كم', 'كجم'))
  assert.throws(() => X.convertUnits(1, 'xx', 'كم'))
})
test('تحليل الأعداد', () => {
  assert.deepEqual(X.factorize(360).factors, { 2: 3, 3: 2, 5: 1 })
  assert.equal(X.factorize(360).divisors, 24)
  assert.equal(X.factorize(97).prime, true)
  assert.equal(X.factorize(999999999989).prime, true)
  assert.equal(X.gcdAll([48, 36, 60]), 12)
  assert.equal(X.lcmAll([4, 6, 10]), 60)
})
test('إحصاء', () => {
  const s = X.stats([2, 4, 4, 4, 5, 5, 7, 9])
  assert.equal(s.mean, 5); assert.equal(s.median, 4.5); assert.deepEqual(s.mode, [4]); assert.equal(s.sd, 2)
})
test('قوة كلمة السر', () => {
  assert.equal(X.passwordStrength('123456').level, 'ضعيفة')
  assert.equal(X.passwordStrength('aaaaaaaaaaaa').level, 'ضعيفة')
  assert.ok(['قوية', 'قوية جداً'].includes(X.passwordStrength('Zx9!kQ2#vLp7$wR').level))
})
test('الروابط ومعلومات الملف والتلخيص', () => {
  const u = X.parseUrl('example.com/a/b?x=1&y=2#top')
  assert.equal(u.host, 'example.com'); assert.deepEqual(u.query, ['x=1', 'y=2']); assert.equal(u.hash, 'top')
  assert.throws(() => X.parseUrl('http://'))
  const fi = X.fileInfo({ imageMessage: { mimetype: 'image/jpeg', fileLength: 2097152, width: 800, height: 600 } })
  assert.equal(fi['الأبعاد'], '800×600'); assert.match(fi['الحجم'], /2\.00 MB/)
  assert.equal(X.fileInfo({ conversation: 'hi' }), null)
  const text = 'الأمن السيبراني مهم جداً لحماية البيانات والأنظمة. الحماية تبدأ بكلمات سر قوية وتحديث الأنظمة. القطط تحب النوم كثيراً في المنزل. حماية البيانات والأنظمة مسؤولية الجميع في المؤسسة.'
  const sum = X.summarize(text, 2)
  assert.ok(sum.length < text.length && /الأنظمة|البيانات/.test(sum))
})
