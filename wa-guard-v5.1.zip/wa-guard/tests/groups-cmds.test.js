import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
const { db, gset } = await import('../lib.js')
const { makeCtx, run } = await import('./_ctx.js')
const { register } = await import('../cmds5-groups.js')
const ctx = makeCtx(); register(ctx)
const mk = () => { const calls = []; const s = new Proxy({ calls, user: { id: '201888888888:3@s.whatsapp.net' } }, { get: (t, k) => (k in t ? t[k] : async (...a) => { calls.push([k, ...a]); return k === 'groupRequestParticipantsList' ? [{ jid: '201111111111@s.whatsapp.net' }, { jid: '201222222222@s.whatsapp.net' }] : k === 'groupInviteCode' ? 'ABC123' : k === 'groupRevokeInvite' ? 'NEW999' : undefined }) }); return s }

test('وضع الموافقة + الطلبات + القبول/الرفض', async () => {
  const s = mk()
  assert.match(await run(ctx, 'وضع الموافقة', { sock: s }, 'تشغيل'), /اتفعّلت/); assert.deepEqual(s.calls[0], ['groupJoinApprovalMode', 'g@g.us', 'on'])
  assert.match(await run(ctx, 'طلبات الانضمام', { sock: s }), /201111111111/)
  assert.match(await run(ctx, 'قبول الطلبات', { sock: s }, '201222222222'), /قبول 1 طلب/)
  const upd = s.calls.find((c) => c[0] === 'groupRequestParticipantsUpdate'); assert.deepEqual(upd.slice(2), [['201222222222@s.whatsapp.net'], 'approve'])
  assert.match(await run(ctx, 'رفض الطلبات', { sock: s }), /رفض 2 طلب/)
})
test('رابط الدعوة والتجديد', async () => {
  const s = mk()
  assert.match(await run(ctx, 'رابط الدعوة', { sock: s }), /chat\.whatsapp\.com\/ABC123/)
  assert.match(await run(ctx, 'تجديد الرابط', { sock: s }), /chat\.whatsapp\.com\/NEW999/)
})
test('الرسائل المؤقتة بقيم صحيحة وبتتجاهل القيم الغلط', async () => {
  const s = mk()
  await run(ctx, 'الرسائل المؤقتة', { sock: s }, '7'); await run(ctx, 'الرسائل المؤقتة', { sock: s }, 'ايقاف')
  assert.deepEqual(s.calls.filter((c) => c[0] === 'groupToggleEphemeral').map((c) => c[2]), [604800, 0])
  assert.match(await run(ctx, 'الرسائل المؤقتة', { sock: s }, '5'), /اكتب/)
})
test('تثبيت/إلغاء التثبيت لازم رد على رسالة', async () => {
  const s = mk()
  assert.match(await run(ctx, 'تثبيت', { sock: s }), /ردّ على الرسالة/)
  await run(ctx, 'تثبيت', { sock: s, ctx: { stanzaId: 'MSG1', participant: '201@s.whatsapp.net' } }, '30')
  const pin = s.calls.find((c) => c[0] === 'sendMessage'); assert.deepEqual([pin[2].type, pin[2].time, pin[2].pin.id], [1, 2592000, 'MSG1'])
  await run(ctx, 'الغاء التثبيت', { sock: s, ctx: { stanzaId: 'MSG1' } })
  assert.equal(s.calls.filter((c) => c[0] === 'sendMessage').pop()[2].type, 2)
})
test('الخاملين: اللي من غير رسائل مسجّلة بس (ومش الأدمنز)', async () => {
  const s = mk(); s.__meta = { participants: [{ id: 'a@s.whatsapp.net', admin: 'admin' }, { id: 'b@s.whatsapp.net' }, { id: 'c@s.whatsapp.net' }] }
  db.xp['g@g.us'] = { 'b@s.whatsapp.net': { msgs: 5, xp: 10 } }
  const o = await run(ctx, 'الخاملين', { sock: s })
  assert.match(o, /1 من 3/); assert.match(o, /@c/); assert.doesNotMatch(o, /@a|@b/)
})
test('جدولة الإعلانات: بعد دقائق، يومياً بتوقيت القاهرة، حد أقصى، عرض وإلغاء', async () => {
  const s = mk(), jid = 'sched@g.us', before = Date.now()
  assert.match(await run(ctx, 'جدولة اعلان', { sock: s, jid }, '30 النص الأول'), /#1/)
  const a = gset(jid).schedules[0]; assert.ok(a.at >= before + 29 * 60_000 && a.at <= before + 31 * 60_000); assert.equal(a.num, '201888888888'); assert.equal(a.every, 0)
  await run(ctx, 'جدولة اعلان', { sock: s, jid }, 'يوميا 21:30 صباح الخير')
  const b = gset(jid).schedules[1]; assert.equal(b.every, 1440); assert.ok(b.at > Date.now())
  assert.match(await run(ctx, 'جدولة اعلان', { sock: s, jid }, '25:99 x'), /وقت غير صالح/)
  assert.match(await run(ctx, 'جدولة اعلان', { sock: s, jid }, 'كلام'), /الصيغة/)
  assert.match(await run(ctx, 'الاعلانات المجدولة', { jid }), /#2/)
  assert.match(await run(ctx, 'الغاء جدولة', { jid }, '1'), /اتلغى/)
  assert.equal(gset(jid).schedules.length, 1)
  for (let i = 0; i < 12; i++) await run(ctx, 'جدولة اعلان', { sock: s, jid }, `${i + 1} نص`)
  assert.equal(gset(jid).schedules.length, 10, 'الحد الأقصى 10')
})
