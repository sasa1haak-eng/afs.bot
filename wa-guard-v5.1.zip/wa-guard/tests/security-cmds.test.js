import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
const { db, gset } = await import('../lib.js')
const { makeCtx, run } = await import('./_ctx.js')
const { sec } = await import('../core/seclog.js')
const { register } = await import('../cmds5-security.js')
const ctx = makeCtx(); register(ctx)
const names = (n) => ctx.registry.find((c) => c.names.includes(n))
const mkSock = () => { const s = { removed: [], docs: [], settings: [], sendMessage: async (j, c) => s.docs.push(c), groupParticipantsUpdate: async (j, ps, a) => s.removed.push([ps[0], a]), groupSettingUpdate: async (j, v) => s.settings.push(v) }; return s }

test('الأوامر مسجّلة بالصيغتين (بمسافة وبشرطة سفلية) وكل الأوامر العامة محددة صلاحيتها', () => {
  assert.ok(names('فحص امني') && names('فحص_امني'))
  for (const c of ctx.registry) assert.ok(['admin', 'owner', 'all'].includes(c.level))
  const owner = ctx.registry.filter((c) => c.level === 'owner')
  assert.ok(owner.length >= 6 && owner.every((c) => c.opts.global), 'أوامر المطور كلها نطاقها الشبكة (global)')
})
test('فحص أمني: جروب مفتوح = درجة ضعيفة + توصيات، وجروب محمي = درجة عالية', async () => {
  const sock = mkSock()
  sock.__meta = { participants: [{ id: 'a', admin: 'admin' }], subject: 'x' }
  let o = await run(ctx, 'فحص امني', { jid: 'audit1@g.us', sock })
  assert.match(o, /🔴 ضعيف/); assert.match(o, /التوصيات/)
  Object.assign(gset('audit2@g.us'), { antilink: true, antiflood: true, antiprofanity: true, antibot: true, antibotStrict: true, raid: { on: true }, warnLimit: 3 })
  const s2 = mkSock(); s2.__meta = { participants: [{ id: 'a', admin: 'admin' }, { id: 'b', admin: 'admin' }], joinApprovalMode: true, restrict: true }
  o = await run(ctx, 'فحص امني', { jid: 'audit2@g.us', sock: s2 })
  assert.match(o, /🟢 ممتاز/); assert.match(o, /100\/100/)
})
test('سجل الأمان والحوادث والأكثر مخالفة', async () => {
  const jid = 'log@g.us'
  sec('antibot', { jid, actor: '201555', why: 'بصمة' }); sec('antibot', { jid, actor: '201555' }); sec('kick', { jid, actor: '201777' })
  assert.match(await run(ctx, 'سجل الامان', { jid }), /201555/)
  assert.match(await run(ctx, 'حوادث', { jid }), /بوت اتطرد: 2/)
  const top = await run(ctx, 'اكثر مخالفة', { jid }); assert.match(top, /1\. 201555 — 2/)
  assert.match(await run(ctx, 'حوادث', { jid: 'empty@g.us' }), /مفيش حوادث/)
})
test('طوارئ وإنهاء الطوارئ عبر الأوامر', async () => {
  const sock = mkSock(), jid = 'cmdem@g.us'
  assert.match(await run(ctx, 'طوارئ', { jid, sock }), /وضع الطوارئ مفعّل/)
  assert.match(await run(ctx, 'طوارئ', { jid, sock }), /شغالة بالفعل/)
  assert.match(await run(ctx, 'انهاء الطوارئ', { jid, sock }), /انتهت الطوارئ/)
  assert.match(await run(ctx, 'انهاء الطوارئ', { jid, sock }), /مفيش طوارئ/)
})
test('كشف الهجمات: ضبط الحد والمدة مع حدود آمنة', async () => {
  const jid = 'rcfg@g.us'
  assert.match(await run(ctx, 'كشف الهجمات', { jid }, 'تشغيل'), /شغال/)
  await run(ctx, 'كشف الهجمات', { jid }, 'حد 12'); await run(ctx, 'كشف الهجمات', { jid }, 'مدة 90')
  assert.deepEqual([gset(jid).raid.limit, gset(jid).raid.window], [12, 90])
  await run(ctx, 'كشف الهجمات', { jid }, 'حد 1'); assert.equal(gset(jid).raid.limit, 12, 'حد غير آمن ما بيتقبلش')
  assert.match(await run(ctx, 'كشف الهجمات', { jid }, 'كلام'), /اكتب/)
})
test('القائمة السوداء: سود/بيض/عرض', async () => {
  const sock = mkSock(), jid = 'blc@g.us'
  assert.match(await run(ctx, 'سود', { jid, sock }, '201234567890'), /القائمة السوداء/)
  assert.deepEqual(sock.removed, [['201234567890@s.whatsapp.net', 'remove']])
  assert.match(await run(ctx, 'القائمة السوداء', { jid }), /201234567890/)
  assert.match(await run(ctx, 'بيض', { jid }, '201234567890'), /اتشال/)
  assert.match(await run(ctx, 'بيض', { jid }, '201234567890'), /مش في القائمة/)
})
test('سلامة البيانات تكشف وتصلح الأرصدة التالفة', async () => {
  db.eco['bad1@s.whatsapp.net'] = { wallet: NaN, bank: -5 }; db.eco['ok1@s.whatsapp.net'] = { wallet: 10, bank: 0 }
  assert.match(await run(ctx, 'سلامة البيانات', { isOwner: true }), /رصيد غير سليم/)
  assert.match(await run(ctx, 'سلامة البيانات', { isOwner: true }, 'اصلاح'), /اتصلّح/)
  assert.deepEqual([db.eco['bad1@s.whatsapp.net'].wallet, db.eco['bad1@s.whatsapp.net'].bank], [0, 0]); assert.equal(db.eco['ok1@s.whatsapp.net'].wallet, 10)
})
test('نسخة احتياطية: بتتبعت للخاص مش الجروب، واستعادة بتأكيد فقط', async () => {
  const sock = mkSock()
  const o = await run(ctx, 'نسخة احتياطية', { isOwner: true, isGroup: true, jid: 'grp@g.us', sender: '201222222222:5@s.whatsapp.net', sock })
  assert.match(o, /اتبعتت لك في الخاص/); assert.equal(sock.docs.length, 1); assert.ok(Buffer.isBuffer(sock.docs[0].document))
  const sent = sock.docs[0]
  const grpAfter = JSON.stringify(db.groups)
  db.groups['tmp@g.us'] = { x: 1 }
  const prev = await run(ctx, 'استعادة', { isOwner: true }, sent.fileName)
  assert.match(prev, /للتأكيد/); assert.ok(db.groups['tmp@g.us'], 'من غير تأكيد: مفيش تغيير')
  assert.match(await run(ctx, 'استعادة', { isOwner: true }, sent.fileName + ' تأكيد'), /تمت الاستعادة/)
  assert.ok(!db.groups['tmp@g.us'])
  assert.match(await run(ctx, 'استعادة', { isOwner: true }, 'backup-19990101-000000.wagb تأكيد'), /مش موجودة/)
})
