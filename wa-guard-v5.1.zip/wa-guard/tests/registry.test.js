// اختبار تكامل: تحميل سجل الأوامر الحقيقي (محتاج المكتبات مثبّتة: npm install)
import './_env.js'
import test, { after } from 'node:test'
import assert from 'node:assert/strict'
const m = await import('../commands.js')
after(() => setTimeout(() => process.exit(0), 100).unref?.())

test('مفيش أسماء أوامر مكررة', () => assert.deepEqual(m.duplicates, []))
test('كل أمر له دالة وصلاحية معروفة وومفيش اسم مشترك بين أمرين', () => {
  const owner = new Map()
  for (const c of m.registry) {
    assert.equal(typeof c.fn, 'function'); assert.ok(['all', 'admin', 'owner'].includes(c.level), c.orig[0])
    for (const n of c.names) { assert.ok(!owner.has(n) || owner.get(n) === c, `الاسم «${n}» مشترك بين أمرين مختلفين`); owner.set(n, c) } // تكرار الاسم جوه نفس الأمر (بهمزة/من غير) مسموح
  }
})
test('أوامر 5.0: موجودة، وأوامر المطور نطاقها الشبكة، وأوامر الأدمن مقيّدة بالجروب', () => {
  const by = (sec) => m.registry.filter((c) => c.opts.sec === sec)
  assert.ok(by('sec5').length >= 15 && by('grp5').length >= 10 && by('tools5').length >= 20 && by('dev5').length >= 10)
  for (const c of [...by('dev5'), ...by('sec5')].filter((x) => x.level === 'owner')) assert.ok(c.opts.global, 'ناقصها global: ' + c.orig[0])
  for (const c of by('grp5')) assert.ok(c.opts.group, c.orig[0])
})
test('كل الأوامر الجديدة عليها وصف أو اسم عربي واضح وبتتسجّل بصيغة الشرطة السفلية لو فيها مسافة', () => {
  for (const c of m.registry.filter((x) => /^(sec5|grp5|tools5|dev5)$/.test(x.opts.sec || ''))) {
    for (const n of c.orig) assert.match(n, /[\u0600-\u06FF]/, n)
    const spaced = c.orig.find((n) => n.includes(' '))
    if (spaced) assert.ok(c.orig.includes(spaced.replace(/ /g, '_')), 'ناقص الصيغة بشرطة: ' + spaced)
  }
})
