import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
const { makeCtx, run } = await import('./_ctx.js')
const prot = await import('../cmds6-protect.js')
const mk = () => { const c = makeCtx(); prot.register(c); return c }

test('قواعد الحماية: لا تكرار ولا أسماء أوامر متضاربة', async () => {
  const all = makeCtx()
  for (const f of ['../cmds6-protect.js', '../cmds6-cyber.js', '../cmds6-dev.js', '../cmds6-games.js']) (await import(f)).register(all)
  const seen = new Map()
  for (const c of all.registry) for (const n of c.names) { assert.ok(!seen.has(n) || seen.get(n) === c, 'اسم مكرر: ' + n); seen.set(n, c) }
  assert.ok(all.registry.length >= 400, 'العدد ' + all.registry.length)
})
test('قواعد الحماية: الفحص الفعلي', () => {
  const g = { prot: { telegram: true, otp: true, cards: true, zalgo: true, apk: true, longtext: true, shortlinks: true } }
  const hit = (x) => prot.checkRules(g, { edited: false, ...x })?.key
  assert.equal(hit({ text: 'انضم t.me/abc' }), 'telegram')
  assert.equal(hit({ text: 'ابعتلي كود التحقق' }), 'otp')
  assert.equal(hit({ text: 'بطاقتي 4111 1111 1111 1111' }), 'cards')
  assert.equal(hit({ text: 'a\u0300\u0301\u0302\u0303' }), 'zalgo')
  assert.equal(hit({ text: '', c: { documentMessage: { fileName: 'x.apk' } } }), 'apk')
  assert.equal(hit({ text: 'س'.repeat(1500) }), 'longtext')
  assert.equal(hit({ text: 'https://bit.ly/x' }), 'shortlinks')
  assert.equal(hit({ text: 'مرحبا بالجميع' }), undefined)
})
test('قواعد الحماية: ما بتتعلقش على مدخل ضخم (ReDoS)', () => {
  const g = { prot: Object.fromEntries(prot.ruleKeys.map((k) => [k, true])) }
  for (const text of ['a'.repeat(200000), 'ab '.repeat(60000), 'a.'.repeat(50000), '😀'.repeat(50000)]) {
    const t = Date.now(); prot.checkRules(g, { text, c: {}, raw: {}, ctx: {} }); assert.ok(Date.now() - t < 1500, 'بطيء: ' + (Date.now() - t))
  }
})
test('أمر منع بيشغّل ويطفّي القاعدة', async () => {
  const c = mk(); const e = { jid: 'g1@g.us' }
  assert.match(await run(c, 'منع الروابط المختصرة', e), /مفعّل/)
  assert.match(await run(c, 'منع الروابط المختصرة', e), /متوقف/)
})
test('SSRF: عناوين داخلية ممنوعة', async () => {
  const { isPrivateIp } = await import('../cmds-net.js').catch(() => ({ isPrivateIp: null }))
  if (!isPrivateIp) return
  for (const ip of ['127.0.0.1', '10.0.0.5', '169.254.169.254', '198.18.0.1', '::1', 'fd00::1', 'fe80::1']) assert.ok(isPrivateIp(ip), ip)
  assert.ok(!isPrivateIp('8.8.8.8'))
})

test('نطق: تنظيف النص والتقسيم', async () => {
  const { cleanText, chunkText } = await import('../cmds6-tts.js')
  assert.equal(cleanText('مرحبا 😀 https://x.com/a *بكم*'), 'مرحبا رابط بكم')
  const parts = chunkText('كلمة '.repeat(120), 180)
  assert.ok(parts.length > 1 && parts.every((p) => p.length <= 180))
})
test('نطق: من نص إلى رسالة صوتية OGG/Opus (محركات مزيّفة)', async () => {
  const { engines, register } = await import('../cmds6-tts.js')
  const { execFileSync } = await import('node:child_process')
  const mp3 = execFileSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=1', '-f', 'mp3', '-'], { maxBuffer: 1 << 24 })
  let used = ''
  engines.edge = async () => { throw new Error('no edge') }
  engines.google = async () => { used = 'google'; return mp3 }
  const c = makeCtx(); register(c)
  let sent
  const e = { sender: 'tts-user@s.whatsapp.net', sock: { sendMessage: async (j, msg) => { sent = msg } } }
  await run(c, 'نطق', e, 'مرحبا بالجميع')
  assert.equal(used, 'google')
  assert.equal(sent.ptt, true)
  assert.equal(sent.mimetype, 'audio/ogg; codecs=opus')
  assert.equal(sent.audio.subarray(0, 4).toString(), 'OggS')
  assert.match(await run(c, 'نطق', { ...e, sender: 'other@s.whatsapp.net' }, ''), /اكتب/)
  assert.match(await run(c, 'نطق', { ...e, sender: 'long@s.whatsapp.net' }, 'ا'.repeat(700)), /طويل/)
})

test('أسئلة الاختيار: بنية سليمة وسير سؤال ← جواب', async () => {
  const learn = await import('../cmds6-learn.js')
  for (const [k, bank] of Object.entries(learn.QUIZ)) for (const r of bank) assert.equal(r.length, 5, `${k}: ${r[0]}`)
  const c = makeCtx()
  ;(await import('../cmds6-games.js')).register(c)
  learn.register(c)
  const e = { jid: 'quiz@g.us', sender: 'q@s.whatsapp.net' }
  const q = await run(c, 'سؤال امن', e)
  assert.match(q, /أ\)/)
  assert.match(await run(c, 'جواب', e), /الإجابة/)
})
test('مكتبة السكربتات: كل ملف موجود ومعرّف بالكامل', async () => {
  const fs = await import('node:fs'), path = await import('node:path')
  const sc = await import('../cmds6-scripts.js')
  const dir = path.join(path.dirname(new URL(import.meta.url).pathname), '..', 'scripts-lib')
  assert.ok(sc.MANIFEST.length >= 30)
  for (const m of sc.MANIFEST) {
    assert.ok(fs.existsSync(path.join(dir, m.file)), m.file)
    for (const k of ['name', 'title', 'desc', 'needs', 'example', 'level', 'cat']) assert.ok(m[k], `${m.name}:${k}`)
    assert.match(sc.describe(m), /طريقة التشغيل/)
  }
  const c = makeCtx(); sc.register(c)
  let doc
  const e = { sender: 'sc@s.whatsapp.net', sock: { sendMessage: async (j, msg) => { doc = msg } } }
  const text = await run(c, 'سكربت فاحص منافذ', e)
  assert.match(String(text), /port_scanner\.py|فاحص منافذ/)
  assert.equal(doc.fileName, 'port_scanner.py')
  assert.ok(doc.document.length > 500)
})
