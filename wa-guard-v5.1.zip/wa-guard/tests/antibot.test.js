import './_env.js'
process.env.ANTIBOT_GAP_MS = '40'; process.env.ANTIBOT_WAIT_MS = '80'
import test from 'node:test'
import assert from 'node:assert/strict'
const { gset, recordMsg } = await import('../lib.js')
const AB = await import('../antibot.js')
AB.setOwnNumbers(() => ['201999999999'])

const JID = 'ab@g.us', g = gset(JID); g.antibot = true
const hex = (n) => Array.from({ length: n }, () => '0123456789ABCDEF'[Math.floor(Math.random() * 16)]).join('')
const ids = { old: () => 'BAE5' + hex(12), modern: () => '3EB0' + hex(18), long: () => '3EB0' + hex(36), android: () => hex(32), ios: () => '3A' + hex(18) }
let t = Date.now()
const msg = (sender, id, { name = 'Ahmed', text = 'hello', content, stanza, dt = 3000 } = {}) => {
  t += dt
  const c = content || { extendedTextMessage: { text, contextInfo: stanza ? { stanzaId: stanza } : undefined } }
  return { jid: JID, sender, key: { id, remoteJid: JID, participant: sender }, m: { pushName: name }, content: c, text: c.extendedTextMessage?.text || '', now: t }
}
const run = (env) => AB.score(g, env, env.now)
const reset = () => { AB._test.state.clear(); AB._test.cmdLog.clear(); AB._test.times.clear(); t = Date.now() }
const human = '201166666666@s.whatsapp.net', bot = '201177777777@s.whatsapp.net'

test('البشر ما بيتطردوش: تطبيق رسمي أو واتساب ويب، ومع ردود سريعة', () => {
  reset(); let trig = false
  for (let i = 0; i < 60; i++) trig ||= run(msg('201111111111@s.whatsapp.net', i % 2 ? ids.android() : ids.ios())).trigger
  for (let i = 0; i < 60; i++) trig ||= run(msg('201122222222@s.whatsapp.net', ids.modern())).trigger
  for (let i = 0; i < 6; i++) { const c = ids.android(); run(msg(human, c, { text: '.cmd' + i })); trig ||= run(msg('201188888888@s.whatsapp.net', ids.ios(), { stanza: c, dt: 600 })).trigger }
  assert.equal(trig, false)
})
test('إشارات حاسمة: بصمة قديمة، معرّف طويل، أزرار/قوائم حتى بمعرّف رسمي', () => {
  reset(); assert.ok(run(msg('2011@s.whatsapp.net', ids.old())).trigger)
  reset(); assert.ok(run(msg('2012@s.whatsapp.net', ids.long())).trigger)
  reset(); assert.ok(run(msg('2013@s.whatsapp.net', ids.android(), { content: { listMessage: {} } })).trigger)
  reset(); assert.ok(run(msg('2014@s.whatsapp.net', ids.modern(), { content: { buttonsMessage: {} } })).trigger)
})
test('سلوك البوتات: رد فوري على الأوامر + معرّف حديث/اسم', () => {
  reset(); const c = ids.android(); run(msg(human, c, { text: '.menu' }))
  assert.ok(run(msg(bot, ids.modern(), { name: 'Cool Bot', stanza: c, dt: 900 })).trigger, 'اسم Bot + معرّف حديث + رد فوري')
  reset(); const c1 = ids.android(); run(msg(human, c1, { text: '.help' }))
  assert.equal(run(msg(bot, ids.modern(), { stanza: c1, dt: 800 })).trigger, false)
  const c2 = ids.android(); run(msg(human, c2, { text: '.ping', dt: 1500 }))
  assert.ok(run(msg(bot, ids.modern(), { stanza: c2, dt: 700 })).trigger, 'ردّان فوريان')
  reset(); const u = () => '3EB0' + hex(14) // معرّف غير معروف: السلوك لوحده ما يكفيش
  for (const tx of ['.a', '.b']) { const c = ids.android(); run(msg(human, c, { text: tx })); var r = run(msg(bot, u(), { stanza: c, dt: 700 })) }
  assert.equal(r.trigger, false)
})
test('الوضع الصارم أكثر حساسية', () => {
  reset(); g.antibotStrict = true
  assert.ok(run(msg('2020@s.whatsapp.net', ids.modern(), { name: 'WA Bot' })).trigger)
  reset(); assert.equal(run(msg('2021@s.whatsapp.net', ids.modern(), { name: 'Omar' })).trigger, false)
  g.antibotStrict = false
})
test('الاستثناءات: بوتاتنا والمسموحين', () => {
  assert.ok(AB.isExempt(g, '201999999999:12@s.whatsapp.net'))
  g.botAllow = ['201555555555']; assert.ok(AB.isExempt(g, '201555555555@s.whatsapp.net')); assert.ok(!AB.isExempt(g, '201555555556@s.whatsapp.net'))
})
test('العقوبة: مسح رسايل البوت بس + طرد + حظر دايم + إعلان، وطرد فوري عند الرجوع', async () => {
  const deleted = [], removed = [], said = []
  const sock = { sendMessage: async (j, c) => { if (c.delete) deleted.push(c.delete.id); else said.push(c) }, groupParticipantsUpdate: async (j, ps) => removed.push(ps[0]) }
  const botJid = '201133333333@s.whatsapp.net'
  for (let i = 0; i < 5; i++) recordMsg(JID, { id: 'M' + i, remoteJid: JID, participant: botJid }, botJid)
  recordMsg(JID, { id: 'H1', remoteJid: JID, participant: human }, human)
  await AB.punish({ sock, jid: JID, meta: { subject: 'T' }, sender: botJid, key: { id: 'MX', remoteJid: JID, participant: botJid }, reasons: ['بصمة Baileys القديمة'], total: 10 })
  assert.deepEqual(removed, [botJid]); assert.equal(deleted.length, 6); assert.ok(!deleted.includes('H1'))
  assert.ok(g.botBan['201133333333']); assert.match(said[0].text, /سماح بوت/)
  removed.length = 0
  await AB.onJoinCheck(sock, { id: JID, participants: [botJid, '201100000001@s.whatsapp.net'], action: 'add' })
  assert.deepEqual(removed, [botJid])
  g.botAllow = ['201133333333']; removed.length = 0
  await AB.onJoinCheck(sock, { id: JID, participants: [botJid], action: 'add' }); assert.equal(removed.length, 0)
})
test('الفحص النشط (أوامر فخ): يمسك اللي بيرد، ويسيب البشر، ويبلّغ عن الأدمن بدون طرد', async () => {
  const jid = 'scan@g.us', gg = gset(jid); gg.antibot = true
  let n = 0; const removed = [], texts = []
  const sock = { sendMessage: async (j, c) => { if (c.text && !c.mentions) { texts.push(c.text); return { key: { id: 'TRAP' + (++n) } } } return {} }, groupParticipantsUpdate: async (j, ps) => removed.push(ps[0]) }
  const botA = '201133333333@s.whatsapp.net', botC = '201155555555@s.whatsapp.net', adm = '201166666660@s.whatsapp.net', chatty = '201122222222@s.whatsapp.net'
  const txt = (tx, st) => ({ extendedTextMessage: { text: tx, contextInfo: st ? { stanzaId: st } : undefined } })
  const sc = (async () => { await new Promise((r) => setTimeout(r, 10)); for (let i = 1; i <= 6; i++) { await new Promise((r) => setTimeout(r, 25))
    AB.observe({ jid, sender: botA, m: {}, content: txt('قايمة', 'TRAP' + i), text: 'قايمة' })
    AB.observe({ jid, sender: botC, m: {}, content: txt('x'), text: '╭─ قايمة الأوامر الكاملة: menu, help, ping, owner, play, sticker ─╮' })
    for (let k = 0; k < 4; k++) AB.observe({ jid, sender: chatty, m: {}, content: txt('هههه'), text: 'هههه' })
    AB.observe({ jid, sender: adm, m: {}, content: txt('menu', 'TRAP' + i), text: 'menu' }) } })()
  const r = await AB.scanBots({ sock, jid, meta: {}, g: gg, kick: true, adminFn: (m, s) => s === adm })
  await sc
  assert.deepEqual(texts, ['.menu', '.help', '.ping', '.اوامر', '!help', '/menu'])
  assert.deepEqual(r.suspects.map((x) => x.n).sort(), ['201133333333', '201155555555'])
  assert.deepEqual(r.admins.map((x) => x.n), ['201166666660']); assert.equal(removed.length, 2)
  assert.ok(AB.isTrap('TRAP1') && !AB.isTrap('nope'))
  const p1 = AB.scanBots({ sock, jid, meta: {}, g: gg, adminFn: () => false }); assert.equal((await AB.scanBots({ sock, jid, meta: {}, g: gg, adminFn: () => false })).busy, true); await p1
})
