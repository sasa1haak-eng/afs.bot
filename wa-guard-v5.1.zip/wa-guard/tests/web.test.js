import './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
import crypto from 'node:crypto'
import http from 'node:http'
import { createWebServer } from '../web/server.js'
import { renderHome, sitemap, robots } from '../web/pages.js'

const lzb = (buf) => { let z = 0; for (const b of buf) { if (b === 0) { z += 8; continue } z += Math.clz32(b) - 24; break } return z }
function fakeDeps(over = {}) {
  const subs = new Map(); const calls = []
  return { calls, subs, maxSubs: 3, listSubs: () => [...subs.entries()].map(([number, linked]) => ({ number, linked, online: linked })),
    installSub: async (n, o) => { calls.push(n); if (over.fail) throw new Error(over.fail); subs.set(n, false); setTimeout(() => { subs.set(n, true); o.onLinked?.() }, 50); return 'ABCD1234' },
    removeSub: async (n) => subs.delete(n), ...over.deps }
}
async function boot(deps, opts = {}) {
  const srv = createWebServer(deps, { siteUrl: 'https://example.com', siteName: 'WA-Guard', powBits: 8, ...opts })
  await new Promise((r) => srv.listen(0, '127.0.0.1', r))
  const base = `http://127.0.0.1:${srv.address().port}`
  const call = async (p, init) => { const r = await fetch(base + p, init); const t = await r.text(); let j; try { j = JSON.parse(t) } catch {} return { r, t, j } }
  const post = (p, body, h = {}) => call(p, { method: 'POST', headers: { 'content-type': 'application/json', ...h }, body: JSON.stringify(body) })
  const solved = async (extra = {}) => {
    const { j: c } = await call('/api/challenge'); let nonce = 0
    while (lzb(crypto.createHash('sha256').update(`${c.ch}:${nonce}`).digest()) < c.bits) nonce++
    return { ch: c.ch, exp: c.exp, bits: c.bits, sig: c.sig, nonce, ...extra }
  }
  return { srv, base, call, post, solved, close: () => new Promise((r) => srv.close(r)) }
}
const body = (phone = '201012345678', x = {}) => ({ phone, consent: true, hp: '', ...x })

test('صفحات: SEO كامل (title/description/canonical/hreflang/JSON-LD/robots/sitemap)', async () => {
  const w = await boot(fakeDeps())
  for (const [p, lang] of [['/', 'ar'], ['/en/', 'en']]) {
    const { r, t } = await w.call(p)
    assert.equal(r.status, 200); assert.match(t, new RegExp(`<html lang="${lang}"`))
    for (const re of [/<title>[^<]{20,70}<\/title>/, /<meta name="description" content="[^"]{80,}/, /rel="canonical"/, /hreflang="x-default"/, /application\/ld\+json/, /property="og:title"/, /<h1>/]) assert.match(t, re, p + ' ' + re)
    assert.ok(!/\sstyle=/.test(t)); assert.match(r.headers.get('content-security-policy'), /script-src 'self'/)
  }
  assert.match((await w.call('/robots.txt')).t, /Sitemap: https:\/\/example\.com\/sitemap\.xml/)
  assert.match((await w.call('/sitemap.xml')).t, /hreflang="en"/)
  assert.equal((await w.call('/privacy')).r.status, 200); assert.equal((await w.call('/terms')).r.status, 200)
  assert.equal((await w.call('/og.png')).r.headers.get('content-type'), 'image/png')
  await w.close()
})
test('أمان الخادم: لا مسارات خارج المسموح، 404، طرق غير مسموحة', async () => {
  const w = await boot(fakeDeps())
  for (const p of ['/../package.json', '/assets/../../.env', '/%2e%2e/index.js', '/web/server.js', '/.env', '/db.json']) assert.equal((await w.call(p)).r.status, 404, p)
  assert.equal((await w.call('/', { method: 'DELETE' })).r.status, 405)
  assert.equal((await w.call('/api/pair')).r.status, 404)
  await w.close()
})
test('مسار الربط الكامل: تحدي ← كود ← حالة ← إلغاء', async () => {
  const d = fakeDeps(); const w = await boot(d)
  const { r, j } = await w.post('/api/pair', body('201012345678', await w.solved()))
  assert.equal(r.status, 200); assert.equal(j.code, 'ABCD-1234'); assert.ok(j.token)
  assert.deepEqual(d.calls, ['201012345678'])
  assert.equal((await w.call('/api/status?token=' + j.token)).j.state, 'waiting')
  await new Promise((r) => setTimeout(r, 120))
  assert.equal((await w.call('/api/status?token=' + j.token)).j.state, 'linked')
  assert.equal((await w.call('/api/status?token=nope')).r.status, 404) // مفيش تسريب لحالة أرقام الناس
  assert.equal((await w.post('/api/unlink', { token: j.token })).r.status, 200)
  assert.equal(d.subs.has('201012345678'), false)
  assert.equal((await w.call('/api/stats')).j.max, 3)
  await w.close()
})
test('الحماية من الإساءة: PoW/موافقة/رقم/فخ بوتات/تحدي مستخدم مرتين', async () => {
  const d = fakeDeps(); const w = await boot(d)
  const err = async (b) => (await w.post('/api/pair', b))
  assert.equal((await err(body('201012345678', { ch: 'x', sig: 'y', exp: 1, bits: 8, nonce: 1 }))).r.status, 400) // PoW مزوّر
  assert.equal((await err(body('201012345678', { ...(await w.solved()), consent: false }))).r.status, 400)
  assert.equal((await err(body('0123', await w.solved()))).r.status, 400) // رقم غلط
  assert.equal((await err(body('201012345678', await w.solved({ hp: 'bot' })))).r.status, 400)
  const s = await w.solved(); assert.equal((await err(body('201055555555', s))).r.status, 200)
  assert.equal((await err(body('201066666666', s))).r.status, 400) // نفس التحدي مرتين
  assert.deepEqual(d.calls, ['201055555555'])
  assert.equal((await w.post('/api/pair', 'x', { 'content-type': 'text/plain' })).r.status, 400)
  await w.close()
})
test('حدود المعدل: لكل IP ولكل رقم، وحد المقاعد', async () => {
  const d = fakeDeps(); const w = await boot(d)
  const codes = []
  for (let i = 0; i < 5; i++) codes.push((await w.post('/api/pair', body(`20101000000${i}`, await w.solved()))).r.status)
  assert.deepEqual(codes.slice(0, 3), [200, 200, 200]); assert.ok(codes.slice(3).every((c) => c === 429 || c === 503), codes.join())
  await w.close()
  const w2 = await boot(fakeDeps({ deps: { maxSubs: 0 } }))
  assert.equal((await w2.post('/api/pair', body('201012345678', await w2.solved()))).r.status, 503)
  await w2.close()
  const w3 = await boot(fakeDeps({ deps: { allow: () => false } }))
  assert.equal((await w3.post('/api/pair', body('201012345678', await w3.solved()))).r.status, 503)
  await w3.close()
})
test('أخطاء الربط بتتحول لرسائل آمنة (من غير تسريب داخلي)', async () => {
  const w = await boot(fakeDeps({ fail: 'ECONNRESET internal stack /home/x' }))
  const { r, j } = await w.post('/api/pair', body('201012345678', await w.solved()))
  assert.equal(r.status, 502); assert.ok(!JSON.stringify(j).includes('/home')); assert.ok(j.error_en)
  await w.close()
  const w2 = await boot(fakeDeps({ fail: 'استنى دقيقة قبل ما تطلب كود تاني.' }))
  assert.equal((await w2.post('/api/pair', body('201012345678', await w2.solved()))).r.status, 429)
  await w2.close()
})
test('جسم ضخم مرفوض، وIP العميل من Cloudflare فقط عبر loopback', async () => {
  const w = await boot(fakeDeps())
  const big = await w.call('/api/pair', { method: 'POST', headers: { 'content-type': 'application/json' }, body: 'x'.repeat(10000) }).catch((e) => ({ r: { status: 0 } }))
  assert.ok([0, 400].includes(big.r.status))
  // نفس الاتصال من loopback بترويسات مختلفة = عملاء مختلفين → حدود منفصلة
  const a = await w.call('/api/challenge', { headers: { 'cf-connecting-ip': '198.51.100.1' } })
  assert.equal(a.r.status, 200)
  await w.close()
})
test('أصل الصفحات: لا نصوص inline ولا أخطاء بالتوليد', () => {
  const cfg = { siteUrl: 'https://x.com', siteName: 'Z', supportUrl: '', hasOg: false }
  for (const l of ['ar', 'en']) { const h = renderHome(l, cfg); assert.ok(!/<script(?![^>]*(src=|application\/(ld\+)?json))/.test(h)); assert.ok(!h.includes('og:image')) }
  assert.match(robots(cfg), /Disallow: \/api\//); assert.match(sitemap(cfg), /<urlset/)
})
