import { TMP } from './_env.js'
import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
const { db, save } = await import('../lib.js')
const B = await import('../core/backup.js')

test('تشفير/فك + مفتاح غلط + تلاعب', () => {
  const buf = B.encrypt({ a: 1, ar: 'عربي' }, 'my-secret-key')
  assert.deepEqual(B.decrypt(buf, 'my-secret-key'), { a: 1, ar: 'عربي' })
  assert.throws(() => B.decrypt(buf, 'wrong-key-1234'), /فشل فك التشفير/)
  const t = Buffer.from(buf); t[t.length - 1] ^= 1
  assert.throws(() => B.decrypt(t, 'my-secret-key'), /فشل فك التشفير/)
  assert.throws(() => B.decrypt(Buffer.from('garbage-garbage-garbage-garbage-garbage-garbage'), 'k'), /مش نسخة/)
  assert.throws(() => B.encrypt({}, 'short'), /BACKUP_KEY/)
})
test('نسخة + استعادة كاملة مع نسخة أمان', () => {
  db.groups['g1@g.us'] = { antilink: true }; db.eco['201@s.whatsapp.net'] = { wallet: 500, bank: 0, inv: {}, last: {} }
  const b = B.createBackup('manual')
  assert.ok(fs.existsSync(b.path)); assert.match(b.name, /^backup-\d{8}-\d{6}\.wagb$/)
  db.groups['g2@g.us'] = { antilink: false }; delete db.eco['201@s.whatsapp.net']
  const r = B.restoreBackup(b.name)
  assert.ok(db.eco['201@s.whatsapp.net'] && !db.groups['g2@g.us'], 'اتسترجعت الحالة وقت النسخة')
  assert.ok(B.listBackups().some((x) => x.name === r.safety), 'نسخة الأمان اتعملت')
  assert.ok(db.brain && db.devs, 'القيم الافتراضية رجعت بعد الاستعادة')
})
test('حماية من الاسم الخبيث والنسخ التالفة', () => {
  assert.throws(() => B.readBackup('../../etc/passwd'), /غير صالح/)
  assert.throws(() => B.readBackup('backup-20200101-000000.wagb'), /مش موجودة/)
  fs.writeFileSync(path.join(B.BACKUP_DIR, 'backup-20200102-000000.wagb'), B.encrypt({ v: 1, db: { nothing: 1 } }))
  assert.throws(() => B.readBackup('backup-20200102-000000.wagb'), /غير سليم/)
  const before = JSON.stringify(db)
  assert.throws(() => B.restoreBackup('backup-20200102-000000.wagb'))
  assert.equal(JSON.stringify(db), before, 'الاستعادة الفاشلة ما بتغيّرش أي حاجة')
})
test('تقليم النسخ القديمة', () => {
  for (let i = 0; i < 14; i++) fs.writeFileSync(path.join(B.BACKUP_DIR, `backup-2021010${i % 9 + 1}-0000${String(i).padStart(2, '0')}.wagb`), B.encrypt({ v: 1, db: { groups: {} } }))
  B.pruneBackups(5)
  assert.ok(B.listBackups().length <= 5)
})
