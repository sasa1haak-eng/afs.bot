// ═══════════ 4.5 — الحماية والأمن السيبراني ═══════════
import fs from 'node:fs'
import { nm, digitsOf, cairo, ago } from './core/names.js'
import { events, counts, topActors, clearLog, TYPE_AR, sec } from './core/seclog.js'
import { startEmergency, endEmergency, recentJoins } from './core/shield.js'
import { createBackup, listBackups, readBackup, restoreBackup, keyReady, BACKUP_DIR } from './core/backup.js'
import { levelOf, LEVEL_AR, capabilities } from './core/perm.js'
import { DB_PATH, db as DB } from './lib.js'
import path from 'node:path'

export function register(c) {
  const { cmd, P, T, panel, kv, tag, getTarget, getMeta, isAdmin, botIsAdmin, gset, save, db, norm } = c
  const SEC = 'sec5'
  const GA = { group: true, sec: SEC } // أدمن + جروب
  const GAB = { group: true, botAdmin: true, sec: SEC }
  const OWN = { global: true, sec: SEC, dm: true }
  const numOf = (e, args) => { const t = getTarget(e, args); return t ? digitsOf(t) : (args.match(/\d{8,15}/) || [])[0] || null }
  const confirmed = (args) => /(^|\s)(تاكيد|تأكيد|confirm|yes)(\s|$)/i.test(norm(args))
  const stripConfirm = (args) => args.replace(/(^|\s)(تاكيد|تأكيد|confirm|yes)(?=\s|$)/gi, ' ').trim()

  // ── فحص أمني بدرجة وتوصيات ──
  cmd(nm('فحص امني'), 'admin', async (e) => {
    const g = gset(e.jid), meta = await getMeta(e.sock, e.jid)
    const admins = (meta?.participants || []).filter((p) => p.admin).length
    const checks = [
      [25, botIsAdmin(e.sock, meta), 'البوت أدمن', 'ارفع رقم البوت أدمن'],
      [10, g.antilink, 'حماية الروابط', `${P}تفعيل مكافحة الروابط`],
      [10, g.antiflood, 'مكافحة الإغراق', `${P}تفعيل مكافحة التكرار`],
      [5, g.antiprofanity, 'فلتر الشتائم', `${P}تفعيل مكافحة الشتائم`],
      [10, g.antibot, 'مضاد البوتات', `${P}تفعيل مضاد البوتات`],
      [5, g.antibotStrict, 'مضاد البوتات الصارم', `${P}مضاد البوتات صارم`],
      [10, g.raid?.on, 'كشف الهجمات الجماعية', `${P}كشف الهجمات تشغيل`],
      [10, meta?.joinApprovalMode, 'موافقة الأدمن على الانضمام', `${P}وضع الموافقة تشغيل`],
      [5, admins >= 2 && admins <= 10, `عدد الأدمنز مناسب (${admins})`, 'خلّي من 2 إلى 10 أدمن (واحد فقط = خطر، والكتير = تسريب صلاحيات)'],
      [5, meta?.restrict, 'تعديل بيانات الجروب للأدمن بس', 'من إعدادات الجروب: الأدمن بس يعدّل المعلومات'],
      [5, (g.warnLimit || 0) >= 2 && g.warnLimit <= 5, 'حد الإنذارات مناسب', `${P}ضبط التحذير 3`],
    ]
    const total = checks.reduce((s, x) => s + x[0], 0)
    const got = checks.reduce((s, x) => s + (x[1] ? x[0] : 0), 0)
    const score = Math.round((got / total) * 100)
    const grade = score >= 85 ? '🟢 ممتاز' : score >= 60 ? '🟡 مقبول' : '🔴 ضعيف'
    const fails = checks.filter((x) => !x[1])
    return e.reply(panel('🛡️ SECURITY AUDIT', [
      kv('الدرجة', `${score}/100 ${grade}`),
      ...checks.map((x) => `${x[1] ? '✅' : '❌'} ${x[2]}`),
      ...(fails.length ? ['', '🔧 التوصيات:', ...fails.slice(0, 5).map((x) => `▸ ${x[3]}`)] : ['', '✨ الجروب محمي بالكامل']),
    ]))
  }, GA)

  cmd(nm('سجل الامان'), 'admin', (e) => {
    const l = events({ jid: e.jid, limit: 12 })
    if (!l.length) return e.reply(`${T.info} مفيش أحداث أمنية مسجّلة للجروب ده.`)
    return e.reply(panel('📜 SECURITY LOG', l.map((x) => `${cairo(x.t)} · ${TYPE_AR[x.type] || x.type}${x.actor ? ' · ' + x.actor : ''}${x.why || x.reason || x.msg ? ' — ' + String(x.why || x.reason || x.msg).slice(0, 40) : ''}`)))
  }, GA)

  cmd(nm('حوادث'), 'admin', (e) => {
    const d = counts({ jid: e.jid, since: Date.now() - 86400_000 }), w = counts({ jid: e.jid, since: Date.now() - 7 * 86400_000 })
    const types = [...new Set([...Object.keys(d), ...Object.keys(w)])]
    if (!types.length) return e.reply(`${T.ok} مفيش حوادث أمنية في آخر 7 أيام.`)
    return e.reply(panel('🚨 INCIDENTS', types.map((t) => `${TYPE_AR[t] || t}: ${d[t] || 0} (24س) · ${w[t] || 0} (7 أيام)`)))
  }, GA)

  cmd(nm('اكثر مخالفة'), 'admin', (e) => {
    const top = topActors({ jid: e.jid, since: Date.now() - 7 * 86400_000, types: ['antibot', 'kick', 'ban', 'blacklist', 'flood', 'link', 'spam'] })
    return e.reply(top.length ? panel('📊 TOP OFFENDERS', top.map(([n, k], i) => `${i + 1}. ${n} — ${k} مخالفة`)) : `${T.ok} مفيش مخالفين مسجّلين في آخر 7 أيام.`)
  }, GA)

  cmd(['طوارئ'], 'admin', async (e) => {
    const g = gset(e.jid)
    if (g.emergency) return e.reply(`${T.warn} الطوارئ شغالة بالفعل من ${ago(g.emergency.t)}. للإنهاء: ${P}انهاء الطوارئ`)
    const meta = await getMeta(e.sock, e.jid)
    const r = await startEmergency({ sock: e.sock, jid: e.jid, meta, g, reason: 'يدوي', by: e.sender, canLock: botIsAdmin(e.sock, meta) })
    return e.reply(`🆘 *وضع الطوارئ مفعّل*\n┃ ▸ الجروب: ${r.locked ? 'اتقفل (الأدمن بس يكتب)' : 'ما اتقفلش (البوت مش أدمن)'}\n┃ ▸ اتفعّلت: الروابط · الشتائم · الإغراق · مضاد البوتات الصارم\n┃ ▸ الإنهاء: ${P}انهاء الطوارئ`)
  }, GA)
  cmd(nm('انهاء الطوارئ'), 'admin', async (e) => {
    const g = gset(e.jid)
    if (!g.emergency) return e.reply(`${T.info} مفيش طوارئ شغالة.`)
    const meta = await getMeta(e.sock, e.jid)
    const r = await endEmergency({ sock: e.sock, jid: e.jid, g, canUnlock: botIsAdmin(e.sock, meta) })
    return e.reply(`✅ انتهت الطوارئ ورجعت إعدادات الحماية السابقة${r.unlocked ? ' وفُتح الجروب' : ''}.`)
  }, GA)

  cmd(nm('كشف الهجمات'), 'admin', (e, args) => {
    const g = gset(e.jid), r = (g.raid ??= { on: false, limit: 8, window: 60 })
    const [a = '', v = ''] = args.trim().split(/\s+/)
    const s = norm(a)
    if (['تشغيل', 'تفعيل', 'on'].map(norm).includes(s)) r.on = true
    else if (['ايقاف', 'تعطيل', 'off'].map(norm).includes(s)) r.on = false
    else if (s === norm('حد') && +v >= 3 && +v <= 100) r.limit = +v
    else if (s === norm('مدة') && +v >= 10 && +v <= 600) r.window = +v
    else if (a && s !== norm('حالة')) return e.reply(`${T.info} اكتب: ${P}كشف الهجمات تشغيل | ايقاف | حد 8 | مدة 60 | حالة`)
    save()
    return e.reply(`🚨 كشف الهجمات: ${r.on ? '✅ شغال' : '❌ متوقف'}\n┃ ▸ الحد: ${r.limit} عضو جديد خلال ${r.window} ثانية\n┃ ▸ لما يتخطى الحد: طوارئ تلقائية (قفل الجروب + حماية كاملة) وتنبيه الأدمن`)
  }, GA)

  cmd(nm('سجل الانضمام'), 'admin', (e) => {
    const l = recentJoins(e.jid, 15)
    return e.reply(l.length ? panel('🚪 RECENT JOINS', l.map((x) => `${cairo(x.t)} · ${x.n}`), `آخر ساعة: ${l.filter((x) => Date.now() - x.t < 3600_000).length} عضو (من لحظة تشغيل البوت)`) : `${T.info} مفيش انضمامات مسجّلة من لحظة تشغيل البوت.`)
  }, GA)

  // ── القائمة السوداء (بتتطرد فوراً لو رجعت) ──
  cmd(['سود'], 'admin', async (e, args) => {
    const n = numOf(e, args)
    if (!n) return e.reply(`${T.info} منشن العضو أو ردّ على رسالته أو اكتب رقمه: ${P}سود 2010xxxxxxx`)
    const g = gset(e.jid)
    ;(g.blacklist ??= {})[n] = { t: Date.now(), by: digitsOf(e.sender) }
    sec('blacklist', { jid: e.jid, actor: n, by: digitsOf(e.sender) })
    save()
    let kicked = false
    try { await e.sock.groupParticipantsUpdate(e.jid, [n + '@s.whatsapp.net'], 'remove'); kicked = true } catch {}
    return e.reply(`📛 @${n} اتحط في القائمة السوداء${kicked ? ' واتطرد' : ''}. لو دخل الجروب تاني هيتطرد فوراً.`, [n + '@s.whatsapp.net'])
  }, GAB)
  cmd(['بيض'], 'admin', (e, args) => {
    const n = numOf(e, args), g = gset(e.jid)
    if (!n || !g.blacklist?.[n]) return e.reply(`${T.info} الرقم ده مش في القائمة السوداء. شوفها بـ ${P}القائمة السوداء`)
    delete g.blacklist[n]; save()
    return e.reply(`${T.ok} اتشال @${n} من القائمة السوداء.`, [n + '@s.whatsapp.net'])
  }, GA)
  cmd(nm('القائمة السوداء'), 'admin', (e) => {
    const l = Object.entries(gset(e.jid).blacklist || {})
    return e.reply(l.length ? panel('📛 BLACKLIST', l.slice(-15).map(([n, x]) => `${n} — من ${ago(x.t)}`)) : `${T.info} القائمة السوداء فاضية.`)
  }, GA)

  // ── الصلاحيات ──
  cmd(nm('صلاحياتي'), 'all', async (e) => {
    const admin = e.isGroup ? isAdmin(await getMeta(e.sock, e.jid), e.sender) : false
    const lv = levelOf(e, admin)
    return e.reply(panel('🔑 PERMISSIONS', [kv('مستواك', LEVEL_AR[lv]), '', ...capabilities(lv).map((x) => `▸ ${x}`)]))
  }, { sec: SEC })
  cmd(['صلاحيات'], 'admin', async (e, args) => {
    const t = getTarget(e, args)
    if (!t) return e.reply(`${T.info} منشن العضو: ${P}صلاحيات @فلان`)
    const meta = await getMeta(e.sock, e.jid)
    const dev = !!db.devs?.[digitsOf(t)]
    return e.reply(`🔑 @${digitsOf(t)}: ${isAdmin(meta, t) ? 'أدمن' : 'عضو'}${dev ? ' · مطور مُمكَّن' : ''}`, [t])
  }, GA)

  // ── سلامة البيانات ──
  cmd(nm('سلامة البيانات'), 'owner', async (e, args) => {
    const fix = norm(args) === norm('اصلاح')
    const rep = []
    let raw = null
    try { raw = JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); rep.push('✅ ملف البيانات سليم وقابل للقراءة') } catch (er) { rep.push(`❌ ملف البيانات: ${er.message.slice(0, 50)}`) }
    try { const st = fs.statSync(DB_PATH + '.bak'); rep.push(`✅ لقطة احتياطية (.bak) عمرها ${ago(st.mtimeMs)}`) } catch { rep.push('⚠️ مفيش لقطة .bak لسه (بتتعمل كل 10 دقايق مع الحفظ)') }
    let bad = 0, fixed = 0
    for (const [id, u] of Object.entries(DB.eco)) {
      for (const k of ['wallet', 'bank']) {
        if (typeof u[k] !== 'number' || !Number.isFinite(u[k]) || u[k] < 0) { bad++; if (fix) { u[k] = 0; fixed++ } }
      }
    }
    rep.push(bad ? `${fix ? '🛠️ اتصلّح' : '⚠️ فيه'} ${bad} رصيد غير سليم (NaN/سالب)` : '✅ كل الأرصدة أرقام سليمة')
    const noSettings = Object.entries(DB.groups).filter(([, g]) => typeof g !== 'object' || g === null).length
    rep.push(noSettings ? `⚠️ ${noSettings} جروب بإعدادات تالفة` : '✅ إعدادات الجروبات سليمة')
    rep.push(kv('الجروبات', Object.keys(DB.groups).length), kv('حسابات الاقتصاد', Object.keys(DB.eco).length), kv('المطورين', Object.keys(DB.devs).length))
    if (fix && fixed) save()
    return e.reply(panel('🧬 DATA INTEGRITY', rep, bad && !fix ? `للإصلاح: ${P}سلامة البيانات اصلاح` : undefined))
  }, OWN)

  // ── النسخ الاحتياطي المشفّر ──
  cmd(nm('نسخة احتياطية'), 'owner', async (e) => {
    if (!keyReady()) return e.reply(`${T.warn} ضيف في .env سطر BACKUP_KEY=كلمة_سر_قوية (8 حروف على الأقل) وأعد تشغيل البوت. بدونها مفيش نسخ مشفّرة.`)
    const b = createBackup('manual')
    const to = e.isGroup ? digitsOf(e.sender) + '@s.whatsapp.net' : e.jid
    await e.sock.sendMessage(to, { document: fs.readFileSync(b.path), mimetype: 'application/octet-stream', fileName: b.name, caption: '💾 نسخة احتياطية مشفّرة (AES-256). احتفظ بها مع BACKUP_KEY في مكان آمن.' })
    return e.reply(`${T.ok} اتعملت النسخة ${b.name} (${(b.bytes / 1024).toFixed(0)} KB)${e.isGroup ? ' واتبعتت لك في الخاص' : ''}.`)
  }, OWN)
  cmd(['النسخ'], 'owner', (e) => {
    const l = listBackups()
    return e.reply(l.length ? panel('💾 BACKUPS', l.slice(0, 10).map((b) => `${b.name} · ${(b.bytes / 1024).toFixed(0)}KB · ${ago(b.mtime)}`), `${P}استعادة اسم_النسخة (أو: اخر)`) : `${T.info} مفيش نسخ بعد. ${P}نسخة احتياطية`)
  }, OWN)
  cmd(['استعادة'], 'owner', async (e, args) => {
    if (!keyReady()) return e.reply(`${T.warn} BACKUP_KEY مش متظبط في .env`)
    let name = stripConfirm(args).trim()
    if (!name || norm(name) === norm('اخر')) name = listBackups()[0]?.name
    if (!name) return e.reply(`${T.info} مفيش نسخ للاستعادة.`)
    let p
    try { p = readBackup(name) } catch (er) { return e.reply(`${T.err} ${er.message}`) }
    const info = `${name}\n┃ ▸ بتاريخ: ${cairo(p.at)}\n┃ ▸ فيها: ${Object.keys(p.db.groups).length} جروب · ${Object.keys(p.db.eco || {}).length} حساب`
    if (!confirmed(args)) return e.reply(`⚠️ *هتتبدّل كل البيانات الحالية بالنسخة دي:*\n┃ ▸ ${info}\n┃ ▸ هتتعمل نسخة أمان من الحالة الحالية قبل الاستبدال.\n┃ ▸ للتأكيد: ${P}استعادة ${name} تأكيد`)
    const r = restoreBackup(name)
    return e.reply(`♻️ *تمت الاستعادة*\n┃ ▸ ${r.restored}\n┃ ▸ نسخة الأمان: ${r.safety}\n┃ ▸ ${r.groups} جروب · ${r.users} حساب`)
  }, OWN)
  cmd(nm('حذف نسخة'), 'owner', (e, args) => {
    const name = args.trim()
    if (!listBackups().some((b) => b.name === name)) return e.reply(`${T.err} الاسم غلط. شوف ${P}النسخ`)
    fs.rmSync(path.join(BACKUP_DIR, name))
    return e.reply(`${T.ok} اتحذفت النسخة ${name}.`)
  }, OWN)
  cmd(nm('مسح السجل الامني'), 'owner', (e, args) => {
    if (!confirmed(args)) return e.reply(`⚠️ هيتمسح السجل الأمني والأخطاء كلها. للتأكيد: ${P}مسح السجل الامني تأكيد`)
    clearLog()
    return e.reply(`${T.ok} اتمسح السجل الأمني.`)
  }, OWN)
}
