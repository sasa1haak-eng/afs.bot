import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'
import { Readable } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { CONFIG, db, log } from './lib.js'
import { SURAHS } from './data.js'

const API = 'https://www.mp3quran.net/api/v3'
const CACHE_FILE = path.resolve('reciters-cache.json')
const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'

export const pad3 = (n) => String(n).padStart(3, '0')

// توحيد الحروف: بدون تشكيل ولا مسافات ولا "ال" التعريف
export const nq = (s = '') =>
  String(s)
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim()
    .replace(/^سوره\s*/, '')
    .replace(/\s+/g, '')
    .replace(/^ال(?=.{2,})/, '')

const SURAH_KEYS = SURAHS.map(nq)

// رقم السورة من الاسم أو الرقم (0 = مش لاقيها)
export function findSurah(text) {
  const t = String(text).trim()
  if (/^\d{1,3}$/.test(t)) {
    const n = Number(t)
    return n >= 1 && n <= 114 ? n : 0
  }
  const k = nq(t)
  if (!k) return 0
  let i = SURAH_KEYS.indexOf(k)
  if (i >= 0) return i + 1
  const starts = SURAH_KEYS.map((x, j) => (x.startsWith(k) ? j : -1)).filter((j) => j >= 0)
  if (starts.length === 1) return starts[0] + 1
  const inc = SURAH_KEYS.map((x, j) => (x.includes(k) ? j : -1)).filter((j) => j >= 0)
  if (k.length >= 3 && inc.length === 1) return inc[0] + 1
  return 0
}

// ═══════════════ القراء (mp3quran.net) ═══════════════
// قراء مضمونين (سيرفراتهم اتأكدت من الواجهة) لو النت أو الواجهة مش متاحة
const FALLBACK = [
  { id: 'fb-maher', name: 'ماهر المعيقلي', moshafs: [{ id: 'fb1', name: 'حفص عن عاصم - مرتل', server: 'https://server12.mp3quran.net/maher/', total: 114, surahs: null }] },
  { id: 'fb-akdr', name: 'إبراهيم الأخضر', moshafs: [{ id: 'fb2', name: 'حفص عن عاصم - مرتل', server: 'https://server6.mp3quran.net/akdr/', total: 114, surahs: null }] },
]

export const CURATED = [
  'مشاري العفاسي', 'ماهر المعيقلي', 'عبد الباسط عبد الصمد', 'عبد الرحمن السديس',
  'سعود الشريم', 'محمود خليل الحصري', 'محمد صديق المنشاوي', 'سعد الغامدي',
  'ناصر القطامي', 'ياسر الدوسري', 'أحمد العجمي', 'إبراهيم الأخضر',
]

let cache = { t: 0, list: null }

function normalizeApi(j) {
  return (j.reciters || [])
    .map((r) => ({
      id: r.id,
      name: String(r.name || '').trim(),
      moshafs: (r.moshaf || [])
        .filter((m) => m.server)
        .map((m) => ({
          id: m.id,
          name: String(m.name || ''),
          server: String(m.server).endsWith('/') ? String(m.server) : String(m.server) + '/',
          total: Number(m.surah_total || 0),
          surahs: m.surah_list
            ? new Set(String(m.surah_list).split(',').map((x) => Number(x.trim())).filter(Boolean))
            : null,
        })),
    }))
    .filter((r) => r.name && r.moshafs.length)
}

export async function getReciters() {
  if (cache.list && Date.now() - cache.t < 12 * 3600_000) return cache.list
  try {
    const res = await fetch(`${API}/reciters?language=ar`, {
      headers: { 'user-agent': UA },
      signal: AbortSignal.timeout(20_000),
    })
    if (!res.ok) throw new Error('status ' + res.status)
    const list = normalizeApi(await res.json())
    if (!list.length) throw new Error('قايمة فاضية')
    cache = { t: Date.now(), list }
    try { fs.writeFileSync(CACHE_FILE, JSON.stringify({ reciters: list.map((r) => ({ ...r, moshafs: r.moshafs.map((m) => ({ ...m, surahs: m.surahs ? [...m.surahs] : null })) })) })) } catch {}
    return list
  } catch (e) {
    log('القراء: تعذر التحميل من mp3quran:', e.message)
    if (cache.list) return cache.list
    try {
      const j = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'))
      const list = (j.reciters || []).map((r) => ({
        ...r,
        moshafs: r.moshafs.map((m) => ({ ...m, surahs: m.surahs ? new Set(m.surahs) : null })),
      }))
      if (list.length) {
        cache = { t: Date.now() - 11 * 3600_000, list } // يحاول تاني بعد ساعة
        return list
      }
    } catch {}
    cache = { t: Date.now() - 11.9 * 3600_000, list: FALLBACK }
    return FALLBACK
  }
}

// أنسب مصحف للقارئ: حفص مرتل كامل ويحتوي السورة المطلوبة
export function bestMoshaf(rec, surah) {
  const has = (m) => !m.surahs || m.surahs.has(surah)
  const ok = rec.moshafs.filter(has)
  if (!ok.length) return null
  const score = (m) =>
    (/حفص/.test(m.name) ? 4 : 0) + (/مرتل/.test(m.name) ? 2 : 0) + (m.total >= 114 ? 1 : 0)
  return ok.sort((a, b) => score(b) - score(a))[0]
}

export function findReciter(list, query) {
  const k = nq(query).replace(/^ال/, '')
  if (!k) return null
  return (
    list.find((r) => nq(r.name) === k) ||
    list.find((r) => nq(r.name).includes(k)) ||
    null
  )
}

// القراء المشهورين (بالترتيب) لو لقيناهم في القايمة
export async function curated() {
  const list = await getReciters()
  const out = []
  for (const name of CURATED) {
    const r = list.find((x) => nq(x.name).includes(nq(name)))
    if (r && !out.includes(r) && bestMoshaf(r, 1)) out.push(r)
  }
  for (const r of list) {
    if (out.length >= 8) break
    if (!out.includes(r) && bestMoshaf(r, 1)) out.push(r)
  }
  return out
}

export async function defaultReciter(jid) {
  const list = await getReciters()
  const saved = db.quran?.[jid]
  const byId = saved != null && list.find((r) => String(r.id) === String(saved))
  if (byId) return byId
  return findReciter(list, CONFIG.QURAN_DEFAULT) || (await curated())[0] || list[0]
}

// ═══════════════ تحميل ملف التلاوة ═══════════════
// بينزل على ملف مؤقت (مش في الذاكرة) ويوقف لو عدّى الحد
export async function fetchSurahFile(url, maxBytes) {
  const res = await fetch(url, { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(300_000) })
  if (!res.ok) throw new Error(`السيرفر رد بـ ${res.status}`)
  const len = Number(res.headers.get('content-length') || 0)
  if (len && len > maxBytes) {
    try { await res.body?.cancel() } catch {}
    return { tooBig: true, size: len }
  }
  const file = path.join(os.tmpdir(), `quran_${crypto.randomBytes(5).toString('hex')}.mp3`)
  let n = 0
  async function* limit(src) {
    for await (const chunk of src) {
      n += chunk.length
      if (n > maxBytes) throw Object.assign(new Error('BIG'), { big: true })
      yield chunk
    }
  }
  try {
    await pipeline(Readable.fromWeb(res.body), limit, fs.createWriteStream(file))
  } catch (e) {
    try { fs.unlinkSync(file) } catch {}
    if (e.big) return { tooBig: true, size: n }
    throw e
  }
  return { file, size: n }
}
