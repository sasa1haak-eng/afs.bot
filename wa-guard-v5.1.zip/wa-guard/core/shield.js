// ═══════════ الدرع: الطوارئ + كشف الهجمات الجماعية + القائمة السوداء ═══════════
import { gset, save, log } from '../lib.js'
import { sec } from './seclog.js'
import { digitsOf } from './names.js'

const joins = new Map() // جروب → [{ n, t }]  (آخر 60)
export const recentJoins = (jid, limit = 15) => (joins.get(jid) ?? []).slice(-limit).reverse()
export function recordJoins(jid, participants, now = Date.now()) {
  const a = joins.get(jid) ?? []
  for (const p of participants) a.push({ n: digitsOf(typeof p === 'string' ? p : p.id), t: now })
  while (a.length > 60) a.shift()
  joins.set(jid, a)
  if (joins.size > 400) joins.delete(joins.keys().next().value)
  return a
}

export async function startEmergency({ sock, jid, meta, g = gset(jid), reason = 'يدوي', by = '', canLock = false }) {
  if (g.emergency) return { already: true }
  g.emergency = {
    t: Date.now(), reason, by,
    prev: { announce: !!meta?.announce, antilink: !!g.antilink, antiprofanity: !!g.antiprofanity, antiflood: !!g.antiflood, antibot: !!g.antibot, antibotStrict: !!g.antibotStrict },
  }
  Object.assign(g, { antilink: true, antiprofanity: true, antiflood: true, antibot: true, antibotStrict: true })
  let locked = false
  if (canLock) { try { await sock.groupSettingUpdate(jid, 'announcement'); locked = true } catch (e) { log('تعذر قفل الجروب في الطوارئ:', e.message) } }
  sec('emergency', { jid, reason, actor: digitsOf(by), locked })
  save()
  return { locked }
}
export async function endEmergency({ sock, jid, g = gset(jid), canUnlock = false }) {
  const em = g.emergency
  if (!em) return { none: true }
  Object.assign(g, em.prev && { antilink: em.prev.antilink, antiprofanity: em.prev.antiprofanity, antiflood: em.prev.antiflood, antibot: em.prev.antibot, antibotStrict: em.prev.antibotStrict })
  let unlocked = false
  if (canUnlock && !em.prev?.announce) { try { await sock.groupSettingUpdate(jid, 'not_announcement'); unlocked = true } catch {} }
  delete g.emergency
  sec('emergency', { jid, reason: 'انتهت', actor: '', ended: true })
  save()
  return { unlocked }
}

// بيتنادى عند أي تغيير في أعضاء الجروب
export async function onParticipants(sock, { id, participants, action }, { getMeta, botIsAdmin } = {}) {
  if (action !== 'add') return { count: 0 }
  const g = gset(id)
  const list = recordJoins(id, participants)
  let meta = null, adminOk = false
  const ensureMeta = async () => { if (!meta && getMeta) { meta = await getMeta(sock, id).catch(() => null); adminOk = !!(meta && botIsAdmin?.(sock, meta)) } }
  const out = { kicked: [], raid: false }

  // 1) القائمة السوداء: بتتطرد فوراً
  for (const p of participants) {
    const jid = typeof p === 'string' ? p : p.id
    const n = digitsOf(jid)
    if (g.blacklist?.[n]) {
      await ensureMeta()
      if (!adminOk) continue
      try {
        await sock.groupParticipantsUpdate(id, [jid], 'remove')
        out.kicked.push(n)
        sec('blacklist', { jid: id, actor: n, why: 'دخول رقم في القائمة السوداء' })
        await sock.sendMessage(id, { text: `📛 @${n} في القائمة السوداء وتم طرده عند الدخول.`, mentions: [jid] }).catch(() => {})
      } catch (e) { log('تعذر طرد رقم من القائمة السوداء:', e.message) }
    }
  }

  // 2) كشف الهجمات: عدد كبير يدخل في وقت قصير
  const r = g.raid
  if (r?.on && !g.emergency) {
    const win = (r.window || 60) * 1000, limit = r.limit || 8
    const now = Date.now()
    const recent = list.filter((x) => now - x.t <= win)
    if (recent.length >= limit) {
      await ensureMeta()
      out.raid = true
      const res = await startEmergency({ sock, jid: id, meta, g, reason: `هجوم جماعي (${recent.length} عضو في ${r.window || 60}ث)`, by: 'auto', canLock: adminOk })
      sec('raid', { jid: id, count: recent.length, window: r.window || 60, locked: !!res.locked })
      await sock.sendMessage(id, {
        text: `🚨 *تم رصد هجوم جماعي*\n┃ ▸ دخل ${recent.length} عضو في ${r.window || 60} ثانية\n┃ ▸ تفعيل وضع الطوارئ: ${res.locked ? 'اتقفل الجروب (الأدمن بس)' : 'اتفعّلت كل الحماية (البوت مش أدمن فمقدرش يقفل)'}\n┃ ▸ الأدمن: راجعوا .سجل الانضمام ثم .انهاء الطوارئ`,
      }).catch(() => {})
      if (res.locked) setTimeout(() => endEmergency({ sock, jid: id, g, canUnlock: true }).catch(() => {}), 30 * 60_000).unref?.()
    }
  }
  return out
}
