// ═══════════ مراقبة صحة النظام ═══════════
import os from 'node:os'
import fs from 'node:fs'
import { db, DB_PATH } from '../lib.js'

export const startedAt = Date.now()
let lagNow = 0, lagMax = 0
let last = Date.now()
setInterval(() => {
  const now = Date.now()
  lagNow = Math.max(0, now - last - 1000)
  lagMax = Math.max(lagMax * 0.98, lagNow) // بيتلاشى تدريجياً
  last = now
}, 1000).unref()

export const fmtDur = (ms) => {
  const s = Math.floor(ms / 1000), d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60)
  return `${d ? d + ' يوم ' : ''}${h ? h + ' س ' : ''}${m} د`
}
export const mb = (b) => `${(b / 1048576).toFixed(1)} MB`

export function snapshot() {
  const mem = process.memoryUsage()
  let dbBytes = 0
  try { dbBytes = fs.statSync(DB_PATH).size } catch {}
  const groups = Object.keys(db.groups || {}).length
  const users = Object.keys(db.eco || {}).length
  return {
    uptimeMs: Date.now() - startedAt, rss: mem.rss, heapUsed: mem.heapUsed, heapTotal: mem.heapTotal, external: mem.external,
    lagNow, lagMax: Math.round(lagMax), load: os.loadavg()[0], cores: os.cpus().length,
    freeMem: os.freemem(), totalMem: os.totalmem(), node: process.version, platform: `${os.platform()} ${os.arch()}`,
    termux: !!process.env.TERMUX_VERSION || /com\.termux/.test(process.env.PREFIX || ''), dbBytes, groups, users,
  }
}
// تقييم بسيط: ok / warn / bad
export function verdict(s = snapshot()) {
  const issues = []
  if (s.rss > 700 * 1048576) issues.push('استهلاك ذاكرة عالي (>700MB)')
  if (s.lagMax > 500) issues.push('تأخر في حلقة الأحداث (>500ms)')
  if (s.dbBytes > 50 * 1048576) issues.push('ملف البيانات كبير (>50MB)')
  if (s.freeMem / s.totalMem < 0.05) issues.push('ذاكرة الجهاز فاضية أقل من 5%')
  return { level: issues.length ? (issues.length > 1 ? 'bad' : 'warn') : 'ok', issues }
}
