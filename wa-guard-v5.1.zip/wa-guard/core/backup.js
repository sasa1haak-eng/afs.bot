// ═══════════ نسخ احتياطي مشفّر (AES-256-GCM) واستعادة ═══════════
// المفتاح من BACKUP_KEY في .env (8 حروف على الأقل) ويتشتق بـ scrypt. صيغة الملف: WAGB1 | salt(16) | iv(12) | tag(16) | بيانات مضغوطة ومشفّرة
import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import { db, save, ensureDb, STATE_DIR } from '../lib.js'
import { DATA_DIR, sec } from './seclog.js'

export const BACKUP_DIR = path.join(DATA_DIR, 'backups')
const MAGIC = Buffer.from('WAGB1')
const NAME_RE = /^backup-\d{8}-\d{6}(-[a-z-]+)?\.wagb$/
export const keyReady = () => (process.env.BACKUP_KEY || '').length >= 8
const deriveKey = (salt, key = process.env.BACKUP_KEY) => crypto.scryptSync(key, salt, 32)

export function encrypt(obj, key = process.env.BACKUP_KEY) {
  if (!key || key.length < 8) throw new Error('ضع BACKUP_KEY في .env (8 حروف على الأقل) عشان النسخ المشفّرة تشتغل')
  const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12)
  const c = crypto.createCipheriv('aes-256-gcm', deriveKey(salt, key), iv)
  const body = Buffer.concat([c.update(zlib.gzipSync(Buffer.from(JSON.stringify(obj)))), c.final()])
  return Buffer.concat([MAGIC, salt, iv, c.getAuthTag(), body])
}
export function decrypt(buf, key = process.env.BACKUP_KEY) {
  if (!key) throw new Error('BACKUP_KEY مش متظبط')
  if (buf.length < 49 || !buf.subarray(0, 5).equals(MAGIC)) throw new Error('الملف مش نسخة احتياطية صالحة')
  const salt = buf.subarray(5, 21), iv = buf.subarray(21, 33), tag = buf.subarray(33, 49), body = buf.subarray(49)
  const d = crypto.createDecipheriv('aes-256-gcm', deriveKey(salt, key), iv)
  d.setAuthTag(tag)
  try { return JSON.parse(zlib.gunzipSync(Buffer.concat([d.update(body), d.final()])).toString('utf8')) }
  catch { throw new Error('فشل فك التشفير: المفتاح غلط أو الملف اتعدّل') }
}

const stamp = () => new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14).replace(/^(\d{8})(\d{6})$/, '$1-$2')
export function listBackups() {
  try {
    return fs.readdirSync(BACKUP_DIR).filter((f) => NAME_RE.test(f)).sort().reverse()
      .map((name) => { const st = fs.statSync(path.join(BACKUP_DIR, name)); return { name, bytes: st.size, mtime: st.mtimeMs } })
  } catch { return [] }
}
export function pruneBackups(keep = 10) {
  for (const b of listBackups().slice(keep)) { try { fs.rmSync(path.join(BACKUP_DIR, b.name)) } catch {} }
}
export function createBackup(reason = 'manual') {
  const extra = {}
  try { extra.lockdown = JSON.parse(fs.readFileSync(path.join(STATE_DIR, 'lockdown.json'), 'utf8')) } catch {}
  const buf = encrypt({ v: 1, at: Date.now(), db, extra })
  fs.mkdirSync(BACKUP_DIR, { recursive: true })
  const tagPart = reason === 'manual' ? '' : `-${reason}`
  const name = `backup-${stamp()}${tagPart}.wagb`
  fs.writeFileSync(path.join(BACKUP_DIR, name), buf, { mode: 0o600 })
  pruneBackups(10)
  sec('backup', { name, bytes: buf.length, reason })
  return { name, path: path.join(BACKUP_DIR, name), bytes: buf.length }
}
export function readBackup(name) {
  if (!NAME_RE.test(name)) throw new Error('اسم النسخة غير صالح')
  const p = path.join(BACKUP_DIR, name)
  if (!fs.existsSync(p)) throw new Error('النسخة دي مش موجودة')
  const payload = decrypt(fs.readFileSync(p))
  if (payload?.v !== 1 || !payload.db || typeof payload.db !== 'object' || typeof payload.db.groups !== 'object') throw new Error('محتوى النسخة غير سليم')
  return payload
}
export function restoreBackup(name) {
  const payload = readBackup(name) // لو فشل مفيش أي تغيير
  const safety = createBackup('pre-restore') // نسخة أمان من الحالة الحالية قبل الاستبدال
  for (const k of Object.keys(db)) delete db[k]
  Object.assign(db, payload.db)
  ensureDb()
  save()
  sec('restore', { name, safety: safety.name })
  return { restored: name, safety: safety.name, groups: Object.keys(db.groups).length, users: Object.keys(db.eco).length }
}
let timer
export function scheduleAuto(hours = 24) {
  if (timer || !keyReady()) return false
  timer = setInterval(() => { try { createBackup('auto') } catch {} }, hours * 3600_000)
  timer.unref?.()
  return true
}
