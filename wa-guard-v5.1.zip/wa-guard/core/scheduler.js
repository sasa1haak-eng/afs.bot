// ═══════════ مجدول الإعلانات ═══════════
// g.schedules = [{ id, text, at, every, num }]  — every بالدقايق للتكرار اليومي/الدوري، num رقم البوت اللي هيبعت
import { db, save, log } from '../lib.js'
import { sockByNumber } from '../sessions.js'

const LATE_MS = 6 * 3600_000 // إعلان متأخر أكتر من 6 ساعات (البوت كان مقفول) بيتلغى
export async function tick(now = Date.now(), getSock = sockByNumber) {
  let sent = 0
  for (const [jid, g] of Object.entries(db.groups)) {
    if (!g?.schedules?.length) continue
    for (const s of [...g.schedules]) {
      if (s.at > now) continue
      if (now - s.at > LATE_MS && !s.every) { g.schedules = g.schedules.filter((x) => x !== s); save(); log(`⏭️ إعلان مجدول فات ميعاده بأكتر من 6 ساعات واتلغى (${jid})`); continue }
      const sock = getSock(s.num)
      if (!sock) continue // البوت مش متصل دلوقتي: نحاول في الدورة الجاية
      try { await sock.sendMessage(jid, { text: s.text }); sent++ } catch (e) { log('تعذر إرسال إعلان مجدول:', e.message); continue }
      if (s.every) s.at += s.every * 60_000 * Math.max(1, Math.ceil((now - s.at + 1) / (s.every * 60_000)))
      else g.schedules = g.schedules.filter((x) => x !== s)
      save()
    }
  }
  return sent
}
let timer
export function startScheduler() { if (!timer) { timer = setInterval(() => tick().catch(() => {}), 30_000); timer.unref?.() } }

// أقرب وقت HH:MM بتوقيت القاهرة (النهارده أو بكره)
export function nextCairoTime(hh, mm, now = Date.now()) {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })
  const p = Object.fromEntries(f.formatToParts(new Date(now)).map((x) => [x.type, +x.value]))
  const offset = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(now / 1000) * 1000
  let t = Date.UTC(p.year, p.month - 1, p.day, hh, mm, 0) - offset
  if (t <= now) t += 86400_000
  return t
}
