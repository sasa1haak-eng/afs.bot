// ═══════════ دوال الأدوات (صافية بدون واتساب → قابلة للاختبار) ═══════════
import crypto from 'node:crypto'

// ── ترميز ──
export const hash = (algo, text) => crypto.createHash(algo).update(text, 'utf8').digest('hex')
export const hexEnc = (s) => Buffer.from(s, 'utf8').toString('hex').replace(/(..)/g, '$1 ').trim()
export const hexDec = (h) => { const x = h.replace(/\s+/g, ''); if (!/^([0-9a-f]{2})+$/i.test(x)) throw new Error('صيغة hex غير صالحة'); return Buffer.from(x, 'hex').toString('utf8') }
const IND = '٠١٢٣٤٥٦٧٨٩'
export const toIndic = (s) => s.replace(/[0-9]/g, (d) => IND[d])
export const toWestern = (s) => s.replace(/[٠-٩]/g, (d) => IND.indexOf(d)).replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))

// ── رقم → كلمات عربي (حتى 999,999,999,999) ──
const ONES = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر']
const TENS = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون']
const HUNDS = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة']
const below1000 = (n) => {
  const h = Math.floor(n / 100), r = n % 100, parts = []
  if (h) parts.push(HUNDS[h])
  if (r) parts.push(r < 20 ? ONES[r] : (r % 10 ? ONES[r % 10] + ' و' : '') + TENS[Math.floor(r / 10)])
  return parts.join(' و')
}
const SCALES = [['', '', '', ''], ['ألف', 'ألفان', 'آلاف', 'ألف'], ['مليون', 'مليونان', 'ملايين', 'مليون'], ['مليار', 'ملياران', 'مليارات', 'مليار']]
export function numToWords(n) {
  n = Math.trunc(Number(n))
  if (!Number.isFinite(n) || Math.abs(n) > 999_999_999_999) throw new Error('الرقم لازم يكون بين -999,999,999,999 و999,999,999,999')
  if (n === 0) return 'صفر'
  const neg = n < 0; n = Math.abs(n)
  const groups = []
  for (let i = 0; n > 0; i++, n = Math.floor(n / 1000)) groups.push(n % 1000)
  const out = []
  for (let i = groups.length - 1; i >= 0; i--) {
    const g = groups[i]
    if (!g) continue
    if (i === 0) out.push(below1000(g))
    else {
      const [one, two, few, many] = SCALES[i]
      out.push(g === 1 ? one : g === 2 ? two : g <= 10 ? `${below1000(g)} ${few}` : `${below1000(g)} ${many}`)
    }
  }
  return (neg ? 'سالب ' : '') + out.join(' و')
}

// ── تاريخ هجري/ميلادي ──
const hijriF = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'numeric', year: 'numeric', timeZone: 'UTC' })
const hijriName = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'long', year: 'numeric', weekday: 'long', timeZone: 'UTC' })
const hparts = (d) => Object.fromEntries(hijriF.formatToParts(d).map((p) => [p.type, +p.value]))
export const toHijri = (date = new Date()) => { const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())); const p = hparts(d); return { y: p.year, m: p.month, d: p.day, text: hijriName.format(d) } }
export function fromHijri(y, m, d) {
  if (y < 1300 || y > 1600 || m < 1 || m > 12 || d < 1 || d > 30) throw new Error('تاريخ هجري غير صالح (السنة 1300–1600)')
  const est = Math.round(y * 0.970224 + 621.5774)
  for (let t = Date.UTC(est - 1, 0, 1); t < Date.UTC(est + 2, 0, 1); t += 86400_000) {
    const p = hparts(new Date(t))
    if (p.year === y && p.month === m && p.day === d) return new Date(t)
  }
  throw new Error('مفيش تاريخ ميلادي مقابل (اليوم ده مش موجود في الشهر الهجري ده)')
}
const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
export const dayName = (d) => DAYS[d.getUTCDay()]
export const parseDate = (s) => {
  const m = s.trim().match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/) || s.trim().match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/) && (() => { const x = s.trim().match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/); return [0, x[3], x[2], x[1]] })()
  if (!m) throw new Error('صيغة التاريخ: 2000-05-17 أو 17/5/2000')
  const [y, mo, d] = [+m[1], +m[2], +m[3]]
  const dt = new Date(Date.UTC(y, mo - 1, d))
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) throw new Error('تاريخ غير موجود')
  return dt
}
export const iso = (d) => d.toISOString().slice(0, 10)
export const daysBetween = (a, b) => Math.round((b - a) / 86400_000)
export function age(birth, now) {
  let y = now.getUTCFullYear() - birth.getUTCFullYear(), m = now.getUTCMonth() - birth.getUTCMonth(), d = now.getUTCDate() - birth.getUTCDate()
  if (d < 0) { m--; d += new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 0)).getUTCDate() }
  if (m < 0) { y--; m += 12 }
  let next = new Date(Date.UTC(now.getUTCFullYear(), birth.getUTCMonth(), birth.getUTCDate()))
  if (next < now) next = new Date(Date.UTC(now.getUTCFullYear() + 1, birth.getUTCMonth(), birth.getUTCDate()))
  return { y, m, d, totalDays: daysBetween(birth, now), nextBirthday: daysBetween(now, next) }
}
export const addDays = (d, n) => new Date(d.getTime() + n * 86400_000)
export function calendar(year, month) {
  const first = new Date(Date.UTC(year, month - 1, 1)), dim = new Date(Date.UTC(year, month, 0)).getUTCDate()
  const lead = (first.getUTCDay() + 1) % 7 // الأسبوع يبدأ السبت
  const cells = [...Array(lead).fill('  '), ...Array.from({ length: dim }, (_, i) => String(i + 1).padStart(2, ' '))]
  const rows = ['سب اح اث ثل أر خم جم']
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7).join(' '))
  return rows.join('\n')
}

// ── تحويل وحدات ──
const U = (base, table) => Object.fromEntries(Object.entries(table).map(([k, f]) => [k, { f, base }]))
const UNITS = {
  ...U('m', { م: 1, متر: 1, كم: 1000, كيلومتر: 1000, سم: 0.01, مم: 0.001, ميل: 1609.344, ياردة: 0.9144, قدم: 0.3048, بوصة: 0.0254, انش: 0.0254 }),
  ...U('kg', { كجم: 1, كيلو: 1, كيلوجرام: 1, جم: 0.001, جرام: 0.001, طن: 1000, رطل: 0.45359237, اونصة: 0.0283495231 }),
  ...U('l', { لتر: 1, مل: 0.001, جالون: 3.785411784, كوب: 0.2365882365 }),
  ...U('ms', { 'م/ث': 1, 'كم/س': 1 / 3.6, 'ميل/س': 0.44704, عقدة: 0.514444 }),
  ...U('b', { بايت: 1, كيلوبايت: 1024, ميجابايت: 1048576, ميجا: 1048576, جيجابايت: 1073741824, جيجا: 1073741824, تيرابايت: 1099511627776, تيرا: 1099511627776 }),
  ...U('s', { ثانية: 1, دقيقة: 60, ساعة: 3600, يوم: 86400, اسبوع: 604800 }),
  ...U('m2', { م2: 1, 'كم2': 1e6, هكتار: 1e4, فدان: 4200.83, قدم2: 0.09290304 }),
  ...U('temp', { مئوية: 1, سيلسيوس: 1, c: 1, فهرنهايت: 1, f: 1, كلفن: 1, k: 1 }),
}
const aliasU = (s) => s.toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').trim()
const NORM_UNITS = Object.fromEntries(Object.entries(UNITS).map(([k, v]) => [aliasU(k), { ...v, key: k }]))
export const unitList = () => [...new Set(Object.keys(UNITS))]
export function convertUnits(value, from, to) {
  const a = NORM_UNITS[aliasU(from)], b = NORM_UNITS[aliasU(to)]
  if (!a || !b) throw new Error(`وحدة غير معروفة: ${!a ? from : to}`)
  if (a.base !== b.base) throw new Error('الوحدتين من أنواع مختلفة')
  if (a.base === 'temp') {
    const kind = (k) => (/فهرنهايت|^f$/i.test(k) ? 'F' : /كلفن|^k$/i.test(k) ? 'K' : 'C')
    const ka = kind(a.key), kb = kind(b.key)
    const c = ka === 'C' ? value : ka === 'F' ? (value - 32) * 5 / 9 : value - 273.15
    return kb === 'C' ? c : kb === 'F' ? c * 9 / 5 + 32 : c + 273.15
  }
  return (value * a.f) / b.f
}

// ── أعداد ──
export function factorize(n) {
  n = Math.trunc(n)
  if (!(n >= 2) || n > 1e12) throw new Error('الرقم لازم يكون من 2 إلى 1,000,000,000,000')
  const f = {}
  let x = n
  for (let p = 2; p * p <= x; p += p === 2 ? 1 : 2) while (x % p === 0) { f[p] = (f[p] || 0) + 1; x /= p }
  if (x > 1) f[x] = (f[x] || 0) + 1
  const divs = Object.values(f).reduce((a, e) => a * (e + 1), 1)
  return { prime: Object.keys(f).length === 1 && Object.values(f)[0] === 1, factors: f, divisors: divs }
}
export const gcd2 = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a }
export const gcdAll = (xs) => xs.reduce(gcd2)
export const lcmAll = (xs) => xs.reduce((a, b) => (a / gcd2(a, b)) * b)
export function stats(xs) {
  const n = xs.length, s = [...xs].sort((a, b) => a - b), sum = xs.reduce((a, b) => a + b, 0), mean = sum / n
  const median = n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2
  const freq = new Map(); for (const x of xs) freq.set(x, (freq.get(x) || 0) + 1)
  const maxf = Math.max(...freq.values()), mode = maxf > 1 ? [...freq].filter(([, f]) => f === maxf).map(([x]) => x) : []
  const ss = xs.reduce((a, x) => a + (x - mean) ** 2, 0)
  return { n, sum, mean, median, mode, min: s[0], max: s[n - 1], range: s[n - 1] - s[0], sd: Math.sqrt(ss / n), sdSample: n > 1 ? Math.sqrt(ss / (n - 1)) : 0 }
}

// ── جداول مرجعية ──
export const HTTP = {
  100: 'متابعة (Continue)', 101: 'تبديل البروتوكول', 200: 'تمام (OK)', 201: 'تم الإنشاء (Created)', 202: 'مقبول (Accepted)', 204: 'لا محتوى (No Content)',
  301: 'نقل دائم (Moved Permanently)', 302: 'نقل مؤقت (Found)', 304: 'لم يتغير (Not Modified)', 307: 'تحويل مؤقت', 308: 'تحويل دائم',
  400: 'طلب خاطئ (Bad Request)', 401: 'غير مصرّح (Unauthorized)', 403: 'ممنوع (Forbidden)', 404: 'غير موجود (Not Found)', 405: 'الطريقة غير مسموحة',
  408: 'انتهت مهلة الطلب', 409: 'تعارض (Conflict)', 410: 'اختفى نهائياً (Gone)', 413: 'الطلب كبير جداً', 418: 'أنا إبريق شاي (I\'m a teapot)', 429: 'طلبات كتير (Too Many Requests)',
  500: 'خطأ في الخادم (Internal Server Error)', 501: 'غير منفّذ', 502: 'بوابة سيئة (Bad Gateway)', 503: 'الخدمة غير متاحة (Service Unavailable)', 504: 'انتهت مهلة البوابة (Gateway Timeout)',
}
export const PORTS = { 20: 'FTP data', 21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 67: 'DHCP', 80: 'HTTP', 110: 'POP3', 123: 'NTP', 143: 'IMAP', 161: 'SNMP', 389: 'LDAP', 443: 'HTTPS', 445: 'SMB', 465: 'SMTPS', 587: 'SMTP (submission)', 993: 'IMAPS', 995: 'POP3S', 1433: 'MS SQL', 3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL', 5900: 'VNC', 6379: 'Redis', 8080: 'HTTP بديل', 27017: 'MongoDB' }
export const portByName = (name) => Object.entries(PORTS).filter(([, v]) => v.toLowerCase().includes(name.toLowerCase())).map(([p, v]) => `${p} = ${v}`)

export function parseUrl(s) {
  const u = new URL(/^[a-z]+:\/\//i.test(s) ? s : 'https://' + s)
  return { protocol: u.protocol.replace(':', ''), host: u.hostname, port: u.port || (u.protocol === 'https:' ? '443 (افتراضي)' : u.protocol === 'http:' ? '80 (افتراضي)' : ''), path: u.pathname, query: [...u.searchParams].map(([k, v]) => `${k}=${v}`), hash: u.hash.replace('#', ''), user: u.username }
}

// ── قوة كلمة السر (محلياً، من غير إرسال لأي مكان) ──
const COMMON = ['123456', 'password', '12345678', 'qwerty', '111111', '123123', 'admin', 'iloveyou', 'abc123', '000000', 'letmein', 'welcome', '1q2w3e', 'password1', '654321']
export function passwordStrength(pw) {
  const pool = (/[a-z]/.test(pw) ? 26 : 0) + (/[A-Z]/.test(pw) ? 26 : 0) + (/[0-9]/.test(pw) ? 10 : 0) + (/[^A-Za-z0-9]/.test(pw) ? 32 : 0)
  let bits = pool ? Math.round(pw.length * Math.log2(pool)) : 0
  const issues = []
  if (pw.length < 10) issues.push('أقصر من 10 حروف')
  if (COMMON.includes(pw.toLowerCase())) { bits = Math.min(bits, 10); issues.push('من كلمات السر الشائعة جداً') }
  if (/^(.)\1+$/.test(pw)) { bits = Math.min(bits, 8); issues.push('حرف واحد متكرر') }
  if (/(012|123|234|345|456|567|678|789|abc|qwe)/i.test(pw)) { bits = Math.max(0, bits - 12); issues.push('فيها تسلسل سهل التخمين') }
  if (!/[A-Z]/.test(pw) || !/[a-z]/.test(pw)) issues.push('مفيهاش حروف كبيرة وصغيرة')
  if (!/[0-9]/.test(pw)) issues.push('مفيهاش أرقام')
  if (!/[^A-Za-z0-9]/.test(pw)) issues.push('مفيهاش رموز')
  const level = bits >= 70 ? 'قوية جداً' : bits >= 50 ? 'قوية' : bits >= 35 ? 'متوسطة' : 'ضعيفة'
  return { bits, level, issues }
}

// ── معلومات ملف من رسالة واتساب (من غير تنزيل) ──
export function fileInfo(content) {
  const type = content && Object.keys(content).find((k) => /(image|video|audio|document|sticker)Message$/.test(k))
  if (!type) return null
  const m = content[type]
  const KB = (n) => { n = Number(n) || 0; return n > 1048576 ? (n / 1048576).toFixed(2) + ' MB' : (n / 1024).toFixed(1) + ' KB' }
  const out = { نوع: type.replace('Message', ''), النوع_MIME: m.mimetype, الحجم: m.fileLength != null ? KB(m.fileLength?.low ?? m.fileLength) : undefined }
  if (m.width) out['الأبعاد'] = `${m.width}×${m.height}`
  if (m.seconds) out['المدة'] = `${m.seconds} ث`
  if (m.pageCount) out['الصفحات'] = m.pageCount
  if (m.fileName) out['الاسم'] = m.fileName
  if (m.isAnimated) out['متحرك'] = 'نعم'
  if (m.caption) out['التعليق'] = String(m.caption).slice(0, 40)
  return Object.fromEntries(Object.entries(out).filter(([, v]) => v !== undefined && v !== ''))
}

// ── تلخيص استخراجي (من غير ذكاء اصطناعي): أهم الجمل بتكرار الكلمات ──
const STOP = new Set('في من على الى إلى عن ان أن إن كان كانت هذا هذه ذلك التي الذي التى هو هي هم ما لا لم لن قد كل بعد قبل مع او أو ثم هناك وقد فيه فيها به بها منه منها عند حتى كما لكن بين حيث إذا اذا غير تم يتم'.split(' '))
export function summarize(text, n = 3) {
  const sentences = text.split(/(?<=[.!?؟…])\s+|\n+/).map((s) => s.trim()).filter((s) => s.length > 15)
  if (sentences.length <= n) return sentences.join(' ')
  const words = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w))
  const freq = new Map(); for (const s of sentences) for (const w of words(s)) freq.set(w, (freq.get(w) || 0) + 1)
  const scored = sentences.map((s, i) => { const w = words(s); return { s, i, sc: w.reduce((a, x) => a + freq.get(x), 0) / Math.sqrt(w.length || 1) } })
  return scored.sort((a, b) => b.sc - a.sc).slice(0, n).sort((a, b) => a.i - b.i).map((x) => x.s).join(' ')
}
