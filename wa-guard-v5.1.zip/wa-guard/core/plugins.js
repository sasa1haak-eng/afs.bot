// ═══════════ نظام الإضافات ═══════════
// أي ملف في plugins/ (اسمه ما يبدأش بـ _) بيصدّر: export default { name, version, description, register(ctx) }
// وبيسجّل أوامره بـ ctx.cmd. الإضافة اللي بتفشل ما بتوقفش البوت. تعطيل/تفعيل: .تعطيل اضافة / .تفعيل اضافة (بعد إعادة التشغيل).
import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { STATE_DIR } from '../lib.js'
import { logError } from './seclog.js'

export const PLUGINS_DIR = path.join(STATE_DIR, 'plugins')
export const loaded = []

export async function loadPlugins(ctx, dir = PLUGINS_DIR) {
  loaded.length = 0
  let files = []
  try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.js') && !f.startsWith('_')).sort() } catch {}
  for (const f of files) {
    const info = { file: f, name: f.replace(/\.js$/, ''), version: '0', status: 'loaded', commands: 0 }
    try {
      const mod = await import(pathToFileURL(path.join(dir, f)).href)
      const p = mod.default || mod.plugin
      if (!p || typeof p.register !== 'function') throw new Error('لازم تصدّر { name, version, register(ctx) }')
      info.name = p.name || info.name; info.version = p.version || '0'; info.description = p.description || ''
      if (ctx.db.plugins?.[info.name]?.disabled) info.status = 'disabled'
      else {
        const before = ctx.registry.length
        await p.register(ctx)
        info.commands = ctx.registry.length - before
      }
    } catch (e) { info.status = 'error'; info.error = String(e.message).slice(0, 120); logError('plugin:' + f, e) }
    loaded.push(info)
  }
  return loaded
}
