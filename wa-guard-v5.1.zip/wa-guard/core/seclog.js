// ═══════════ السجل الأمني والأخطاء ═══════════
// كل حدث: { t, type, jid?, actor?, ... } بيتخزّن في الذاكرة (آخر 500) وفي data/security.log (JSON Lines) مع تدوير عند 1MB.
import fs from 'node:fs'
import path from 'node:path'
import { STATE_DIR } from '../lib.js'

export const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(STATE_DIR, 'data'))
const FILE = path.join(DATA_DIR, 'security.log')
const MAX_BYTES = 1_000_000
const RING = 500
const ring = []

function load() {
  try {
    const lines = fs.readFileSync(FILE, 'utf8').trim().split('\n').slice(-RING)
    for (const l of lines) { try { ring.push(JSON.parse(l)) } catch {} }
  } catch {}
}
load()

export function sec(type, data = {}) {
  const ev = { t: Date.now(), type, ...data }
  ring.push(ev)
  if (ring.length > RING) ring.shift()
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true })
    try { if (fs.statSync(FILE).size > MAX_BYTES) fs.renameSync(FILE, FILE + '.1') } catch {}
    fs.appendFileSync(FILE, JSON.stringify(ev) + '\n')
  } catch {}
  return ev
}
export const logError = (where, err) => sec('error', { where, msg: String(err?.message || err).slice(0, 300) })

export function events({ jid, type, since = 0, limit = 20 } = {}) {
  return ring.filter((e) => e.t >= since && (!jid || e.jid === jid) && (!type || e.type === type)).slice(-limit).reverse()
}
export function counts({ jid, since = 0 } = {}) {
  const c = {}
  for (const e of ring) if (e.t >= since && (!jid || e.jid === jid)) c[e.type] = (c[e.type] || 0) + 1
  return c
}
export function topActors({ jid, since = 0, limit = 5, types } = {}) {
  const c = {}
  for (const e of ring) if (e.t >= since && e.actor && (!jid || e.jid === jid) && (!types || types.includes(e.type))) c[e.actor] = (c[e.actor] || 0) + 1
  return Object.entries(c).sort((a, b) => b[1] - a[1]).slice(0, limit)
}
export const clearLog = () => { ring.length = 0; try { fs.rmSync(FILE, { force: true }); fs.rmSync(FILE + '.1', { force: true }) } catch {} }
export const logFileBytes = () => { try { return fs.statSync(FILE).size } catch { return 0 } }
export const _ring = ring

export const TYPE_AR = {
  antibot: '🤖 بوت اتطرد', kick: '👢 طرد', ban: '⛔ حظر', blacklist: '📛 قائمة سوداء', raid: '🚨 هجوم جماعي', emergency: '🆘 طوارئ',
  perm: '🔑 صلاحيات', backup: '💾 نسخة احتياطية', restore: '♻️ استعادة', lockdown: '🔒 إيقاف', error: '⚠️ خطأ', flood: '🌊 إغراق', link: '🔗 رابط', spam: '📨 سبام',
}
