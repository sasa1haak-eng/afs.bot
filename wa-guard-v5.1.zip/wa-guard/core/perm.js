// ═══════════ نظام الصلاحيات الموحّد ═══════════
// المستويات: owner (المطور الأساسي + المطورين المتمكَّنين على البوت الأساسي) · subowner (مالك بوت فرعي، نطاقه رقمه بس)
//            admin (أدمن الجروب) · member (عضو)
// القاعدة: أي أمر نطاقه كل الشبكة (حظر عام، رصيد، تدريب، بث...) لازم owner، مش subowner.
import { isMainSock } from '../sessions.js'

export const isMainOwner = (e) => !!(e?.isOwner && e?.sock && isMainSock(e.sock))
export const isSubOwner = (e) => !!(e?.isOwner && e?.sock && !isMainSock(e.sock))
export const levelOf = (e, admin = false) => (isMainOwner(e) ? 'owner' : isSubOwner(e) ? 'subowner' : admin ? 'admin' : 'member')
export const LEVEL_AR = { owner: 'المطور الأساسي', subowner: 'مالك بوت فرعي', admin: 'أدمن', member: 'عضو' }
export const RANK = { member: 0, admin: 1, subowner: 2, owner: 3 }
export const atLeast = (level, need) => RANK[level] >= RANK[need]

// أوامر قديمة نطاقها كل الشبكة (الأوامر الجديدة بتستخدم opts.global)
export const LEGACY_GLOBAL = ['حظر', 'ban', 'الغاء الحظر', 'unban', 'المحظورين', 'هدية رصيد', 'تصفير رصيد', 'تدريب تلقائي', 'مسح التدريب', 'المنصبين']

// بيحدد لو الأمر ده محتاج مطور أساسي (normFn = دالة تطبيع الأسماء بتاعة البوت)
export const needsMainOwner = (cmdEntry, normFn = (x) => x) => {
  if (cmdEntry.opts?.global) return true
  const set = LEGACY_GLOBAL.map(normFn)
  return cmdEntry.names.some((n) => set.includes(n))
}
// وصف الصلاحيات للمستخدم
export function capabilities(level) {
  const base = ['الأوامر العامة (ألعاب، أدوات، اقتصاد)']
  if (atLeast(level, 'admin')) base.push('أوامر إدارة الجروب (حماية، كتم، تحذير، ترحيب...)')
  if (level === 'subowner') base.push('التحكم في بوتك الفرعي في جروباتك فقط')
  if (level === 'owner') base.push('أوامر الشبكة كلها (حظر عام، رصيد، تدريب، بث، نسخ احتياطي، إضافات، تشخيص)')
  return base
}
