// طبقة توافق لتشغيل البوت على Node 18 (مثلاً داخل تطبيق الأندرويد/nodejs-mobile) — بتضيف دوال JavaScript/Node الأحدث لو ناقصة.
// على Node 20+ ما بتعمل أي حاجة (كل فحص بيتخطى لو الدالة موجودة أصلاً).
// بتتحمّل أول حاجة في index.js. ما بتغطيش الصيغ الجديدة (زي regex بعلامة v) — دي بتتكشف في فحص البناء (make-resources.sh).
import { webcrypto } from 'node:crypto'
import { File as NodeFile } from 'node:buffer'

const def = (obj, name, fn) => {
  if (obj && typeof obj[name] !== 'function') Object.defineProperty(obj, name, { value: fn, writable: true, configurable: true, enumerable: false })
}

// ── Array (ES2023) ──
const AP = Array.prototype
def(AP, 'toSorted', function (cmp) { return [...this].sort(cmp) })
def(AP, 'toReversed', function () { return [...this].reverse() })
def(AP, 'toSpliced', function (...a) { const c = [...this]; c.splice(...a); return c })
def(AP, 'with', function (i, v) {
  const c = [...this]; const k = i < 0 ? c.length + i : i
  if (k < 0 || k >= c.length) throw new RangeError('Invalid index : ' + i)
  c[k] = v; return c
})
def(Array, 'fromAsync', async function (src, map) {
  const out = []; let i = 0
  if (src && (src[Symbol.asyncIterator] || src[Symbol.iterator])) { for await (const x of src) out.push(map ? await map(x, i++) : x) }
  else { const a = Array.from(src); for (const x of a) out.push(map ? await map(await x, i++) : await x) }
  return out
})
// ── Object / Map groupBy ──
def(Object, 'groupBy', (items, fn) => { const o = Object.create(null); let i = 0; for (const x of items) { const k = fn(x, i++); (o[k] ??= []).push(x) } return o })
def(Map, 'groupBy', (items, fn) => { const m = new Map(); let i = 0; for (const x of items) { const k = fn(x, i++); if (!m.has(k)) m.set(k, []); m.get(k).push(x) } return m })
// ── Promise.withResolvers ──
def(Promise, 'withResolvers', function () { let resolve, reject; const promise = new this((a, b) => { resolve = a; reject = b }); return { promise, resolve, reject } })
// ── String ──
def(String.prototype, 'isWellFormed', function () { return !/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/.test(String(this)) })
def(String.prototype, 'toWellFormed', function () { return String(this).replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '\uFFFD') })
// ── Set methods (ES2025) ──
const SP = Set.prototype
const asSet = (o) => (o instanceof Set ? o : new Set(o.keys ? o.keys() : o))
def(SP, 'union', function (o) { return new Set([...this, ...asSet(o)]) })
def(SP, 'intersection', function (o) { const s = asSet(o); return new Set([...this].filter((x) => s.has(x))) })
def(SP, 'difference', function (o) { const s = asSet(o); return new Set([...this].filter((x) => !s.has(x))) })
def(SP, 'symmetricDifference', function (o) { const s = asSet(o); return new Set([...[...this].filter((x) => !s.has(x)), ...[...s].filter((x) => !this.has(x))]) })
def(SP, 'isSubsetOf', function (o) { const s = asSet(o); return [...this].every((x) => s.has(x)) })
def(SP, 'isSupersetOf', function (o) { return [...asSet(o)].every((x) => this.has(x)) })
def(SP, 'isDisjointFrom', function (o) { const s = asSet(o); return ![...this].some((x) => s.has(x)) })
// ── Symbol.dispose / asyncDispose ──
if (!Symbol.dispose) Object.defineProperty(Symbol, 'dispose', { value: Symbol.for('Symbol.dispose') })
if (!Symbol.asyncDispose) Object.defineProperty(Symbol, 'asyncDispose', { value: Symbol.for('Symbol.asyncDispose') })
// ── AbortSignal.any ──
def(AbortSignal, 'any', (signals) => {
  const c = new AbortController()
  for (const s of signals) { if (s.aborted) { c.abort(s.reason); break } s.addEventListener('abort', () => c.abort(s.reason), { once: true }) }
  return c.signal
})
// ── globals ──
if (!globalThis.crypto) Object.defineProperty(globalThis, 'crypto', { value: webcrypto, configurable: true, writable: true })
if (!globalThis.File && NodeFile) Object.defineProperty(globalThis, 'File', { value: NodeFile, configurable: true, writable: true })

export const COMPAT_ACTIVE = parseInt(process.versions.node, 10) < 20
