// أسماء الأوامر: بنسجّل الصيغة بمسافة والصيغة بشرطة سفلية (فحص امني / فحص_امني)
export const nm = (...names) => [...new Set(names.flatMap((n) => (n.includes(' ') ? [n, n.replace(/ /g, '_')] : [n])))]
export const digitsOf = (j = '') => String(j).split('@')[0].split(':')[0].replace(/\D/g, '')
export const cairo = (t) => { try { return new Date(t).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo', hour12: true, month: 'numeric', day: 'numeric', hour: 'numeric', minute: '2-digit' }) } catch { return String(t) } }
export const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'الآن' : m < 60 ? `${m} د` : m < 1440 ? `${Math.round(m / 60)} س` : `${Math.round(m / 1440)} يوم` }
