// تحميل أسئلة إضافية من extra-questions.json (لو موجود) عشان تزود الأسئلة من غير ما تعدّل الكود
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const FILE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'extra-questions.json')
export const EXTRA = (() => {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')) } catch { return {} }
})()
// الشكل: { "trivia": [["السؤال", ["إجابة", "إجابة تانية"]]], "riddles": [...نفس الشكل], "words": ["كلمة"],
//          "capitals": [["الدولة", "العاصمة"]], "million": { "1": [{"q":"..","ok":"..","bad":["..","..",".."]}], "2": [], "3": [] } }
export const extra = (key, fallback = []) => (Array.isArray(EXTRA[key]) ? EXTRA[key] : fallback)
