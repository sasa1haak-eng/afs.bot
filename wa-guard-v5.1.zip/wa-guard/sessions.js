import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
} from '@whiskeysockets/baileys'
import pino from 'pino'
import fs from 'node:fs'
import path from 'node:path'
import { CONFIG, STATE_DIR, log, invalidateMeta, sleep } from './lib.js'

const MAIN_DIR = path.join(STATE_DIR, 'auth')
const SUB_DIR = path.join(STATE_DIR, 'sessions')

let handlers = {}
export const setHandlers = (h) => { handlers = h }

// number → { sock, dir }
const subs = new Map()
const lastReq = new Map()

// البوت الأساسي بيتعرف بالـ socket نفسه مش بمقارنة الرقم (لو BOT_NUMBER مختلف عن الحساب المربوط كان كل أمر بيفشل)
let mainSock = null
export const isMainSock = (sock) => sock === mainSock
export const _testSetMain = (sock) => { mainSock = sock } // للاختبارات فقط
export const sockByNumber = (n) => (n === mainNumber() ? mainSock : subs.get(n)?.sock) || null
export const mainNumber = () => (mainSock?.user?.id || '').split(/[:@]/)[0] || CONFIG.NUMBER

export const listSubs = () =>
  [...subs.entries()].map(([number, s]) => ({
    number,
    linked: !!s.sock.authState.creds.registered,
    online: !!s.sock.user,
  }))

// ═══════════════ قفل النسخة الواحدة ═══════════════
// منع تشغيل نسختين من البوت بنفس الجلسة (بيسبب فصل وتسجيل خروج)
const LOCK = path.join(STATE_DIR, 'bot.lock')
export function acquireLock() {
  if (fs.existsSync(LOCK)) {
    const pid = parseInt(fs.readFileSync(LOCK, 'utf8'))
    if (pid && pid !== process.pid) {
      let alive = true
      try { process.kill(pid, 0) } catch (e) { alive = e.code === 'EPERM' }
      // بعد إعادة تشغيل الموبايل الأرقام بتتكرر: نتأكد إنها فعلاً عملية البوت
      if (alive) {
        try {
          const cmd = fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8')
          if (!cmd.includes('index.js')) alive = false
        } catch {} // لو مش قادرين نقرأها (ويندوز) نفترض إنها شغالة
      }
      if (alive)
        throw new Error(`في نسخة تانية من البوت شغالة (PID ${pid}). اقفلها الأول: kill ${pid}`)
    }
  }
  fs.writeFileSync(LOCK, String(process.pid))
  const release = () => {
    try { if (fs.readFileSync(LOCK, 'utf8') === String(process.pid)) fs.unlinkSync(LOCK) } catch {}
  }
  process.on('exit', release)
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) process.on(sig, () => process.exit(0))
}

const REASONS = {
  401: 'loggedOut (واتساب لغى الجلسة)', 403: 'forbidden', 408: 'timedOut',
  411: 'multideviceMismatch', 428: 'connectionClosed', 440: 'connectionReplaced (نسخة تانية بنفس الحساب)',
  500: 'badSession', 503: 'unavailableService', 515: 'restartRequired',
}

async function getVersion() {
  try {
    const r = await Promise.race([
      fetchLatestBaileysVersion(),
      new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000)),
    ])
    return r.version
  } catch {
    return undefined // الإصدار الافتراضي في المكتبة
  }
}

// ═══════════════ الاتصال ═══════════════
async function connect(o) {
  const { dir, number, main } = o
  const { state, saveCreds } = await useMultiFileAuthState(dir)
  const version = await getVersion()

  const sock = makeWASocket({
    ...(version ? { version } : {}),
    keepAliveIntervalMs: 25_000,
    connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000,
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.ubuntu('Chrome'),
    markOnlineOnConnect: false,
    syncFullHistory: false,
  })
  if (main) mainSock = sock
  else subs.set(number, { sock, dir })

  // طلب كود الربط لو الرقم لسه متربطش
  // لازم نستنى الاتصال يجهز (حدث qr أو connecting) بدل مؤقت ثابت، ونعيد المحاولة لو فشل
  if (!state.creds.registered) {
    let asked = false
    const ask = async () => {
      if (asked) return
      asked = true
      let lastErr
      for (let i = 0; i < 3; i++) {
        try {
          await sleep(i === 0 ? 1500 : 3000)
          return o.onCode?.(await sock.requestPairingCode(number))
        } catch (e) {
          lastErr = e
          log(`⚠️ فشل طلب كود الربط (محاولة ${i + 1}/3): ${e.message}`)
        }
      }
      o.onError?.(lastErr)
      if (!main) removeSub(number)
    }
    sock.ev.on('connection.update', ({ connection, qr }) => {
      if (qr || connection === 'connecting') ask()
    })
    setTimeout(ask, 6000) // احتياطي لو الحدث فاتنا
    if (!main)
      setTimeout(() => {
        if (subs.get(number)?.sock === sock && !sock.authState.creds.registered) {
          o.onExpire?.()
          removeSub(number)
        }
      }, 150_000)
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      o.retries = 0
      log(main ? '✅ البوت الأساسي شغال' : `✅ بوت فرعي شغال: ${number}`)
      if (process.env.DEBUG_MSGS === '1') log(`👤 الحساب: ${sock.user?.id} | lid: ${sock.user?.lid || '—'}`)
      if (!main && state.creds.registered && o.onLinked && !o.linkedNotified) {
        o.linkedNotified = true
        o.onLinked(sock)
      }
    }
    if (connection === 'close') {
      const err = lastDisconnect?.error
      const code = err?.output?.statusCode
      log(`🔌 انفصل (${main ? 'الأساسي' : number}) كود: ${code} ${REASONS[code] || ''} | ${err?.message || ''}`)

      if (code === DisconnectReason.loggedOut) {
        if (!main) return void removeSub(number)
        if (o.wipedAt && Date.now() - o.wipedAt < 600_000) {
          console.log('\n❌ واتساب لغى الجلسة تاني بسرعة. وقفت عشان مكررش طلبات الربط.')
          console.log('اتأكد إن مفيش نسخة تانية شغالة، وابعتلي سطور "انفصل" اللي فوق.')
          process.exit(1)
        }
        o.wipedAt = Date.now()
        log('❌ الجلسة اتلغت، بمسح auth وطلب كود جديد (مرة واحدة)...')
        fs.rmSync(dir, { recursive: true, force: true })
        return void setTimeout(() => connect(o), 2000)
      }
      if (code === DisconnectReason.connectionReplaced) {
        if (main) {
          console.log('\n⚠️ نسخة تانية من البوت اشتغلت بنفس الحساب، بقفل دي عشان ماتتخانقوش.')
          process.exit(1)
        }
        return
      }
      if (!main) {
        if (subs.get(number)?.sock !== sock) return // اتشال
        if (!sock.authState.creds.registered) return // لسه متربطش (المؤقت هيشيله)
      }
      o.retries = (o.retries || 0) + 1
      const delay = code === DisconnectReason.restartRequired ? 500 : Math.min(2000 * 2 ** (o.retries - 1), 60_000)
      log(`🔄 إعادة الاتصال بعد ${Math.round(delay / 1000)}ث...`)
      setTimeout(() => connect(o).catch((e) => log('فشل الاتصال:', e.message)), delay)
    }
  })

  sock.ev.on('group-participants.update', (ev) =>
    handlers.onParticipants?.(sock, ev).catch((e) => log('ترحيب:', e.message))
  )
  sock.ev.on('groups.update', (u) => u.forEach((x) => x.id && invalidateMeta(x.id)))
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (process.env.DEBUG_MSGS === '1')
      for (const m of messages)
        log(`📩 [${type}] ${m.key.remoteJid} fromMe=${!!m.key.fromMe} ${(m.message?.conversation || m.message?.extendedTextMessage?.text || Object.keys(m.message || {})[0] || '').slice(0, 40)}`)
    if (type !== 'notify') return
    for (const m of messages) {
      try {
        await handlers.onMessage?.(sock, m)
      } catch (e) {
        log('خطأ:', e.message)
      }
    }
  })
  return sock
}

// ═══════════════ البوت الأساسي ═══════════════
export const startMain = () =>
  connect({
    dir: MAIN_DIR,
    number: CONFIG.NUMBER,
    main: true,
    onCode: (code) => {
      console.log(`\n🔑 كود الربط: ${code}`)
      console.log('واتساب ← الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف\n')
    },
    onError: (e) => console.log('فشل طلب الكود:', e.message),
  })

// ═══════════════ البوتات الفرعية ═══════════════
export async function removeSub(number) {
  const s = subs.get(number)
  if (!s) return false
  subs.delete(number)
  try { await s.sock.logout() } catch {}
  try { s.sock.end(undefined) } catch {}
  fs.rmSync(s.dir, { recursive: true, force: true })
  log('🗑️ تم إلغاء بوت فرعي:', number)
  return true
}

// بترجع كود الربط (8 حروف) أو ترمي خطأ
export function installSub(number, { onLinked, onExpire } = {}) {
  if (!/^\d{8,15}$/.test(number))
    throw new Error('الرقم غير صحيح، اكتبه بالكود الدولي بدون + (مثال 201234567890)')
  if (number === mainNumber() || number === CONFIG.NUMBER) throw new Error('ده رقم البوت الأساسي.')

  const old = subs.get(number)
  if (old?.sock.authState.creds.registered)
    throw new Error('رقمك متنصب بالفعل. لإلغائه اكتب .الغاء التنصيب')
  if (!old && subs.size >= CONFIG.MAX_SUBBOTS)
    throw new Error(`وصلنا للحد الأقصى من البوتات الفرعية (${CONFIG.MAX_SUBBOTS}).`)
  if (Date.now() - (lastReq.get(number) || 0) < 60_000)
    throw new Error('استنى دقيقة قبل ما تطلب كود تاني.')
  lastReq.set(number, Date.now())

  return (async () => {
    try {
      return await doInstall()
    } catch (e) {
      lastReq.delete(number) // الطلب فشل: نسمح بإعادة المحاولة فوراً
      throw e
    }
  })()

  async function doInstall() {
    if (old) await removeSub(number)
    const dir = path.join(SUB_DIR, number)
    fs.rmSync(dir, { recursive: true, force: true })
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => {
        reject(new Error('انتهت مهلة طلب الكود، جرب تاني.'))
        removeSub(number)
      }, 60_000)
      connect({
        dir, number, main: false, onLinked, onExpire,
        onCode: (c) => { clearTimeout(t); resolve(c) },
        onError: (e) => { clearTimeout(t); reject(new Error('فشل طلب الكود: ' + e.message)) },
      }).catch((e) => { clearTimeout(t); reject(e) })
    })
  }
}

// تشغيل البوتات الفرعية اللي كانت متربطة قبل كده
export async function restoreSubs() {
  if (!fs.existsSync(SUB_DIR)) return
  for (const n of fs.readdirSync(SUB_DIR)) {
    const dir = path.join(SUB_DIR, n)
    try {
      const creds = JSON.parse(fs.readFileSync(path.join(dir, 'creds.json'), 'utf8'))
      if (!creds.registered || subs.size >= CONFIG.MAX_SUBBOTS) {
        if (!creds.registered) fs.rmSync(dir, { recursive: true, force: true })
        continue
      }
      await connect({ dir, number: n, main: false })
      await sleep(1500)
    } catch (e) {
      log('تعذر تشغيل بوت فرعي', n, e.message)
    }
  }
}
