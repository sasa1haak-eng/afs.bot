// ═══════════ 6.0 — محرك قواعد الحماية (كل قاعدة = أمر تفعيل/تعطيل + فحص فعلي للرسايل) ═══════════
import { nm } from './core/names.js'

const has = (re) => (x) => re.test(x.text)
const typ = (...keys) => (x) => keys.some((k) => x.c?.[k])
const count = (re) => (t) => (t.match(re) || []).length
const URL_RE = /(?:https?:\/\/|www\.)\S+|\b[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|net|org|io|me|ly|gl|co|info|xyz|top|ru|cn|tk|ml|ga|cf|gq|site|online|click|link|shop|vip|club|app|dev)\b\S*/gi
const dom = (re) => (x) => (x.text.match(URL_RE) || []).some((u) => re.test(u))
const len = (n) => (x) => (x.fullLen ?? x.text.length) > n
const lines = (n) => (x) => x.text.split('\n').length > n
const caps = (x) => { const l = x.text.replace(/[^A-Za-z]/g, ''); return l.length >= 12 && l.replace(/[^A-Z]/g, '').length / l.length > 0.7 }

// [المفتاح, الاسم العربي, دالة الفحص]
export const RULES = [
  // ── أنواع المحتوى ──
  ['stickers', 'الملصقات', typ('stickerMessage')],
  ['voice', 'الرسايل الصوتية', typ('audioMessage')],
  ['images', 'الصور', typ('imageMessage')],
  ['videos', 'الفيديوهات', typ('videoMessage')],
  ['contacts', 'جهات الاتصال', typ('contactMessage', 'contactsArrayMessage')],
  ['location', 'المواقع', typ('locationMessage', 'liveLocationMessage')],
  ['polls', 'الاستفتاءات', typ('pollCreationMessage', 'pollCreationMessageV2', 'pollCreationMessageV3')],
  ['docs', 'المستندات', typ('documentMessage')],
  ['products', 'رسايل المنتجات', typ('productMessage', 'orderMessage')],
  ['buttons', 'رسايل الأزرار', typ('buttonsMessage', 'buttonsResponseMessage', 'templateMessage', 'listMessage', 'interactiveMessage')],
  ['gif', 'صور GIF', (x) => !!x.c?.videoMessage?.gifPlayback],
  ['pdf', 'ملفات PDF', (x) => /pdf/i.test(x.c?.documentMessage?.mimetype || '')],
  ['zip', 'الملفات المضغوطة', (x) => /zip|rar|7z|tar|gzip/i.test(x.c?.documentMessage?.mimetype || '') || /\.(zip|rar|7z|tar|gz)$/i.test(x.c?.documentMessage?.fileName || '')],
  ['apk', 'ملفات APK', (x) => /\.apk$/i.test(x.c?.documentMessage?.fileName || '') || /android\.package/i.test(x.c?.documentMessage?.mimetype || '')],
  ['exe', 'الملفات التنفيذية', (x) => /\.(exe|msi|bat|cmd|scr|com|vbs|ps1|jar|sh|dmg|pkg|deb)$/i.test(x.c?.documentMessage?.fileName || '')],
  ['bigdoc', 'المستندات الكبيرة (+10MB)', (x) => Number(x.c?.documentMessage?.fileLength || 0) > 10 * 1024 * 1024],
  ['bigvideo', 'الفيديوهات الكبيرة (+30MB)', (x) => Number(x.c?.videoMessage?.fileLength || 0) > 30 * 1024 * 1024],
  ['longvoice', 'الصوتيات الطويلة (+3 دقايق)', (x) => Number(x.c?.audioMessage?.seconds || 0) > 180],
  ['longvideo', 'الفيديوهات الطويلة (+3 دقايق)', (x) => Number(x.c?.videoMessage?.seconds || 0) > 180],
  ['forwarded', 'الرسايل المحوّلة', (x) => !!x.ctx?.isForwarded],
  ['manyfwd', 'الرسايل المحوّلة كتير', (x) => (x.ctx?.forwardingScore || 0) >= 5],
  ['viewonce', 'الوسائط لمرة واحدة', (x) => !!(x.raw?.viewOnceMessage || x.raw?.viewOnceMessageV2 || x.raw?.viewOnceMessageV2Extension)],
  ['ephemeral', 'الرسايل المؤقتة', (x) => !!x.raw?.ephemeralMessage],
  ['channelfwd', 'تحويل من القنوات', (x) => !!x.ctx?.forwardedNewsletterMessageInfo],
  ['quotedstatus', 'الرد على الحالات', (x) => x.ctx?.remoteJid === 'status@broadcast'],
  ['mentionstatus', 'ذكر الجروب في حالة', typ('groupStatusMentionMessage')],
  ['invite', 'دعوات الجروبات (كرت)', typ('groupInviteMessage')],
  ['newsletter', 'دعوات القنوات', typ('newsletterAdminInviteMessage')],
  ['payment', 'رسايل الدفع', typ('requestPaymentMessage', 'sendPaymentMessage', 'paymentInviteMessage')],
  ['calls', 'سجل المكالمات', typ('call', 'scheduledCallCreationMessage')],
  ['events', 'رسايل الأحداث', typ('eventMessage')],
  // ── الروابط والدومينات ──
  ['anylink', 'أي رابط', has(URL_RE)],
  ['telegram', 'روابط تيليجرام', dom(/(?:t\.me|telegram\.(?:me|org))/i)],
  ['discord', 'روابط ديسكورد', dom(/discord(?:\.gg|app\.com|\.com)/i)],
  ['instagram', 'روابط انستجرام', dom(/instagram\.com|instagr\.am/i)],
  ['facebook', 'روابط فيسبوك', dom(/facebook\.com|fb\.(?:com|me|watch)/i)],
  ['youtube', 'روابط يوتيوب', dom(/youtube\.com|youtu\.be/i)],
  ['tiktok', 'روابط تيك توك', dom(/tiktok\.com/i)],
  ['twitter', 'روابط تويتر/إكس', dom(/(?:twitter|x)\.com|t\.co/i)],
  ['snapchat', 'روابط سناب شات', dom(/snapchat\.com|snap\.com/i)],
  ['wachannel', 'روابط قنوات واتساب', dom(/whatsapp\.com\/channel/i)],
  ['wagroup', 'روابط جروبات واتساب', dom(/chat\.whatsapp\.com/i)],
  ['wame', 'روابط wa.me', dom(/wa\.me/i)],
  ['shortlinks', 'الروابط المختصرة', dom(/(?:bit\.ly|tinyurl\.com|cutt\.ly|is\.gd|rb\.gy|t\.ly|shorturl\.at|ow\.ly|goo\.gl|rebrand\.ly|s\.id|shrtco\.de)/i)],
  ['iplinks', 'روابط بعنوان IP', has(/https?:\/\/\d{1,3}(?:\.\d{1,3}){3}/i)],
  ['http', 'روابط غير مشفرة (http)', has(/\bhttp:\/\//i)],
  ['punycode', 'دومينات punycode المشبوهة', has(/xn--[a-z0-9-]+/i)],
  ['onion', 'روابط onion', has(/\.onion\b/i)],
  ['badtld', 'الدومينات المشبوهة (xyz/top/tk...)', dom(/\.(?:xyz|top|tk|ml|ga|cf|gq|click|link|work|zip|mov|icu|buzz|rest)(?:[/?#:]|$)/i)],
  ['filelinks', 'روابط تحميل ملفات', dom(/\.(?:apk|exe|zip|rar|msi|bat|scr|jar|dmg)(?:[?#]|$)/i)],
  ['googledocs', 'روابط جوجل (فورم/درايف)', dom(/(?:docs|forms|drive)\.google\.com|forms\.gle/i)],
  ['payments', 'روابط الدفع والتحويل', dom(/paypal\.me|paypal\.com|cash\.app|venmo\.com|patreon\.com|buymeacoffee\.com/i)],
  ['streaming', 'روابط البث', dom(/twitch\.tv|kick\.com|facebook\.com\/live/i)],
  ['maps', 'روابط الخرائط', dom(/maps\.google|goo\.gl\/maps|maps\.app\.goo\.gl|waze\.com/i)],
  ['login', 'صفحات تسجيل الدخول المشبوهة', has(/https?:\/\/\S*(?:login|signin|verify|secure|account|wallet|update)\S*/i)],
  ['cloud', 'روابط التخزين السحابي', dom(/mega\.nz|mediafire\.com|dropbox\.com|wetransfer\.com|1drv\.ms|sendspace\.com/i)],
  ['multilink', 'أكتر من رابط في رسالة', (x) => count(URL_RE)(x.text) > 1],
  ['manylinks', 'أكتر من 3 روابط', (x) => count(URL_RE)(x.text) > 3],
  ['email', 'عناوين الإيميل', has(/[\w.+-]+@[\w-]+\.[\w.-]+/)],
  // ── بيانات شخصية ومحتوى احتيالي ──
  ['phones', 'أرقام الهواتف', has(/(?:\+|00)?\d[\d\s-]{8,}\d/)],
  ['longnum', 'الأرقام الطويلة (+10)', has(/\d{10,}/)],
  ['crypto', 'عناوين العملات الرقمية', has(/\b(?:0x[a-fA-F0-9]{40}|bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}|T[A-Za-z1-9]{33})\b/)],
  ['seedphrase', 'عبارات استرجاع المحافظ', has(/(?:seed phrase|recovery phrase|private key|مفتاح خاص|عبارة الاسترجاع)/i)],
  ['cards', 'أرقام البطاقات البنكية', (x) => { const m = x.text.replace(/[\s-]/g, '').match(/\d{13,19}/g) || []; return m.some((n) => { let s = 0, d = false; for (let i = n.length - 1; i >= 0; i--) { let v = +n[i]; if (d) { v *= 2; if (v > 9) v -= 9 } s += v; d = !d } return s % 10 === 0 }) }],
  ['iban', 'أرقام الآيبان', has(/\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b/)],
  ['otp', 'طلب أكواد التحقق', has(/(?:send|share|give).{0,15}(?:code|otp)|(?:ابعت|ارسل|هات|اعطني).{0,15}(?:الكود|كود التحقق|رمز التحقق)/i)],
  ['scamwords', 'كلمات الاحتيال', has(/(?:you (?:have )?won|congratulations.{0,20}(?:prize|winner)|claim (?:your )?(?:prize|reward)|ربحت|مبروك.{0,15}(?:جائزة|فزت)|اضغط.{0,10}(?:للاستلام|لتستلم))/i)],
  ['investment', 'عروض الاستثمار والربح السريع', has(/(?:guaranteed (?:profit|returns?)|double your (?:money|bitcoin)|ربح مضمون|ضاعف (?:اموالك|أموالك|رصيدك)|استثمر.{0,20}(?:ارباح|أرباح)|forex signals|توصيات فوركس)/i)],
  ['jobscam', 'وظائف وهمية', has(/(?:work from home.{0,30}\$|earn \$?\d+.{0,20}(?:daily|per day)|وظيفة.{0,20}(?:من المنزل|اون لاين).{0,30}(?:دولار|\$)|اربح.{0,15}يوميا)/i)],
  ['loans', 'إعلانات القروض', has(/(?:instant loan|loan approved|قرض فوري|تمويل فوري|قروض بدون)/i)],
  ['adult', 'محتوى للكبار (كلمات)', has(/\b(?:porn|xxx|nsfw|onlyfans|sex ?cam)\b|سكس|اباحي|إباحي/i)],
  ['gambling', 'القمار', has(/\b(?:casino|betting|1xbet|bet365|poker|slots?)\b|كازينو|مراهنات|قمار|رهان/i)],
  ['drugs', 'ترويج المخدرات', has(/(?:weed|cocaine|heroin|mdma|tramadol|حشيش|بانجو|مخدرات|ترامادول|هيروين)/i)],
  ['hackservice', 'إعلانات الاختراق', has(/(?:hack(?:ing)? service|account recovery service|hire a hacker|اختراق حسابات|استرجاع حسابات|هكر للايجار|تهكير)/i)],
  ['followers', 'بيع المتابعين', has(/(?:buy (?:followers|likes|views)|بيع متابعين|زيادة متابعين|شحن متابعين|متابعين حقيقيين)/i)],
  ['ads', 'الإعلانات والترويج', has(/(?:للبيع|للايجار|للإيجار|خصم \d+%|اطلب الان|اطلب الآن|تواصل واتساب|whatsapp me|dm me|for sale|promo code|كود خصم)/i)],
  ['joinreq', 'طلبات الانضمام لجروبات', has(/(?:join (?:my|our) group|ادخل(?:وا)? جروب|انضم(?:وا)? (?:لجروب|لقناة)|اشترك(?:وا)? في (?:قناتي|جروبي))/i)],
  ['chainmsg', 'رسايل السلسلة', has(/(?:forward (?:this|to)|send to \d+|ابعتها ل|انشرها ل|شاركها مع|ارسلها لـ?\s*\d+)/i)],
  ['mentionbot', 'ذكر أرقام أو بوتات', has(/@\d{10,}/)],
  ['religionspam', 'نشر مواد دينية متكررة', has(/(?:copy and paste|انسخ والصق|ولا تقطع السلسلة)/i)],
  // ── شكل النص ──
  ['longtext', 'الرسايل الطويلة (+1000 حرف)', len(1000)],
  ['hugetext', 'الرسايل الضخمة (+3000 حرف)', len(3000)],
  ['manylines', 'الرسايل كتيرة الأسطر (+15)', lines(15)],
  ['capslock', 'الكتابة بالأحرف الكبيرة', caps],
  ['repeatchars', 'تكرار الحروف (aaaaaaa)', has(/(.)\1{9,}/u)],
  ['repeatword', 'تكرار الكلمات', has(/\b(\S{2,})(?:\s+\1){4,}/iu)],
  ['zalgo', 'النص المشوّه (Zalgo)', has(/[\u0300-\u036f]{3,}/)],
  ['rtlmark', 'أحرف اتجاه النص الخفية (RTL override)', has(/[\u202a-\u202e\u2066-\u2069]/)],
  ['zerowidth', 'الأحرف غير المرئية', has(/[\u200b-\u200d\u2060\ufeff]{2,}/)],
  ['crashchars', 'نصوص تعليق التطبيق (أحرف ثقيلة)', (x) => x.text.length > 800 && /[\u0600-\u06ff\u0900-\u097f\u0e00-\u0e7f][\u064b-\u065f\u0300-\u036f]{6,}/.test(x.text)],
  ['emojispam', 'الإيموجي الكتير (+10)', (x) => count(/\p{Extended_Pictographic}/gu)(x.text) > 10],
  ['emojionly', 'رسايل إيموجي فقط', (x) => x.text.length > 0 && !/[\p{L}\p{N}]/u.test(x.text) && /\p{Extended_Pictographic}/u.test(x.text)],
  ['symbols', 'رسايل رموز فقط', (x) => x.text.replace(/\s/g, '').length > 5 && !/[\p{L}\p{N}\p{Extended_Pictographic}]/u.test(x.text)],
  ['digitsonly', 'رسايل أرقام فقط', has(/^\s*[\d\s.,]{6,}\s*$/)],
  ['hashtags', 'الهاشتاجات الكتير (+5)', (x) => count(/#\S+/g)(x.text) > 5],
  ['mentions', 'المنشن الكتير (+5)', (x) => count(/@\d{5,}/g)(x.text) > 5],
  ['massmention', 'منشن جماعي (+10 في الميتاداتا)', (x) => (x.ctx?.mentionedJid?.length || 0) > 10],
  ['nonarabic', 'غير العربي (حروف لاتينية فقط)', (x) => x.text.length > 15 && !/[\u0600-\u06ff]/.test(x.text) && /[A-Za-z]{10}/.test(x.text)],
  ['cyrillic', 'الحروف السيريلية', has(/[\u0400-\u04ff]{3,}/)],
  ['chinese', 'الحروف الصينية/اليابانية/الكورية', has(/[\u3040-\u30ff\u4e00-\u9fff\uac00-\ud7af]{2,}/)],
  ['hindi', 'الحروف الهندية', has(/[\u0900-\u097f]{3,}/)],
  ['persian', 'الحروف الفارسية', has(/[پچژگ]{1}/)],
  ['quotesonly', 'اقتباسات فقط', has(/^\s*[>"«“].{0,}[<"»”]\s*$/)],
  ['short', 'الرسايل القصيرة جدا (حرف واحد)', (x) => x.text.length === 1],
  ['asciiart', 'الرسم بالرموز (ASCII art)', has(/[▒▓█░▄▀■□◢◣◤◥]{4,}|[│┃┆┇┊┋]{3,}/)],
  ['decorated', 'الزخرفة الثقيلة', has(/[ᴀ-ᴢＡ-Ｚａ-ｚ𝐀-𝟿]{6,}/u)],
  ['spoiler', 'نصوص مخفية', has(/\|\|.+\|\|/)],
  ['bold', 'النص الغامق/المائل الكتير', (x) => count(/[*_~]{1,2}[^*_~\n]+[*_~]{1,2}/g)(x.text) > 6],
  ['code', 'الأكواد (```)', has(/```/)],
  ['questions', 'علامات الاستفهام الكتير', has(/[?؟]{5,}/)],
  ['exclaim', 'علامات التعجب الكتير', has(/!{5,}/)],
  ['dots', 'النقاط الكتير', has(/\.{8,}/)],
  // ── مضايقات وسلوك ──
  ['insultmention', 'السب مع المنشن', (x) => (x.ctx?.mentionedJid?.length || 0) > 0 && /(?:حمار|كلب|زبالة|حقير|stupid|idiot|loser)/i.test(x.text)],
  ['threats', 'التهديد', has(/(?:هقتلك|هذبحك|هموتك|i will kill you|i'll kill you|i will find you|هجيبك)/i)],
  ['hatespeech', 'خطاب الكراهية', has(/(?:اقتلوا|يجب قتل|death to all|kill all)/i)],
  ['doxx', 'نشر بيانات شخصية', has(/(?:عنوانه|رقم بطاقته|بياناته الشخصية|his address is|her address is|home address)/i)],
  ['selfharm', 'محتوى إيذاء النفس', has(/(?:طرق الانتحار|how to (?:kill|hurt) myself)/i)],
  ['begging', 'التسول', has(/(?:ساعدوني ماديا|ارجوكم تبرع|محتاج مبلغ|please donate|send me money)/i)],
  ['offtopic', 'كلمة "خاص" (ترويج للمحادثة الخاصة)', has(/^\s*(?:خاص|ع الخاص|كلمني خاص|dm|pm)\s*$/i)],
  ['greetonly', 'التحيات المتكررة فقط', has(/^\s*(?:صباح الخير|مساء الخير|السلام عليكم|هاي|hi|hello|hey)\s*[!.]*\s*$/i)],
  ['bots', 'أوامر بوتات أخرى', has(/^[!\/#$%&*](?:play|ping|menu|help|sticker|ytmp3|yt|tagall|hidetag)\b/i)],
  ['tagall', 'أوامر منشن الكل', has(/^[.!#\/](?:tagall|everyone|hidetag|منشن|تاج)/i)],
  ['linkpreview', 'روابط بمعاينة صور', (x) => !!x.c?.extendedTextMessage?.matchedText && !!x.c?.extendedTextMessage?.jpegThumbnail],
  ['mediacaption', 'الوسائط بتعليق فيه رابط', (x) => /(https?:\/\/|www\.)/i.test(x.c?.imageMessage?.caption || x.c?.videoMessage?.caption || x.c?.documentMessage?.caption || '')],
  ['emptycaption', 'الوسائط بدون تعليق', (x) => (!!x.c?.imageMessage && !x.c.imageMessage.caption) || (!!x.c?.videoMessage && !x.c.videoMessage.caption)],
  ['edit', 'تعديل الرسايل', (x) => !!x.edited],
  ['reaction', 'التفاعلات (ريأكشن)', typ('reactionMessage')],
  ['pin', 'تثبيت الرسايل', typ('pinInChatMessage')],
  ['revoked', 'الرسايل المحذوفة', (x) => x.raw?.protocolMessage?.type === 0],
  ['keepinchat', 'حفظ الرسايل في الشات', typ('keepInChatMessage')],
  ['liststicker', 'ملصقات حزمة متحركة', (x) => !!x.c?.stickerMessage?.isAnimated],
  ['aistick', 'الملصقات المصنوعة بالـ AI', (x) => !!x.c?.stickerMessage?.isAiSticker],
  ['avatar', 'ملصقات الأفاتار', (x) => !!x.c?.stickerMessage?.isAvatar],
  ['lottie', 'ملصقات Lottie', (x) => !!x.c?.stickerMessage?.isLottie],
]

export const ruleKeys = RULES.map((r) => r[0])
export const RULE = Object.fromEntries(RULES.map(([k, ar, fn]) => [k, { ar, fn }]))

// بيرجّع أول قاعدة مفعّلة اتخالفت (أو null). x = { text, c (محتوى مطبّع), raw (message خام), ctx, edited }
export function checkRules(g, x) {
  const on = g.prot
  if (!on) return null
  x.fullLen = (x.text || '').length
  x.text = (x.text || '').slice(0, 4000) // سقف لحماية الريجكس من ReDoS
  for (const [k, ar, fn] of RULES) {
    if (!on[k]) continue
    try { if (fn(x)) return { key: k, ar } } catch {}
  }
  return null
}
export const anyRuleOn = (g) => !!g.prot && Object.values(g.prot).some(Boolean)

export function register(c) {
  const { cmd, P, T, panel, kv, gset, save } = c
  const SEC = 'prot6'
  const base = { sec: SEC, group: true }
  const flip = (e, args, key, ar) => {
    const g = gset(e.jid)
    g.prot ??= {}
    const a = args.trim().toLowerCase()
    const next = /^(on|تفعيل|شغل|فعل)/.test(a) ? true : /^(off|تعطيل|ايقاف|وقف|اقفل)/.test(a) ? false : !g.prot[key]
    if (next) g.prot[key] = true; else delete g.prot[key]
    save()
    return e.reply(`${next ? '🛡️' : '🔓'} منع ${ar}: *${next ? 'مفعّل' : 'متوقف'}*${next ? '\n(الرسالة المخالفة هتتمسح والعضو يتحذّر)' : ''}`)
  }
  for (const [key, ar] of RULES) {
    cmd(nm('منع ' + ar.replace(/\s+/g, ' ').replace(/[()+/]/g, '')), 'admin', (e, args) => flip(e, args, key, ar), { ...base, d: `قاعدة حماية: ${ar} (تفعيل/تعطيل)`, u: `منع ${ar}` })
  }
  cmd(nm('قواعد الحماية'), 'admin', (e) => {
    const g = gset(e.jid)
    const on = RULES.filter(([k]) => g.prot?.[k])
    return e.reply(panel('🛡️ RULES', [kv('المفعّل', `${on.length} من ${RULES.length}`), ...(on.length ? on.map(([, ar]) => `✅ ${ar}`) : ['مفيش قواعد مفعّلة']), '', `${P}منع <اسم القاعدة> لتفعيلها أو تعطيلها`], `${P}قواعد الحماية الكل`))
  }, { ...base, d: 'القواعد المفعّلة في الجروب' })
  cmd(nm('قواعد الحماية الكل'), 'admin', (e) => e.reply(panel('📋 ALL RULES', RULES.map(([k, ar]) => `• منع ${ar}`))), { ...base, d: 'قائمة كل قواعد الحماية المتاحة' })
  const preset = (name, keys, d) => cmd(nm('حماية ' + name), 'admin', (e) => {
    const g = gset(e.jid); g.prot ??= {}
    for (const k of keys) g.prot[k] = true
    save()
    return e.reply(`${T.ok} اتفعّلت حزمة «${name}» (${keys.length} قاعدة)`)
  }, { ...base, d })
  preset('الاحتيال', ['scamwords', 'investment', 'jobscam', 'loans', 'crypto', 'seedphrase', 'otp', 'hackservice', 'followers', 'login', 'shortlinks', 'badtld', 'filelinks', 'iplinks', 'punycode'], 'حزمة قواعد ضد الاحتيال والتصيّد')
  preset('الانهيار', ['crashchars', 'zalgo', 'rtlmark', 'zerowidth', 'hugetext', 'repeatchars', 'asciiart'], 'حزمة ضد رسايل تعليق التطبيق')
  preset('الروابط', ['anylink'], 'منع كل الروابط')
  preset('الاعلانات', ['ads', 'joinreq', 'telegram', 'discord', 'wagroup', 'wachannel', 'followers', 'invite', 'newsletter', 'products'], 'حزمة ضد الإعلانات والترويج')
  preset('الازعاج', ['repeatchars', 'repeatword', 'emojispam', 'capslock', 'massmention', 'mentions', 'hashtags', 'manylines', 'longtext'], 'حزمة ضد الإزعاج والسبام')
  preset('الملفات', ['apk', 'exe', 'zip', 'bigdoc', 'bigvideo'], 'حزمة ضد الملفات الخطرة والكبيرة')
  cmd(nm('تصفير القواعد'), 'admin', (e) => { const g = gset(e.jid); g.prot = {}; save(); return e.reply(`${T.ok} اتعطّلت كل قواعد الحماية`) }, { ...base, d: 'تعطيل كل قواعد الحماية دفعة واحدة' })
}
