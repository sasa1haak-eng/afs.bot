// ═══════════ أدوات الجروب: قواعد، ملاحظات، استطلاع، تقارير، حماية سريعة ═══════════
export function register(c) {
  const { cmd, P, T, panel, kv, tag, clean, gset, db, save, getMeta, isAdmin, botIsAdmin, fetchMedia, dot, uptime } = c
  const SEC = 'group'
  const G = { group: true, sec: SEC }
  const GA = { group: true, botAdmin: true, sec: SEC }
  const timeOf = (t) => new Date(t).toLocaleTimeString('ar-EG', { timeZone: c.CONFIG.TZ, hour: '2-digit', minute: '2-digit' })

  cmd(['الادمنز'], 'all', async (e) => {
    const meta = await getMeta(e.sock, e.jid)
    const ad = meta.participants.filter((p) => p.admin).map((p) => p.id)
    return e.reply(panel('👮 ADMINS', ad.map((id, i) => `${i + 1}. ${tag(id)}`)), ad)
  }, { ...G, d: 'قايمة الأدمنز' })

  cmd(['الاعضاء'], 'all', async (e) => {
    const meta = await getMeta(e.sock, e.jid)
    const ad = meta.participants.filter((p) => p.admin).length
    return e.reply(panel('👥 MEMBERS', [kv('الإجمالي', meta.participants.length), kv('الأدمنز', ad), kv('الأعضاء', meta.participants.length - ad)]))
  }, { ...G, d: 'عدد الأعضاء' })

  cmd(['نداء الادمنز'], 'all', async (e, args) => {
    const meta = await getMeta(e.sock, e.jid)
    const ad = meta.participants.filter((p) => p.admin).map((p) => p.id)
    const g = gset(e.jid)
    if (Date.now() - (g._call || 0) < 60_000) return e.reply(`${T.warn} استنى دقيقة بين كل نداء`)
    g._call = Date.now()
    return e.reply(`🚨 نداء للإدارة من ${tag(clean(e.sender))}${args ? `\n▸ ${args.slice(0, 200)}` : ''}\n${ad.map(tag).join(' ')}`, [clean(e.sender), ...ad])
  }, { ...G, d: 'ينادي الأدمنز (كل دقيقة مرة)' })

  cmd(['الوصف'], 'all', async (e) => {
    const meta = await getMeta(e.sock, e.jid)
    return e.reply(panel('📝 DESCRIPTION', [meta.desc || 'مفيش وصف']))
  }, { ...G, d: 'وصف الجروب' })

  // ── القواعد ──
  cmd(['قواعد'], 'all', (e) => e.reply(panel('📜 RULES', [gset(e.jid).rules || `مفيش قواعد متحددة. الأدمن يكتب ${P}ضبط القواعد ...`])), { ...G, d: 'قواعد الجروب' })
  cmd(['ضبط القواعد'], 'admin', (e, args) => {
    if (!args.trim()) return e.reply(`${T.info} اكتب: ${P}ضبط القواعد 1- ممنوع الروابط 2- احترام الجميع`)
    gset(e.jid).rules = args.trim().slice(0, 1500); save()
    return e.reply(`${T.ok} اتحفظت القواعد (${P}قواعد لعرضها)`)
  }, { ...G, d: 'تحديد قواعد الجروب (للأدمن)', u: 'ضبط القواعد ...' })

  // ── الملاحظات ──
  cmd(['ملاحظة'], 'all', async (e, args) => {
    const g = gset(e.jid)
    const m = args.trim().match(/^(\S+)\s*([\s\S]*)$/)
    if (!m) return e.reply(`${T.info} اعرض: ${P}ملاحظة اسم | احفظ (للأدمن): ${P}ملاحظة اسم النص`)
    const [, name, text] = m
    if (!text.trim()) return e.reply(g.notes[name] ? panel(`📌 ${name}`, [g.notes[name]]) : `${T.err} مفيش ملاحظة بالاسم ده (${P}ملاحظات)`)
    if (!e.isOwner) { const meta = await getMeta(e.sock, e.jid); if (!isAdmin(meta, e.sender)) return e.reply(`${T.warn} الحفظ للأدمن بس`) }
    if (Object.keys(g.notes).length >= 30 && !g.notes[name]) return e.reply(`${T.err} وصلت الحد (30 ملاحظة)`)
    g.notes[name] = text.trim().slice(0, 600); save()
    return e.reply(`${T.ok} اتحفظت ملاحظة *${name}*`)
  }, { ...G, d: 'اعرض أو احفظ ملاحظة', u: 'ملاحظة اسم النص' })
  cmd(['ملاحظات'], 'all', (e) => {
    const n = Object.keys(gset(e.jid).notes)
    return e.reply(n.length ? panel('📌 NOTES', n.map((x) => `▸ ${x}`), `${P}ملاحظة اسم`) : `${T.info} مفيش ملاحظات`)
  }, { ...G, d: 'قايمة الملاحظات' })
  cmd(['حذف ملاحظة'], 'admin', (e, args) => {
    const g = gset(e.jid)
    if (!g.notes[args.trim()]) return e.reply(`${T.err} مفيش ملاحظة بالاسم ده`)
    delete g.notes[args.trim()]; save()
    return e.reply(`${T.ok} اتحذفت`)
  }, { ...G, d: 'حذف ملاحظة (للأدمن)', u: 'حذف ملاحظة اسم' })

  // ── إعلان واستطلاع ──
  cmd(['اعلان'], 'admin', async (e, args) => {
    if (!args.trim()) return e.reply(`${T.info} اكتب: ${P}اعلان نص الإعلان`)
    const meta = await getMeta(e.sock, e.jid)
    await e.sock.sendMessage(e.jid, { text: panel('📢 ANNOUNCEMENT', [args.trim()]), mentions: meta.participants.map((p) => p.id) })
  }, { ...G, d: 'إعلان بمنشن مخفي للكل (للأدمن)', u: 'اعلان النص' })
  cmd(['استطلاع'], 'all', async (e, args) => {
    const parts = args.split('|').map((x) => x.trim()).filter(Boolean)
    if (parts.length < 3 || parts.length > 13) return e.reply(`${T.info} اكتب: ${P}استطلاع السؤال | خيار1 | خيار2 | خيار3`)
    await e.sock.sendMessage(e.jid, { poll: { name: parts[0].slice(0, 200), values: parts.slice(1).map((x) => x.slice(0, 80)), selectableCount: 1 } })
  }, { sec: SEC, d: 'استطلاع رأي', u: 'استطلاع السؤال | خ1 | خ2' })

  // ── الوداع والتقارير والسجل ──
  cmd(['ضبط الوداع'], 'admin', (e, args) => {
    gset(e.jid).goodbyeText = args.trim() === 'افتراضي' ? '' : args.trim().slice(0, 500); save()
    return e.reply(`${T.ok} اتضبط نص الوداع (استخدم {user} و{group})، وفعّله بـ ${P}تفعيل الوداع`)
  }, { ...G, d: 'نص الوداع (للأدمن)', u: 'ضبط الوداع نص' })
  cmd(['تقرير'], 'admin', async (e) => {
    const g = gset(e.jid)
    const meta = await getMeta(e.sock, e.jid)
    const top = Object.entries(db.xp[e.jid] || {}).sort((a, b) => b[1].xp - a[1].xp).slice(0, 3)
    const on = ['antilink', 'antisticker', 'antiimage', 'antiprofanity', 'antiflood', 'antibot', 'aimod'].filter((k) => g[k]).length
    return e.reply(panel(`📊 REPORT · ${meta.subject}`, [
      kv('الأعضاء', meta.participants.length), kv('الأدمنز', meta.participants.filter((p) => p.admin).length),
      kv('البوت أدمن', dot(botIsAdmin(e.sock, meta))), kv('طبقات الحماية الشغالة', `${on}/7`),
      kv('محذوف (إجمالي)', db.stats.deleted), kv('مطرودين (إجمالي)', db.stats.kicked),
      kv('عمليات في السجل', (db.modlog[e.jid] || []).length), kv('مكتومين', Object.keys(g.muted).length),
      ...top.map(([id, x], i) => `${['🥇', '🥈', '🥉'][i]} ${tag(id)} (${x.msgs} رسالة)`),
    ]), top.map(([id]) => id))
  }, { ...G, d: 'تقرير سريع عن الجروب (للأدمن)' })
  cmd(['سجل'], 'admin', (e) => {
    const l = (db.modlog[e.jid] || []).slice(-10).reverse()
    return e.reply(l.length ? panel('🗂 MOD LOG', l.map((x) => `${timeOf(x.t)} ▸ ${x.text}`)) : `${T.info} السجل فاضي`)
  }, { ...G, d: 'آخر عمليات الإشراف (للأدمن)' })
  cmd(['تحذيرات'], 'admin', (e) => {
    const w = Object.entries(gset(e.jid).warnings).filter(([, n]) => n > 0)
    return e.reply(w.length ? panel('⚠ WARNINGS', w.map(([id, n]) => `▸ ${tag(id)}: ${n}`)) : `${T.info} مفيش تحذيرات`, w.map(([id]) => id))
  }, { ...G, d: 'الأعضاء اللي عليهم تحذيرات (للأدمن)' })
  cmd(['انذاراتي'], 'all', (e) => {
    const n = gset(e.jid).warnings[clean(e.sender)] || 0
    return e.reply(`${n ? '⚠️' : '✅'} إنذاراتك: ${n}/${gset(e.jid).warnLimit || 3}`)
  }, { ...G, d: 'إنذاراتك في الجروب' })

  // ── حماية سريعة (بريسيت) ──
  const preset = (names, d, set) =>
    cmd(names, 'owner', (e) => {
      const g = gset(e.jid)
      set(g); save()
      return e.reply(`${T.ok} ${d}\n${['antilink', 'antiprofanity', 'antiflood', 'antibot'].map((k) => `${dot(g[k])} ${k}`).join('  ')}`)
    }, { ...G, d })
  preset(['حماية كاملة'], 'تشغيل الحماية الكاملة (روابط/شتايم/تكرار/بوتات + إنذارات 3)', (g) => Object.assign(g, { antilink: true, antiprofanity: true, antiflood: true, antibot: true, warnLimit: 3 }))
  preset(['حماية خفيفة'], 'حماية خفيفة (روابط وشتايم فقط)', (g) => Object.assign(g, { antilink: true, antiprofanity: true, antiflood: false, antibot: false }))
  preset(['حماية ايقاف'], 'إيقاف كل أنواع الحماية', (g) => Object.assign(g, { antilink: false, antiprofanity: false, antiflood: false, antibot: false, antisticker: false, antiimage: false, aimod: false }))

  // ── إدارة متقدمة ──
  cmd(['قفل مؤقت'], 'admin', async (e, args) => {
    const n = Math.min(Math.max(parseInt(args) || 0, 1), 1440)
    if (!args.trim() || !parseInt(args)) return e.reply(`${T.info} اكتب: ${P}قفل مؤقت 30 (بالدقايق)`)
    await e.sock.groupSettingUpdate(e.jid, 'announcement')
    const { sock, jid } = e
    setTimeout(async () => { try { await sock.groupSettingUpdate(jid, 'not_announcement'); await sock.sendMessage(jid, { text: `${T.ok} انتهى القفل المؤقت، الجروب اتفتح 🔓` }) } catch {} }, n * 60_000)
    return e.reply(`${T.ok} الجروب مقفول ${n} دقيقة وبعدها هيتفتح لوحده 🔒 (لو البوت اتقفل قبلها افتحه يدوي)`)
  }, { ...GA, d: 'قفل الجروب مدة وفتحه تلقائي', u: 'قفل مؤقت 30' })
  cmd(['صورة الجروب'], 'all', async (e) => {
    let url
    try { url = await e.sock.profilePictureUrl(e.jid, 'image') } catch {}
    if (!url) return e.reply(`${T.info} الجروب مفيهوش صورة`)
    const res = await fetch(url, { signal: AbortSignal.timeout(15000) })
    const buf = Buffer.from(await res.arrayBuffer())
    if (buf.length > 8 * 1024 * 1024) return e.reply(`${T.err} الصورة كبيرة`)
    return e.sock.sendMessage(e.jid, { image: buf, caption: '🖼️' }, { quoted: e.m })
  }, { ...G, d: 'صورة الجروب' })
  cmd(['ضبط صورة'], 'admin', async (e) => {
    const m = await fetchMedia(e)
    if (!m || m.type !== 'imageMessage') return e.reply(`${T.info} ردّ على صورة واكتب ${P}ضبط صورة`)
    await e.sock.updateProfilePicture(e.jid, m.buffer)
    return e.reply(`${T.ok} اتغيرت صورة الجروب`)
  }, { ...GA, d: 'تغيير صورة الجروب (رد على صورة)', u: 'ضبط صورة' })
  cmd(['مغادرة'], 'owner', async (e) => {
    await e.reply(`👋 مع السلامة، البوت هيغادر الجروب`)
    await e.sock.groupLeave(e.jid)
  }, { ...G, d: 'البوت يغادر الجروب (للمالك)' })
  cmd(['انضم'], 'owner', async (e, args) => {
    const code = args.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/)?.[1]
    if (!code) return e.reply(`${T.info} اكتب: ${P}انضم https://chat.whatsapp.com/XXXX`)
    await e.sock.groupAcceptInvite(code)
    return e.reply(`${T.ok} تم الانضمام`)
  }, { sec: SEC, d: 'البوت ينضم لجروب برابط (للمالك)', u: 'انضم رابط' })
  cmd(['تجربة الترحيب'], 'owner', async (e) => {
    const g = gset(e.jid)
    const meta = await getMeta(e.sock, e.jid)
    const t = (g.welcomeText || '⟦⌁ ACCESS GRANTED⟧\n┃ ▸ مرحباً {user}\n┃ ▸ الشبكة: *{group}*').replaceAll('{user}', tag(clean(e.sender))).replaceAll('{group}', meta.subject).replaceAll('{desc}', meta.desc || '')
    return e.reply(t, [clean(e.sender)])
  }, { ...G, d: 'تجربة رسالة الترحيب (للمالك)' })
}
