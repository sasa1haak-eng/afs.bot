import './core/compat.js' // لازم أول import: توافق Node 18 (تطبيق الأندرويد)
import { normalizeMessageContent } from '@whiskeysockets/baileys'
import { CONFIG, gset, clean, log, getMeta, invalidateMeta, recordMsg, botIsAdmin } from './lib.js'
import { setHandlers, startMain, restoreSubs, acquireLock, installSub, removeSub, listSubs } from './sessions.js'
import { maybeAutoReply, noteOwnerMessage, noteIncoming, hasAI, askAI } from './ai.js'
import { handleCommand, sendBotCard, realCount, pulseCompetitionScheduler } from './commands.js'
import { answer as brainAnswer } from './brain.js'
import { bumpXP } from './eco.js'
import { isDev } from './cmds-dev.js'
import { runGuards } from './guards.js'
import { onJoinCheck, isTrap, observe as botObserve } from './antibot.js'
import { onParticipants as shieldJoin } from './core/shield.js'

// ═══════════════ استخراج الرسالة ═══════════════
function extract(m) {
  let key = m.key
  let edited = false
  let c
  try {
    c = normalizeMessageContent(m.message)
  } catch {
    return { text: '', key, hasInvite: false, ctx: null, edited, content: null }
  }
  const ed = c?.protocolMessage?.editedMessage // رسالة اتعدلت
  if (ed) {
    key = { ...m.key, id: c.protocolMessage.key?.id ?? m.key.id }
    c = normalizeMessageContent(ed)
    edited = true
  }
  if (!c) return { text: '', key, hasInvite: false, ctx: null, edited, content: null }
  const text =
    c.conversation ||
    c.extendedTextMessage?.text ||
    c.imageMessage?.caption ||
    c.videoMessage?.caption ||
    c.documentMessage?.caption ||
    ''
  const ctx =
    Object.values(c).find((v) => v && typeof v === 'object' && v.contextInfo)?.contextInfo || null
  return { text, key, hasInvite: !!c.groupInviteMessage, ctx, edited, content: c }
}

// ═══════════════ كلمة "بوت": بطاقة التعريف والدردشة ═══════════════
const cardAt = new Map()
const chatAt = new Map()
async function botTriggers({ sock, m, jid, text, isGroup, sender }) {
  const t = text.trim()
  if (t.length > 320 || t.startsWith(CONFIG.PREFIX)) return false
  const g = isGroup ? gset(jid) : null

  // "بوت" لوحدها → بطاقة البوت (صورة + معلومات + طريقة الاستخدام + المطور)
  if (/^(بوت|البوت|يا بوت|bot)[\s!؟?.]*$/i.test(t)) {
    if (g && g.botcall === false) return false
    const now = Date.now()
    if (now - (cardAt.get(jid) || 0) < CONFIG.CARD_COOLDOWN_S * 1000) return true
    cardAt.set(jid, now)
    await sendBotCard(sock, jid, m)
    return true
  }

  // "بوت + كلامك" → دردشة بالذكاء المحلي (والسحابي لو متظبط)
  const c = t.match(/^(?:يا\s+)?(?:بوت|bot)[\s,،:]+([\s\S]{2,300})$/i)
  if (!c) return false
  if (g && g.chat === false) return false
  const who = `${jid}|${clean(sender || '')}`
  if (Date.now() - (chatAt.get(who) || 0) < 3000) return true
  chatAt.set(who, Date.now())
  const q = c[1].trim()
  let reply = brainAnswer(q, { jid, vars: { count: String(realCount()) } })?.reply
  if (!reply && hasAI()) {
    try {
      reply = await askAI({
        system: 'أنت بوت واتساب ودود. جاوب باختصار (3 أسطر كحد أقصى) وبنفس لهجة السائل. ارفض بأدب أي طلب ضار.',
        messages: [{ role: 'user', content: q }],
        maxTokens: 300,
      })
    } catch {}
  }
  if (!reply) reply = `🤔 مش فاهم قصدك. علّمني: ${CONFIG.PREFIX}علمني ${q.slice(0, 25)} = ردك\nأو اكتب ${CONFIG.PREFIX}الاوامر`
  await sock.sendMessage(jid, { text: reply }, { quoted: m })
  return true
}

// ═══════════════ معالجة الرسائل ═══════════════
const seenBy = new WeakMap() // كل جلسة (بوت) ليها قايمة خاصة

export async function onMessage(sock, m) {
  pulseCompetitionScheduler(sock)
  const jid = m.key.remoteJid
  if (!jid || jid === 'status@broadcast' || !m.message) return

  const id = m.key.id
  let seen = seenBy.get(sock)
  if (!seen) seenBy.set(sock, (seen = new Set()))
  if (seen.has(id)) return
  seen.add(id)
  if (seen.size > 1000) seen.delete(seen.values().next().value)

  const isGroup = jid.endsWith('@g.us')
  const fromMe = !!m.key.fromMe
  const { text, key, hasInvite, ctx, edited, content } = extract(m)
  if (!key?.id) return
  const sender =
    m.key.participant || m.participant || (fromMe ? clean(sock.user?.id) : jid)
  const isOwner = fromMe || isDev(sock, m, sender) // المالك أو مطور مُمكَّن (.تمكين)

  if (isTrap(m.key.id)) return // رسالة فخ للبوتات (مش أمر حقيقي)
  if (isGroup && !edited) recordMsg(jid, m.key, sender)
  if (isGroup && !fromMe && !edited) botObserve({ jid, sender, m, content, text })

  // 1) الحماية (للأعضاء بس، رسايل المالك مش بتتفحص)
  if (
    isGroup && !isOwner &&
    (await runGuards({ sock, m, jid, key, text, hasInvite, content, sender, edited, ctx }))
  ) return

  // 1a) كلمة "بوت" (بطاقة البوت / دردشة) + نقاط النشاط (XP)
  if (!edited && text && (await botTriggers({ sock, m, jid, text, isGroup, sender }))) return
  if (isGroup && !edited && text && !text.startsWith(CONFIG.PREFIX)) {
    const x = bumpXP(jid, sender)
    if (x.up && gset(jid).levels)
      sock.sendMessage(jid, {
        text: `⟦✔ OK⟧ @${clean(sender).split('@')[0]} وصلت للمستوى *${x.level}* 🎉`,
        mentions: [clean(sender)],
      }).catch(() => {})
  }

  // 1b) الخاص: لو انت كتبت بنفسك الرد الآلي بيقف، ولو حد كتب لك بيرد الذكاء (لو مفعّل)
  if (!isGroup) {
    if (fromMe) noteOwnerMessage(sock, jid, m.key.id, text)
    else if (!edited && text && !text.startsWith(CONFIG.PREFIX)) {
      noteIncoming(sock, jid, text)
      maybeAutoReply(sock, jid, text).catch((e) => log('رد آلي:', e.message))
      return
    }
  }

  // 2) الأوامر
  const ts = Number(m.messageTimestamp)
  const age = ts ? Date.now() / 1000 - ts : 0
  const dbg = process.env.DEBUG_MSGS === '1'
  if (edited || age > 90 || !text.startsWith(CONFIG.PREFIX)) {
    if (dbg && text.startsWith(CONFIG.PREFIX))
      log(`⏳ تجاهل أمر: عمر الرسالة ${Math.round(age)} ثانية (لو كبير يبقى ساعة الجهاز غلط)`)
    return
  }
  const handled = await handleCommand({ sock, m, jid, text, ctx, isOwner, isGroup, sender })
  if (dbg && !handled)
    log(`❔ الأمر مش معروف أو مش مسموحلك بيه (isOwner=${isOwner}, group=${isGroup}): ${text.slice(0, 30)}`)
}

// ═══════════════ الترحيب والوداع ═══════════════
const DEFAULT_GOODBYE = '⟦⌁ SESSION CLOSED⟧\n┃ ▸ {user} غادر *{group}*\n┃ ▸ في أمان الله 👋'
const DEFAULT_WELCOME = '⟦⌁ ACCESS GRANTED⟧\n┃ ▸ مرحباً {user}\n┃ ▸ الشبكة: *{group}*\n┃ ▸ اقرأ الوصف والتزم بالقواعد'

export async function onParticipants(sock, { id, participants, action }) {
  invalidateMeta(id)
  if (action !== 'add' && action !== 'remove') return
  const g = gset(id)
  await onJoinCheck(sock, { id, participants, action }) // بوت محظور بيتطرد فوراً
  await shieldJoin(sock, { id, participants, action }, { getMeta, botIsAdmin }).catch((e) => log('خطأ الدرع:', e.message)) // قائمة سوداء + كشف الهجمات
  const on = action === 'add' ? g.welcome : g.goodbye
  if (!on) return
  const meta = await getMeta(sock, id)
  const base = action === 'add' ? g.welcomeText || DEFAULT_WELCOME : g.goodbyeText || DEFAULT_GOODBYE
  for (const p of participants) {
    const jid = typeof p === 'string' ? p : p.id
    if (!jid) continue
    if (action === 'add' && ((g.antibot && g.botBan?.[jid.split('@')[0].split(':')[0]]) || g.blacklist?.[jid.split('@')[0].split(':')[0]])) continue
    const text = base
      .replaceAll('{user}', '@' + jid.split('@')[0])
      .replaceAll('{group}', meta.subject)
      .replaceAll('{desc}', meta.desc || '')
    await sock.sendMessage(id, { text, mentions: [jid] })
  }
}

// ═══════════════ تشغيل البوت ═══════════════
process.on('uncaughtException', (e) => log('uncaught:', e.message))
process.on('unhandledRejection', (e) => log('rejection:', e?.message || e))

setHandlers({ onMessage, onParticipants })

if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split(/[\\/]/).pop())) {
  try {
    if (!/^\d{8,15}$/.test(CONFIG.NUMBER))
      throw new Error('BOT_NUMBER غير مضبوط. انسخ .env.example إلى .env وضع رقم الحساب بالكود الدولي بدون +.')
    acquireLock()
  } catch (e) {
    console.log('\n❌ ' + e.message)
    process.exit(1)
  }
  log(`ℹ️ Node ${process.version} على ${process.platform}/${process.arch}`)
  if (parseInt(process.versions.node, 10) < 20) log('⚠️ Node أقدم من 20: بعض المكتبات (Baileys 7) مصممة لـ Node 20+. لو حصل خطأ غريب فده السبب المحتمل.')
  await startMain()
  await restoreSubs()
  // الموقع (اختياري): فعّله بـ WEB_PORT في .env — شوف DEPLOY-WEB.md
  if (process.env.WEB_PORT) {
    const { createWebServer } = await import('./web/server.js')
    const port = Number(process.env.WEB_PORT), host = process.env.WEB_HOST || '127.0.0.1'
    const srv = createWebServer(
      { installSub, removeSub, listSubs, maxSubs: CONFIG.MAX_SUBBOTS, allow: () => CONFIG.ALLOW_INSTALL, log },
      { siteUrl: process.env.SITE_URL, siteName: process.env.SITE_NAME, supportUrl: process.env.SUPPORT_URL, powBits: Number(process.env.WEB_POW_BITS) || 14 },
    )
    srv.on('error', (e) => log('🌐 فشل تشغيل الموقع:', e.message))
    srv.listen(port, host, () => log(`🌐 الموقع شغال على http://${host}:${port} (${srv.cfg.siteUrl})`))
  }
}
