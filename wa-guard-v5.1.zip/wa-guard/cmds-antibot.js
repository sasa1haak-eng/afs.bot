// ═══════════ أوامر مضاد البوتات: وضع صارم، سماح، حظر، سجل ═══════════
import { gset, save, db, getMeta, isAdmin, botIsAdmin } from './lib.js'
import { digits, scanBots, recentEvals } from './antibot.js'

// بيشغّل الفحص النشط ويرجّع نص التقرير (بيتستخدم من الأمر ومن التفعيل)
export async function runScan(e, { announce = true } = {}) {
  const g = gset(e.jid)
  const meta = await getMeta(e.sock, e.jid)
  const canKick = botIsAdmin(e.sock, meta)
  if (announce) await e.reply(`🕵️ *فحص البوتات بدأ* (حوالي 25 ثانية)\n┃ ▸ هبعت كام أمر تجريبي (.menu .help .ping ...) وأراقب مين بيرد.\n┃ ▸ مفيش داعي ترد على حاجة دلوقتي.${canKick ? '' : '\n┃ ⚠️ البوت مش أدمن: هيبلّغ بس من غير طرد.'}`)
  const r = await scanBots({ sock: e.sock, jid: e.jid, meta, g, kick: g.antibot && canKick, adminFn: isAdmin })
  if (r.busy) return e.reply('⏳ فيه فحص شغال في الجروب ده بالفعل.')
  const tagOf = (x) => `@${x.n}${x.name ? ` (${x.name.slice(0, 14)})` : ''}`
  const lines = [`🕵️ *نتيجة فحص البوتات*`, `┃ ▸ أعضاء ردّوا على الفخ: ${r.seen}`]
  if (r.suspects.length) lines.push(`┃ ▸ 🤖 بوتات مكتشفة: ${r.suspects.map(tagOf).join('، ')}`, g.antibot && canKick ? '┃ ▸ اتمسحت رسايلهم واتطردوا واتحظروا من الرجوع.' : `┃ ▸ اطردهم بـ ${'.'}حظر بوت @ (أو فعّل المضاد والبوت أدمن)`)
  else lines.push('┃ ▸ ✅ مفيش بوت رد على الأوامر التجريبية.')
  if (r.admins.length) lines.push(`┃ ▸ ⚠️ أدمنز بيردوا زي البوتات: ${r.admins.map(tagOf).join('، ')} (مش هيتطردوا، شيلهم من الإدارة يدوي لو بوتات)`)
  if (!r.suspects.length && !r.admins.length) lines.push('┃ ▸ لاحظ: فيه بوتات مبتردش على الغرباء أو بأوامر تانية، فـ مضاد البوتات العادي بيكمّل الحماية.')
  return e.sock.sendMessage(e.jid, { text: lines.join('\n'), mentions: [...r.suspects, ...r.admins].map((x) => x.sender) })
}
export const autoScan = (e) => runScan(e, { announce: false }).catch(() => {})

export function register(c) {
  const { cmd, P, T, panel, kv, getTarget } = c
  const G = { group: true }
  const numberOf = (e, args) => {
    const t = getTarget(e, args)
    return t ? digits(t) : (args.match(/\d{8,15}/) || [])[0] || null
  }
  const ago = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 60 ? `${m} د` : m < 1440 ? `${Math.round(m / 60)} س` : `${Math.round(m / 1440)} يوم` }

  cmd(['مضاد البوتات صارم'], 'owner', (e) => {
    const g = gset(e.jid)
    g.antibot = true; g.antibotStrict = true; save()
    return e.reply(`🤖 مضاد البوتات: ✅ *الوضع الصارم*\n┃ ▸ حساسية أعلى (الحد 4 نقاط بدل 6)\n┃ ▸ لو بوت سليم اتطرد غلط: ${P}سماح بوت @\n┃ ▸ للرجوع للعادي: ${P}مضاد البوتات عادي`)
  }, G)
  cmd(['مضاد البوتات عادي'], 'owner', (e) => {
    const g = gset(e.jid)
    g.antibotStrict = false; save()
    return e.reply(`🤖 مضاد البوتات: الوضع العادي (الحد 6 نقاط)${g.antibot ? '' : `\n${T.info} المضاد لسه مش مفعّل: ${P}تفعيل مضاد البوتات`}`)
  }, G)

  cmd(['سماح بوت', 'استثناء بوت'], 'owner', (e, args) => {
    const n = numberOf(e, args)
    if (!n) return e.reply(`${T.info} منشن البوت أو ردّ على رسالته أو اكتب رقمه: ${P}سماح بوت 2010xxxxxxx`)
    const g = gset(e.jid)
    g.botAllow ??= []
    if (!g.botAllow.includes(n)) g.botAllow.push(n)
    delete g.botBan?.[n]
    save()
    return e.reply(`${T.ok} @${n} اتضاف للبوتات المسموحة (مش هيتفحص ولا يتطرد) واتشال من الحظر.`, [n + '@s.whatsapp.net'])
  }, G)

  cmd(['حظر بوت'], 'owner', async (e, args) => {
    const n = numberOf(e, args)
    if (!n) return e.reply(`${T.info} منشن البوت أو ردّ على رسالته أو اكتب رقمه: ${P}حظر بوت 2010xxxxxxx`)
    const g = gset(e.jid)
    g.botBan ??= {}
    g.botBan[n] = { t: Date.now(), why: 'حظر يدوي' }
    g.botAllow = (g.botAllow || []).filter((x) => x !== n)
    save()
    let kicked = false
    try { await e.sock.groupParticipantsUpdate(e.jid, [n + '@s.whatsapp.net'], 'remove'); kicked = true } catch {}
    return e.reply(`${T.ok} @${n} اتحظر كبوت${kicked ? ' واتطرد' : ' (مش موجود في الجروب أو البوت مش أدمن)'}. لو اتضاف تاني هيتطرد فوراً (لازم مضاد البوتات يكون مفعّل).`, [n + '@s.whatsapp.net'])
  }, G)

  cmd(['رفع حظر بوت', 'الغاء حظر بوت'], 'owner', (e, args) => {
    const n = numberOf(e, args)
    const g = gset(e.jid)
    if (!n || !g.botBan?.[n]) return e.reply(`${T.info} الرقم ده مش في قايمة الحظر. شوف ${P}سجل البوتات`)
    delete g.botBan[n]; save()
    return e.reply(`${T.ok} اتشال @${n} من حظر البوتات.`, [n + '@s.whatsapp.net'])
  }, G)

  cmd(['فحص البوتات', 'كشف البوتات'], 'owner', (e) => runScan(e), G)

  cmd(['حالة مضاد البوتات', 'تشخيص مضاد البوتات'], 'owner', async (e) => {
    const g = gset(e.jid)
    const meta = await getMeta(e.sock, e.jid)
    const admin = botIsAdmin(e.sock, meta)
    const ev = recentEvals(e.jid).slice(-10).reverse()
    const lines = [
      kv('المضاد', g.antibot ? (g.antibotStrict ? '✅ مفعّل (صارم)' : '✅ مفعّل (عادي)') : `❌ مقفول (فعّله: ${P}تفعيل مضاد البوتات)`),
      kv('البوت أدمن', admin ? 'نعم ✅' : 'لا ❌ (من غير أدمن مفيش فحص ولا طرد)'),
      kv('استثناء الأدمنز', g.exemptAdmins ? 'شغال (بوت أدمن ما بيتفحصش، شوف ادمن ايقاف)' : 'مقفول'),
      '', 'آخر رسايل اتفحصت:',
      ...(ev.length ? ev.map((x) => `▸ ${x.n}${x.name ? ` (${x.name.slice(0, 12)})` : ''} · ${x.id} · ${x.skip ? x.skip : `${x.total} نقطة${x.reasons.length ? ' — ' + x.reasons[0] : ''}`}`) : ['لسه مفيش رسايل اتفحصت (لازم المضاد يكون مفعّل والبوت أدمن)']),
    ]
    return e.reply(panel('🔎 ANTIBOT STATUS', lines, `${P}فحص البوتات · ${P}مضاد البوتات صارم`))
  }, G)

  cmd(['سجل البوتات', 'البوتات المحظورة'], 'owner', (e) => {
    const g = gset(e.jid)
    const ban = Object.entries(g.botBan || {}).sort((a, b) => b[1].t - a[1].t)
    const lines = [
      kv('المضاد', g.antibot ? (g.antibotStrict ? '✅ صارم' : '✅ عادي') : '❌ مقفول'),
      kv('محظورين', ban.length), kv('مسموحين', (g.botAllow || []).length), '',
      ...(ban.length ? ban.slice(0, 10).map(([n, x]) => `▸ ${n} — من ${ago(x.t)} — ${x.why || ''}`) : ['مفيش بوتات محظورة']),
    ]
    if ((g.botAllow || []).length) lines.push('', 'مسموحين: ' + g.botAllow.slice(0, 10).join('، '))
    return e.reply(panel('🤖 BOT LOG', lines, `${P}حظر بوت @ · ${P}سماح بوت @ · ${P}رفع حظر بوت @`))
  }, G)
}
