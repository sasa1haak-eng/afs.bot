// شخصيات أنمي (بنت/امرأة): "# اسم الأنمي" ثم سطر لكل شخصية: الاسم بالعربي (بدائل بـ /)|الاسم بالإنجليزي
export const FEMALE_RAW = `
# One Piece
نامي|Nami
نيكو روبين/روبين|Nico Robin
نفرتاري فيفي/فيفي|Nefertari Vivi
بوا هانكوك/هانكوك|Boa Hancock
ياماتو|Yamato
ألفيدا|Alvida
بيرونا|Perona
شارلوت بودينغ/بودينغ|Charlotte Pudding
شارلوت لينلين/بيغ مام|Charlotte Linlin
تاشيغي|Tashigi
بيلميري|Bellemere
نوجيكو|Nojiko
كايا|Kaya
ريبيكا|Rebecca
شيراهوشي|Shirahoshi
هينا|Hina
كوكورو|Kokoro
مونيه|Monet
بيبي 5|Baby 5
فيولا|Viola
كوالا|Koala
ريجو فينسموك/ريجو|Vinsmoke Reiju
كاريفا|Kalifa
ميس غولدن ويك|Miss Goldenweek
أوتا|Uta
كاروت|Carrot
ساندرسونيا|Boa Sandersonia
ماريغولد|Boa Marigold
تسورو|Tsuru
# Naruto
ساكورا هارونو/ساكورا|Sakura Haruno
هيناتا هيوغا/هيناتا|Hinata Hyuga
إينو ياماناكا/إينو|Ino Yamanaka
تينتن|Tenten
تسوناده|Tsunade
كوشينا أوزوماكي/كوشينا|Kushina Uzumaki
تيماري|Temari
كونان|Konan
سارادا أوتشيها/سارادا|Sarada Uchiha
أنكو ميتاراشي/أنكو|Anko Mitarashi
كورناي يوهي/كورناي|Kurenai Yuhi
شيزوني|Shizune
ميي تيروميي/ميي|Mei Terumi
كارين|Karin
تايويا|Tayuya
ساموي|Samui
يوغيتو|Yugito Nii
رين نوهارا/رين|Rin Nohara
ميكوتو أوتشيها/ميكوتو|Mikoto Uchiha
كاغويا أوتسوتسوكي/كاغويا|Kaguya Otsutsuki
هانابي هيوغا/هانابي|Hanabi Hyuga
فو|Fu
شيون|Shion
هانا إينوزوكا|Hana Inuzuka
ميراي ساروتوبي|Mirai Sarutobi
# Dragon Ball
بولما|Bulma
تشي تشي|Chi-Chi
أندرويد 18|Android 18
فيديل/فيديل ساتان|Videl
بان|Pan
مارون|Marron
لانش|Launch
أندرويد 21|Android 21
كاوليفلا|Caulifla
كالي|Kale
ماي|Mai
برا|Bra
فادوس|Vados
تشيلاي|Cheelai
# Bleach
روكيا كوتشيكي/روكيا|Rukia Kuchiki
أوريهيمي إينوي/أوريهيمي|Orihime Inoue
يوروتشي شيهوين/يوروتشي|Yoruichi Shihoin
رانغيكو ماتسوموتو/رانغيكو|Rangiku Matsumoto
سوي فون|Soi Fon
نيل|Nelliel Tu Odelschwanck
تيير هاريبل/هاريبل|Tier Harribel
نيمو كوروتسوتشي|Nemu Kurotsuchi
إيسانى كوتيتسو|Isane Kotetsu
ريتسو أونوهانا/أونوهانا|Retsu Unohana
مومو هيناموري/مومو|Momo Hinamori
نانو إيسي|Nanao Ise
كوكاكو شيبا|Kukaku Shiba
تاتسوكي أريساوا/تاتسوكي|Tatsuki Arisawa
هيوري ساروغاكي|Hiyori Sarugaki
ليسا ياداماروا|Lisa Yadomaru
ماشيرو كونا|Mashiro Kuna
لولي أيفرن|Loly Aivirrne
# Attack on Titan
ميكاسا أكرمان/ميكاسا|Mikasa Ackerman
آني ليونهارت/آني|Annie Leonhart
ساشا براوس/ساشا|Sasha Braus
هيستوريا رايس/كريستا|Historia Reiss
يمير|Ymir
بيك فينغر/بيك|Pieck Finger
كارلا ييغر/كارلا|Carla Yeager
ريكو برزنسكا|Rico Brzenska
بيترا رال/بيترا|Petra Ral
فريدا رايس|Frieda Reiss
مينا كارولينا|Mina Carolina
كيومي أزوماييتو|Kiyomi Azumabito
# Demon Slayer
نيزوكو كامادو/نيزوكو|Nezuko Kamado
شينوبو كوتشو/شينوبو|Shinobu Kocho
ميتسوري كانروجي/ميتسوري|Mitsuri Kanroji
كاناو تسويوري/كاناو|Kanao Tsuyuri
داكي|Daki
ماكومو|Makomo
كاناي كوتشو|Kanae Kocho
أوي كانزاكي|Aoi Kanzaki
تاماييو|Tamayo
هينيتسورو|Hinatsuru
ماكيو|Makio
سوما|Suma
كي كامادو|Kie Kamado
# Jujutsu Kaisen
ماكي زينين/ماكي|Maki Zenin
نوبارا كوغيساكي/نوبارا|Nobara Kugisaki
ماي ماي|Mei Mei
يوكي تسوكومو|Yuki Tsukumo
كاسومي ميوا|Kasumi Miwa
مومو نيشيميا|Momo Nishimiya
ماي زينين|Mai Zenin
أوتاهيمي إيوري|Utahime Iori
شوكو إييري|Shoko Ieiri
ريكا أوريموتو/ريكا|Rika Orimoto
تسوميكي فوشيغورو|Tsumiki Fushiguro
كيرارا هوشي|Kirara Hoshi
# My Hero Academia
أوتشاكو أوراراكا/أوتشاكو|Ochaco Uraraka
تسويو أساي/تسويو|Tsuyu Asui
مومو ياويوروزو/مومو|Momo Yaoyorozu
كيوكا جيرو/كيوكا|Kyoka Jiro
مينا أشيدو/مينا|Mina Ashido
هيميكو توغا/توغا|Himiko Toga
إيري|Eri
مونت ليدي|Mt. Lady
ميدنايت|Midnight
راغدول|Ragdoll
روومي أوساغيياما|Rumi Usagiyama
نيجيرى هادو|Nejire Hado
تورو هاغاكوري|Toru Hagakure
إنكو ميدوريا|Inko Midoriya
ميتسوكي باكوغو|Mitsuki Bakugo
فويومي تودوروكي|Fuyumi Todoroki
كامي أوتسوشيمي|Camie Utsushimi
إيتسوكا كيندو|Itsuka Kendo
سيتسونا توكاغي|Setsuna Tokage
بوني تسونوتوري|Pony Tsunotori
نانا شيمورا|Nana Shimura
ريكفري غيرل|Recovery Girl
ماندالاي|Mandalay
# Hunter x Hunter
بيسكي/بيسكيت كروغر|Biscuit Krueger
باكونودا|Pakunoda
ماتشي|Machi
شيزوكو|Shizuku Murasaki
مينشي|Menchi
كالوتو زولديك|Kalluto Zoldyck
ألوكا زولديك|Alluka Zoldyck
كوموغي|Komugi
بالم|Palm Siberia
كاناري|Canary
ميتو فريكس|Mito Freecss
كيكيو زولديك|Kikyo Zoldyck
نيون نوستراد|Neon Nostrade
# Fullmetal Alchemist
وينري روكبيل/وينري|Winry Rockbell
ريزا هوكاي/ريزا|Riza Hawkeye
لست|Lust
إيزومي كيرتس/إيزومي|Izumi Curtis
مي تشانغ/مي|Mei Chang
أوليفيير أرمسترونغ/أوليفيير|Olivier Mira Armstrong
غراسيا هيوز|Gracia Hughes
ماريا روس|Maria Ross
تريشا إلريك|Trisha Elric
بيناكو روكبيل|Pinako Rockbell
لان فان|Lan Fan
شيسكا|Sheska
# Death Note
ميسا أماني/ميسا|Misa Amane
ريم|Rem
كيومي تاكادا|Kiyomi Takada
ساياو ياغامي|Sayu Yagami
ناومي ميسورا|Naomi Misora
هالي ليدنر|Halle Lidner
# Detective Conan
ران موري/ران|Ran Mouri
كازوها توياما/كازوها|Kazuha Toyama
سونوكو سوزوكي/سونوكو|Sonoko Suzuki
جودي ستارلينغ/جودي|Jodie Starling
فيرموث|Vermouth
كير|Kir
يومي ميازاكي|Yumi Miyamoto
ميوكي ساتو|Miyuki Sato
إيري كيساكي|Eri Kisaki
ماسومي سيرا|Masumi Sera
أكيمي ميانو|Akemi Miyano
يوكيكو كودو|Yukiko Kudo
# Pokemon
ميستي|Misty
داون/هيكاري|Dawn
ماي|May
سيرينا|Serena
جيسي|Jessie
الممرضة جوي|Nurse Joy
الضابطة جيني|Officer Jenny
سينثيا|Cynthia
ليلي|Lillie
كاسي|Casey
إريكا|Erika
سابرينا|Sabrina
# Sailor Moon
أوساغي تسوكينو/أوساغي|Usagi Tsukino
آمي ميزونو/آمي|Ami Mizuno
ري هينو/ري|Rei Hino
ماكوتو كينو/ماكوتو|Makoto Kino
مينا آيينو/مينا|Minako Aino
هاروكا تينوه|Haruka Tenoh
ميتشيرو كايوه|Michiru Kaioh
سيتسونا ميياكاوا|Setsuna Meioh
هوتارو تومويه|Hotaru Tomoe
الملكة بيريل|Queen Beryl
لونا|Luna
# Cardcaptor Sakura
ناديشيكو كينوموتو|Nadeshiko Kinomoto
سونومي دايدوجي|Sonomi Daidouji
# Fruits Basket
تورو هوندا/تورو|Tohru Honda
كاغورا سوما|Kagura Sohma
أريسا أوتاني|Arisa Uotani
ساكي هاناجيما|Saki Hanajima
رين سوما|Rin Sohma
كيوكو هوندا|Kyoko Honda
# Ouran High School Host Club
هاروهي فوجيوكا/هاروهي|Haruhi Fujioka
رينغي هوشاكوجي|Renge Houshakuji
# Clannad
ناغيسا فوروكاوا/ناغيسا|Nagisa Furukawa
فوكو إيبوكي|Fuko Ibuki
كيو فوجيباياشي|Kyou Fujibayashi
ريو فوجيباياشي|Ryou Fujibayashi
تومويو ساكاغامي|Tomoyo Sakagami
كوتومي إيتشينوسي|Kotomi Ichinose
سانائي فوروكاوا|Sanae Furukawa
# Toradora
تايغا أيساكا/تايغا|Taiga Aisaka
ميوري كوشيما/ميوري|Minori Kushieda
آمي كاواشيما/آمي|Ami Kawashima
ياسوكو تاكاسو|Yasuko Takasu
# K-On!
يوي هيراساوا/يوي|Yui Hirasawa
ميو أكياما/ميو|Mio Akiyama
ريتسو تاينكا/ريتسو|Ritsu Tainaka
تسوغومي كوتوبوكي/موجي|Tsumugi Kotobuki
أزوسا ناكانو/أزوسا|Azusa Nakano
أوي هيراساوا|Ui Hirasawa
نودوكا ماناب|Nodoka Manabe
ساواكو ياماناكا|Sawako Yamanaka
# Madoka Magica
مادوكا كانامي/مادوكا|Madoka Kaname
هومورا أكيمي/هومورا|Homura Akemi
ساياكا ميكي/ساياكا|Sayaka Miki
ماامي تومويه|Mami Tomoe
كيوكو ساكورا|Kyoko Sakura
# Haruhi Suzumiya
هاروهي سوزوميا/هاروهي|Haruhi Suzumiya
يوكي ناغاتو|Yuki Nagato
ميكورو أساهينا|Mikuru Asahina
# Lucky Star
كوناتا إيزومي/كوناتا|Konata Izumi
كاغامي هيراغي|Kagami Hiiragi
ميوكي تاكارا|Miyuki Takara
# Bocchi the Rock
هيتوري غوتو/بوتشي|Hitori Gotoh
نيجيكا إيجيشي|Nijika Ijichi
ريو ياماندا|Ryo Yamada
إيكويو كيتا|Ikuyo Kita
# Frieren
فريرن|Frieren
فيرن|Fern
سيري|Serie
لاوفي|Lawine
كان|Kanne
فلامي|Flamme
أورا|Aura
# Dandadan
مومو أياسي/مومو أياسى|Momo Ayase
أيرا شيراتوري|Aira Shiratori
# Kaguya-sama
كاغويا شينوميا/كاغويا|Kaguya Shinomiya
تشيكا فوجيوارا/تشيكا|Chika Fujiwara
آي هاياساكا|Ai Hayasaka
ميكو إيينو|Miko Iino
إيريكا تسوباميه|Erika Tsubame
كي شيروغاني|Kei Shirogane
# Oshi no Ko
آي هوشينو|Ai Hoshino
روبي هوشينو|Ruby Hoshino
كانا أريما|Kana Arima
أكاني كوروكاوا|Akane Kurokawa
ميم تشو|MEM-cho
# Sword Art Online
أسونا يوكي/أسونا|Asuna Yuuki
سينون|Sinon
ليفا|Leafa
سيليكا|Silica
ليزبيت|Lisbeth
أليس شوبيرغ|Alice Schuberg
يوكي كونو|Yuuki Konno
# Fairy Tail
لوسي هارتفيليا/لوسي|Lucy Heartfilia
إرزا سكارلت/إرزا|Erza Scarlet
ميراجين شتراوس/ميراجين|Mirajane Strauss
جوفيا لوكسر/جوفيا|Juvia Lockser
ليفي ماكغاردن/ليفي|Levy McGarden
كانا ألبيرونا/كانا|Cana Alberona
ليزانا شتراوس|Lisanna Strauss
مافيس فيرميليون|Mavis Vermilion
ألتير ميلكوفيتش|Ultear Milkovich
ميريدي|Meredy
مينيرفا|Minerva Orland
كاغورا ميكازوتشي|Kagura Mikazuchi
بيسكا كونيل|Bisca Connell
إيفرغرين|Evergreen
كارلا|Carla
# Black Clover
نويل سيلفا/نويل|Noelle Silva
ميريوليونا فيرميليون/ميريوليونا|Mereoleona Vermillion
فانيسا إنوتشنتي/فانيسا|Vanessa Enoteca
سيكري سوالوتيل|Secre Swallowtail
الأخت ليلي|Sister Lily
نيرو|Nero
ريل بواسمورتييه|Rill Boismortier
ميموزا فيرميليون|Mimosa Vermillion
# Soul Eater
ماكا ألبارن/ماكا|Maka Albarn
تسوباكي ناكاتسوكاسا|Tsubaki Nakatsukasa
بلير|Blair
ميدوسا|Medusa
ليز تومسون|Liz Thompson
باتي تومسون|Patty Thompson
# Tokyo Ghoul
توكا كيريشيما/توكا|Touka Kirishima
ريزي كاميشيرو|Rize Kamishiro
إيتو يوشيمورا|Eto Yoshimura
أكيرا مادو|Akira Mado
# One Punch Man
تاتسوماكي|Tatsumaki
فوبوكي|Fubuki
سايكوس|Psykos
# Gintama
تسوكويو|Tsukuyo
أوتاي شيمورا|Otae Shimura
أوتوسي|Otose
كيوبي ياغيو|Kyubei Yagyu
# JoJo's Bizarre Adventure
جولين كوجو|Jolyne Cujoh
ليزا ليزا|Lisa Lisa
تريش أونا|Trish Una
إيرينا بندلتون|Erina Pendleton
هولي جوستار|Holly Joestar
يوكاكو ياماغيشي|Yukako Yamagishi
# Code Geass
سي سي/C.C.|C.C.
كالين ستادتفيلد/كالين|Kallen Stadtfeld
إيوفيميا|Euphemia li Britannia
كورنيليا|Cornelia li Britannia
شيرلي فينيت|Shirley Fenette
ميلي أشفورد|Milly Ashford
نينا أينشتاين|Nina Einstein
فيليتا نو|Villetta Nu
أنيا ألستريم|Anya Alstreim
# Neon Genesis Evangelion
ري أياناامي/ري|Rei Ayanami
أسوكا لانغلي/أسوكا|Asuka Langley Soryu
ميساتو كاتسوراغي/ميساتو|Misato Katsuragi
ريتسوكو أكاغي|Ritsuko Akagi
مايا إيبوكي|Maya Ibuki
ماري ماكيناامي|Mari Makinami Illustrious
هيكاري هوراكي|Hikari Horaki
# Cowboy Bebop
فاي فالنتاين/فاي|Faye Valentine
جوليا|Julia
# Gurren Lagann
يوكو ليتنر/يوكو|Yoko Littner
نيا تيبينيت/نيا|Nia Teppelin
# Steins;Gate
كوريسو ماكيسي/كوريسو|Kurisu Makise
مايوري شينا|Mayuri Shiina
سوزوها أماني|Suzuha Amane
مويكا كيريو|Moeka Kiryu
لوكا أوراشيما|Luka Urushibara
فاريس|Faris Nyannyan
# Fate
سابر/أرتوريا|Saber
رين توساكا/رين|Rin Tohsaka
ساكورا ماتو|Sakura Matou
ريدر|Rider
كاستر|Medea
جان دارك|Jeanne d'Arc
نيرو كلوديوس|Nero Claudius
ماش كيريلايت|Mash Kyrielight
إيشتار|Ishtar
سكاثاخ|Scathach
# Re:Zero
إيميليا|Emilia
رام|Ram
بياتريس|Beatrice
إيكيدنا|Echidna
فيلت|Felt
بريسيلا باريل|Priscilla Barielle
كروش كارستن|Crusch Karsten
أناستازيا هوشين|Anastasia Hoshin
فريدريكا باومان|Frederica Baumann
ساتيلا|Satella
# Konosuba
أكوا|Aqua
ميغومين|Megumin
داركنس/لاليتينا|Darkness
ويز|Wiz
يونيون|Yunyun
إيريس|Eris
# Overlord
ألبيدو|Albedo
شالتير|Shalltear Bloodfallen
ناربيرال غاما|Narberal Gamma
لوبوسريجينا|Lupusregina Beta
إنتوما|Entoma Vasilissa Zeta
سوليشن|Solution Epsilon
رينر|Renner Theiere Chardelon Ryle Vaiself
# Mushoku Tensei
روكسي ميغورديا/روكسي|Roxy Migurdia
إيريس بوريياس غريرات/إيريس|Eris Boreas Greyrat
سيلفيت|Sylphiette
نورن غريرات|Norn Greyrat
زينيث|Zenith Greyrat
ليليا|Lilia
أيشا|Aisha Greyrat
غيسلين|Ghislaine Dedoldia
# Spy x Family
يور فورجر/يور|Yor Forger
فيونا فروست|Fiona Frost
سيلفيا شيروود|Sylvia Sherwood
كاميلا|Camilla
# Chainsaw Man
باور|Power
ماكيما|Makima
كوبيني هاياكاوا|Kobeni Higashiyama
هيميينو|Himeno
ريزي|Reze
كوانشي|Quanxi
آسا ميتاكا|Asa Mitaka
يورو|Yoru
# Berserk
كاسكا|Casca
فارنيزي|Farnese
شيرك|Schierke
# Hellsing
إنتيغرا هيلسينغ/إنتيغرا|Integra Hellsing
سيراس فيكتوريا/سيراس|Seras Victoria
# Trigun
ميريل سترايف|Meryl Stryfe
ميلي تومسون|Milly Thompson
# Rurouni Kenshin
كاورو كاميا/كاورو|Kaoru Kamiya
ميغومي تاكاني|Megumi Takani
توموي يوكيشيرو|Tomoe Yukishiro
ميساو ماكيماتشي|Misao Makimachi
# Yu Yu Hakusho
بوتان|Botan
جينكاي|Genkai
كيكو يوكيمورا|Keiko Yukimura
يوكينا|Yukina
شيزورو كوابارا|Shizuru Kuwabara
# Inuyasha
كاغومي هيوراغاشي/كاغومي|Kagome Higurashi
سانغو|Sango
كيكيو|Kikyo
كاغورا|Kagura
كاييدي|Kaede
# Ranma 1/2
أكاني تندو/أكاني|Akane Tendo
شامبو|Shampoo
أوكيو كونوجي|Ukyo Kuonji
كوداتشي كونو|Kodachi Kuno
كاسومي تندو|Kasumi Tendo
نابيكي تندو|Nabiki Tendo
# Studio Ghibli
سوفي هاتر/صوفي|Sophie Hatter
نوسيكا/ناوسيكا|Nausicaa
سان/الأميرة مونونوكي|San
ليدي إيبوشي/إيبوشي|Lady Eboshi
فيو بيكولو|Fio Piccolo
جينا|Gina
دولا|Dola
يوبابا|Yubaba
زينيبا|Zeniba
لين|Lin
الأميرة كاغويا|Princess Kaguya
# Lupin III
فوجيكو مين/فوجيكو|Fujiko Mine
كلاريس|Clarisse de Cagliostro
# Gundam
لاكوس كلاين|Lacus Clyne
كاجالي يولا أثها|Cagalli Yula Athha
فلاي ألستر|Flay Allster
ساييلا ماس|Sayla Mass
# Grendizer
مارية|Maria Grace Fleed
# Saint Seiya
ساوري كيدو/أثينا|Saori Kido
# Yu-Gi-Oh
تيا غاردنر|Tea Gardner
ماي فالنتاين|Mai Valentine
# Beyblade
هيلاري تاتشيبانا|Hilary Tachibana
# Akame ga Kill
أكامي|Akame
إسديث|Esdeath
ليون|Leone
ماين|Mine
تشيلسي|Chelsea
كورومي|Kurome
شيلي|Sheele
ناجيندا|Najenda
سيريو يوبيكويتوس/سيريو|Seryu Ubiquitous
# Violet Evergarden
فيوليت إيفرغاردن/فيوليت|Violet Evergarden
# Darling in the Franxx
زيرو تو/002|Zero Two
إيتشيغو|Ichigo
ميكو|Miku
# Your Name / Weathering with You / Suzume
ميتسوها ميياميزو/ميتسوها|Mitsuha Miyamizu
هينا أماانو|Hina Amano
سوزومي إيواتو|Suzume Iwato
# Your Lie in April
كاوري ميازونو/كاوري|Kaori Miyazono
تسوباكي ساوابي|Tsubaki Sawabe
# A Silent Voice
شوكو نيشيميا/شوكو|Shoko Nishimiya
# Anohana
مينما|Menma
أنارو|Anaru
# Angel Beats
كاناي تاتشيبانا|Kanade Tachibana
يوري ناكامورا|Yuri Nakamura
# A Certain Scientific Railgun
ميكوتو ميساكا/ميكوتو|Mikoto Misaka
كوروكو شيراي|Kuroko Shirai
ساتين روكو|Ruiko Saten
ميساكي شوكوهو|Misaki Shokuhou
# Date A Live
توهكا ياتوغامي/توهكا|Tohka Yatogami
كورومي توكيساكي/كورومي|Kurumi Tokisaki
أوريغامي توبييتشي|Origami Tobiichi
كوتوري إيتسوكا|Kotori Itsuka
# Nisekoi
شيتوغي كيريساكي|Chitoge Kirisaki
كوساكي أونوديرا|Kosaki Onodera
ماريكا تاتشيباانا|Marika Tachibana
# The Quintessential Quintuplets
إيتشيكا ناكانو|Ichika Nakano
نينو ناكانو|Nino Nakano
ميكو ناكانو|Miku Nakano
يوتسوبا ناكانو|Yotsuba Nakano
إيتسوكي ناكانو|Itsuki Nakano
# Horimiya
كيوكو هوري/هوري|Kyoko Hori
# Spice and Wolf
هولو|Holo
# Bunny Girl Senpai
ماي ساكوراجيما/ماي|Mai Sakurajima
توموي كوغا|Tomoe Koga
نودوكا توييهاما|Nodoka Toyohama
ريو فوتابا|Rio Futaba
كايدي أزوساغاوا|Kaede Azusagawa
# Monogatari
هيتاغي سينجوغاهارا/هيتاغي|Hitagi Senjogahara
تسوباسا هانيكاوا|Tsubasa Hanekawa
شينوبو أوشينو|Shinobu Oshino
سوروغا كانبارو|Suruga Kanbaru
# Kill la Kill
ريوكو ماتوي/ريوكو|Ryuko Matoi
ساتسوكي كيريوين/ساتسوكي|Satsuki Kiryuin
ماكو مانكانشوكو|Mako Mankanshoku
# Little Witch Academia
أكو كاغاري/أكو|Atsuko Kagari
ديانا كافنديش|Diana Cavendish
سوسي مانبافاران|Sucy Manbavaran
# Maid Dragon
توهرو|Tohru
لوكوا|Lucoa
إلما|Elma
كوبياشي|Kobayashi
# Yuru Camp
ريـن شيما/رين|Rin Shima
ناديشيكو كاغاميهارا/ناديشيكو|Nadeshiko Kagamihara
تشياكي أوغاكي|Chiaki Ogaki
إينا سايتو|Ena Saitou
# Love Live!
هونوكا كوساكا|Honoka Kosaka
كوتوري مينامي|Kotori Minami
أومي سونودا|Umi Sonoda
ماكي نيشيكينو|Maki Nishikino
ريـن هوشيزورا|Rin Hoshizora
هانايو كويزومي|Hanayo Koizumi
نيكو يازاوا|Nico Yazawa
نوزومي توجو|Nozomi Tojo
إيلي أياسي|Eli Ayase
# Revolutionary Girl Utena
أوتينا تينجو|Utena Tenjou
أنثي هيميميا|Anthy Himemiya
# Kamisama Kiss
نانامي مومزونو|Nanami Momozono
# Skip Beat!
كيوكو موغامي|Kyoko Mogami
# Maid Sama!
ميساكي أيوزاوا/ميساكي|Misaki Ayuzawa
# Kimi ni Todoke
ساواكو كورونوما/ساواكو|Sawako Kuronuma
# Akatsuki no Yona
يونا|Yona
# Black Lagoon
ريفي|Revy
بالاليكا|Balalaika
# Ghost in the Shell
موتوكو كوساناغي/ميجور|Motoko Kusanagi
# Psycho-Pass
أكاني تسونيموري/أكاني|Akane Tsunemori
# Another
مي ميساكي|Mei Misaki
# Higurashi
رينا ريوغو|Rena Ryugu
ميون سونوزاكي|Mion Sonozaki
شيون سونوزاكي|Shion Sonozaki
# Umineko
# Claymore
كلير|Clare
تيريزا|Teresa
# Fire Force
تاماكي كوتاتسو|Tamaki Kotatsu
ماكي أوزي|Maki Oze
# The Promised Neverland
إيزابيلا|Isabella
كرون|Sister Krone
# Dungeon Meshi
مارسيل|Marcille Donato
فالين|Falin Thorden
# Vivy
فيفي|Vivy
# My Dress-Up Darling
مارين كيتاغاوا/مارين|Marin Kitagawa
# Mushishi / misc
# Princess Mononoke / Spirited misc
# Nana
نانا أوساكي|Nana Osaki
نانا كوماتسو/هاتشي|Nana Komatsu
# Sakura Wars / misc
ساكورا شينغوجي|Sakura Shinguji
`
