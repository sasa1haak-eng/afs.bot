// ═══════════ أوامر الحساب والتحويلات والتواريخ (أوفلاين) ═══════════
const ONES = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر']
const TENS = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون']
const HUND = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة']
const SCALES = [null, ['ألف', 'ألفان', 'آلاف'], ['مليون', 'مليونان', 'ملايين'], ['مليار', 'ملياران', 'مليارات'], ['تريليون', 'تريليونان', 'تريليونات']]

const below1000 = (n) => {
  const parts = []
  const h = Math.floor(n / 100)
  const r = n % 100
  if (h) parts.push(HUND[h])
  if (r) {
    if (r < 20) parts.push(ONES[r])
    else parts.push(r % 10 ? `${ONES[r % 10]} و${TENS[Math.floor(r / 10)]}` : TENS[Math.floor(r / 10)])
  }
  return parts.join(' و')
}

export function numToArabic(n) {
  if (!Number.isFinite(n) || Math.abs(n) >= 1e15) throw new Error('الرقم كبير (أقل من 10^15)')
  if (n === 0) return 'صفر'
  const neg = n < 0
  n = Math.floor(Math.abs(n))
  const groups = []
  while (n > 0) { groups.push(n % 1000); n = Math.floor(n / 1000) }
  const words = []
  for (let i = groups.length - 1; i >= 0; i--) {
    const g = groups[i]
    if (!g) continue
    if (i === 0) words.push(below1000(g))
    else {
      const [s1, s2, pl] = SCALES[i]
      words.push(g === 1 ? s1 : g === 2 ? s2 : g <= 10 ? `${below1000(g)} ${pl}` : `${below1000(g)} ${s1}`)
    }
  }
  return (neg ? 'سالب ' : '') + words.join(' و')
}

const ROMAN = [[1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'], [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'], [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']]
export const toRoman = (n) => { let o = ''; for (const [v, s] of ROMAN) while (n >= v) { o += s; n -= v } return o }
export const fromRoman = (s) => {
  const m = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 }
  let t = 0
  const u = s.toUpperCase()
  for (let i = 0; i < u.length; i++) {
    const a = m[u[i]], b = m[u[i + 1]]
    if (!a) throw new Error('رقم روماني غير صالح')
    t += b > a ? -a : a
  }
  return t
}

const ZODIAC = [['الجدي', 12, 22], ['الدلو', 1, 20], ['الحوت', 2, 19], ['الحمل', 3, 21], ['الثور', 4, 20], ['الجوزاء', 5, 21], ['السرطان', 6, 21], ['الأسد', 7, 23], ['العذراء', 8, 23], ['الميزان', 9, 23], ['العقرب', 10, 23], ['القوس', 11, 22]]

const ZONES = [['القاهرة', 'Africa/Cairo'], ['الرياض', 'Asia/Riyadh'], ['دبي', 'Asia/Dubai'], ['الكويت', 'Asia/Kuwait'], ['الدوحة', 'Asia/Qatar'], ['بغداد', 'Asia/Baghdad'], ['عمان', 'Asia/Amman'], ['بيروت', 'Asia/Beirut'], ['الدار البيضاء', 'Africa/Casablanca'], ['الجزائر', 'Africa/Algiers'], ['تونس', 'Africa/Tunis'], ['اسطنبول', 'Europe/Istanbul'], ['لندن', 'Europe/London'], ['باريس', 'Europe/Paris'], ['برلين', 'Europe/Berlin'], ['موسكو', 'Europe/Moscow'], ['نيويورك', 'America/New_York'], ['لوس انجلوس', 'America/Los_Angeles'], ['طوكيو', 'Asia/Tokyo'], ['بكين', 'Asia/Shanghai'], ['دلهي', 'Asia/Kolkata'], ['سيدني', 'Australia/Sydney']]

const toAscii = (s) => String(s).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/٫/g, '.').replace(/[،]/g, ',')
export function parseDate(str) {
  const t = toAscii(str).trim()
  let m = t.match(/(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/)
  let y, mo, d
  if (m) [y, mo, d] = [+m[1], +m[2], +m[3]]
  else if ((m = t.match(/(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/))) [d, mo, y] = [+m[1], +m[2], +m[3]]
  else return null
  const dt = new Date(Date.UTC(y, mo - 1, d))
  return dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d ? dt : null
}
const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
const todayUTC = () => { const n = new Date(); return new Date(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate())) }
const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a))

export function register(c) {
  const { cmd, P, T, panel, kv, pick, shuffle } = c
  const SEC = 'math'
  const fmt = (n) => (Number.isInteger(n) ? String(n) : String(Math.round(n * 1e8) / 1e8))
  const nums = (args) => (toAscii(args).match(/-?\d+(?:\.\d+)?/g) || []).map(Number)

  // أمر حسابي: بياخد أرقام من النص
  const ncmd = (names, usage, d, min, fn, sec = SEC) =>
    cmd(names, 'all', async (e, args) => {
      const a = nums(args)
      if (a.length < min) return e.reply(`${T.info} اكتب: ${P}${usage}`)
      await e.reply(String(await fn(a, args, e)))
    }, { sec, d, u: usage })

  // ── الأعداد ──
  ncmd(['رقم بالحروف'], 'رقم بالحروف 1250', 'الرقم بالحروف العربي', 1, (a) => `🔢 ${numToArabic(a[0])}`)
  ncmd(['رومانية'], 'رومانية 2025', 'رقم ← روماني (1 إلى 3999)', 1, (a) => { if (a[0] < 1 || a[0] > 3999) throw new Error('من 1 لـ 3999'); return toRoman(Math.floor(a[0])) })
  cmd(['من رومانية'], 'all', (e, args) => args.trim() ? e.reply(String(fromRoman(args.trim()))) : e.reply(`${T.info} اكتب: ${P}من رومانية MMXXV`), { sec: SEC, d: 'روماني ← رقم', u: 'من رومانية MMXXV' })
  ncmd(['عشري ثنائي'], 'عشري ثنائي 10', 'عشري ← ثنائي', 1, (a) => Math.floor(a[0]).toString(2))
  cmd(['ثنائي عشري'], 'all', (e, args) => /^[01]+$/.test(args.trim()) ? e.reply(String(parseInt(args.trim(), 2))) : e.reply(`${T.info} اكتب: ${P}ثنائي عشري 1010`), { sec: SEC, d: 'ثنائي ← عشري', u: 'ثنائي عشري 1010' })
  ncmd(['عشري هيكس'], 'عشري هيكس 255', 'عشري ← Hex', 1, (a) => Math.floor(a[0]).toString(16).toUpperCase())
  cmd(['هيكس عشري'], 'all', (e, args) => /^[0-9a-fA-F]+$/.test(args.trim()) ? e.reply(String(parseInt(args.trim(), 16))) : e.reply(`${T.info} اكتب: ${P}هيكس عشري FF`), { sec: SEC, d: 'Hex ← عشري', u: 'هيكس عشري FF' })
  ncmd(['عشري ثماني'], 'عشري ثماني 64', 'عشري ← ثماني', 1, (a) => Math.floor(a[0]).toString(8))
  ncmd(['اولي'], 'اولي 97', 'هل الرقم أولي؟', 1, (a) => {
    const n = Math.floor(a[0])
    if (n < 2 || n > 1e12) throw new Error('من 2 لـ 10^12')
    for (let i = 2; i * i <= n; i++) if (n % i === 0) return `${T.info} ${n} مش أولي (يقبل القسمة على ${i})`
    return `${T.ok} ${n} عدد أولي`
  })
  ncmd(['مضروب'], 'مضروب 10', 'مضروب العدد (حتى 100)', 1, (a) => {
    const n = Math.floor(a[0])
    if (n < 0 || n > 100) throw new Error('من 0 لـ 100')
    let r = 1n
    for (let i = 2n; i <= BigInt(n); i++) r *= i
    return `${n}! = ${r}`
  })
  ncmd(['قواسم'], 'قواسم 36', 'كل قواسم العدد', 1, (a) => {
    const n = Math.floor(a[0])
    if (n < 1 || n > 1e12) throw new Error('من 1 لـ 10^12')
    const d = []
    for (let i = 1; i * i <= n; i++) if (n % i === 0) { d.push(i); if (i !== n / i) d.push(n / i) }
    return `قواسم ${n} (${d.length}): ${d.sort((x, y) => x - y).slice(0, 60).join(', ')}`
  })
  ncmd(['عوامل اوليه'], 'عوامل اوليه 360', 'تحليل لعوامل أولية', 1, (a) => {
    let n = Math.floor(a[0])
    if (n < 2 || n > 1e12) throw new Error('من 2 لـ 10^12')
    const f = []
    for (let i = 2; i * i <= n; i++) while (n % i === 0) { f.push(i); n /= i }
    if (n > 1) f.push(n)
    return `${Math.floor(a[0])} = ${f.join(' × ')}`
  })
  ncmd(['قما'], 'قما 12 18', 'القاسم المشترك الأكبر', 2, (a) => `ق.م.أ = ${a.map(Math.floor).reduce(gcd)}`)
  ncmd(['مما'], 'مما 4 6', 'المضاعف المشترك الأصغر', 2, (a) => `م.م.أ = ${a.map(Math.floor).reduce((x, y) => (x * y) / gcd(x, y))}`)
  ncmd(['جذر'], 'جذر 144', 'الجذر التربيعي', 1, (a) => { if (a[0] < 0) throw new Error('مفيش جذر حقيقي لرقم سالب'); return `√${fmt(a[0])} = ${fmt(Math.sqrt(a[0]))}` })
  ncmd(['تربيع'], 'تربيع 12', 'مربع الرقم', 1, (a) => fmt(a[0] ** 2))
  ncmd(['تكعيب'], 'تكعيب 5', 'مكعب الرقم', 1, (a) => fmt(a[0] ** 3))
  ncmd(['اس'], 'اس 2 10', 'أ أس ب', 2, (a) => { const r = a[0] ** a[1]; if (!Number.isFinite(r)) throw new Error('الناتج كبير جداً'); return fmt(r) })
  ncmd(['لوغاريتم'], 'لوغاريتم 1000', 'لوغاريتم أساس 10', 1, (a) => { if (a[0] <= 0) throw new Error('لازم رقم موجب'); return fmt(Math.log10(a[0])) })
  ncmd(['لوغاريتم طبيعي'], 'لوغاريتم طبيعي 10', 'ln', 1, (a) => { if (a[0] <= 0) throw new Error('لازم رقم موجب'); return fmt(Math.log(a[0])) })
  ncmd(['جيب'], 'جيب 30', 'sin (بالدرجات)', 1, (a) => fmt(Math.sin((a[0] * Math.PI) / 180)))
  ncmd(['جيب التمام'], 'جيب التمام 60', 'cos (بالدرجات)', 1, (a) => fmt(Math.cos((a[0] * Math.PI) / 180)))
  ncmd(['ظل'], 'ظل 45', 'tan (بالدرجات)', 1, (a) => fmt(Math.tan((a[0] * Math.PI) / 180)))
  ncmd(['درجات لراديان'], 'درجات لراديان 180', 'درجات ← راديان', 1, (a) => fmt((a[0] * Math.PI) / 180))
  ncmd(['راديان لدرجات'], 'راديان لدرجات 3.14159', 'راديان ← درجات', 1, (a) => fmt((a[0] * 180) / Math.PI))
  ncmd(['فيبوناتشي'], 'فيبوناتشي 10', 'أول n حد من المتتالية', 1, (a) => {
    const n = Math.min(Math.max(Math.floor(a[0]), 1), 60)
    const f = [0, 1]
    while (f.length < n) f.push(f[f.length - 1] + f[f.length - 2])
    return f.slice(0, n).join(', ')
  })
  ncmd(['جدول ضرب'], 'جدول ضرب 7', 'جدول ضرب رقم', 1, (a) => panel(`✖ ${fmt(a[0])}`, Array.from({ length: 12 }, (_, i) => `${fmt(a[0])} × ${i + 1} = ${fmt(a[0] * (i + 1))}`)))
  ncmd(['زوجي ام فردي'], 'زوجي ام فردي 7', 'زوجي ولا فردي', 1, (a) => (Math.floor(a[0]) % 2 === 0 ? 'زوجي ✅' : 'فردي ✅'))
  cmd(['ارقام عربيه'], 'all', (e, args) => args.trim() ? e.reply(args.replace(/[0-9]/g, (d) => '٠١٢٣٤٥٦٧٨٩'[d])) : e.reply(`${T.info} اكتب: ${P}ارقام عربيه 2025`), { sec: SEC, d: 'أرقام غربية ← هندية', u: 'ارقام عربية 2025' })
  cmd(['ارقام غربيه'], 'all', (e, args) => args.trim() ? e.reply(toAscii(args)) : e.reply(`${T.info} اكتب: ${P}ارقام غربية ٢٠٢٥`), { sec: SEC, d: 'أرقام هندية ← غربية', u: 'ارقام غربية ٢٠٢٥' })

  // ── نسب ومالية ──
  ncmd(['نسبه مئويه'], 'نسبة مئوية 20 500', 'x% من y', 2, (a) => `${fmt(a[0])}% من ${fmt(a[1])} = ${fmt((a[0] / 100) * a[1])}`)
  ncmd(['زياده نسبه'], 'زيادة نسبة 500 10', 'زيادة نسبة على رقم', 2, (a) => `${fmt(a[0])} + ${fmt(a[1])}% = ${fmt(a[0] * (1 + a[1] / 100))}`)
  ncmd(['خصم'], 'خصم 1000 25', 'السعر بعد الخصم', 2, (a) => panel('🏷 DISCOUNT', [kv('السعر', fmt(a[0])), kv('الخصم', `${fmt(a[1])}%`), kv('قيمة الخصم', fmt((a[0] * a[1]) / 100)), kv('بعد الخصم', fmt(a[0] * (1 - a[1] / 100)))]))
  ncmd(['ضريبه'], 'ضريبة 1000 14', 'السعر بعد إضافة ضريبة %', 2, (a) => panel('🧾 TAX', [kv('السعر', fmt(a[0])), kv('الضريبة', fmt((a[0] * a[1]) / 100)), kv('الإجمالي', fmt(a[0] * (1 + a[1] / 100)))]))
  ncmd(['نسبه التغير'], 'نسبة التغير 80 100', 'نسبة التغير بين رقمين', 2, (a) => { if (a[0] === 0) throw new Error('الرقم الأول مينفعش صفر'); const p = ((a[1] - a[0]) / a[0]) * 100; return `${p >= 0 ? '📈' : '📉'} ${fmt(p)}%` })
  ncmd(['فايده'], 'فايدة 10000 12 5', 'فايدة مركبة: المبلغ، النسبة السنوية، السنين', 3, (a) => { const r = a[0] * (1 + a[1] / 100) ** a[2]; return panel('💹 INTEREST', [kv('الأصل', fmt(a[0])), kv('الناتج', fmt(r)), kv('الربح', fmt(r - a[0]))]) })
  ncmd(['قسط'], 'قسط 100000 18 5', 'القسط الشهري: المبلغ، الفايدة السنوية، السنين', 3, (a) => {
    const n = a[2] * 12
    const i = a[1] / 1200
    const pay = i === 0 ? a[0] / n : (a[0] * i) / (1 - (1 + i) ** -n)
    return panel('🏦 LOAN', [kv('القسط الشهري', fmt(pay)), kv('الإجمالي', fmt(pay * n)), kv('الفوايد', fmt(pay * n - a[0]))])
  })
  ncmd(['متوسط'], 'متوسط 10 20 30', 'متوسط الأرقام', 1, (a) => fmt(a.reduce((x, y) => x + y, 0) / a.length))
  ncmd(['وسيط'], 'وسيط 1 5 9 3', 'وسيط الأرقام', 1, (a) => { const s = [...a].sort((x, y) => x - y); const m = Math.floor(s.length / 2); return fmt(s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2) })
  ncmd(['اكبر رقم'], 'اكبر رقم 3 9 4', 'أكبر رقم', 1, (a) => fmt(Math.max(...a)))
  ncmd(['اصغر رقم'], 'اصغر رقم 3 9 4', 'أصغر رقم', 1, (a) => fmt(Math.min(...a)))
  ncmd(['مجموع'], 'مجموع 1 2 3', 'مجموع الأرقام', 1, (a) => fmt(a.reduce((x, y) => x + y, 0)))
  ncmd(['ضرب'], 'ضرب 2 3 4', 'حاصل ضرب الأرقام', 1, (a) => fmt(a.reduce((x, y) => x * y, 1)))
  ncmd(['تقريب'], 'تقريب 3.14159 2', 'تقريب لعدد خانات', 1, (a) => { const d = Math.min(Math.max(a[1] ?? 0, 0), 10); return (Math.round(a[0] * 10 ** d) / 10 ** d).toFixed(d) })

  // ── هندسة ──
  ncmd(['مساحه دايره'], 'مساحة دايرة 7', 'مساحة دايرة (نصف القطر)', 1, (a) => fmt(Math.PI * a[0] ** 2))
  ncmd(['محيط دايره'], 'محيط دايرة 7', 'محيط دايرة', 1, (a) => fmt(2 * Math.PI * a[0]))
  ncmd(['مساحه مستطيل'], 'مساحة مستطيل 5 8', 'مساحة مستطيل', 2, (a) => fmt(a[0] * a[1]))
  ncmd(['مساحه مثلث'], 'مساحة مثلث 6 4', 'مساحة مثلث (قاعدة، ارتفاع)', 2, (a) => fmt((a[0] * a[1]) / 2))
  ncmd(['حجم كره'], 'حجم كرة 3', 'حجم كرة', 1, (a) => fmt((4 / 3) * Math.PI * a[0] ** 3))
  ncmd(['وتر'], 'وتر 3 4', 'الوتر (فيثاغورس)', 2, (a) => fmt(Math.hypot(a[0], a[1])))
  ncmd(['معادله تربيعيه'], 'معادلة تربيعية 1 -3 2', 'جذور أس² + بس + ج = 0', 3, (a) => {
    const [x, y, z] = a
    if (x === 0) throw new Error('أ لازم تختلف عن صفر')
    const d = y * y - 4 * x * z
    if (d >= 0) return `Δ = ${fmt(d)}\nس₁ = ${fmt((-y + Math.sqrt(d)) / (2 * x))}\nس₂ = ${fmt((-y - Math.sqrt(d)) / (2 * x))}`
    return `Δ = ${fmt(d)} (جذور مركبة)\nس = ${fmt(-y / (2 * x))} ± ${fmt(Math.sqrt(-d) / (2 * x))}i`
  })

  // ── صحة ──
  ncmd(['كتله الجسم'], 'كتلة الجسم 70 175', 'BMI: الوزن (كجم) والطول (سم)', 2, (a) => {
    const b = a[0] / (a[1] / 100) ** 2
    const cat = b < 18.5 ? 'أقل من الطبيعي' : b < 25 ? 'طبيعي' : b < 30 ? 'زيادة وزن' : 'سمنة'
    return panel('⚖ BMI', [kv('المؤشر', fmt(Math.round(b * 10) / 10)), kv('التصنيف', cat)], 'معلومة عامة، مش بديل عن الطبيب')
  })
  ncmd(['سعرات'], 'سعرات ذكر 70 175 25', 'احتياج السعرات التقريبي: النوع والوزن والطول والسن', 3, (a, raw) => {
    const [w, h, age] = a
    const female = /انثى|أنثى|بنت|female|\bf\b/i.test(raw)
    const bmr = 10 * w + 6.25 * h - 5 * age + (female ? -161 : 5)
    return panel('🔥 CALORIES', [kv('الأساسي (BMR)', Math.round(bmr)), kv('قليل الحركة', Math.round(bmr * 1.2)), kv('نشاط متوسط', Math.round(bmr * 1.55))], 'تقدير عام، مش بديل عن أخصائي')
  })
  ncmd(['ماء يومي'], 'ماء يومي 70', 'تقدير احتياج الميّه باللتر', 1, (a) => `💧 حوالي ${fmt(Math.round(a[0] * 0.035 * 10) / 10)} لتر في اليوم (تقدير عام)`)

  // ── عشوائي وقرعة ──
  ncmd(['عشوائي'], 'عشوائي 1 100', 'رقم عشوائي بين رقمين', 0, (a) => {
    const [lo, hi] = a.length >= 2 ? [Math.min(a[0], a[1]), Math.max(a[0], a[1])] : [1, a[0] || 100]
    return `🎲 ${Math.floor(Math.random() * (hi - lo + 1)) + Math.floor(lo)}`
  })
  ncmd(['نرد'], 'نرد 6 2', 'رمي نرد (عدد الأوجه، عدد النرد)', 0, (a) => {
    const sides = Math.min(Math.max(Math.floor(a[0] || 6), 2), 1000)
    const n = Math.min(Math.max(Math.floor(a[1] || 1), 1), 10)
    const r = Array.from({ length: n }, () => Math.floor(Math.random() * sides) + 1)
    return `🎲 ${r.join(' + ')}${n > 1 ? ` = ${r.reduce((x, y) => x + y, 0)}` : ''}`
  })
  cmd(['عمله معدنيه', 'قرعة عملة'], 'all', (e) => e.reply(`🪙 ${pick(['صورة', 'كتابة'])}`), { sec: SEC, d: 'صورة ولا كتابة' })
  cmd(['اختر'], 'all', (e, args) => {
    const o = args.split(/\s*(?:\||،|,| او )\s*/).map((x) => x.trim()).filter(Boolean)
    return o.length < 2 ? e.reply(`${T.info} اكتب: ${P}اختر شاي | قهوة | عصير`) : e.reply(`🎯 اخترتلك: *${pick(o)}*`)
  }, { sec: SEC, d: 'يختار من اختيارات', u: 'اختر شاي | قهوة' })
  cmd(['قرعه'], 'all', (e, args) => {
    const m = toAscii(args).match(/^(\d+)\s+([\s\S]+)$/)
    const o = (m ? m[2] : args).split(/\s*(?:\||،|,|\n)\s*/).map((x) => x.trim()).filter(Boolean)
    if (o.length < 2) return e.reply(`${T.info} اكتب: ${P}قرعة 2 احمد | محمد | علي`)
    const k = Math.min(m ? Number(m[1]) : 1, o.length)
    return e.reply(panel('🎰 DRAW', shuffle(o).slice(0, k).map((x, i) => `${i + 1}. ${x}`)))
  }, { sec: SEC, d: 'قرعة بين أسماء', u: 'قرعة 2 احمد | محمد | علي' })

  // ── التواريخ والوقت ──
  const needDate = (e, args, usage) => { const d = parseDate(args); if (!d) { e.reply(`${T.info} اكتب: ${P}${usage}`); return null } return d }
  cmd(['عمر'], 'all', (e, args) => {
    const b = needDate(e, args, 'عمر 2000-05-17'); if (!b) return
    const t = todayUTC()
    let y = t.getUTCFullYear() - b.getUTCFullYear(), m = t.getUTCMonth() - b.getUTCMonth(), d = t.getUTCDate() - b.getUTCDate()
    if (d < 0) { m--; d += new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), 0)).getUTCDate() }
    if (m < 0) { y--; m += 12 }
    if (y < 0) return e.reply(`${T.err} التاريخ في المستقبل`)
    const days = Math.round((t - b) / 864e5)
    return e.reply(panel('🎂 AGE', [kv('العمر', `${y} سنة و${m} شهر و${d} يوم`), kv('إجمالي الأيام', days), kv('عيد ميلادك الجاي بعد', `${(() => { let n = new Date(Date.UTC(t.getUTCFullYear(), b.getUTCMonth(), b.getUTCDate())); if (n < t) n = new Date(Date.UTC(t.getUTCFullYear() + 1, b.getUTCMonth(), b.getUTCDate())); return Math.round((n - t) / 864e5) })()} يوم`)]))
  }, { sec: SEC, d: 'حساب العمر من تاريخ الميلاد', u: 'عمر 2000-05-17' })
  cmd(['ايام بين'], 'all', (e, args) => {
    const ds = (toAscii(args).match(/\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4}/g) || []).map(parseDate)
    if (ds.length < 2 || ds.some((x) => !x)) return e.reply(`${T.info} اكتب: ${P}ايام بين 2025-01-01 2025-03-01`)
    return e.reply(`📆 الفرق: ${Math.abs(Math.round((ds[1] - ds[0]) / 864e5))} يوم`)
  }, { sec: SEC, d: 'الفرق بين تاريخين بالأيام', u: 'ايام بين 2025-01-01 2025-03-01' })
  cmd(['كم باقي'], 'all', (e, args) => {
    const d = needDate(e, args, 'كم باقي 2026-12-31'); if (!d) return
    const n = Math.round((d - todayUTC()) / 864e5)
    return e.reply(n >= 0 ? `⏳ باقي ${n} يوم (${Math.floor(n / 7)} أسبوع و${n % 7} يوم)` : `⌛ عدّى من ${-n} يوم`)
  }, { sec: SEC, d: 'كم يوم باقي على تاريخ', u: 'كم باقي 2026-12-31' })
  cmd(['يوم التاريخ'], 'all', (e, args) => { const d = needDate(e, args, 'يوم التاريخ 2025-01-01'); if (d) e.reply(`📅 ${DAYS[d.getUTCDay()]}`) }, { sec: SEC, d: 'يوم الأسبوع لتاريخ', u: 'يوم التاريخ 2025-01-01' })
  cmd(['اضافه ايام'], 'all', (e, args) => {
    const d = parseDate(args)
    const n = nums(args.replace(/\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4}/, ''))[0]
    if (!d || n === undefined) return e.reply(`${T.info} اكتب: ${P}اضافة ايام 2025-01-01 30`)
    const r = new Date(d.getTime() + n * 864e5)
    return e.reply(`📅 ${r.toISOString().slice(0, 10)} (${DAYS[r.getUTCDay()]})`)
  }, { sec: SEC, d: 'تاريخ + عدد أيام', u: 'اضافة ايام 2025-01-01 30' })
  cmd(['اسبوع السنه'], 'all', (e, args) => {
    const d = args.trim() ? parseDate(args) : todayUTC()
    if (!d) return e.reply(`${T.info} اكتب: ${P}اسبوع السنة 2025-06-15`)
    const start = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
    return e.reply(`📆 الأسبوع رقم ${Math.ceil(((d - start) / 864e5 + start.getUTCDay() + 1) / 7)} من السنة`)
  }, { sec: SEC, d: 'رقم الأسبوع في السنة', u: 'اسبوع السنة' })
  ncmd(['سنه كبيسه'], 'سنة كبيسة 2024', 'هل السنة كبيسة؟', 1, (a) => { const y = Math.floor(a[0]); return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? `${y} سنة كبيسة ✅` : `${y} مش كبيسة` })
  cmd(['وقت المدن'], 'all', (e) => {
    const now = new Date()
    return e.reply(panel('🌍 WORLD CLOCK', ZONES.map(([n, z]) => kv(n, now.toLocaleTimeString('ar-EG', { timeZone: z, hour: 'numeric', minute: '2-digit' })))))
  }, { sec: SEC, d: 'الساعة في مدن العالم' })
  cmd(['وقت مدينه'], 'all', (e, args) => {
    const q = args.trim()
    const z = ZONES.find(([n]) => q && n.includes(q))
    if (!z) return e.reply(`${T.info} اكتب: ${P}وقت مدينة لندن`)
    return e.reply(`🕒 ${z[0]}: ${new Date().toLocaleString('ar-EG', { timeZone: z[1], dateStyle: 'medium', timeStyle: 'short' })}`)
  }, { sec: SEC, d: 'الساعة في مدينة معينة', u: 'وقت مدينة لندن' })

  // ── التحويلات ──
  const CONV = [
    ['كم لميل', 'كم', 'ميل', (x) => x * 0.621371], ['ميل لكم', 'ميل', 'كم', (x) => x / 0.621371],
    ['كم لمتر', 'كم', 'متر', (x) => x * 1000], ['متر لسم', 'متر', 'سم', (x) => x * 100], ['سم لملم', 'سم', 'ملم', (x) => x * 10],
    ['متر لقدم', 'متر', 'قدم', (x) => x * 3.28084], ['قدم لمتر', 'قدم', 'متر', (x) => x / 3.28084],
    ['سم لانش', 'سم', 'إنش', (x) => x / 2.54], ['انش لسم', 'إنش', 'سم', (x) => x * 2.54], ['ميل بحري لكم', 'ميل بحري', 'كم', (x) => x * 1.852],
    ['كجم لرطل', 'كجم', 'رطل', (x) => x * 2.20462], ['رطل لكجم', 'رطل', 'كجم', (x) => x / 2.20462],
    ['كجم لجرام', 'كجم', 'جرام', (x) => x * 1000], ['طن لكجم', 'طن', 'كجم', (x) => x * 1000],
    ['جرام لاوقيه', 'جرام', 'أوقية', (x) => x / 28.3495], ['اوقيه لجرام', 'أوقية', 'جرام', (x) => x * 28.3495],
    ['لتر لجالون', 'لتر', 'جالون', (x) => x * 0.264172], ['جالون للتر', 'جالون', 'لتر', (x) => x / 0.264172], ['لتر لملل', 'لتر', 'ملل', (x) => x * 1000],
    ['سيلسيوس لفهرنهايت', '°م', '°ف', (x) => (x * 9) / 5 + 32], ['فهرنهايت لسيلسيوس', '°ف', '°م', (x) => ((x - 32) * 5) / 9],
    ['سيلسيوس لكلفن', '°م', 'K', (x) => x + 273.15], ['كلفن لسيلسيوس', 'K', '°م', (x) => x - 273.15],
    ['كم ساعه لمتر ثانيه', 'كم/س', 'م/ث', (x) => x / 3.6], ['متر ثانيه لكم ساعه', 'م/ث', 'كم/س', (x) => x * 3.6],
    ['بايت لميجا', 'بايت', 'ميجا', (x) => x / 1048576], ['ميجا لجيجا', 'ميجا', 'جيجا', (x) => x / 1024], ['جيجا لميجا', 'جيجا', 'ميجا', (x) => x * 1024], ['جيجا لتيرا', 'جيجا', 'تيرا', (x) => x / 1024],
    ['ساعه لدقيقه', 'ساعة', 'دقيقة', (x) => x * 60], ['يوم لساعه', 'يوم', 'ساعة', (x) => x * 24], ['اسبوع ليوم', 'أسبوع', 'يوم', (x) => x * 7], ['سنه ليوم', 'سنة', 'يوم', (x) => x * 365],
    ['فدان لمتر مربع', 'فدان', 'م²', (x) => x * 4200.83], ['متر مربع لفدان', 'م²', 'فدان', (x) => x / 4200.83],
  ]
  for (const [name, from, to, fn] of CONV)
    ncmd([name], `${name.replace(/ ل/, ' ل')} 10`.replace(/^(\S+ \S+)\s/, '$1 '), `${from} ← ${to}`, 1, (a) => `🔁 ${fmt(a[0])} ${from} = ${fmt(fn(a[0]))} ${to}`, 'conv')
}
