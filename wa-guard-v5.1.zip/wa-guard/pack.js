// تجهيز نسخة من كود البوت للإرسال: قائمة بيضاء (كود فقط) — مفيش .env ولا auth ولا sessions ولا db.json ولا node_modules
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

const sh = promisify(execFile)
const allowed = (name, isDir) =>
  isDir
    ? ['assets', 'core', 'tests'].includes(name)
    : /\.(js|md)$/.test(name) || name === 'package.json' || name === 'package-lock.json' || name === '.env.example' || name === 'extra-questions.example.json'

export async function buildPackage(root) {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'wapack-'))
  const stage = path.join(work, 'wa-guard')
  fs.mkdirSync(stage)
  for (const f of fs.readdirSync(root)) {
    const src = path.join(root, f)
    if (allowed(f, fs.statSync(src).isDirectory())) fs.cpSync(src, path.join(stage, f), { recursive: true })
  }
  let file, mime
  try {
    file = path.join(work, 'wa-guard.zip')
    await sh('zip', ['-rq', file, 'wa-guard'], { cwd: work })
    mime = 'application/zip'
  } catch (e) {
    if (e.code !== 'ENOENT') throw e
    file = path.join(work, 'wa-guard.tar.gz') // لو zip مش متنصّب (pkg install zip)
    await sh('tar', ['-czf', file, 'wa-guard'], { cwd: work })
    mime = 'application/gzip'
  }
  const buffer = fs.readFileSync(file)
  const fileName = path.basename(file)
  fs.rmSync(work, { recursive: true, force: true })
  return { buffer, fileName, mime }
}
