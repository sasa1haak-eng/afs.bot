// ═══════════ الاقتصاد الافتراضي (عملات للعب بس) والمستويات ═══════════
import { isMainOwner } from './core/perm.js'
import {
  user, addCoins, cooldownLeft, fmtMs, money, levelOf,
  JOBS, TIER_NEED, RANKS, jobOf, rankOf, MISSIONS, missionsOf, track,
} from './eco.js'

// المتجر: cat = القسم · use = نوع الاستخدام
const SHOP = {
  // أدوات دايمة
  سنارة: { price: 500, cat: '🧰 أدوات', d: '+1 سمكة في كل صيدة' },
  'سنارة ذهبية': { price: 4000, cat: '🧰 أدوات', d: '+2 سمكة وفرصة أكبر للسمك النادر واللؤلؤ' },
  معول: { price: 800, cat: '🧰 أدوات', d: '+1 خام في كل تعدين' },
  'معول الماس': { price: 6000, cat: '🧰 أدوات', d: '+2 خام وفرصة أكبر للذهب والماس' },
  جرار: { price: 5000, cat: '🧰 أدوات', d: '+3 محصول في كل زراعة' },
  'ساعة ذكية': { price: 7000, cat: '🧰 أدوات', d: 'الشغل أسرع 20% وأرباحه +10%' },
  'ميزان تاجر': { price: 1500, cat: '🧰 أدوات', d: 'بيع بضاعة السوق بزيادة 5%' },
  'بنك ذهبي': { price: 10000, cat: '🧰 أدوات', d: 'فايدة 1% من رصيد البنك مع كل راتب (حد أقصى 500)' },
  // مستهلكات
  بذور: { price: 100, cat: '🧪 مستهلكات', d: 'بذرة للزراعة (بتتستهلك)' },
  سماد: { price: 250, cat: '🧪 مستهلكات', d: 'يضاعف محصول زراعتك الجاية' },
  طعم: { price: 150, cat: '🧪 مستهلكات', d: 'يزود فرصة السمك الكبير في صيدتك الجاية' },
  جوكر: { price: 2500, cat: '🧪 مستهلكات', d: 'تعيد استخدام أي مساعدة في لعبة «مليون»' },
  // حماية
  درع: { price: 1500, cat: '🛡️ حماية', d: 'حماية من السرقة 24 ساعة' },
  'درع قوي': { price: 4000, cat: '🛡️ حماية', d: 'حماية من السرقة 72 ساعة' },
  قفل: { price: 1200, cat: '🛡️ حماية', d: 'يصد أول محاولة سرقة عليك ويتكسر' },
  // هجوم
  قفازات: { price: 2500, cat: '🦹 للسرقة', d: '+15% فرصة نجاح في السرقة' },
  قناع: { price: 1800, cat: '🦹 للسرقة', d: 'لو فشلت السرقة مفيش غرامة (مرة واحدة)' },
}
const VALUE = {
  سمكة: 40, 'سمكة كبيرة': 120, قرش: 400, لؤلؤة: 500,
  حديد: 60, نحاس: 80, فضة: 130, ذهب: 200, الماس: 700,
  قمح: 30, طماطم: 45, ذرة: 35, فراولة: 55, عنب: 50,
}
const FOOD = new Set(['سمكة', 'سمكة كبيرة', 'قرش', 'قمح', 'طماطم', 'ذرة', 'فراولة', 'عنب'])
const FISH = [['سمكة', '🐟', 68], ['سمكة كبيرة', '🐠', 24], ['قرش', '🦈', 5], ['لؤلؤة', '🦪', 3]]
const ORES = [['حديد', '⛓️', 40], ['نحاس', '🟤', 25], ['فضة', '🥈', 17], ['ذهب', '🥇', 13], ['الماس', '💎', 5]]
const CROPS = [['قمح', '🌾'], ['طماطم', '🍅'], ['ذرة', '🌽'], ['فراولة', '🍓'], ['عنب', '🍇']]
// سوق التجارة: أسعار متغيرة كل ساعة (معروفة للكل) — اشتري وقت الرخص وبيع وقت الغلا
const GOODS = { تمر: [60, 5, 0], عسل: [150, 7, 1.3], 'زيت زيتون': [100, 9, 2.1], قماش: [220, 11, 3.4], توابل: [80, 13, 4.2] }
const GOODS_CAP = 10
const priceAt = (name, hour) => { const [base, per, ph] = GOODS[name]; return Math.max(1, Math.round(base * (1 + 0.3 * Math.sin(hour / per * Math.PI + ph)))) }
const QUESTS = [
  'وصّلت طلبية لحد في الحتة', 'ساعدت جارك يشيل كراتين', 'حلّيت مشكلة في الشغل', 'رتّبت المخزن', 'شغّلت الوردية الليلية',
  'أصلحت عطل مفاجئ', 'علّمت طفل يركب عجلة', 'وزّعت أكل على المحتاجين', 'نضّفت الشارع مع الجيران', 'رجّعت محفظة ضايعة لصاحبها',
  'ساعدت سواح يلاقوا الطريق', 'حضّرت وليمة للحي', 'ساعدت في تنظيم سوق خيري', 'سقيت زرع الحي كله', 'صلّحت كرسي متكسر للمسجد',
  'شلت شنط عجوز لحد البيت', 'علّقت لافتات للمحل الجديد', 'دلّيت واحد تايه على المحطة', 'خلّصت طلبات توصيل متأخرة', 'ساعدت في نقل عفش جارك',
  'نظّمت طابور في الجمعية', 'رسمت جدارية على سور المدرسة', 'ساعدت في إنقاذ قطة عالقة', 'حفرت بئر صغير للحديقة', 'جمعت تبرعات للمكتبة',
  'علّمت جارك يستخدم الموبايل', 'ساعدت في حصاد الموسم', 'ركّبت لمبات الشارع', 'خلّصت أوراق حد في المصلحة', 'حرست المحل ليلة كاملة',
]
const wpick = (list) => { let r = Math.random() * list.reduce((s, x) => s + x[2], 0); for (const x of list) { r -= x[2]; if (r <= 0) return x } return list[0] }
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1))
const nextRank = (works) => RANKS.find((r) => r.at > works)

export function register(c) {
  const { cmd, P, T, panel, kv, tag, clean, getTarget, db, save, bar } = c
  const SEC = 'eco'
  const me = (e) => clean(e.sender || '')
  // حساب المطور: رصيد عملي غير محدود، ويُعاد ضبطه عند كل أمر اقتصادي يرسله مالك البوت.
  const DEV_BALANCE = Number.MAX_SAFE_INTEGER
  const account = (e) => {
    const u = user(e.sender)
    // رصيد المطور الافتراضي للمطور الأساسي بس. (قبل كده كان لأي مالك بوت فرعي = ثغرة: رصيد لا نهائي + تحويل لغيره)
    if (isMainOwner(e)) { u.wallet = DEV_BALANCE; u.bank = DEV_BALANCE; save() }
    return u
  }
  const amount = (args, max) => { const a = args.trim(); if (/^(الكل|all)$/i.test(a)) return max; const n = parseInt(a.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))); return Number.isFinite(n) ? n : NaN }
  const wait = (u, key, ms, e) => { const l = cooldownLeft(u, key, ms); if (l) { e.reply(`${T.warn} استنى ${fmtMs(l)}`); return true } return false }
  const total = (u) => u.wallet + u.bank
  const has = (u, item) => (u.inv[item] || 0) > 0
  const use = (u, item) => { if (has(u, item)) { u.inv[item]--; return true } return false }

  cmd(['رصيد'], 'all', (e, args) => {
    const t = getTarget(e, args) || e.sender
    const u = (isMainOwner(e) && clean(t) === me(e)) ? account(e) : user(t)
    return e.reply(panel('💰 WALLET', [kv('صاحب الحساب', tag(clean(t))), kv('المحفظة', money(u.wallet)), kv('البنك', money(u.bank)), kv('الإجمالي', money(total(u))), u.job ? kv('الوظيفة', `${u.job} (${rankOf(u).name})`) : '', u.hasanat ? kv('الحسنات', `${u.hasanat} ✨`) : ''].filter(Boolean)), [clean(t)])
  }, { sec: SEC, d: 'رصيدك أو رصيد حد (@)', u: 'رصيد @' })

  cmd(['راتب'], 'all', (e) => {
    const u = account(e)
    if (wait(u, 'daily', 24 * 3600_000, e)) return
    const J = jobOf(u)
    let n = rnd(500, 1000)
    const notes = []
    if (J) { const bonus = RANKS.indexOf(rankOf(u)) * 100; if (bonus) { n += bonus; notes.push(`رتبة ${rankOf(u).name} +${bonus}`) } }
    if (J?.name === 'مهندس') { n = Math.round(n * 1.3); notes.push('مهندس ×1.3') }
    let interest = 0
    if (has(u, 'بنك ذهبي') && u.bank > 0 && !isMainOwner(e)) { interest = Math.min(500, Math.floor(u.bank * 0.01)); n += interest }
    u.last.daily = Date.now()
    addCoins(e.sender, n)
    track(e.sender, 'salary')
    return e.reply(`${T.ok} راتبك اليومي: +${money(n)}${notes.length ? `\n▸ ${notes.join(' · ')}` : ''}${interest ? `\n🏦 فايدة البنك الذهبي: +${money(interest)}` : ''}\nرصيدك: ${money(u.wallet)}`)
  }, { sec: SEC, d: 'راتب يومي (كل 24 ساعة)' })

  // ── الشغل والوظائف ──
  cmd(['عمل'], 'all', (e) => {
    const u = account(e)
    const J = jobOf(u)
    const watch = has(u, 'ساعة ذكية')
    const cd = (J?.cd ?? 30) * 60_000 * (watch ? 0.8 : 1)
    if (wait(u, 'work', cd, e)) return
    const rankBefore = rankOf(u)
    let base = J ? rnd(...J.pay) * rankBefore.mult : rnd(40, 120)
    if (J?.name === 'مبرمج') base *= 1.25
    if (watch) base *= 1.1
    const r = Math.random()
    let note = ''
    if (r < 0.08) { base *= 1.6; note = '\n🎉 بقشيش إضافي من العميل!' }
    else if (r < 0.14) { base *= 0.5; note = '\n🔧 حصل عطل في نص الشغل والدخل قلّ' }
    let n = Math.round(base)
    if (J?.name === 'مصور' && Math.random() < 0.12) { n += 250; note += '\n📸 صورة مميزة اتباعت: +250 🪙' }
    u.last.work = Date.now()
    u.works = (u.works || 0) + 1
    if (J) u.jobWorks = (u.jobWorks || 0) + 1
    const rankAfter = rankOf(u)
    if (J && rankAfter !== rankBefore) note += `\n🏅 ترقية! بقيت *${rankAfter.name}* (دخل ×${rankAfter.mult})`
    addCoins(e.sender, n)
    track(e.sender, 'work')
    return e.reply(`⚒️ اشتغلت${J ? ` كـ${J.icon} ${J.name} (${rankAfter.name})` : ' شغل حر'} واتحاسبت: +${money(n)}${note}${J ? '' : `\n💡 اختار وظيفة بـ ${P}وظيفة عشان دخلك يزيد ويبقى ليك ميزة`}`)
  }, { sec: SEC, d: 'شغل كل 30 دقيقة (الوظيفة بتزود الدخل)' })

  cmd(['وظيفة'], 'all', (e, args) => {
    const u = account(e)
    const a = args.trim()
    if (!a) {
      const lines = Object.entries(JOBS).map(([n, j]) => {
        const need = TIER_NEED[j.tier]
        const lock = (u.works || 0) >= need ? '' : ` 🔒(${need} شغل)`
        return `${j.icon} ${n}${lock} — ${j.pay[0]}~${j.pay[1]} 🪙 | ${j.perk}`
      })
      return e.reply(panel('💼 JOBS', [...lines, '', `شغلك لحد دلوقتي: ${u.works || 0} مرة`, 'الرتب: متدرب ← موظف ← محترف ← خبير ← مدير (كل رتبة دخل أعلى)'], `${P}وظيفة مبرمج · ${P}وظيفتي · ${P}استقالة`))
    }
    const name = Object.keys(JOBS).find((n) => n === a || n.includes(a))
    if (!name) return e.reply(`${T.err} الوظيفة دي مش موجودة. اكتب ${P}وظيفة وشوف القايمة`)
    const need = TIER_NEED[JOBS[name].tier]
    if ((u.works || 0) < need) return e.reply(`${T.warn} وظيفة ${name} محتاجة ${need} مرة شغل (${P}عمل) وانت عملت ${u.works || 0}`)
    if (u.job === name) return e.reply(`${T.info} انت أصلاً شغال ${name}`)
    u.job = name; u.jobWorks = 0; save()
    return e.reply(`${T.ok} بقيت *${JOBS[name].icon} ${name}*\n✨ الميزة: ${JOBS[name].perk}\n(رتبتك بتبدأ من متدرب وبتزيد مع كل شغل)`)
  }, { sec: SEC, d: 'اختار وظيفة (دخل وميزة)', u: 'وظيفة مبرمج' })

  cmd(['وظيفتي'], 'all', (e) => {
    const u = account(e)
    const J = jobOf(u)
    if (!J) return e.reply(`${T.info} انت من غير وظيفة. اكتب ${P}وظيفة`)
    const rk = rankOf(u), nx = nextRank(u.jobWorks || 0)
    return e.reply(panel('💼 MY JOB', [
      kv('الوظيفة', `${J.icon} ${J.name}`), kv('الرتبة', `${rk.name} (دخل ×${rk.mult})`), kv('الميزة', J.perk),
      kv('شغلك هنا', u.jobWorks || 0),
      nx ? kv('الرتبة الجاية', `${nx.name} بعد ${nx.at - (u.jobWorks || 0)} شغل`) : kv('الرتبة', 'وصلت للقمة 👑'),
    ]))
  }, { sec: SEC, d: 'وظيفتك ورتبتك' })

  cmd(['استقالة'], 'all', (e) => {
    const u = account(e)
    if (!u.job) return e.reply(`${T.info} انت من غير وظيفة أصلاً`)
    const old = u.job; u.job = ''; u.jobWorks = 0; save()
    return e.reply(`${T.ok} استقلت من وظيفة ${old}. رتبتك رجعت من الأول لو اشتغلتها تاني.`)
  }, { sec: SEC, d: 'استقالة من الوظيفة' })

  cmd(['ايداع'], 'all', (e, args) => {
    const u = account(e); const n = amount(args, u.wallet)
    if (!(n > 0) || n > u.wallet) return e.reply(`${T.err} مبلغ غير صالح (معاك ${money(u.wallet)})`)
    u.wallet -= n; u.bank += n; save()
    track(e.sender, 'deposit', n)
    return e.reply(`🏦 اتودع ${money(n)} | البنك: ${money(u.bank)}`)
  }, { sec: SEC, d: 'ايداع في البنك (أو الكل)', u: 'ايداع 500' })
  cmd(['سحب'], 'all', (e, args) => {
    const u = account(e); const n = amount(args, u.bank)
    if (!(n > 0) || n > u.bank) return e.reply(`${T.err} مبلغ غير صالح (في البنك ${money(u.bank)})`)
    u.bank -= n; u.wallet += n; save()
    return e.reply(`🏧 اتسحب ${money(n)} | المحفظة: ${money(u.wallet)}`)
  }, { sec: SEC, d: 'سحب من البنك (أو الكل)', u: 'سحب 500' })

  cmd(['حول'], 'all', (e, args) => {
    const t = getTarget(e, args)
    const n = amount(args.replace(/@\S+/g, '').replace(/\d{9,}/g, ''), 0)
    if (!t) return e.reply(`${T.info} اكتب: ${P}حول @فلان 100`)
    if (clean(t) === me(e)) return e.reply(`${T.err} مينفعش تحول لنفسك`)
    const u = account(e)
    if (!(n > 0) || n > u.wallet) return e.reply(`${T.err} مبلغ غير صالح (معاك ${money(u.wallet)})`)
    u.wallet -= n; user(t).wallet += n; save()
    return e.reply(`${T.ok} ${tag(me(e))} حوّل ${money(n)} إلى ${tag(clean(t))}`, [me(e), clean(t)])
  }, { sec: SEC, d: 'تحويل رصيد لحد', u: 'حول @ 100' })

  cmd(['اغنياء'], 'all', (e) => {
    const top = Object.entries(db.eco).filter(([, u]) => total(u) > 0).sort((a, b) => total(b[1]) - total(a[1])).slice(0, 10)
    if (!top.length) return e.reply(`${T.info} لسه محدش معاه فلوس، اكتب ${P}راتب`)
    return e.reply(panel('💎 RICHEST', top.map(([id, u], i) => `${i + 1}. ${tag(id)} — ${money(total(u))}`)), top.map(([id]) => id))
  }, { sec: SEC, d: 'أغنى 10' })

  cmd(['ثروتي'], 'all', (e) => {
    const u = account(e)
    const rank = Object.values(db.eco).filter((x) => total(x) > total(u)).length + 1
    return e.reply(panel('📊 NET WORTH', [kv('الإجمالي', money(total(u))), kv('ترتيبك', `#${rank} من ${Object.keys(db.eco).length}`)]))
  }, { sec: SEC, d: 'ثروتك وترتيبك' })

  // ── أبواب الخير والتجارة الحلال ──
  cmd(['صدقة'], 'all', (e, args) => {
    const u = account(e); const n = amount(args, u.wallet)
    if (!(n > 0) || n > u.wallet) return e.reply(`${T.info} اكتب: ${P}صدقة 100 (معاك ${money(u.wallet)})`)
    u.wallet -= n
    u.hasanat = (u.hasanat || 0) + Math.max(1, Math.floor(n / 10))
    save()
    track(e.sender, 'sadaqa')
    return e.reply(`🤲 تقبّل الله منك! تصدّقت بـ ${money(n)}\n✨ حسناتك: ${u.hasanat}\n«ما نقصت صدقة من مال»`)
  }, { sec: SEC, d: 'تصدّق بجزء من فلوسك واكسب حسنات', u: 'صدقة 100' })

  cmd(['زكاة'], 'all', (e) => {
    const u = account(e)
    if (isMainOwner(e)) return e.reply(`${T.info} رصيد مالك البوت افتراضي، الزكاة للأعضاء.`)
    const NISAB = 5000
    if (total(u) < NISAB) return e.reply(`${T.info} لسه ما بلغتش النصاب (${money(NISAB)})`)
    if (wait(u, 'zakat', 7 * 24 * 3600_000, e)) return
    const due = Math.floor(total(u) * 0.025)
    const fromWallet = Math.min(u.wallet, due)
    u.wallet -= fromWallet; u.bank -= due - fromWallet
    u.last.zakat = Date.now()
    u.hasanat = (u.hasanat || 0) + Math.floor(due / 5)
    save()
    track(e.sender, 'sadaqa')
    return e.reply(`🕌 أخرجت زكاة مالك: ${money(due)} (2.5%)\n✨ حسناتك: ${u.hasanat}\nتقبّل الله منك وبارك في مالك`)
  }, { sec: SEC, d: 'زكاة المال 2.5% (كل أسبوع، للي عدّى النصاب)' })

  cmd(['سوق'], 'all', (e, args) => {
    const u = account(e)
    u.goods ??= {}
    const hour = Math.floor(Date.now() / 3600_000)
    const m = args.trim().match(/^(شراء|بيع)\s+(.+?)\s*(\d+)?$/)
    if (!m) {
      const rows = Object.keys(GOODS).map((g) => {
        const p = priceAt(g, hour), prev = priceAt(g, hour - 1), nxt = priceAt(g, hour + 1)
        return `▸ ${g}: ${money(p)} ${p > prev ? '📈' : p < prev ? '📉' : '➖'} (الساعة الجاية ${nxt > p ? 'أغلى' : nxt < p ? 'أرخص' : 'نفسه'}) — عندك ${u.goods[g] || 0}`
      })
      return e.reply(panel('🏪 MARKET', rows, `الأسعار بتتغير كل ساعة · ${P}سوق شراء تمر 5 · ${P}سوق بيع تمر 5\nأقصى مخزون ${GOODS_CAP} من كل صنف · فرق 3% عمولة السوق`))
    }
    const g = Object.keys(GOODS).find((x) => x === m[2].trim())
    if (!g) return e.reply(`${T.err} الصنف ده مش في السوق (${Object.keys(GOODS).join('، ')})`)
    const q = Math.max(1, Math.min(parseInt(m[3]) || 1, GOODS_CAP))
    const p = priceAt(g, hour)
    if (m[1] === 'شراء') {
      if ((u.goods[g] || 0) + q > GOODS_CAP) return e.reply(`${T.warn} المخزن بيشيل ${GOODS_CAP} بس من كل صنف`)
      const cost = Math.ceil(p * q * 1.03)
      if (u.wallet < cost) return e.reply(`${T.err} محتاج ${money(cost)} ومعاك ${money(u.wallet)}`)
      u.wallet -= cost; u.goods[g] = (u.goods[g] || 0) + q; save()
      return e.reply(`${T.ok} اشتريت ${q}× ${g} بـ ${money(cost)} (سعر الوحدة ${money(p)})`)
    }
    if ((u.goods[g] || 0) < q) return e.reply(`${T.err} عندك ${u.goods[g] || 0} بس من ${g}`)
    const bonus = 1 + (has(u, 'ميزان تاجر') ? 0.05 : 0) + (u.job === 'تاجر' ? 0.05 : 0)
    const gain = Math.floor(p * q * 0.97 * bonus)
    u.goods[g] -= q; u.wallet += gain; save()
    track(e.sender, 'trade')
    return e.reply(`${T.ok} بعت ${q}× ${g} بـ ${money(gain)} (سعر الوحدة ${money(p)})`)
  }, { sec: SEC, d: 'سوق التجارة: اشتري رخيص وبيع غالي (أسعار معروفة)', u: 'سوق' })

  // ── جمع الموارد ──
  const gather = (names, key, ms, d, run) =>
    cmd(names, 'all', (e) => { const u = account(e); if (wait(u, key, ms, e)) return; const out = run(u, e); if (out) { u.last[key] = Date.now(); track(e.sender, key); save(); return e.reply(out) } }, { sec: SEC, d })
  gather(['صيد'], 'fish', 10 * 60_000, 'اصطاد سمك (كل 10 دقايق)', (u) => {
    const golden = has(u, 'سنارة ذهبية')
    const baited = use(u, 'طعم')
    const boost = (golden ? 1.8 : 1) * (baited ? 2 : 1)
    const pool = FISH.map(([n, i, w]) => [n, i, n === 'سمكة' ? w : w * boost])
    const n = rnd(1, 3) + (golden ? 2 : has(u, 'سنارة') ? 1 : 0) + (u.job === 'صياد' ? 1 : 0)
    const got = {}
    for (let i = 0; i < n; i++) { const [name] = wpick(pool); got[name] = (got[name] || 0) + 1; u.inv[name] = (u.inv[name] || 0) + 1 }
    return `🎣 صدت: ${Object.entries(got).map(([k, v]) => `${v}× ${k}`).join('، ')}${baited ? '\n🪱 استخدمت طُعم' : ''}\nبعهم بـ ${P}بيع الكل`
  })
  gather(['تعدين'], 'mine', 15 * 60_000, 'استخرج معادن (كل 15 دقيقة)', (u) => {
    const dia = has(u, 'معول الماس')
    const pool = ORES.map(([n, i, w]) => [n, i, n === 'ذهب' || n === 'الماس' ? w * (dia ? 1.8 : 1) : w])
    const n = rnd(1, 2) + (dia ? 2 : has(u, 'معول') ? 1 : 0) + (u.job === 'نجار' ? 1 : 0)
    const got = {}
    for (let i = 0; i < n; i++) { const [name] = wpick(pool); got[name] = (got[name] || 0) + 1; u.inv[name] = (u.inv[name] || 0) + 1 }
    return `⛏️ استخرجت: ${Object.entries(got).map(([k, v]) => `${v}× ${k}`).join('، ')}`
  })
  gather(['زراعة'], 'farm', 20 * 60_000, 'ازرع واحصد (محتاج بذور)', (u, e) => {
    if (!has(u, 'بذور')) { e.reply(`${T.warn} محتاج بذور! اشتري من ${P}متجر`); return null }
    u.inv['بذور']--
    const [name, icon] = CROPS[Math.floor(Math.random() * CROPS.length)]
    let n = rnd(2, 5) + (has(u, 'جرار') ? 3 : 0) + (u.job === 'فلاح' ? 2 : 0)
    const fert = use(u, 'سماد')
    if (fert) n *= 2
    u.inv[name] = (u.inv[name] || 0) + n
    return `🌱 زرعت وحصدت ${n}× ${icon} ${name}${fert ? '\n🧪 السماد ضاعف المحصول' : ''}`
  })

  cmd(['سرقة'], 'all', (e, args) => {
    const t = getTarget(e, args)
    if (!t) return e.reply(`${T.info} اكتب: ${P}سرقة @فلان`)
    if (clean(t) === me(e)) return e.reply(`${T.err} مينفعش تسرق نفسك`)
    const u = account(e), v = user(t)
    if (wait(u, 'steal', 3600_000, e)) return
    if (u.wallet < 200) return e.reply(`${T.err} لازم يبقى معاك 200 على الأقل (كفالة)`)
    if (v.wallet < 100) return e.reply(`${T.info} ${tag(clean(t))} معاه فلوس قليلة مش تستاهل`)
    if (v.shield > Date.now()) return e.reply(`🛡️ ${tag(clean(t))} عنده درع!`, [clean(t)])
    u.last.steal = Date.now()
    const fine = () => (use(u, 'قناع') ? 0 : Math.min(u.wallet, 150))
    if (use(v, 'قفل')) {
      const f = fine(); u.wallet -= f; v.wallet += f; save()
      return e.reply(`🔒 ${tag(clean(t))} كان عنده قفل واتكسر! فشلت السرقة${f ? ` ودفعت غرامة ${money(f)}` : ' (القناع حماك من الغرامة)'}`, [clean(t)])
    }
    if (Math.random() < 0.35 + (has(u, 'قفازات') ? 0.15 : 0)) {
      const n = Math.max(1, Math.floor(v.wallet * (0.1 + Math.random() * 0.15)))
      v.wallet -= n; u.wallet += n; save()
      return e.reply(`🦹 سرقت ${money(n)} من ${tag(clean(t))}!`, [clean(t)])
    }
    const f = fine()
    u.wallet -= f; v.wallet += f; save()
    return e.reply(`🚔 اتمسكت! ${f ? `دفعت غرامة ${money(f)} لـ ${tag(clean(t))}` : 'بس القناع حماك من الغرامة'}`, [clean(t)])
  }, { sec: SEC, d: 'حاول تسرق من حد (فرصة 35%)', u: 'سرقة @' })

  cmd(['مهمة'], 'all', (e) => {
    const u = account(e)
    if (wait(u, 'quest', 6 * 3600_000, e)) return
    const n = rnd(100, 250)
    u.last.quest = Date.now()
    addCoins(e.sender, n)
    track(e.sender, 'quest')
    return e.reply(`📋 ${QUESTS[Math.floor(Math.random() * QUESTS.length)]} وخدت +${money(n)}`)
  }, { sec: SEC, d: 'مهمة سريعة كل 6 ساعات' })

  // ── المهام اليومية (3 مهام جديدة كل يوم + مكافأة لو خلّصتهم كلهم) ──
  const BONUS_ALL = 500
  const missionLines = (u, q) => q.list.map((id) => {
    const m = MISSIONS.find((x) => x.id === id)
    const p = Math.min(q.prog[m.key] || 0, m.goal)
    const st = q.claimed.includes(id) ? '🏁 اتسلّمت' : p >= m.goal ? `✅ جاهزة للاستلام` : `${p}/${m.goal}`
    return `▸ ${m.text}\n   ${st} · 🎁 ${money(m.reward)}`
  })
  cmd(['مهام'], 'all', (e) => {
    const u = account(e); const q = missionsOf(e.sender)
    return e.reply(panel('📋 DAILY MISSIONS', [...missionLines(u, q), '', `🎁 مكافأة إنهاء التلاتة: ${money(BONUS_ALL)}`], `استلم جوايزك بـ ${P}استلام · المهام بتتجدد كل يوم (توقيت القاهرة)`))
  }, { sec: SEC, d: 'مهامك اليومية وتقدّمك', u: 'مهام' })
  cmd(['استلام'], 'all', (e) => {
    const u = account(e); const q = missionsOf(e.sender)
    let got = 0, n = 0
    for (const id of q.list) {
      const m = MISSIONS.find((x) => x.id === id)
      if (!q.claimed.includes(id) && (q.prog[m.key] || 0) >= m.goal) { q.claimed.push(id); got += m.reward; n++ }
    }
    if (!n) return e.reply(`${T.info} مفيش مهام جاهزة للاستلام دلوقتي. شوف ${P}مهام`)
    let bonus = 0
    if (!q.bonus && q.claimed.length === q.list.length) { q.bonus = true; bonus = BONUS_ALL }
    addCoins(e.sender, got + bonus)
    return e.reply(`${T.ok} استلمت ${n} مهمة: +${money(got)}${bonus ? `\n🎉 خلّصت كل مهام النهارده! مكافأة +${money(bonus)}` : ''}`)
  }, { sec: SEC, d: 'استلام جوايز المهام الخالصة', u: 'استلام' })

  // ── المتجر والحقيبة ──
  const priceOf = (e, item) => Math.round(SHOP[item].price * (user(e.sender).job === 'تاجر' ? 0.9 : 1))
  cmd(['متجر'], 'all', (e) => {
    const cats = [...new Set(Object.values(SHOP).map((x) => x.cat))]
    const lines = []
    for (const cat of cats) {
      lines.push(`*${cat}*`)
      for (const [n, x] of Object.entries(SHOP)) if (x.cat === cat) lines.push(`▸ ${n}: ${money(priceOf(e, n))} — ${x.d}`)
      lines.push('')
    }
    return e.reply(panel('🛒 SHOP', lines.slice(0, -1), `${P}شراء سنارة · ${P}شراء بذور 5`))
  }, { sec: SEC, d: 'قايمة المتجر (أدوات، حماية، مستهلكات)' })
  cmd(['شراء'], 'all', (e, args) => {
    const m = args.trim().match(/^(.+?)\s*(\d+)?$/)
    const item = m && Object.keys(SHOP).find((k) => k === m[1].trim())
    if (!item) return e.reply(`${T.info} اكتب: ${P}شراء سنارة (شوف ${P}متجر)`)
    const u = account(e)
    const permanent = ['سنارة', 'سنارة ذهبية', 'معول', 'معول الماس', 'جرار', 'ساعة ذكية', 'بنك ذهبي', 'قفازات', 'ميزان تاجر'].includes(item)
    let q = Math.min(Math.max(parseInt(m[2]) || 1, 1), 99)
    if (permanent) { if (has(u, item)) return e.reply(`${T.info} عندك ${item} بالفعل`); q = 1 }
    const cost = priceOf(e, item) * q
    if (u.wallet < cost) return e.reply(`${T.err} محتاج ${money(cost)} ومعاك ${money(u.wallet)}`)
    u.wallet -= cost
    if (item === 'درع' || item === 'درع قوي') {
      const hrs = (item === 'درع' ? 24 : 72) * (u.job === 'طبيب' ? 2 : 1)
      u.shield = Math.max(u.shield || 0, Date.now()) + hrs * 3600_000
    } else u.inv[item] = (u.inv[item] || 0) + q
    save()
    track(e.sender, 'buy')
    return e.reply(`${T.ok} اشتريت ${q}× ${item} بـ ${money(cost)}`)
  }, { sec: SEC, d: 'اشتري من المتجر', u: 'شراء سنارة' })
  cmd(['بيع'], 'all', (e, args) => {
    const u = account(e)
    const a = args.trim()
    const sellable = Object.keys(VALUE).filter((k) => u.inv[k] > 0)
    if (!a) return e.reply(`${T.info} اكتب: ${P}بيع الكل أو ${P}بيع سمكة 2`)
    const unit = (k) => {
      let mult = 1
      if (u.job === 'طباخ' && FOOD.has(k)) mult += 0.15
      if (u.job === 'تاجر') mult += 0.1
      return Math.round(VALUE[k] * mult)
    }
    let earned = 0
    const parts = []
    if (/^(الكل|all)$/i.test(a)) for (const k of sellable) { earned += u.inv[k] * unit(k); parts.push(`${u.inv[k]}× ${k}`); u.inv[k] = 0 }
    else {
      const m = a.match(/^(.+?)\s*(\d+)?$/)
      const k = sellable.find((x) => x === m[1].trim())
      if (!k) return e.reply(`${T.err} مفيش معاك "${m[1]}" للبيع`)
      const q = Math.min(parseInt(m[2]) || 1, u.inv[k])
      earned = q * unit(k); parts.push(`${q}× ${k}`); u.inv[k] -= q
    }
    if (!earned) return e.reply(`${T.info} مفيش حاجة تتباع`)
    u.wallet += earned; save()
    track(e.sender, 'sold', earned)
    return e.reply(`${T.ok} بعت ${parts.join('، ')} بـ ${money(earned)}`)
  }, { sec: SEC, d: 'بيع حاجتك (أو الكل)', u: 'بيع الكل' })
  cmd(['شنطة'], 'all', (e) => {
    const u = account(e)
    const items = Object.entries(u.inv).filter(([, n]) => n > 0)
    const extra = []
    if (u.shield > Date.now()) extra.push(`🛡️ درع لحد ${fmtMs(u.shield - Date.now())}`)
    for (const [g, n] of Object.entries(u.goods || {})) if (n > 0) extra.push(`🏪 بضاعة: ${g} × ${n}`)
    return e.reply(panel('🎒 INVENTORY', [...(items.length ? items.map(([k, n]) => `▸ ${k}: ${n}`) : ['فاضية']), ...extra]))
  }, { sec: SEC, d: 'حاجتك' })

  // ── المستويات (لكل جروب) ──
  cmd(['مستوى'], 'all', (e, args) => {
    const t = clean(getTarget(e, args) || e.sender)
    const x = db.xp[e.jid]?.[t]
    if (!x) return e.reply(`${T.info} لسه مفيش نشاط مسجّل`)
    const lvl = levelOf(x.xp), cur = lvl * lvl * 100, nxt = (lvl + 1) ** 2 * 100
    return e.reply(panel('⭐ LEVEL', [kv('العضو', tag(t)), kv('المستوى', lvl), kv('الخبرة', `${x.xp} / ${nxt}`), bar(x.xp - cur, nxt - cur), kv('الرسايل', x.msgs)]), [t])
  }, { sec: SEC, d: 'مستواك أو مستوى حد في الجروب', u: 'مستوى @' })
  cmd(['ترتيب'], 'all', (e) => {
    const g = db.xp[e.jid] || {}
    const top = Object.entries(g).sort((a, b) => b[1].xp - a[1].xp).slice(0, 10)
    if (!top.length) return e.reply(`${T.info} لسه مفيش نشاط`)
    return e.reply(panel('🏅 TOP ACTIVE', top.map(([id, x], i) => `${i + 1}. ${tag(id)} — م${levelOf(x.xp)} · ${x.msgs} رسالة`)), top.map(([id]) => id))
  }, { sec: SEC, group: true, d: 'أنشط الأعضاء في الجروب' })

  // ── للمالك ──
  cmd(['هدية رصيد'], 'owner', (e, args) => {
    const t = getTarget(e, args)
    const n = parseInt(args.replace(/@\S+/g, '').replace(/\d{9,}/g, '').trim())
    if (!t || !(n > 0)) return e.reply(`${T.info} اكتب: ${P}هدية رصيد @فلان 1000`)
    addCoins(t, n)
    return e.reply(`${T.ok} اتضاف ${money(n)} لـ ${tag(clean(t))}`, [clean(t)])
  }, { sec: SEC, d: 'إضافة رصيد لحد (للمالك)', u: 'هدية رصيد @ 1000' })
  cmd(['تصفير رصيد'], 'owner', (e, args) => {
    const t = getTarget(e, args)
    if (!t) return e.reply(`${T.info} اكتب: ${P}تصفير رصيد @فلان`)
    delete db.eco[clean(t)]; save()
    return e.reply(`${T.ok} اتصفّر حساب ${tag(clean(t))}`, [clean(t)])
  }, { sec: SEC, d: 'تصفير حساب (للمالك)', u: 'تصفير رصيد @' })
}
