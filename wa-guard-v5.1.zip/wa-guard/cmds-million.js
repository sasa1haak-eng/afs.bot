// ═══════════ لعبة «من سيربح المليون» ═══════════
import {
  LADDER, SAFE, LETTERS, LIFELINES, newGame, answer, parseChoice, fifty, poll, phone, swap,
  prizeOnWrong, prizeOnWithdraw,
} from './million.js'
import { user, addCoins, addPts, money, cooldownLeft, fmtMs, track } from './eco.js'

const COOLDOWN = 15 * 60_000 // استراحة بين لعبتين
const IDLE = 10 * 60_000 // لو سبت اللعبة من غير ما ترد، بتتحسب انسحاب
const FRIENDS = ['كريم', 'سلمى', 'عمرو', 'منى', 'ياسر', 'هالة', 'مصطفى']
const pick = (a) => a[Math.floor(Math.random() * a.length)]

export function register(c) {
  const { cmd, P, T, panel, kv, tag, clean, save } = c
  const SEC = 'games'
  const games = new Map() // "الشات|اللاعب" → حالة اللعبة
  const keyOf = (e) => `${e.jid}|${clean(e.sender)}`
  const me = (e) => clean(e.sender)

  const helpsLine = (g, e) => {
    const jokers = user(e.sender).inv['جوكر'] || 0
    return `🆘 ${Object.entries(LIFELINES).map(([k, n]) => `${g.used[k] ? '❌' : '✅'} ${n}`).join(' · ')}${jokers ? `\n🃏 جوكر معاك: ${jokers} (يعيد أي مساعدة)` : ''}`
  }

  const view = (g, e, head = []) => {
    const q = g.cur
    const guaranteed = g.lvl > SAFE[1] ? LADDER[SAFE[1] - 1] : g.lvl > SAFE[0] ? LADDER[SAFE[0] - 1] : 0
    return panel('💰 WHO WANTS TO BE A MILLIONAIRE', [
      ...head,
      kv('اللاعب', tag(me(e))),
      kv('السؤال', `${g.lvl} من ${LADDER.length} — بـ ${money(LADDER[g.lvl - 1])}`),
      kv('مضمون ليك', money(guaranteed)),
      '',
      `❓ ${q.q}`,
      '',
      ...q.opts.map((o, i) => (g.removed.includes(i) ? `${LETTERS[i]}) ➖` : `${LETTERS[i]}) ${o}`)),
      '',
      helpsLine(g, e),
    ], `${P}مليون أ/ب/ج/د · ${P}انسحاب · ${P}مليون سلم`)
  }

  const arm = (k, g, e) => {
    clearTimeout(g.timer)
    g.timer = setTimeout(async () => {
      if (games.get(k) !== g) return
      const prize = prizeOnWithdraw(g.lvl)
      finish(k, g, e, prize)
      try { await e.sock.sendMessage(e.jid, { text: `${T.time} ${tag(me(e))} سبت اللعبة مفتوحة فاتحسبت انسحاب.\n💰 خدت ${money(prize)}`, mentions: [me(e)] }) } catch {}
    }, IDLE)
  }
  const finish = (k, g, e, prize, win = false) => {
    clearTimeout(g.timer)
    games.delete(k)
    const u = user(e.sender)
    u.last.million = Date.now()
    u.milSeen = g.seen.slice(-150)
    if (prize > 0) addCoins(e.sender, prize)
    addPts(e.sender, win ? 100 : Math.max(0, g.lvl - 1) * 2, win)
    if (win) track(e.sender, 'win')
    save()
  }
  const lifeline = (kind, run) => async (e) => {
    const k = keyOf(e), g = games.get(k)
    if (!g) return e.reply(`${T.info} مفيش لعبة شغالة ليك. ابدأ بـ ${P}مليون`)
    if (g.used[kind]) {
      const u = user(e.sender)
      if (!(u.inv['جوكر'] > 0)) return e.reply(`${T.warn} استخدمت «${LIFELINES[kind]}» قبل كده`)
      u.inv['جوكر']--
      await e.reply('🃏 استخدمت جوكر وأعدت المساعدة!')
    }
    g.used[kind] = true
    g.last = Date.now()
    arm(k, g, e)
    return run(e, g)
  }

  cmd(['مليون'], 'all', async (e, args) => {
    const k = keyOf(e)
    const a = args.trim()
    let g = games.get(k)

    if (/^(سلم|جوائز|الجوائز)$/.test(a)) {
      return e.reply(panel('🏆 LADDER', [...LADDER].map((v, i) => `${i + 1 === g?.lvl ? '👉' : '  '} ${String(i + 1).padStart(2)}) ${money(v)}${SAFE.includes(i + 1) ? ' 🛡️' : ''}${i + 1 === LADDER.length ? ' 👑' : ''}`).reverse(), '🛡️ = مستوى أمان: لو غلطت بعده بترجع له'))
    }
    if (/^(مساعدة|شرح|help)$/.test(a)) {
      return e.reply(panel('📖 HOW TO PLAY', [
        '15 سؤال من السهل للصعب، وكل سؤال له جايزة.',
        `الجايزة الكبرى: ${money(LADDER[LADDER.length - 1])}`,
        `🛡️ مستويات الأمان: السؤال ${SAFE[0]} (${money(LADDER[SAFE[0] - 1])}) و ${SAFE[1]} (${money(LADDER[SAFE[1] - 1])})`,
        `✍️ جاوب: ${P}مليون أ / ب / ج / د`,
        `🏃 انسحب في أي وقت واخد اللي كسبته: ${P}انسحاب`,
        `🆘 ${P}حذف اجابتين · ${P}سؤال الجمهور · ${P}الاتصال بصديق · ${P}تبديل السؤال`,
        '(كل مساعدة مرة واحدة، والجوكر من المتجر يعيدها)',
      ]))
    }
    if (/^(انسحاب|انسحب)$/.test(a)) return withdraw(e)

    if (a) {
      if (!g) return e.reply(`${T.info} مفيش لعبة شغالة ليك. ابدأ بـ ${P}مليون`)
      const idx = parseChoice(a)
      if (idx < 0) return e.reply(`${T.info} اكتب: ${P}مليون أ أو ب أو ج أو د`)
      const r = answer(g, idx)
      if (r.result === 'removed') return e.reply(`${T.warn} الاختيار ده اتحذف! اختار من الباقي.`)
      if (r.result === 'wrong') {
        const right = `${LETTERS[r.correct]}) ${g.cur.opts[r.correct]}`
        finish(k, g, e, r.prize)
        return e.reply(`❌ إجابة خاطئة يا ${tag(me(e))}!\nالإجابة الصح: *${right}*\n💰 خدت ${money(r.prize)}${r.prize ? ' (من مستوى الأمان)' : ''}\nاللعبة خلصت. ابدأ تاني بعد ${fmtMs(COOLDOWN)} بـ ${P}مليون`, [me(e)])
      }
      if (r.result === 'win') {
        finish(k, g, e, r.prize, true)
        return e.reply(`🎉🎉 *مبروك يا ${tag(me(e))}! كسبت المليون!* 🎉🎉\n💰 الجايزة: ${money(r.prize)}\n👑 +100 نقطة`, [me(e)])
      }
      // صح وكمّل
      track(e.sender, 'million_q')
      arm(k, g, e)
      const head = [`✅ إجابة صحيحة!${r.safe ? ` 🛡️ ضمنت ${money(r.safe)}` : ''}`, kv('لو انسحبت دلوقتي', money(prizeOnWithdraw(g.lvl))), '']
      return e.reply(view(g, e, head), [me(e)])
    }

    // بدون وسيط: ابدأ أو اعرض السؤال الحالي
    if (g) { arm(k, g, e); return e.reply(view(g, e), [me(e)]) }
    const u = user(e.sender)
    if (!e.isOwner) {
      const left = cooldownLeft(u, 'million', COOLDOWN)
      if (left) return e.reply(`${T.warn} استنى ${fmtMs(left)} قبل ما تلعب «مليون» تاني`)
    }
    g = newGame(u.milSeen || [])
    g.sock = e.sock
    games.set(k, g)
    arm(k, g, e)
    return e.reply(view(g, e, ['🎬 اللعبة بدأت! 15 سؤال والجايزة الكبرى ' + money(LADDER[LADDER.length - 1]), '']), [me(e)])
  }, { sec: SEC, d: 'من سيربح المليون (15 سؤال و4 مساعدات)', u: 'مليون' })

  const withdraw = async (e) => {
    const k = keyOf(e), g = games.get(k)
    if (!g) return e.reply(`${T.info} مفيش لعبة «مليون» شغالة ليك`)
    const prize = prizeOnWithdraw(g.lvl)
    const right = `${LETTERS[g.cur.ok]}) ${g.cur.opts[g.cur.ok]}`
    finish(k, g, e, prize)
    return e.reply(`🏃 ${tag(me(e))} انسحب بذكاء!\n💰 خد ${money(prize)}\n(الإجابة الصح كانت: ${right})`, [me(e)])
  }
  cmd(['انسحاب'], 'all', withdraw, { sec: SEC, d: 'انسحب من «مليون» واخد اللي كسبته' })

  cmd(['حذف اجابتين', 'حذف إجابتين'], 'all', lifeline('fifty', (e, g) => {
    fifty(g)
    return e.reply(view(g, e, ['✂️ اتحذفت إجابتين غلط!', '']), [me(e)])
  }), { sec: SEC, d: '«مليون»: يحذف إجابتين غلط' })

  cmd(['سؤال الجمهور'], 'all', lifeline('poll', (e, g) => {
    const rows = poll(g).map(({ i, pct }) => `${LETTERS[i]}) ${'▓'.repeat(Math.round(pct / 10)).padEnd(10, '░')} ${pct}%`)
    return e.reply(panel('👥 AUDIENCE POLL', ['الجمهور صوّت:', ...rows], `${P}مليون أ/ب/ج/د`))
  }), { sec: SEC, d: '«مليون»: الجمهور يصوّت (البوت بيجاوب)' })

  cmd(['الاتصال بصديق', 'اتصال بصديق'], 'all', lifeline('phone', (e, g) => {
    const f = phone(g)
    const ans = `${LETTERS[f.i]}) ${g.cur.opts[f.i]}`
    const who = pick(FRIENDS)
    const say = f.knows
      ? f.sure ? `أنا متأكد تقريباً إن الإجابة *${ans}*` : `أعتقد إنها *${ans}*… بس مش متأكد 100%`
      : `والله مش عارف… لو هخمّن هقول *${ans}*`
    return e.reply(`📞 اتصلت بصديقك *${who}*:\n💬 «${say}»`)
  }), { sec: SEC, d: '«مليون»: تتصل بصديق (البوت بيجاوب)' })

  cmd(['تبديل السؤال', 'تغيير السؤال'], 'all', lifeline('swap', (e, g) => {
    swap(g)
    return e.reply(view(g, e, ['🔄 اتبدّل السؤال بسؤال جديد بنفس الصعوبة', '']), [me(e)])
  }), { sec: SEC, d: '«مليون»: يبدّل السؤال بسؤال تاني' })
}
