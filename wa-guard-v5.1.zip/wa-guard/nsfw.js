// كشف الصور والملصقات الخادشة (نموذج NSFWJS بيشتغل أوفلاين جوه Node)
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { CONFIG } from './lib.js'

const sh = promisify(execFile)
let tf, model, loading
let chain = Promise.resolve()
let pending = 0

export async function getModel() {
  if (model) return { tf, model }
  loading ??= (async () => {
    const saved = [console.log, console.info, console.warn]
    console.log = console.info = console.warn = () => {}
    try {
      tf = await import('@tensorflow/tfjs')
      const nsfw = await import('nsfwjs')
      model = await nsfw.load('MobileNetV2')
    } finally {
      ;[console.log, console.info, console.warn] = saved
    }
  })().catch((e) => {
    loading = null
    throw new Error('مكتبات الكشف مش متثبتة: npm i nsfwjs @tensorflow/tfjs  (' + e.message + ')')
  })
  await loading
  return { tf, model }
}

// تشغيل واحدة ورا التانية (الكشف بطيء)، ولو الطابور زحمة بنرفض الجديد
export function enqueue(fn) {
  if (pending >= 8) return Promise.reject(new Error('طابور الكشف مزدحم'))
  pending++
  const p = chain.then(fn).finally(() => pending--)
  chain = p.catch(() => {})
  return p
}

export async function classify(buf, threshold = 0.6) {
  const { tf, model } = await getModel()
  const { createCanvas, loadImage } = await import('@napi-rs/canvas')
  const img = await loadImage(buf)
  const cv = createCanvas(224, 224)
  const ctx = cv.getContext('2d')
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, 224, 224)
  ctx.drawImage(img, 0, 0, 224, 224)
  const { data } = ctx.getImageData(0, 0, 224, 224)
  const rgb = new Int32Array(224 * 224 * 3)
  for (let i = 0, j = 0; i < data.length; i += 4) {
    rgb[j++] = data[i]
    rgb[j++] = data[i + 1]
    rgb[j++] = data[i + 2]
  }
  const t = tf.tensor3d(rgb, [224, 224, 3], 'int32')
  let out
  try {
    out = await model.classify(t)
  } finally {
    t.dispose()
  }
  const p = Object.fromEntries(out.map((x) => [x.className, x.probability]))
  const score = (p.Porn || 0) + (p.Hentai || 0) + (p.Sexy || 0) * 0.5
  return { flagged: score >= threshold, p, score }
}

// ═══════════════ الملصقات المتحركة والفيديو ═══════════════
// بنسحب 4 إطارات موزعة على الملصق المتحرك ونفحص كل واحد
async function webpFrames(buf, n = 4) {
  const { default: webp } = await import('node-webpmux')
  const img = new webp.Image()
  await img.load(buf)
  if (!img.hasAnim || !img.frames?.length) return [buf]
  const total = img.frames.length
  const cnt = Math.min(n, total)
  const idx = [...new Set(Array.from({ length: cnt }, (_, i) => Math.floor((i * (total - 1)) / Math.max(1, cnt - 1))))]
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wfr-'))
  try {
    await img.demux({ path: dir, prefix: 'f' })
    return idx.map((i) => fs.readFileSync(path.join(dir, `f_${i}.webp`)))
  } finally {
    fs.rmSync(dir, { recursive: true, force: true })
  }
}

async function videoFrames(buf) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vfr-'))
  try {
    fs.writeFileSync(path.join(dir, 'in.mp4'), buf)
    await sh(
      CONFIG.FFMPEG,
      ['-y', '-i', path.join(dir, 'in.mp4'),
       '-vf', 'fps=1,scale=224:224:force_original_aspect_ratio=increase,crop=224:224',
       '-frames:v', '4', path.join(dir, 'f%d.png')],
      { timeout: 40_000, windowsHide: true }
    )
    return fs.readdirSync(dir).filter((f) => f.endsWith('.png')).sort().map((f) => fs.readFileSync(path.join(dir, f)))
  } finally {
    fs.rmSync(dir, { recursive: true, force: true })
  }
}

// kind: 'image' | 'sticker' | 'animated' | 'video'
export async function classifyMedia(buf, kind, threshold = 0.6) {
  const frames =
    kind === 'video' ? await videoFrames(buf)
    : kind === 'animated' ? await webpFrames(buf)
    : [buf]
  let best = null
  for (const f of frames) {
    const r = await classify(f, threshold)
    if (!best || r.score > best.score) best = r
    if (r.flagged) break
  }
  if (!best) throw new Error('مقدرتش أقرأ الملف')
  return { ...best, frames: frames.length }
}
