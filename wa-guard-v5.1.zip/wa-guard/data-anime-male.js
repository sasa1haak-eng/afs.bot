// شخصيات أنمي (ولد/رجل): "# اسم الأنمي" ثم سطر لكل شخصية: الاسم بالعربي (بدائل بـ /)|الاسم بالإنجليزي
export const MALE_RAW = `
# One Piece
مونكي دي لوفي/لوفي|Monkey D. Luffy
رورونوا زورو/زورو|Roronoa Zoro
سانجي|Sanji
أوسوب|Usopp
فرانكي|Franky
بروك|Brook
جينبي|Jinbe
بورتغاس دي إيس/إيس|Portgas D. Ace
سابو|Sabo
شانكس|Shanks
دراكول ميهوك/ميهوك|Dracule Mihawk
ترافالغار لو/لو|Trafalgar Law
يوستاس كيد/كيد|Eustass Kid
إدوارد نيوغيت/وايت بيرد|Edward Newgate
كايدو|Kaido
شارلوت كاتاكوري/كاتاكوري|Charlotte Katakuri
ماركو|Marco
بلاكبيرد/ماركوس دي تيتش|Marshall D. Teach
غول دي روجر/روجر|Gol D. Roger
مونكي دي غارب/غارب|Monkey D. Garp
سموكر|Smoker
أكاينو/ساكازوكي|Sakazuki
أوكيجي/كوزان|Kuzan
كيزارو/بورسالينو|Borsalino
روب لوتشي/لوتشي|Rob Lucci
كروكودايل|Crocodile
دونكيشوت دوفلامينغو/دوفلامينغو|Donquixote Doflamingo
باغي|Buggy
أرلونغ|Arlong
إينيل|Enel
بارثولوميو كوما/كوما|Bartholomew Kuma
كوبي|Koby
هيلميبو|Helmeppo
دراغون|Monkey D. Dragon
غيكو موريا/موريا|Gecko Moria
بون كراي|Bon Clay
كافنديش|Cavendish
بارتولو|Bartolomeo
ريلي/سيلفرز ريلي|Silvers Rayleigh
زيف|Zeff
كورو|Kuro
دون كريج|Don Krieg
كينيمون|Kin'emon
كان جوروو|Kanjuro
# Naruto
ناروتو أوزوماكي/ناروتو|Naruto Uzumaki
ساسكي أوتشيها/ساسكي|Sasuke Uchiha
كاكاشي هاتاكي/كاكاشي|Kakashi Hatake
إيتاتشي أوتشيها/إيتاتشي|Itachi Uchiha
جيرايا|Jiraiya
ميناتو نامكازي/ميناتو|Minato Namikaze
أوروتشيمارو|Orochimaru
مادارا أوتشيها/مادارا|Madara Uchiha
أوبيتو أوتشيها/أوبيتو|Obito Uchiha
هاشيراما سينجو/هاشيراما|Hashirama Senju
توبيراما سينجو/توبيراما|Tobirama Senju
ناغاتو/بين|Nagato
غارا/جارا|Gaara
روك لي|Rock Lee
نيجي هيوغا/نيجي|Neji Hyuga
شيكامارو نارا/شيكامارو|Shikamaru Nara
تشوجي أكيميتشي/تشوجي|Choji Akimichi
كيبا إينوزوكا/كيبا|Kiba Inuzuka
شينو أبورامي/شينو|Shino Aburame
مايت غاي/غاي|Might Guy
أسوما ساروتوبي/أسوما|Asuma Sarutobi
زابوزا|Zabuza Momochi
هاكو|Haku
كابوتو|Kabuto Yakushi
ديدارا|Deidara
ساسوري|Sasori
كيساميه/كيسامي|Kisame Hoshigaki
هيدان|Hidan
كاكازو|Kakuzu
كيلر بي|Killer B
ساي|Sai
ياماتو|Yamato
إيروكا|Iruka Umino
هيروزن ساروتوبي/الهوكاجي الثالث|Hiruzen Sarutobi
دانزو|Danzo Shimura
كاوكي/كاواكي|Kawaki
إيزومو|Izumo Kamizuki
راسا|Rasa
كانكورو|Kankuro
أوتاكاتا|Utakata
# Dragon Ball
سون غوكو/غوكو/جوكو|Son Goku
فيجيتا/فيجيتا|Vegeta
سون غوهان/غوهان|Son Gohan
بيكولو|Piccolo
كرلين|Krillin
ترانكس/ترنكس|Trunks
غوتن|Goten
فريزا|Frieza
سيل|Cell
ماجن بو|Majin Buu
السيد روشي/ماستر روشي|Master Roshi
يامشا|Yamcha
تين شين هان|Tien Shinhan
تشاوتزو|Chiaotzu
بيرس/بيروس|Beerus
ويس|Whis
بروللي|Broly
هيت|Hit
جيرين|Jiren
أندرويد 17|Android 17
أندرويد 16|Android 16
رادتز|Raditz
ناباب|Nappa
دكتور غيرو|Dr. Gero
ميستر ساتان/ساتان|Mr. Satan
كولر|Cooler
زاماسو|Zamasu
غوغيتا|Gogeta
فيجيتو|Vegito
باردوك|Bardock
دندي|Dende
أوب|Uub
غوكو بلاك|Goku Black
غوتنكس|Gotenks
الملك كولد/كينغ كولد|King Cold
# Bleach
إيتشيغو كوروساكي/إيتشيغو|Ichigo Kurosaki
رينجي أباراي/رينجي|Renji Abarai
بياكويا كوتشيكي/بياكويا|Byakuya Kuchiki
كينباتشي زاراكي/كينباتشي|Kenpachi Zaraki
توشيرو هيتسوغايا/توشيرو|Toshiro Hitsugaya
سوسكي آيزن/آيزن|Sosuke Aizen
جين إيتشيمارو/جين|Gin Ichimaru
كاناميه توسن|Kaname Tosen
كيسكي أوراهارا/أوراهارا|Kisuke Urahara
أوريو إيشيدا/أوريو|Uryu Ishida
ياسوتورا ساادو/تشاد|Yasutora Sado
أولكويورا شيفر/أولكويورا|Ulquiorra Cifer
غريميو جاغرجاك/غريميو|Grimmjow Jaegerjaquez
ستارك|Coyote Starrk
ماويو كوروتسوتشي/ماويو|Mayuri Kurotsuchi
شونسوي كيوراكو|Shunsui Kyoraku
جوشيرو أوكيتاكي|Jushiro Ukitake
غينريوساي ياماموتو/ياماموتو|Genryusai Yamamoto
إيشين كوروساكي/إيشين|Isshin Kurosaki
إيكاكو مادارامي/إيكاكو|Ikkaku Madarame
يوميتشيكا|Yumichika Ayasegawa
نوتورا|Nnoitra Gilga
بارجان|Baraggan Louisenbairn
# Attack on Titan
إيرين ييغر/إرين|Eren Yeager
ليفاي أكرمان/ليفاي|Levi Ackerman
أرمين أرلرت/أرمين|Armin Arlert
رايز بريماون/راينر|Reiner Braun
برتولت|Bertholdt Hoover
جان كيرشتاين/جين|Jean Kirstein
كوني سبرينغر/كوني|Connie Springer
إروين سميث/إروين|Erwin Smith
زيك ييغر/زيك|Zeke Yeager
بوركو غالياد/بوركو|Porco Galliard
ماركو بوت|Marco Bott
فلوك|Floch Forster
كيني أكرمان/كيني|Kenny Ackerman
غريشا ييغر/غريشا|Grisha Yeager
هانيس|Hannes
بيكسيس|Dot Pixis
مايك زاكاريوس|Mike Zacharias
إلد جين|Eld Jinn
# Demon Slayer
تانجيرو كامادو/تانجيرو|Tanjiro Kamado
زينيتسو أغاتسوما/زينيتسو|Zenitsu Agatsuma
إينوسكي هاشيبيرا/إينوسكي|Inosuke Hashibira
جيو توميوكا/جيو|Giyu Tomioka
كيوجورو رينغوكو/رينغوكو|Kyojuro Rengoku
تينجين أوزوي/تينجين|Tengen Uzui
موتشيرو توكيتو/موتشيرو|Muichiro Tokito
غيوميه هيميجيما/غيومي|Gyomei Himejima
سانيمي شينازوغاوا/سانيمي|Sanemi Shinazugawa
أوباني إيغورو/أوباني|Obanai Iguro
موزان كيبوتسوجي/موزان|Muzan Kibutsuji
أكازا|Akaza
دوما|Douma
كوكوشيبو|Kokushibo
كايغاكو|Kaigaku
غينيا شينازوغاوا/غينيا|Genya Shinazugawa
ساكونجي أوروكوداكي/أوروكوداكي|Sakonji Urokodaki
سابيتو|Sabito
غيوتارو|Gyutaro
شينجورو رينغوكو|Shinjuro Rengoku
كاغايا أوبوياشيكي/كاغايا|Kagaya Ubuyashiki
# Jujutsu Kaisen
يوجي إيتادوري/يوجي|Yuji Itadori
ميغومي فوشيغورو/ميغومي|Megumi Fushiguro
ساتورو غوجو/غوجو|Satoru Gojo
سوكونا|Ryomen Sukuna
كينتو ناناميي/ناناميي|Kento Nanami
يوتا أوكوتسو/يوتا|Yuta Okkotsu
توجي فوشيغورو/توجي|Toji Fushiguro
سوغورو غيتو/غيتو|Suguru Geto
توجي إيناماكي/توغي|Toge Inumaki
باندا|Panda
كينجي هاكاري/هاكاري|Kinji Hakari
ناويا زينين|Naoya Zenin
ماهيتو|Mahito
جوغو|Jogo
هاناومي|Hanami
تشوسو|Choso
كينجاكو|Kenjaku
آوي تودو/تودو|Aoi Todo
ماساميتشي ياغا|Masamichi Yaga
جونبي يوشينو|Junpei Yoshino
كوكيتشي موتا/ميكامارو|Kokichi Muta
# My Hero Academia
إيزوكو ميدوريا/ديكو|Izuku Midoriya
كاتسوكي باكوغو/باكوغو|Katsuki Bakugo
شوتو تودوروكي/تودوروكي|Shoto Todoroki
أول مايت|All Might
إندفور/إنديفور|Endeavor
إريزر هيد/آيزاوا|Shota Aizawa
هوكس|Hawks
دابي|Dabi
تومورا شيغاراكي/شيغاراكي|Tomura Shigaraki
أول فور وان|All For One
ستين|Stain
أوفرهول|Overhaul
تينيا إيدا/إيدا|Tenya Iida
إيجيرو كيريشيما/كيريشيما|Eijiro Kirishima
دينكي كامينارى/كامينارى|Denki Kaminari
مينورو مينيتا/مينيتا|Minoru Mineta
فوميكاغي توكويامي/توكويامي|Fumikage Tokoyami
هيتوشي شينسو/شينسو|Hitoshi Shinso
ميريو توغاتا/ميريو|Mirio Togata
بريزنت مايك|Present Mic
غران تورينو|Gran Torino
تواىس|Twice
سبينر|Spinner
كوجي كودا|Koji Koda
ماشيرو أوجيرو/أوجيرو|Mashirao Ojiro
# Hunter x Hunter
غون فريكس/غون|Gon Freecss
كيلوا زولديك/كيلوا|Killua Zoldyck
كورابيكا|Kurapika
ليورايو|Leorio Paradinight
هيسوكا|Hisoka Morow
كرولو لوسيلفر/كرولو|Chrollo Lucilfer
إيلومي زولديك/إيلومي|Illumi Zoldyck
نيتيرو/أيزاك نيتيرو|Isaac Netero
ميرويم|Meruem
نفيربيتو|Neferpitou
فيتان|Feitan
فينكس|Phinks
نوبوناغا|Nobunaga Hazama
أوفوجين|Uvogin
سيلفا زولديك/سيلفا|Silva Zoldyck
زينو زولديك/زينو|Zeno Zoldyck
جينغ فريكس/جينغ|Ging Freecss
كايت|Kite
كنوف|Knov
موريل|Morel Mackernasey
# Fullmetal Alchemist
إدوارد إلريك/إد|Edward Elric
ألفونس إلريك/ألفونس|Alphonse Elric
روي موستانغ/موستانغ|Roy Mustang
ألكس لويس أرمسترونغ/أرمسترونغ|Alex Louis Armstrong
سكار|Scar
فان هوهنهايم|Van Hohenheim
غريد|Greed
إنفي|Envy
غلوتوني|Gluttony
كينغ برادلي|King Bradley
ماس هيوز|Maes Hughes
جين هافوك|Jean Havoc
لينغ ياو|Ling Yao
فاذر|Father
سيليم برادلي|Selim Bradley
باري ذا تشوبر|Barry the Chopper
هايمانز بريدا|Heymans Breda
# Death Note
لايت ياغامي/لايت|Light Yagami
إل/L|L Lawliet
ريوك|Ryuk
نير|Near
ميلو|Mello
تيرو ميكامي|Teru Mikami
سوئيتشيرو ياغامي|Soichiro Yagami
ماتسودا|Touta Matsuda
واتاري|Watari
# Detective Conan
شينيتشي كودو/شينيتشي|Shinichi Kudo
كوجورو موري/كوغورو|Kogoro Mouri
هيجي هاتوري/هيجي|Heiji Hattori
كايتو كيد/كيد اللص|Kaito Kid
البروفيسور أغاسا/أغاسا|Professor Agasa
جين|Gin
فودكا|Vodka
شويتشي أكاي/أكاي|Shuichi Akai
تورو أمورو/أمورو|Toru Amuro
المفتش ميغوري/ميغوري|Juzo Megure
تاكاغي|Wataru Takagi
يوساكو كودو|Yusaku Kudo
# Doraemon
دورايمون|Doraemon
ديكيسوجي|Hidetoshi Dekisugi
نوبيسوكي نوبي|Nobisuke Nobi
# Crayon Shin-chan
هيروشي نوهارا|Hiroshi Nohara
أكشن كامين|Action Kamen
شيرو|Shiro
# Pokemon
غاري أوك|Gary Oak
بروك|Brock
جيمس|James
مياو|Meowth
بيكاتشو|Pikachu
البروفيسور أوك|Professor Oak
ريد|Red
كلمونت|Clemont
سيلان|Cilan
ليون|Leon
# Digimon
أغومون|Agumon
غابومون|Gabumon
باتامون|Patamon
غومامون|Gomamon
تينتومون|Tentomon
# Dr. Stone
سينكو إيشيغامي/سينكو|Senku Ishigami
تايجو أوكي/تايجو|Taiju Oki
تسوكاسا شيشيو/تسوكاسا|Tsukasa Shishio
كروم|Chrome
جين أساغيري|Gen Asagiri
كينرو|Kinro
غينرو|Ginro
أوكيو سايونجي|Ukyo Saionji
هيوغا|Hyoga
ماغما|Magma
# Haikyu!!
شويو هيناتا/هيناتا|Shoyo Hinata
توبيو كاغيياما/كاغيياما|Tobio Kageyama
كي تسوكيشيما/تسوكيشيما|Kei Tsukishima
تاداشي ياماغوتشي/ياماغوتشي|Tadashi Yamaguchi
دايتشي ساوامورا/دايتشي|Daichi Sawamura
كويشي سوغاوارا/سوغاوارا|Koshi Sugawara
آساهي أزوماني|Asahi Azumane
ياو نيشينويا/نيشينويا|Yu Nishinoya
ريونوسكي تاناكا/تاناكا|Ryunosuke Tanaka
تورو أويكاوا/أويكاوا|Tooru Oikawa
هاجيمي إيواإيزومي/إيوايزومي|Hajime Iwaizumi
واكاتوشي أوشيجيما/أوشيجيما|Wakatoshi Ushijima
تيتسورو كوروو/كوروو|Tetsuro Kuroo
كوتارو بوكوتو/بوكوتو|Kotaro Bokuto
كيجي أكاشي|Keiji Akaashi
كينما كوزومي/كينما|Kenma Kozume
أتسومو ميايا|Atsumu Miya
أوسامو ميايا|Osamu Miya
كييومي ساكوسا|Kiyoomi Sakusa
# Slam Dunk
هاناميتشي ساكوراغي/ساكوراغي|Hanamichi Sakuragi
كايدي روكاوا/روكاوا|Kaede Rukawa
هيساشي ميتسوي/ميتسوي|Hisashi Mitsui
ريوتا ميياغي/ميياغي|Ryota Miyagi
تاكينوري أكاغي/أكاغي|Takenori Akagi
كيمينوبو كوغور|Kiminobu Kogure
أكيرا سيندوه/سيندوه|Akira Sendoh
# Kuroko no Basket
كوروكو تيتسويا/كوروكو|Tetsuya Kuroko
تايغا كاغامي/كاغامي|Taiga Kagami
دايكي أومينيه/أومينيه|Daiki Aomine
ريوتا كيسي/كيسي|Ryota Kise
شينتارو ميدوريما/ميدوريما|Shintaro Midorima
أتسوشي موراساكيبارا|Atsushi Murasakibara
سييجورو أكاشي/أكاشي|Seijuro Akashi
# Captain Tsubasa
تسوباسا أوزورا/ماجد|Tsubasa Ozora
غينزو واكاباياشي/سامي|Genzo Wakabayashi
كوجيرو هيوغا/هيوغا|Kojiro Hyuga
تارو ميساكي/ميساكي|Taro Misaki
كارل هاينز شنايدر|Karl-Heinz Schneider
# Sword Art Online
كيريتو|Kirito
كلاين|Klein
أجيل|Agil
هيثكليف|Heathcliff
يوجيو|Eugeo
# Black Clover
أستا|Asta
يونو|Yuno
يامي سوكيهيرو/يامي|Yami Sukehiro
جوليوس نوفاكرونو|Julius Novachrono
ويليام فانغيانس|William Vangeance
زورا|Zora Ideale
لاك فولتيا|Luck Voltia
ماغنا سوينغ|Magna Swing
ناخت|Nacht Faust
غوردون|Gordon Agrippa
غوش|Gauche Adlai
فينرال|Finral Roulacase
ليشت|Licht
لوسيفيرو|Lucifero
# Fairy Tail
ناتسو دراغنيل/ناتسو|Natsu Dragneel
غراي فولباستر/غراي|Gray Fullbuster
هابي|Happy
غاجيل ريدفوكس/غاجيل|Gajeel Redfox
لاكسوس دريار/لاكسوس|Laxus Dreyar
ماكاروف دريار/ماكاروف|Makarov Dreyar
جيلال فرنانديس/جيلال|Jellal Fernandes
إلفمان شتراوس/إلفمان|Elfman Strauss
جيلدارتس كلايف/جيلدارتس|Gildarts Clive
زيريف|Zeref Dragneel
أكنولوجيا|Acnologia
ستينغ يوكلف|Sting Eucliffe
روغ تشينى|Rogue Cheney
# Soul Eater
ديث ذا كيد|Death the Kid
سول إيتر إيفانز|Soul Eater Evans
بلاك ستار|Black Star
شينيغامي|Shinigami
# Black Butler
سيباستيان ميكايليس/سيباستيان|Sebastian Michaelis
غريل ساتكليف|Grell Sutcliff
# Tokyo Ghoul
كين كانيكي/كانيكي|Ken Kaneki
هيدي ناغاكي/هيدي|Hideyoshi Nagachika
يوشيمورا|Yoshimura
جوزو سوزويا/جوزو|Juzo Suzuya
# One Punch Man
سايتاما|Saitama
جينوس|Genos
موم رايدر|Mumen Rider
كينغ|King
بانغ|Bang
غاروو|Garou
سونيك|Speed-o'-Sound Sonic
بوروس|Lord Boros
ميتال بات|Metal Bat
# Mob Psycho 100
موب/شيجيو كاغياما|Shigeo Kageyama
ريجن أراتاكا/ريجن|Arataka Reigen
ديمبل|Dimple
تيروكي هانازاوا|Teruki Hanazawa
# Gintama
غينتوكي ساكاتا/غينتوكي|Gintoki Sakata
شينباتشي شيمورا|Shinpachi Shimura
توشيرو هيجيكاتا/هيجيكاتا|Toshiro Hijikata
سوغو أوكيتا/أوكيتا|Sogo Okita
إيساو كوندو/كوندو|Isao Kondo
كوتارو كاتسورا/كاتسورا|Kotaro Katsura
شينسوكي تاكاسوغي/تاكاسوغي|Shinsuke Takasugi
# JoJo's Bizarre Adventure
جوناثان جوستار|Jonathan Joestar
جوزيف جوستار|Joseph Joestar
جوتارو كوجو/جوتارو|Jotaro Kujo
جوسوكي هيغاشيكاتا/جوسوكي|Josuke Higashikata
جيورنو جوفانا/جيورنو|Giorno Giovanna
ديو براندو/ديو|Dio Brando
يوشيكاجي كيرا/كيرا|Yoshikage Kira
جان بيير بولناريف/بولناريف|Jean Pierre Polnareff
نوريكاكي كاكيوين/كاكيوين|Noriaki Kakyoin
محمد أفدول/أفدول|Muhammad Avdol
ديابولو|Diavolo
إنريكو بوتشي/بوتشي|Enrico Pucci
# Code Geass
لولوش لامبيروج/لولوش|Lelouch Lamperouge
سوزاكو كورورجي/سوزاكو|Suzaku Kururugi
شنايزل|Schneizel el Britannia
# Neon Genesis Evangelion
شينجي إيكاري/شينجي|Shinji Ikari
كاورو ناغيسا/كاورو|Kaworu Nagisa
غيندو إيكاري/غيندو|Gendo Ikari
# Cowboy Bebop
سبايك سبيغل/سبايك|Spike Spiegel
جيت بلاك|Jet Black
فيشس|Vicious
# Gurren Lagann
سيمون|Simon
كامينا|Kamina
# Steins;Gate
ريتارو أوكابي/أوكابي|Rintaro Okabe
إتارو هاشيدا/دارو|Itaru Hashida
# Fate
شيرو إيميا/شيرو|Shirou Emiya
أرتشر|Archer
جلجامش|Gilgamesh
كيريتسوغو إيميا|Kiritsugu Emiya
# Re:Zero
ناتسوكي سوبارو/سوبارو|Natsuki Subaru
بوك|Puck
روزوال|Roswaal L Mathers
راينهارد فان أستريا|Reinhard van Astrea
# Konosuba
كازوما ساتو/كازوما|Kazuma Satou
# Overlord
آينز أوول غاون/آينز|Ainz Ooal Gown
ديميورغو|Demiurge
كوسيتوس|Cocytus
# Mushoku Tensei
رودويس غريرات/رودويس|Rudeus Greyrat
# Spy x Family
لويد فورجر/لويد|Loid Forger
بوند|Bond Forger
دامیان ديزموند|Damian Desmond
# Chainsaw Man
دينجي|Denji
أكي هاياكاوا/أكي|Aki Hayakawa
بوتشيتا|Pochita
# Vinland Saga
ثورفين|Thorfinn
أسكيلاد|Askeladd
كانوت|Canute
# Berserk
غاتس|Guts
غريفيث|Griffith
# Hellsing
ألوكارد|Alucard
# Trigun
فاش ذا ستامبيد/فاش|Vash the Stampede
نيكولاس د. وولفوود|Nicholas D. Wolfwood
# Rurouni Kenshin
كينشين هيمورا/كينشين|Kenshin Himura
سانوسكي ساغارا|Sanosuke Sagara
هاجيمي سايتو/سايتو|Hajime Saito
# Yu Yu Hakusho
يوسكي أوراميشي/يوسكي|Yusuke Urameshi
كازوما كوابارا/كوابارا|Kazuma Kuwabara
هيي|Hiei
كوراما|Kurama
# Inuyasha
إينوياشا|Inuyasha
سيشومارو|Sesshomaru
ميروكو|Miroku
ناراكو|Naraku
# Ranma 1/2
رانما ساوتومي/رانما|Ranma Saotome
ريوغا هيبيكي/ريوغا|Ryoga Hibiki
# Sailor Moon
ماموروشيبا/توكسيدو ماسك|Mamoru Chiba
# Cardcaptor Sakura
كيروبيروس/كيرو|Kerberos
يوكيتو تسوكيشيرو|Yukito Tsukishiro
# Fruits Basket
كيو سوما|Kyo Sohma
يوكي سوما|Yuki Sohma
شيغيري سوما|Shigure Sohma
# Ouran High School Host Club
تاماكي سوه/تاماكي|Tamaki Suoh
كيويا أوتوري|Kyoya Ohtori
هيكارو هيتاتشيين|Hikaru Hitachiin
كاورو هيتاتشيين|Kaoru Hitachiin
# Clannad
تومويا أوكازاكي/تومويا|Tomoya Okazaki
# Toradora
ريوجي تاكاسو/ريوجي|Ryuji Takasu
يوساكو كيتامورا|Yusaku Kitamura
# Haruhi Suzumiya
كيون|Kyon
إيتسوكي كويزومي|Itsuki Koizumi
# Frieren
هيميل|Himmel
شتارك|Stark
أيزن|Eisen
هايتر|Heiter
# Kaguya-sama
ميوكي شيروغاني/ميوكي|Miyuki Shirogane
يو إيشيغامي|Yu Ishigami
# Oshi no Ko
أكوا هوشينو|Aqua Hoshino
# Blue Lock
يويتشي إيساغي/إيساغي|Yoichi Isagi
ميغورو باتشيرا|Meguru Bachira
ريو إيتوشي|Rin Itoshi
سيشيرو ناغي/ناغي|Seishiro Nagi
ريو ميكاغي|Reo Mikage
شويي باروو/باروو|Shoei Baro
# Studio Ghibli
هاول|Howl
كالسيفر|Calcifer
أشيتاكا|Ashitaka
بورکو روسو|Porco Rosso
موسكا|Muska
سوسكي|Sosuke
جيجي|Jiji
# Lupin III
لوبين الثالث/أرسين لوبين|Lupin III
دايسوكي جيغن/جيغن|Daisuke Jigen
غويمون إيشيكاوا/غويمون|Goemon Ishikawa
زينيغاتا|Koichi Zenigata
# Gundam
أمورو راي/أمورو|Amuro Ray
شار أزنابل/شار|Char Aznable
كيرا ياماتو|Kira Yamato
أثرون زالا|Athrun Zala
# Grendizer
أكتوروس/دوك فليد|Duke Fleed
كوجي كابوتو/ألكور|Koji Kabuto
# Saint Seiya
سييا|Seiya
شيريو|Shiryu
شن|Shun
إيكي|Ikki
شاكا|Shaka
# Yu-Gi-Oh
يوغي موتو/يوغي|Yugi Muto
آتيم|Atem
سيتو كايبا/كايبا|Seto Kaiba
جوي ويلر/جوي|Joey Wheeler
تريستان تيلور|Tristan Taylor
ماريك إيشتار|Marik Ishtar
باكورا|Bakura Ryou
بيغاسوس|Maximillion Pegasus
# Beyblade
تايسون غرانجر/تايسون|Tyson Granger
كاي هيوواتاري/كاي|Kai Hiwatari
راي كون|Rei Kon
ماكس تيت|Max Tate
كيني|Kenny
# Akame ga Kill
تاتسومي|Tatsumi
بولات|Bulat
لوبوك|Lubbock
ويف|Wave
# Death Parade
ديسيم|Decim
# Parasyte
شينيتشي إيزومي/شينيتشي|Shinichi Izumi
ميغي|Migi
# Psycho-Pass
شينيا كوغامي/كوغامي|Shinya Kogami
شو ماكيشيما|Shogo Makishima
نوبوتشيكا غينوزا/غينوزا|Nobuchika Ginoza
# Ghost in the Shell
باتو|Batou
# Spirited Away
# Made in Abyss
ريغ|Reg
# Dungeon Meshi
لايوس|Laios Thorden
سينشي|Senshi
تشيلتشاك|Chilchuck Tims
# Promised Neverland
# Boruto
# Dragon Quest
دايي|Dai
# Slayers
غوري غابريف/غوري|Gourry Gabriev
# Assassination Classroom
كورو سينسي|Koro-sensei
ناغيسا شيوتا|Nagisa Shiota
كارما أكابان|Karma Akabane
# Seven Deadly Sins
ميليوداس|Meliodas
بان|Ban
كينغ|Harlequin King
# Fire Force
شينرا كوساكابي/شينرا|Shinra Kusakabe
# Mashle
ماشل بورنديد/ماشل|Mash Burnedead
# Sakamoto Days
تارو ساكاموتو/ساكاموتو|Taro Sakamoto
# Solo Leveling
سونغ جين وو/جين وو|Sung Jinwoo
# Naruto Shippuden extras
شيسوي أوتشيها/شيسوي|Shisui Uchiha
# Attack on Titan extras
# Bleach extras
# Black Lagoon
روك|Rock
# Samurai Champloo
موغين|Mugen
جين|Jin
# Soul extras
سبيريت ألبارن|Spirit Albarn
# Initial D
تاكومي فوجيوارا/تاكومي|Takumi Fujiwara
# Fist of the North Star
كينشيرو|Kenshiro
راوه|Raoh
# Saiyuki
سانزو|Genjo Sanzo
# Hajime no Ippo
إيبّو ماكونوتشي/إيبّو|Ippo Makunouchi
# Ashita no Joe
جو ياباكي/جو|Joe Yabuki
# Yowamushi Pedal
أونودا ساكاميتشي|Sakamichi Onoda
# Prince of Tennis
ريوما إيتشيزن/ريوما|Ryoma Echizen
# Eyeshield 21
سينا كوباياكاوا/سينا|Sena Kobayakawa
# Naruto side
# Haikyu side
# Bleach (more)
هاناتارو يامادا|Hanataro Yamada
شوهي هيساغي|Shuhei Hisagi
شينجي هيراكو|Shinji Hirako
تيساي تسوكابيشي|Tessai Tsukabishi
ساجين كوماموورا|Sajin Komamura
إيزورو كيرا|Izuru Kira
كايين شيبا|Kaien Shiba
# Naruto (more)
شيكاكو نارا|Shikaku Nara
إينويتشي ياماناكا|Inoichi Yamanaka
هياشي هيوغا|Hiashi Hyuga
فوغاكو أوتشيها|Fugaku Uchiha
هاياتي غيتسو|Hayate Gekko
غينما شيرانوي|Genma Shiranui
إيبيكي مورينو|Ibiki Morino
كيميمارو|Kimimaro
جوغو|Jugo
سويغيتسو هوزوكي|Suigetsu Hozuki
# My Hero Academia (more)
سير نايتآي|Sir Nighteye
كوروغيري|Kurogiri
ميستر كومبريس|Mr. Compress
موسكيولار|Muscular
# One Piece (more)
سينغوكو|Sengoku
فوجيتورا|Fujitora
فوكسي|Foxy
واپول|Wapol
# Demon Slayer (more)
هانتينغو|Hantengu
إينمو|Enmu
# Hunter x Hunter (more)
وينغ|Wing
بوكل|Pokkle
هانزو|Hanzo
# Slam Dunk (more)
شينيتشي ماكي/ماكي|Shinichi Maki
كينجي فوجيما/فوجيما|Kenji Fujima
نوبوناغا كيوتا/كيوتا|Nobunaga Kiyota
`
