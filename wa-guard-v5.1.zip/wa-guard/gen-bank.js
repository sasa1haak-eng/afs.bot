// ═══════ مولّد الأسئلة من جداول الحقائق (بيتشغل مرة واحدة عند تشغيل البوت) ═══════
import { COUNTRIES } from './data-countries.js'
import { SURAHS, ELEMENTS_LIST, ELEMENTS_COMMON, CURRENCIES, CITIES_LIST, EG_GOVS_LIST, LANDMARKS_LIST } from './data-facts.js'

export const ALIAS = {
  'أمريكا': ['الولايات المتحدة', 'الولايات المتحدة الامريكية'], 'بريطانيا': ['المملكة المتحدة', 'انجلترا', 'بريطانيا العظمى'],
  'الإمارات': ['الامارات العربية المتحدة'], 'التشيك': ['تشيكيا', 'جمهورية التشيك'], 'مقدونيا الشمالية': ['مقدونيا'],
  'ساحل العاج': ['كوت ديفوار'], 'إسواتيني': ['سوازيلاند'], 'ميانمار': ['بورما'], 'جزر القمر': ['القمر'],
  'الدومينيكان': ['جمهورية الدومينيكان'], 'الكونغو': ['جمهورية الكونغو', 'الكونغو برازافيل'],
  'الكونغو الديمقراطية': ['جمهورية الكونغو الديمقراطية', 'الكونغو كينشاسا'], 'أفريقيا الوسطى': ['جمهورية افريقيا الوسطى'],
  'تيمور الشرقية': ['تيمور'], 'كوريا الجنوبية': ['كوريا'], 'الرأس الأخضر': ['كابو فيردي'], 'الفاتيكان': ['دولة الفاتيكان'],
  'البوسنة والهرسك': ['البوسنة'], 'ساو تومي وبرينسيبي': ['ساو تومي'], 'أنتيغوا وبربودا': ['انتيغوا'], 'سانت كيتس ونيفيس': ['سانت كيتس'],
  'سانت فنسنت والغرينادين': ['سانت فنسنت'], 'ترينيداد وتوباغو': ['ترينيداد'], 'جنوب أفريقيا': ['جنوب افريقيا'], 'فلسطين': ['دولة فلسطين'],
}
export const CONT_ALIAS = { 'أفريقيا': ['افريقيا'], 'أوقيانوسيا': ['استراليا', 'اوقيانوسيا'], 'أمريكا الشمالية': ['شمال امريكا'], 'أمريكا الجنوبية': ['جنوب امريكا'] }
export const TRANSCONT = { تركيا: ['أوروبا'], روسيا: ['آسيا'], كازاخستان: ['أوروبا'], أذربيجان: ['أوروبا'], جورجيا: ['أوروبا'], أرمينيا: ['أوروبا'], قبرص: ['أوروبا'], مصر: ['آسيا'] }
export const namesOf = (cn) => [cn.name, ...(ALIAS[cn.name] || [])]
export const contAnswers = (cn) => {
  const a = [cn.continent, ...(TRANSCONT[cn.name] || [])]
  return [...new Set(a.flatMap((c) => [c, ...(CONT_ALIAS[c] || [])]))]
}

const T1 = new Set('eg sa ae kw qa iq jo lb sy ly tn dz ma sd ye om bh ps tr ir us gb fr de it es ru cn jp in br ar ca au mx pt gr nl ch se kr pk id sg'.split(' '))
const T2 = new Set('so mr dj km af bd th vn my ph ua pl cz hu ro at be no dk fi ie is nz za ng ke et gh tz ug sn cm ci co pe cl ve cu bo ec uy py kz uz az ge am by rs hr bg sk si lt lv ee np lk mm kh la mn kp lu mt cy al ba'.split(' '))
const fame = (iso) => (T1.has(iso) ? 1 : T2.has(iso) ? 2 : 3)
const CUR_T1 = new Set('eg sa ae kw qa us gb jp cn in de fr it es ru tr'.split(' '))
const byIso = Object.fromEntries(COUNTRIES.map((c) => [c.iso, c]))
const shuffle = (a) => { const x = [...a]; for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]] } return x }
const pick3 = (pool, ok) => shuffle([...new Set(pool)].filter((x) => x !== ok)).slice(0, 3)
const nearNums = (n, max, min = 1) => {
  const c = []; for (let d = -4; d <= 4; d++) if (d && n + d >= min && n + d <= max) c.push(String(n + d)); return shuffle(c).slice(0, 3)
}

const mil = { 1: [], 2: [], 3: [] }
const addM = (tier, q, ok, bad) => { if (bad.length === 3 && !bad.includes(ok)) mil[tier].push({ q, ok, bad, gen: true }) }
const trivia = []
const caps = []

// ── الدول ──
for (const cn of COUNTRIES) {
  const t = fame(cn.iso)
  const sameCont = COUNTRIES.filter((x) => x.continent === cn.continent && x.iso !== cn.iso)
  addM(t, `ما عاصمة ${cn.name}؟`, cn.capital, pick3(sameCont.map((x) => x.capital), cn.capital))
  addM(t, `دي علم أنهي دولة؟ ${cn.flag}`, cn.name, pick3(sameCont.map((x) => x.name), cn.name))
  if (!TRANSCONT[cn.name]) {
    const conts = [...new Set(COUNTRIES.map((x) => x.continent))]
    addM(t === 1 ? 1 : 2, `في أي قارة تقع ${cn.name}؟`, cn.continent, pick3(conts, cn.continent))
  }
  caps.push([`علم ${cn.flag} — ما عاصمة الدولة صاحبة العلم؟`, cn.capitals])
}

// ── العملات ──
const curOf = {}
const curNames = []
for (const l of CURRENCIES.trim().split('\n')) {
  const [name, isos] = l.split('|')
  curNames.push(name)
  for (const iso of isos.split(' ')) if (byIso[iso]) curOf[iso] = name
}
for (const [iso, name] of Object.entries(curOf)) {
  const cn = byIso[iso]
  const first = name.split(' ')[0]
  const t = CUR_T1.has(iso) ? 1 : T1.has(iso) ? 2 : 3
  addM(t, `ما العملة الرسمية في ${cn.name}؟`, name, pick3(curNames, name))
  trivia.push([`ما العملة الرسمية في ${cn.name}؟`, [name, first]])
}

// ── المدن (من غير العواصم، ومن غير الأسماء الملتبسة) ──
{
  const capNames = new Set(COUNTRIES.flatMap((c) => c.capitals))
  const seen = new Map()
  for (const c of CITIES_LIST) { if (!byIso[c.iso]) continue; const s = seen.get(c.city) || new Set(); s.add(c.iso); seen.set(c.city, s) }
  const done = new Set()
  for (const c of CITIES_LIST) {
    if (!byIso[c.iso] || done.has(c.city) || capNames.has(c.city) || seen.get(c.city).size > 1) continue
    done.add(c.city)
    const cn = byIso[c.iso]
    const sameCont = COUNTRIES.filter((x) => x.continent === cn.continent && x.iso !== cn.iso)
    const f = fame(c.iso)
    const t = c.famous ? (f === 1 ? 1 : 2) : f === 1 ? 2 : 3
    addM(t, `في أي دولة تقع مدينة ${c.city}؟`, cn.name, pick3(sameCont.map((x) => x.name), cn.name))
    trivia.push([`في أي دولة تقع مدينة ${c.city}؟`, namesOf(cn)])
    caps.push([`في أي دولة تقع مدينة ${c.city}؟`, namesOf(cn)])
  }
}

// ── المعالم والجبال ──
for (const l of LANDMARKS_LIST) {
  const cn = byIso[l.iso]; if (!cn) continue
  const sameCont = COUNTRIES.filter((x) => x.continent === cn.continent && x.iso !== cn.iso)
  const f = fame(l.iso)
  const kind = /^جبل|^بركان/.test(l.name) ? 'يقع' : 'يقع'
  const q = `في أي دولة ${kind} ${/^جبل|^بركان/.test(l.name) ? '' : 'معلم '}${l.name}؟`.replace('  ', ' ')
  addM(f === 3 ? 3 : 2, q, cn.name, pick3(sameCont.map((x) => x.name), cn.name))
  trivia.push([q, namesOf(cn)])
  caps.push([q, namesOf(cn)])
}

// ── محافظات مصر ──
for (const g of EG_GOVS_LIST) {
  if (g.gov === g.cap) continue
  addM(2, `ما عاصمة محافظة ${g.gov}؟`, g.cap, pick3(EG_GOVS_LIST.map((x) => x.cap).filter((x) => x !== g.cap), g.cap))
  addM(2, `ما المحافظة التي عاصمتها ${g.cap}؟`, g.gov, pick3(EG_GOVS_LIST.map((x) => x.gov), g.gov))
  for (const arr of [trivia, caps]) {
    arr.push([`ما عاصمة محافظة ${g.gov}؟`, [g.cap]])
    arr.push([`ما المحافظة التي عاصمتها ${g.cap}؟`, [g.gov]])
  }
}

// ── سور القرآن ──
{
  const easy = new Set([1, 2, 110, 111, 112, 113, 114, 108])
  const mid = new Set([3, 4, 5, 12, 18, 19, 36, 55, 56, 67, 78, 93, 94, 95, 96, 97, 99, 100, 101, 102, 103, 104, 105, 106, 107, 109])
  SURAHS.forEach((name, i) => {
    const n = i + 1
    const t = easy.has(n) ? 1 : mid.has(n) ? 2 : 3
    addM(t, `ما ترتيب سورة ${name} في المصحف؟`, String(n), nearNums(n, 114))
    const nearNames = [-3, -2, -1, 1, 2, 3].map((d) => SURAHS[i + d]).filter(Boolean)
    addM(t, `ما اسم السورة رقم ${n} في ترتيب المصحف؟`, name, pick3(nearNames, name))
    trivia.push([`ما ترتيب سورة ${name} في المصحف؟`, [String(n)]])
    trivia.push([`ما اسم السورة رقم ${n} في ترتيب المصحف؟`, [name]])
  })
}

// ── العناصر الكيميائية ──
{
  const pool = ELEMENTS_LIST
  for (const el of pool) {
    const t = ['H', 'O'].includes(el.sym) ? 1 : ELEMENTS_COMMON.has(el.sym) ? 2 : 3
    const others = pool.filter((x) => x !== el)
    addM(t, `ما الرمز الكيميائي لعنصر ${el.name.replace(/^ال/, '')}؟`, el.sym, pick3(others.map((x) => x.sym), el.sym))
    addM(t, `ما العنصر الذي رمزه الكيميائي ${el.sym}؟`, el.name.replace(/^ال/, ''), pick3(others.map((x) => x.name.replace(/^ال/, '')), el.name.replace(/^ال/, '')))
    addM(el.n <= 20 ? 2 : 3, `ما العدد الذري لعنصر ${el.name.replace(/^ال/, '')}؟`, String(el.n), nearNums(el.n, 94))
    addM(el.n <= 20 ? 2 : 3, `ما العنصر الذي عدده الذري ${el.n}؟`, el.name.replace(/^ال/, ''), pick3(others.filter((x) => Math.abs(x.n - el.n) < 20).map((x) => x.name.replace(/^ال/, '')), el.name.replace(/^ال/, '')))
    trivia.push([`ما الرمز الكيميائي لعنصر ${el.name.replace(/^ال/, '')}؟`, [el.sym]])
    trivia.push([`ما العنصر الذي رمزه الكيميائي ${el.sym}؟`, [el.name.replace(/^ال/, '')]])
    trivia.push([`ما العدد الذري لعنصر ${el.name.replace(/^ال/, '')}؟`, [String(el.n)]])
    trivia.push([`ما العنصر الذي عدده الذري ${el.n}؟`, [el.name.replace(/^ال/, '')]])
  }
}

// ── ألغاز "من أنا؟" مولَّدة من الحقائق + كلمات للمبعثرة والمشنقة ──
const riddles = []
for (const cn of COUNTRIES) {
  const cur = curOf[cn.iso]
  riddles.push([`أنا دولة في ${cn.continent}، عاصمتي ${cn.capital}${cur ? ` وعملتي ${cur}` : ''}. من أنا؟`, namesOf(cn)])
}
for (const el of ELEMENTS_LIST) riddles.push([`أنا عنصر كيميائي عددي الذري ${el.n} ورمزي ${el.sym}. من أنا؟`, [el.name.replace(/^ال/, '')]])
SURAHS.forEach((name, i) => riddles.push([`أنا سورة قرآنية ترتيبي ${i + 1} في المصحف. من أنا؟`, [name]]))
const wordSet = new Set()
const addWord = (w) => { const x = w.replace(/^ال/, '').trim(); if (x && !/\s/.test(x) && x.length >= 3 && x.length <= 9 && !/[()]/.test(x)) wordSet.add(x) }
for (const cn of COUNTRIES) { addWord(cn.name); addWord(cn.capital) }
SURAHS.forEach(addWord)
ELEMENTS_LIST.forEach((e) => addWord(e.name))
for (const c of CITIES_LIST) addWord(c.city)

export const GEN = { million: mil, trivia, capitals: caps, riddles, words: [...wordSet] }
