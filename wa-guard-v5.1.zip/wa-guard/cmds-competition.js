// ═══════════════ نظام المسابقات ═══════════════
let schedulerPulse = null
export function pulseCompetitionScheduler(sock) { schedulerPulse?.(sock) }

export function register(c) {
  const { cmd, P, T, panel, kv, clean, tag, db, save } = c
  const SEC = 'competition'
  const CONTACTS = ['201505669304', '201205583520']
  const digits = (s = '') => String(s).replace(/\D/g, '')
  const phone = (jid = '') => {
    let d = digits(String(jid).split('@')[0].split(':')[0])
    if (d.startsWith('0') && d.length === 11) d = '20' + d.slice(1)
    return d
  }
  const manager = (e) => CONTACTS.includes(phone(e.sender || ''))
  const data = () => (db.competitions ??= { nextId: 1, items: [], weekly: { enabled: false } })
  let schedulerTimer = null
  let schedulerSock = null
  const cairoParts = (date = new Date()) => {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date)
    return Object.fromEntries(parts.map(p => [p.type, p.value]))
  }
  const cairoEpoch = (dateText, timeText) => {
    const desired = Date.parse(`${dateText}T${timeText}:00Z`)
    if (!Number.isFinite(desired)) return NaN
    let guess = desired
    for (let i = 0; i < 3; i++) {
      const p = cairoParts(new Date(guess))
      const shown = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute))
      guess += desired - shown
    }
    return guess
  }
  const weekKey = (date = new Date()) => {
    const p = cairoParts(date)
    const weekdayIndex = ({ Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 })[p.weekday] ?? 0
    const shift = (weekdayIndex - 5 + 7) % 7
    const friday = new Date(date.getTime() - shift * 86400000)
    const fp = cairoParts(friday)
    return `${fp.year}-${fp.month}-${fp.day}`
  }
  const startWeeklyIfDue = async () => {
    const store = data()
    const w = store.weekly
    if (!w?.enabled || !w.jid || !schedulerSock) return
    const now = Date.now()
    const p = cairoParts(new Date(now))
    const key = w.pendingWeekKey || weekKey(new Date(now))
    const due = w.postponedUntil ? Number(w.postponedUntil) : null
    const weekdayIndex = ({ Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 })[p.weekday] ?? 0
    const shift = (weekdayIndex - 5 + 7) % 7
    const fridayDate = new Date(now - shift * 86400000)
    const fp = cairoParts(fridayDate)
    const scheduled = cairoEpoch(`${fp.year}-${fp.month}-${fp.day}`, '14:00')
    if (due ? due > now : now < scheduled) return
    if (w.lastStartKey === key) return
    const already = store.items.find(x => x.jid === w.jid && x.weeklyKey === key)
    if (already) { w.lastStartKey = key; w.postponedUntil = null; w.pendingWeekKey = null; save(); return }
    const id = store.nextId++
    const title = w.title || 'المسابقة الأسبوعية'
    const details = w.details || 'نفّذ المطلوب وأرسل مشاركتك للإدارة.'
    const item = { id, title, details, hours: 72, jid: w.jid, createdBy: 'weekly-system', createdAt: now, endsAt: now + 72*3600000, status: 'open', entries: [], winner: null, weeklyKey: key }
    store.items.push(item)
    w.lastStartKey = key
    w.postponedUntil = null
    w.pendingWeekKey = null
    save()
    const end = new Date(item.endsAt).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo' })
    const message = `🏆 *بدأت المسابقة الأسبوعية #${id}*\n\n🎯 *المطلوب:* ${title}\n📝 *التفاصيل والشروط:* ${details}\n⏳ *مدة المسابقة:* 72 ساعة\n🕒 *آخر موعد للمشاركة:* ${end} بتوقيت مصر\n\n📩 *للمشاركة:*\n${P}مشاركة ${id} وصف العمل أو رابطه\n\n📨 ستصل مشاركتك إلى الإدارة للمراجعة. إذا كنت من الفائزين فسيتم الإعلان عنك أو الإشارة إليك في الجروب، ثم تواصل مع أحد الأدمن لاستلام الجائزة.\n☎️ 01505669304\n☎️ 01205583520\n\nبالتوفيق للجميع! 🍀`
    await schedulerSock.sendMessage(w.jid, { text: message }).catch(() => {})
  }
  const ensureScheduler = (sock) => {
    schedulerSock = sock
    if (schedulerTimer) return
    schedulerTimer = setInterval(() => { startWeeklyIfDue().catch(() => {}) }, 30_000)
    schedulerTimer.unref?.()
  }
  schedulerPulse = (sock) => { ensureScheduler(sock); startWeeklyIfDue().catch(() => {}) }
  const active = (x) => x.status === 'open' && x.endsAt > Date.now()
  const durationText = (ms) => {
    const h = Math.max(0, Math.ceil(ms / 3600000))
    if (h >= 24 && h % 24 === 0) return `${h / 24} يوم${h / 24 === 1 ? '' : ''}`
    return `${h} ساعة`
  }
  const expire = (x) => {
    if (x.status === 'open' && x.endsAt <= Date.now()) { x.status = 'ended'; x.endedAt = Date.now(); return true }
    return false
  }
  const statusText = (x) => active(x) ? `🟢 مفتوحة · متبقي ${durationText(x.endsAt - Date.now())}` : '🔴 انتهت'
  const find = (id) => data().items.find((x) => x.id === Number(id))

  cmd(['مسابقة', 'مسابقات'], 'all', async (e, args) => {
    const store = data()
    ensureScheduler(e.sock)
    startWeeklyIfDue().catch(() => {})
    let changed = false
    for (const x of store.items) if (expire(x)) changed = true
    if (changed) save()
    const sub = args.trim()
    if (!sub || /^(قائمة|عرض)$/i.test(sub)) {
      const list = store.items.filter((x) => x.jid === e.jid).sort((a,b) => b.createdAt-a.createdAt).slice(0, 10)
      if (!list.length) return e.reply(`🏆 مفيش مسابقات مسجلة في الجروب ده حالياً.\nلإنشاء مسابقة: ${P}مسابقة إنشاء | تصميم شعار | 72 | الشروط`)
      return e.reply(panel('🏆 المسابقات', list.map(x => `#${x.id} · ${x.title}\n${statusText(x)} · المشاركات: ${x.entries.length}`), `للمشاركة: ${P}مشاركة رقم المسابقة وصف/رابط العمل`))
    }
    if (/^أسبوعية\s+تفعيل(?:\s*\|)?/u.test(sub) || /^اسبوعية\s+تفعيل(?:\s*\|)?/u.test(sub)) {
      if (!manager(e)) return e.reply(`${T.warn} إعداد المسابقة الأسبوعية للمطورين المسؤولين فقط.`)
      if (!e.isGroup) return e.reply(`${T.warn} نفّذ الأمر داخل الجروب المطلوب تشغيل المسابقات فيه.`)
      const parts = sub.replace(/^(أسبوعية|اسبوعية)\s+تفعيل\s*/u, '').replace(/^\|/, '').split('|').map(v => v.trim())
      const w = store.weekly ??= { enabled: false }
      w.enabled = true; w.jid = e.jid
      w.title = (parts[0] || w.title || 'المسابقة الأسبوعية').slice(0, 100)
      w.details = (parts.slice(1).join(' | ') || w.details || 'نفّذ المطلوب وأرسل مشاركتك للإدارة.').slice(0, 1500)
      save(); ensureScheduler(e.sock); startWeeklyIfDue().catch(() => {})
      return e.reply(`✅ تم تفعيل نظام المسابقة الأسبوعية في هذا الجروب.\n🗓️ كل يوم جمعة الساعة 2:00 ظهرًا بتوقيت مصر.\n⏳ مدة المشاركة 72 ساعة.\n🎯 عنوان المسابقة: ${w.title}\n📝 التفاصيل: ${w.details}\n\nللتأجيل: ${P}مسابقة تأجيل YYYY-MM-DD HH:mm\nلإيقاف النظام: ${P}مسابقة أسبوعية إيقاف`)
    }
    if (/^(أسبوعية|اسبوعية)\s+إيقاف$|^(أسبوعية|اسبوعية)\s+ايقاف$/u.test(sub)) {
      if (!manager(e)) return e.reply(`${T.warn} إيقاف النظام للمطورين المسؤولين فقط.`)
      if (store.weekly) store.weekly.enabled = false
      save()
      return e.reply('⏸️ تم إيقاف المسابقة الأسبوعية التلقائية.')
    }
    const postpone = sub.match(/^تأجيل\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})$/u)
    if (postpone) {
      if (!manager(e)) return e.reply(`${T.warn} تأجيل المسابقة للمطورين المسؤولين فقط.`)
      const w = store.weekly
      if (!w?.enabled || w.jid !== e.jid) return e.reply(`${T.warn} فعّل المسابقة الأسبوعية أولًا داخل الجروب.`)
      const target = cairoEpoch(postpone[1], postpone[2])
      if (!Number.isFinite(target) || target <= Date.now()) return e.reply(`${T.warn} أدخل موعدًا مستقبليًا بصيغة YYYY-MM-DD HH:mm بتوقيت مصر.`)
      w.postponedUntil = target; w.pendingWeekKey = weekKey(new Date()); save(); ensureScheduler(e.sock)
      const when = new Date(target).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo' })
      await e.reply(`⏰ تم ضبط موعد بدء المسابقة على ${when} بتوقيت مصر.`)
      await e.sock.sendMessage(e.jid, { text: `📢 *تنويه: تم تأجيل المسابقة الأسبوعية*\nالموعد الجديد: ${when} بتوقيت مصر.` })
      return
    }
    if (/^إنشاء\b|^انشاء\b/.test(sub)) {
      if (!manager(e)) return e.reply(`${T.warn} إنشاء المسابقات وإدارتها للمطورين المسؤولين فقط.`)
      const parts = sub.replace(/^(إنشاء|انشاء)\s*/, '').split('|').map(s => s.trim())
      if (parts.length < 3 || !parts[0] || !/^\d+$/.test(parts[1])) return e.reply(`صيغة إنشاء المسابقة:\n${P}مسابقة إنشاء | تصميم شعار | 72 | الشروط والتفاصيل\n\nالمدة بالساعات (مثال 24 أو 72).`)
      const title = parts[0].slice(0, 100)
      const hours = Number(parts[1])
      if (!Number.isSafeInteger(hours) || hours < 1 || hours > 720) return e.reply(`${T.warn} المدة من ساعة واحدة إلى 720 ساعة (30 يومًا).`)
      const details = (parts.slice(2).join(' | ') || 'لا توجد شروط إضافية').slice(0, 1500)
      const id = store.nextId++
      const item = { id, title, details, hours, jid: e.jid, createdBy: phone(e.sender), createdAt: Date.now(), endsAt: Date.now() + hours*3600000, status: 'open', entries: [], winner: null }
      store.items.push(item); save()
      await e.reply(`🏆 *مسابقة جديدة #${id}*\n\n🎯 *العنوان:* ${title}\n📝 *التفاصيل والشروط:* ${details}\n⏳ *المدة:* ${hours} ساعة\n🕒 *موعد الانتهاء:* ${new Date(item.endsAt).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo' })}\n\n📩 للمشاركة اكتب:\n${P}مشاركة ${id} وصف العمل أو رابطه\n\n👨‍💻 *المسؤولون:* المطور SASA HACK وفريق الإدارة\n☎️ 01505669304\n☎️ 01205583520\n\nبالتوفيق للجميع!`)
      return
    }
    const m = sub.match(/^(إنهاء|انهاء|إغلاق|اغلاق)\s+(\d+)$/)
    if (m) {
      if (!manager(e)) return e.reply(`${T.warn} إنهاء المسابقات للمطورين المسؤولين فقط.`)
      const x = find(m[2]); if (!x || x.jid !== e.jid) return e.reply(`${T.err} رقم المسابقة غير موجود في الجروب ده.`)
      x.status = 'ended'; x.endedAt = Date.now(); save()
      return e.reply(`🔒 انتهت المسابقة #${x.id} — *${x.title}*\nعدد المشاركات: ${x.entries.length}`)
    }
    const w = sub.match(/^فائز\s+(\d+)\s+(.+)$/)
    if (w) {
      if (!manager(e)) return e.reply(`${T.warn} إعلان الفائز للمطورين المسؤولين فقط.`)
      const x = find(w[1]); if (!x || x.jid !== e.jid) return e.reply(`${T.err} رقم المسابقة غير موجود في الجروب ده.`)
      const target = e.ctx?.mentionedJid?.[0]
      if (!target) return e.reply(`منشن الفائز: ${P}مسابقة فائز ${x.id} @العضو`)
      x.winner = clean(target); x.status = 'ended'; x.endedAt = Date.now(); save()
      return e.reply(`🏆🎉 *الفائز في المسابقة #${x.id}*\n${x.title}\nالفائز: ${tag(x.winner)}\nمبروك!\n📩 تواصل مع أحد الأدمن لاستلام الجائزة: 01505669304 أو 01205583520`, [x.winner])
    }
    if (/^مساعدة$/.test(sub)) return e.reply(`🏆 *نظام المسابقات*\n${P}مسابقات — عرض مسابقات الجروب\n${P}مسابقة أسبوعية تفعيل | العنوان | الشروط — تفعيل أسبوعي كل جمعة 2 ظهرًا\n${P}مسابقة تأجيل YYYY-MM-DD HH:mm — تأجيل الموعد\n${P}مسابقة أسبوعية إيقاف — إيقاف التكرار\n${P}مسابقة إنشاء | العنوان | الساعات | الشروط — للمطورين فقط\n${P}مشاركة رقم المسابقة وصف/رابط العمل — للمشاركة\n${P}مسابقة إنهاء رقم — للمطورين فقط\n${P}مسابقة فائز رقم @العضو — إعلان الفائز`)
    return e.reply(`أمر غير معروف. اكتب ${P}مسابقة مساعدة`)
  }, { sec: SEC, d: 'إنشاء وعرض وإدارة المسابقات' })

  cmd(['مشاركة', 'تسليم'], 'all', async (e, args) => {
    ensureScheduler(e.sock)
    startWeeklyIfDue().catch(() => {})
    const m = args.trim().match(/^(\d+)\s+([\s\S]+)/)
    if (!m) return e.reply(`للمشاركة اكتب:\n${P}مشاركة رقم_المسابقة وصف العمل أو رابطه`)
    const x = find(m[1])
    if (!x || x.jid !== e.jid) return e.reply(`${T.err} المسابقة غير موجودة في الجروب ده.`)
    if (expire(x)) { save(); return e.reply(`${T.warn} انتهى موعد المسابقة، باب المشاركة مغلق.`) }
    if (!active(x)) return e.reply(`${T.warn} المسابقة مغلقة.`)
    const sender = clean(e.sender || '')
    const content = m[2].trim().slice(0, 2000)
    const old = x.entries.find(v => v.sender === sender)
    if (old) { old.content = content; old.updatedAt = Date.now() }
    else x.entries.push({ sender, content, submittedAt: Date.now() })
    save()
    const submitter = phone(e.sender || '')
    const adminNotice = `📨 *مشاركة جديدة في المسابقة #${x.id}*\n🏆 ${x.title}\n👤 المشارك: ${tag(sender)}\n🔗 المحتوى: ${content}`
    for (const contact of CONTACTS) {
      try { await e.sock.sendMessage(`${contact}@s.whatsapp.net`, { text: adminNotice, mentions: [sender] }) } catch {}
    }
    return e.reply(`✅ تم ${old ? 'تحديث' : 'تسجيل'} مشاركتك في المسابقة #${x.id} — *${x.title}*\n📨 تم إرسال المشاركة للإدارة للمراجعة.\nعدد المشاركات: ${x.entries.length}\nتقدر تعدّل مشاركتك بإرسال الأمر مرة ثانية.`)
  }, { sec: SEC, d: 'إرسال أو تحديث مشاركتك في مسابقة', u: 'مشاركة 1 رابط التصميم' })

  cmd(['مشاركات'], 'all', async (e, args) => {
    ensureScheduler(e.sock)
    startWeeklyIfDue().catch(() => {})
    const m = args.trim().match(/^(\d+)$/)
    if (!m) return e.reply(`اكتب: ${P}مشاركات رقم_المسابقة`)
    const x = find(m[1]); if (!x || x.jid !== e.jid) return e.reply(`${T.err} المسابقة غير موجودة في الجروب ده.`)
    if (expire(x)) save()
    if (!manager(e)) return e.reply(`${T.warn} عرض تفاصيل المشاركات للمطورين المسؤولين فقط.`)
    if (!x.entries.length) return e.reply('لا توجد مشاركات حتى الآن.')
    const rows = x.entries.map((v,i) => `${i+1}. ${tag(v.sender)}\n${v.content}`)
    return e.reply(panel(`📨 مشاركات المسابقة #${x.id}`, rows), x.entries.map(v => v.sender))
  }, { sec: SEC, d: 'عرض المشاركات للمطورين المسؤولين' })
}
