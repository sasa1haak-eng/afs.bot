// ═══════════ 6.1 — .نطق : تحويل النص لرسالة صوتية (بدون مفتاح API) ═══════════
// المحركات بالترتيب:
//  1) Edge TTS عبر حزمة اختيارية msedge-tts  → أصوات سعودية عصبية: ar-SA-HamedNeural (ذكر) / ar-SA-ZariyahNeural (أنثى)
//  2) Google Translate TTS (بدون مفتاح) كاحتياطي لو الأول مش متثبت أو فشل
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { nm } from './core/names.js'

const sh = promisify(execFile)
const MAX_CHARS = 600
const VOICES = { male: 'ar-SA-HamedNeural', female: 'ar-SA-ZariyahNeural' }
const GENDER_WORDS = { ذكر: 'male', ولد: 'male', رجل: 'male', انثى: 'female', أنثى: 'female', بنت: 'female', ست: 'female' }

export function cleanText(t) {
  return String(t || '')
    .replace(/(?:https?:\/\/|www\.)\S+/gi, ' رابط ')
    .replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g, '')
    .replace(/[*_~`>|#]/g, ' ')
    .replace(/\p{Extended_Pictographic}/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}
// تقسيم النص لقطع (جوجل بيقبل ~200 حرف) على حدود الجمل/الكلمات
export function chunkText(t, max = 180) {
  const out = []
  let cur = ''
  for (const part of t.split(/(?<=[.!?؟،,؛;:])\s+/)) {
    for (const w of part.split(' ')) {
      const word = w.length > max ? w.slice(0, max) : w
      if ((cur + ' ' + word).trim().length > max) { if (cur) out.push(cur); cur = word } else cur = (cur + ' ' + word).trim()
    }
  }
  if (cur) out.push(cur)
  return out
}

const timeout = (p, ms, msg) => Promise.race([p, new Promise((_, r) => setTimeout(() => r(new Error(msg)), ms))])

async function edgeTTS(text, voice) {
  const mod = await import('msedge-tts') // اختيارية: npm i msedge-tts
  const { MsEdgeTTS, OUTPUT_FORMAT } = mod
  const tts = new MsEdgeTTS()
  await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3)
  const r = tts.toStream(text)
  const stream = r?.audioStream ?? r
  const chunks = []
  await timeout(new Promise((res, rej) => { stream.on('data', (d) => chunks.push(d)); stream.on('end', res); stream.on('error', rej) }), 25_000, 'Edge TTS timeout')
  const buf = Buffer.concat(chunks)
  if (buf.length < 500) throw new Error('رد فاضي من Edge TTS')
  return buf
}

async function googleTTS(text) {
  const bufs = []
  for (const q of chunkText(text)) {
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ar&q=${encodeURIComponent(q)}`
    const res = await fetch(url, { signal: AbortSignal.timeout(15_000), headers: { 'user-agent': 'Mozilla/5.0' } })
    if (!res.ok) throw new Error('Google TTS ' + res.status)
    const b = Buffer.from(await res.arrayBuffer())
    if (b.length > 5 * 1024 * 1024) throw new Error('رد كبير')
    bufs.push(b)
  }
  return Buffer.concat(bufs) // دمج MP3 المتتالي سليم
}

// بيحوّل أي صوت لـ OGG/Opus (الصيغة اللي واتساب بيعرضها كرسالة صوتية)
export async function toVoiceNote(mp3, ffmpeg = 'ffmpeg') {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tts-'))
  const inp = path.join(dir, 'in.mp3'), out = path.join(dir, 'out.ogg')
  try {
    fs.writeFileSync(inp, mp3)
    await sh(ffmpeg, ['-y', '-i', inp, '-vn', '-ac', '1', '-ar', '48000', '-c:a', 'libopus', '-b:a', '32k', '-application', 'voip', '-f', 'ogg', out], { timeout: 30_000 })
    return fs.readFileSync(out)
  } finally { fs.rmSync(dir, { recursive: true, force: true }) }
}

export const engines = { edge: edgeTTS, google: googleTTS } // قابلة للاستبدال في الاختبار

const last = new Map()
export function register(c) {
  const { cmd, P, T, CONFIG } = c
  cmd(nm('نطق'), 'all', async (e, args) => {
    let a = args.trim(), gender = process.env.TTS_GENDER === 'female' ? 'female' : 'male'
    const first = a.split(/\s+/)[0]
    if (GENDER_WORDS[first]) { gender = GENDER_WORDS[first]; a = a.slice(first.length).trim() }
    const text = cleanText(a || c.quotedText?.(e.ctx) || '')
    if (!text) return e.reply(`${T.info} اكتب: ${P}نطق نصك هنا\nأو رد على رسالة بـ ${P}نطق\nللصوت الأنثوي: ${P}نطق انثى نصك`)
    if (text.length > MAX_CHARS) return e.reply(`${T.warn} النص طويل (أقصى ${MAX_CHARS} حرف)، والحالي ${text.length}`)
    const k = e.sender || e.jid, now = Date.now()
    if (now - (last.get(k) || 0) < 8000) return e.reply(`${T.warn} استنى ثواني بين كل نطق`)
    last.set(k, now)
    if (last.size > 2000) for (const [x, t] of last) if (now - t > 60_000) last.delete(x)
    let audio, used = ''
    try { audio = await engines.edge(text, VOICES[gender]); used = 'edge' } catch {}
    if (!audio) { try { audio = await engines.google(text); used = 'google' } catch (err) { return e.reply(`${T.err} مقدرتش أولّد الصوت (محتاج إنترنت). ${err.message}`) } }
    try {
      const ogg = await toVoiceNote(audio, CONFIG?.FFMPEG || 'ffmpeg')
      return e.sock.sendMessage(e.jid, { audio: ogg, mimetype: 'audio/ogg; codecs=opus', ptt: true }, { quoted: e.m })
    } catch (err) {
      if (err.code === 'ENOENT') return e.reply(`${T.err} ffmpeg مش متثبت (pkg install ffmpeg)`)
      return e.reply(`${T.err} فشل تحويل الصوت (${used})`)
    }
  }, { sec: 'games6', d: 'يحوّل النص لرسالة صوتية (صوت سعودي) بدون API', u: 'نطق مرحبا بالجميع' })
}
