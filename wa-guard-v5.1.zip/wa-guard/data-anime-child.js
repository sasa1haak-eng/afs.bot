// شخصيات أنمي (أطفال): "# اسم الأنمي" ثم سطر لكل شخصية: الاسم بالعربي (بدائل بـ /)|الاسم بالإنجليزي
export const CHILD_RAW = `
# Doraemon
نوبيتا نوبي/نوبيتا|Nobita Nobi
شيزوكا ميناموتو/شيزوكا|Shizuka Minamoto
جيان/تاكيشي غودا|Takeshi Goda
سونيو هونيكاوا/سونيو|Suneo Honekawa
دورامي|Dorami
جايكو غودا|Jaiko Goda
سيواشي نوبي/سيواشي|Sewashi Nobi
# Crayon Shin-chan
شينوسكي نوهارا/شين تشان|Shinnosuke Nohara
تورو كازاما/كازاما|Toru Kazama
نيني ساكورادا/نيني|Nene Sakurada
ماساو ساتو/ماساو|Masao Sato
بو سوزوكي/بو|Bo Suzuki
هيماواري نوهارا/هيماواري|Himawari Nohara
آي سواتومي|Ai Suotome
# Chibi Maruko-chan
موموكو ساكورا/ماروكو|Momoko Sakura
تاماي هوناامي/تاما|Tamae Honami
هاناوا|Kazuhiko Hanawa
ماروو سويهيرو|Maruo Suehiro
# Sazae-san
كاتسو إيسونو/كاتسو|Katsuo Isono
واكامي إيسونو/واكامي|Wakame Isono
تارا فوغوتا/تارا|Tarao Fuguta
# Pokemon
آش كيتشوم/ساتوشي|Ash Ketchum
ماكس|Max
إيريس|Iris
بوني|Bonnie
ريتشي|Ritchie
مالو|Mallow
لانا|Lana
سوفوكليس|Sophocles
ليكو|Liko
روي|Roy
دوت|Dot
# Digimon Adventure
تايتشي ياغامي/تاي|Taichi Yagami
ياماتو إيشيدا/ماط|Yamato Ishida
سورا تاكينوتشي/سورا|Sora Takenouchi
كوشيرو إيزومي/إيزي|Koushiro Izumi
ميمي تاتشيكاوا/ميمي|Mimi Tachikawa
جو كيدو/جو|Joe Kido
تاكيرو تاكايشي/تي كي|Takeru Takaishi
هيكاري ياغامي/كاري|Hikari Yagami
# Digimon Adventure 02
دايسوكي موتوميا/دايسوكي|Daisuke Motomiya
ميياكو إينوي/ميياكو|Miyako Inoue
إيوري هيدا|Iori Hida
كين إيتشيجوجي/كين|Ken Ichijouji
# Digimon Tamers
تاكاتو ماتسوكي/تاكاتو|Takato Matsuki
ريكا نوناكا/ريكا|Rika Nonaka
هنري وونغ|Henry Wong
جيري كاتو|Jeri Katou
كينتا كيتاغاوا|Kenta Kitagawa
كازو شيودا|Kazu Shioda
# Digimon Frontier
تاكويا كانبارا/تاكويا|Takuya Kanbara
كوجي ميناموتو/كوجي|Koji Minamoto
جي بي شيباياما|JP Shibayama
زوي أوريموتو/زوي|Zoe Orimoto
تومي هيمي|Tommy Himi
كويتشي كيمورا|Koichi Kimura
# Detective Conan
كونان إدوغاوا/كونان|Conan Edogawa
آي هايبارا|Ai Haibara
أيومي يوشيدا/أيومي|Ayumi Yoshida
جنتا كوجيما/جنتا|Genta Kojima
ميتسوهيكو تسوبورايا/ميتسوهيكو|Mitsuhiko Tsuburaya
# Naruto / Boruto
كونوهامارو ساروتوبي/كونوهامارو|Konohamaru Sarutobi
موغي|Moegi Kazamatsuri
أودون|Udon Ise
بوروتو أوزوماكي/بوروتو|Boruto Uzumaki
ميتسوكي|Mitsuki
هيماواري أوزوماكي|Himawari Uzumaki
شيكاداي نارا/شيكاداي|Shikadai Nara
إينوجين ياماناكا/إينوجين|Inojin Yamanaka
تشوتشو أكيميتشي/تشوتشو|Chocho Akimichi
ميتال لي|Metal Lee
إيواب يوي|Iwabe Yui
دينكي كاميناريمون|Denki Kaminarimon
واسابي إيزونو|Wasabi Izuno
نميدا سوزومينو|Namida Suzumeno
سوميري كاكيي|Sumire Kakei
إيناري|Inari
# One Piece
مومونوسوكي/موموسوكي|Kozuki Momonosuke
تاما|Tama
شوغار|Sugar
# Attack on Titan
فالكو غرايس/فالكو|Falco Grice
غابي براون/غابي|Gabi Braun
# Demon Slayer
تاكيو كامادو|Takeo Kamado
هاناكو كامادو|Hanako Kamado
شيغيرو كامادو|Shigeru Kamado
روكوتا كامادو|Rokuta Kamado
سومي ناكاهارا|Sumi Nakahara
كيو تيراوتشي|Kiyo Terauchi
ناهو تاكادا|Naho Takada
يوشيرو|Yushiro
روي|Rui
# Studio Ghibli
ساتسوكي كوساكابي/ساتسوكي|Satsuki Kusakabe
ماي كوساكابي/ماي|Mei Kusakabe
تشيهيرو أوغينو/تشيهيرو|Chihiro Ogino
كيكي|Kiki
بونيو|Ponyo
شيتا|Sheeta
بازو|Pazu
أريتي|Arrietty
تومبو|Tombo Kopurasu
بوه|Boh
ماهيتو ماكي|Mahito Maki
توتورو|Totoro
سيتا|Seita
سيتسوكو|Setsuko
# Cardcaptor Sakura
ساكورا كينوموتو/ساكورا|Sakura Kinomoto
تومويو دايدوجي/تومويو|Tomoyo Daidouji
شاورن لي/سياوران|Syaoran Li
ميلينغ لي|Meiling Li
تشيهارو ميهارا|Chiharu Mihara
ناوكو ياناغيساوا|Naoko Yanagisawa
ريكا ساساكي|Rika Sasaki
تاكاشي يامازاكي|Takashi Yamazaki
إيرويل|Eriol Hiiragizawa
# Sailor Moon
تشيبيوسا/ريني|Chibiusa
# World Masterpiece Theater
آن شيرلي/آن|Anne Shirley
ديانا باري|Diana Barry
غيلبرت بلايث|Gilbert Blythe
هايدي|Heidi
بيتر|Peter
كلارا زيزيمان/كلارا|Clara Sesemann
ريمي|Remi
ماركو|Marco Rossi
بوليانا|Pollyanna Whittier
سارة كرو/سارة|Sara Crewe
نيلو|Nello
توم سوير|Tom Sawyer
هكلبري فن|Huckleberry Finn
بيكي ثاتشر|Becky Thatcher
بيتر بان|Peter Pan
ويندي دارلينغ|Wendy Darling
# Yotsuba&!
يوتسوبا كويوا/يوتسوبا|Yotsuba Koiwai
ميورا هاياساكا|Miura Hayasaka
# Barakamon
نارو كوتوشي/نارو|Naru Kotoishi
ميوا ياماامورا|Miwa Yamamura
# Usagi Drop
رين كاغا|Rin Kaga
# Ojamajo Doremi
دوريمي هاروكازي/دوريمي|Doremi Harukaze
هازوكي فوجيوارا|Hazuki Fujiwara
آيكو سينو|Aiko Senoo
أونبو سيغاوا|Onpu Segawa
موموكو أسوكا|Momoko Asuka
بوب هاروكازي|Pop Harukaze
# Yo-kai Watch
نيت آدامز/كيتا|Nate Adams
كايتي فوريستر|Katie Forester
بير|Bear Kojima
# Zatch Bell
زاتش بيل/غاش|Zatch Bell
تيا|Tia
# Dr. Stone
سويكا|Suika
# The Promised Neverland
إيما|Emma
نورمان|Norman
راي|Ray
دون|Don
غيلدا|Gilda
آنا|Anna
كوني|Conny
فيل|Phil
كارول|Carol
توما|Thoma
نات|Nat
# Made in Abyss
ريكو|Riko
ناناتشي|Nanachi
بروشكا|Prushka
ميتي|Mitty
# Spy x Family
آنيا فورجر/آنيا|Anya Forger
داميان ديزموند|Damian Desmond
بيكي بلاكبيل|Becky Blackbell
# Chainsaw Man
ناويوتا|Nayuta
# Fullmetal Alchemist
نينا تاكر|Nina Tucker
إليسيا هيوز|Elysia Hughes
# Fairy Tail
ويندي مارفل/ويندي|Wendy Marvell
روميو كونبولت|Romeo Conbolt
أسوكا كونيل|Asuka Connell
# Black Clover
تشارمي بابي|Charmy Pappitson
# Bleach
كارين كوروساكي|Karin Kurosaki
يوزو كوروساكي|Yuzu Kurosaki
ياتشيرو كوساجيشي|Yachiru Kusajishi
أورورو تسوموغيا|Ururu Tsumugiya
جينتا هاناكاري|Jinta Hanakari
# Nintama Rantaro
رانتارو إينادرا|Rantaro Inadera
كيريمارو|Kirimaru
شينبي|Shinbei
# Gakuen Alice
ميكان ساكورا|Mikan Sakura
ناتسومي هيوغا|Natsume Hyuga
روكا نوغي|Ruka Nogi
هوتارو إيماي|Hotaru Imai
# Kodomo no Omocha
سانا كوراتا|Sana Kurata
أكيتو هاياما|Akito Hayama
# Shugo Chara!
آمو هيناموري|Amu Hinamori
تاداسي هوتوري|Tadase Hotori
# Astro Boy
أسترو بوي/أتوم|Astro Boy
أوران|Uran
# Tetsujin 28-go
شوتارو كانيدا|Shotaro Kaneda
# Wolf Children
أمي هانا|Ame Hana
يوكي هانا|Yuki Hana
# Mirai
كون|Kun
# Hotarubi no Mori e
هوتارو تاكيغاوا|Hotaru Takegawa
# Totto-chan
توتو تشان/تيتسوكو|Tetsuko Kuroyanagi
# Barefoot Gen
غين ناكاأوكا|Gen Nakaoka
# Dr. Slump
أرالي نوريماكي/أرالي|Arale Norimaki
# Sgt. Frog
فويوكي هيناتا|Fuyuki Hinata
# Hunter x Hunter
زوشي|Zushi
# Haikyu!!
ناتسو هيناتا|Natsu Hinata
# Hamtaro
لورا هاروناا|Laura Haruna
# Beyblade Burst
فالت آوي|Valt Aoi
رانتارو كيياما|Rantaro Kiyama
شو كوريناي|Shu Kurenai
# Alice
أليس|Alice
# Pinocchio
بينوكيو|Pinocchio
# Rascal the Raccoon
ستيرلينغ نورث|Sterling North
`
