// ═══════════ الألعاب (حالة اللعبة بتتحفظ لكل شات) ═══════════
import { normalize } from './brain.js'
import { user, addCoins, addPts, money, track } from './eco.js'
import { COUNTRIES } from './data-countries.js'
import { MILLION_BASE } from './data-million.js'
import { WORDS_ALL, RIDDLES_EXTRA } from './data-games.js'
import { extra } from './data-extra.js'
import { GEN, namesOf, contAnswers } from './gen-bank.js'

const TRIVIA_OLD = [
  ['كم عدد أيام الأسبوع؟', ['7', 'سبعة']], ['ما أكبر كوكب في المجموعة الشمسية؟', ['المشتري']], ['ما أسرع حيوان بري؟', ['الفهد']],
  ['ما أطول نهر في أفريقيا؟', ['النيل']], ['كم عدد ألوان قوس قزح؟', ['7', 'سبعة']], ['ما أصغر قارة؟', ['استراليا']],
  ['ما هو الكوكب الأحمر؟', ['المريخ']], ['كم عدد أركان الإسلام؟', ['5', 'خمسة']], ['كم عدد سور القرآن الكريم؟', ['114']],
  ['ما أول سورة في القرآن؟', ['الفاتحة']], ['من هو أول الخلفاء الراشدين؟', ['ابو بكر', 'ابو بكر الصديق']],
  ['ما لغة الأرقام في الحاسوب؟ (ثنائية/عشرية)', ['ثنائية', 'الثنائية', 'ثنائي']], ['كم ساعة في اليوم؟', ['24']],
  ['ما أكبر محيط في العالم؟', ['الهادي', 'الهادئ', 'المحيط الهادي', 'المحيط الهادئ']], ['ما العملة الرسمية لمصر؟', ['الجنيه', 'جنيه', 'الجنيه المصري']],
  ['في أي قارة تقع مصر؟', ['افريقيا']], ['كم عدد أضلاع المسدس؟', ['6', 'ستة']], ['ما ناتج 12 × 12؟', ['144']],
  ['ما الغاز الذي نحتاجه في التنفس؟', ['الاكسجين', 'اكسجين']], ['كم يوماً في السنة الكبيسة؟', ['366']],
  ['ما أكبر حيوان في العالم؟', ['الحوت الازرق', 'الحوت']], ['من هو الملقب بملك الغابة؟', ['الاسد', 'اسد']],
  ['ما الشهر الذي يصوم فيه المسلمون؟', ['رمضان']], ['كم عدد الصلوات المفروضة يومياً؟', ['5', 'خمس', 'خمسة']],
  ['ما عاصمة فرنسا؟', ['باريس']], ['من مؤلف رواية "أولاد حارتنا"؟', ['نجيب محفوظ']], ['ما أعلى جبل في العالم؟', ['ايفرست', 'افرست']],
  ['ما اسم أصغر كوكب في المجموعة الشمسية؟', ['عطارد']], ['كم عدد أصابع اليد الواحدة؟', ['5', 'خمسة', 'خمس']],
]
const CAPITALS_OLD = [
  ['مصر', 'القاهرة'], ['السعودية', 'الرياض'], ['الإمارات', 'ابوظبي'], ['الكويت', 'الكويت'], ['قطر', 'الدوحة'], ['البحرين', 'المنامة'],
  ['عُمان', 'مسقط'], ['الأردن', 'عمان'], ['لبنان', 'بيروت'], ['سوريا', 'دمشق'], ['العراق', 'بغداد'], ['اليمن', 'صنعاء'],
  ['ليبيا', 'طرابلس'], ['تونس', 'تونس'], ['الجزائر', 'الجزائر'], ['المغرب', 'الرباط'], ['السودان', 'الخرطوم'], ['موريتانيا', 'نواكشوط'],
  ['الصومال', 'مقديشو'], ['تركيا', 'انقرة'], ['فرنسا', 'باريس'], ['ألمانيا', 'برلين'], ['إيطاليا', 'روما'], ['إسبانيا', 'مدريد'],
  ['بريطانيا', 'لندن'], ['اليابان', 'طوكيو'], ['الصين', 'بكين'], ['روسيا', 'موسكو'], ['أمريكا', 'واشنطن'], ['البرازيل', 'برازيليا'],
  ['كندا', 'اوتاوا'], ['أستراليا', 'كانبرا'], ['الهند', 'نيودلهي'], ['باكستان', 'اسلام اباد'], ['اندونيسيا', 'جاكرتا'], ['اليونان', 'اثينا'],
]
const FLAGS_OLD = [
  ['🇪🇬', 'مصر'], ['🇸🇦', 'السعودية'], ['🇦🇪', 'الامارات'], ['🇰🇼', 'الكويت'], ['🇶🇦', 'قطر'], ['🇧🇭', 'البحرين'], ['🇴🇲', 'عمان'],
  ['🇯🇴', 'الاردن'], ['🇱🇧', 'لبنان'], ['🇸🇾', 'سوريا'], ['🇮🇶', 'العراق'], ['🇵🇸', 'فلسطين'], ['🇾🇪', 'اليمن'], ['🇱🇾', 'ليبيا'],
  ['🇹🇳', 'تونس'], ['🇩🇿', 'الجزائر'], ['🇲🇦', 'المغرب'], ['🇸🇩', 'السودان'], ['🇹🇷', 'تركيا'], ['🇫🇷', 'فرنسا'], ['🇩🇪', 'المانيا'],
  ['🇮🇹', 'ايطاليا'], ['🇪🇸', 'اسبانيا'], ['🇬🇧', 'بريطانيا'], ['🇺🇸', 'امريكا'], ['🇯🇵', 'اليابان'], ['🇧🇷', 'البرازيل'], ['🇦🇷', 'الارجنتين'],
]
const WORDS_OLD = ['مدرسة', 'كمبيوتر', 'سيارة', 'طائرة', 'مستشفى', 'حديقة', 'مكتبة', 'شجرة', 'برتقال', 'تفاحة', 'كتاب', 'نافذة', 'صحراء', 'جامعة', 'مطار', 'نجمة', 'جبل', 'مطر', 'سحابة', 'طبيب', 'مهندس', 'موسيقى', 'شاطئ', 'قطار', 'هاتف']
const RIDDLES_OLD = [
  ['شيء له أسنان ولا يعض، ما هو؟', ['المشط', 'مشط']], ['شيء يكتب ولا يقرأ، ما هو؟', ['القلم', 'قلم']], ['له عين ولا يرى، ما هو؟', ['الابرة', 'ابرة', 'الابره']],
  ['يمشي بلا أرجل ويبكي بلا عيون، ما هو؟', ['السحاب', 'الغيم', 'السحابة', 'سحاب']], ['شيء كلما أخذت منه كبر، ما هو؟', ['الحفرة', 'حفرة']],
  ['يسمع بلا أذن ويتكلم بلا لسان، ما هو؟', ['الصدى', 'صدى']], ['شيء لا يمشي إلا بالضرب، ما هو؟', ['المسمار', 'مسمار']],
  ['أخت خالك وليست خالتك، من تكون؟', ['امي', 'أمي', 'والدتي']], ['شيء كلما جف ابتل، ما هو؟', ['المنشفة', 'منشفة', 'الفوطة']],
  ['بيت ليس فيه أبواب ولا نوافذ، ما هو؟', ['بيت الشعر', 'بيت شعر']], ['شيء تراه في الليل 3 مرات وفي النهار مرة، ما هو؟', ['حرف اللام', 'اللام', 'حرف الام']],
]
const norm = (s) => normalize(s).replace(/(^| )ال/g, '$1').trim()
const rnd = (a) => a[Math.floor(Math.random() * a.length)]

// ── البنوك الكاملة: الأساسي + المولَّد من الجداول (gen-bank.js) + extra-questions.json ──
const uniq = (list, key) => { const seen = new Set(); return list.filter((x) => { const k = key(x); if (seen.has(k)) return false; seen.add(k); return true }) }
const CAPITALS = uniq([
  ...COUNTRIES.map((cn) => [`ما عاصمة ${cn.name}؟`, cn.capitals]),
  ...COUNTRIES.map((cn) => [`ما الدولة التي عاصمتها ${cn.capital}؟`, namesOf(cn)]),
  ...CAPITALS_OLD.map(([n, a]) => [`ما عاصمة ${n}؟`, [a]]),
  ...GEN.capitals,
  ...extra('capitals').map(([n, a]) => [`ما عاصمة ${n}؟`, [a]]),
], (x) => x[0])
const FLAGS = uniq([
  ...COUNTRIES.map((cn) => [cn.flag, namesOf(cn)]),
  ...FLAGS_OLD.map(([f, n]) => [f, [n]]),
], (x) => x[0])
const TRIVIA = uniq([
  ...TRIVIA_OLD,
  ...Object.values(MILLION_BASE).flat()
    .filter((x) => x.ok.length <= 22 && !/[()ﷺ]/.test(x.ok) && !/هذه|أي من/.test(x.q))
    .map((x) => [x.q, [x.ok]]),
  ...COUNTRIES.map((cn) => [`في أي قارة تقع ${cn.name}؟`, contAnswers(cn)]),
  ...GEN.trivia,
  ...extra('trivia'),
], (x) => x[0])
const WORDS = [...new Set([...WORDS_OLD, ...WORDS_ALL, ...GEN.words, ...extra('words')])]
const RIDDLES = uniq([...RIDDLES_OLD, ...RIDDLES_EXTRA, ...GEN.riddles, ...extra('riddles')], (x) => x[0])

// ── أسئلة دينية: مكتوبة يدوياً + أسئلة السور المولَّدة ──
const ISLAMIC_HAND = [
  ['كم عدد ركعات صلاة الفجر؟', ['2', 'ركعتان', 'اثنين']], ['كم عدد ركعات صلاة المغرب؟', ['3', 'ثلاث', 'ثلاثة']],
  ['كم عدد ركعات صلاة العشاء (الفرض)؟', ['4', 'اربع', 'أربع', 'اربعة']], ['في أي شهر نزل القرآن الكريم؟', ['رمضان']],
  ['في أي ليلة نزل القرآن الكريم؟', ['ليلة القدر', 'القدر']], ['كم عدد أجزاء القرآن الكريم؟', ['30', 'ثلاثون', 'ثلاثين']],
  ['ما أطول آية في القرآن الكريم؟', ['آية الدين', 'الدين']], ['ما السورة التي لا تبدأ بالبسملة؟', ['التوبة', 'براءة']],
  ['من هو أول مؤذن في الإسلام؟', ['بلال', 'بلال بن رباح']], ['من هو أبو الأنبياء؟', ['إبراهيم', 'ابراهيم', 'إبراهيم عليه السلام']],
  ['ما اسم ناقة النبي ﷺ؟', ['القصواء']], ['ما اسم أم النبي ﷺ؟', ['آمنة', 'امنة', 'آمنة بنت وهب']],
  ['من أول من أسلم من النساء؟', ['خديجة', 'خديجة بنت خويلد']], ['كم عدد أركان الإيمان؟', ['6', 'ستة', 'ست']],
  ['كم عدد أركان الإسلام؟', ['5', 'خمسة', 'خمس']], ['ما ثالث أركان الإسلام؟', ['الزكاة', 'زكاة']],
  ['من الملك الموكل بالوحي؟', ['جبريل', 'جبريل عليه السلام']], ['ما أول ما نزل من القرآن الكريم؟', ['اقرأ', 'سورة العلق', 'العلق']],
  ['ما اسم والد النبي ﷺ؟', ['عبد الله']], ['من الصحابي الملقب بالفاروق؟', ['عمر', 'عمر بن الخطاب']],
  ['من الصحابي الملقب بذي النورين؟', ['عثمان', 'عثمان بن عفان']], ['من الملقب بأسد الله؟', ['حمزة', 'حمزة بن عبد المطلب']],
  ['أين دُفن النبي ﷺ؟', ['المدينة المنورة', 'المدينة']], ['ما القبلة الأولى للمسلمين؟', ['المسجد الأقصى', 'بيت المقدس', 'الأقصى']],
  ['من النبي الذي ألقي في النار فكانت بردًا وسلامًا؟', ['إبراهيم', 'ابراهيم']], ['من النبي الذي ابتلعه الحوت؟', ['يونس', 'ذو النون']],
  ['من النبي الذي سخّر الله له الريح والجن؟', ['سليمان']], ['من النبي الذي كلّمه الله تكليمًا؟', ['موسى', 'موسى عليه السلام']],
  ['ما الكتاب الذي أنزل على النبي عيسى عليه السلام؟', ['الإنجيل', 'انجيل', 'الانجيل']], ['ما الكتاب الذي أنزل على النبي داود عليه السلام؟', ['الزبور']],
  ['ما الكتاب الذي أنزل على النبي موسى عليه السلام؟', ['التوراة']], ['كم عدد الأنبياء المذكورين في القرآن الكريم؟', ['25', 'خمسة وعشرون']],
  ['ما أول بيت وُضع للناس لعبادة الله؟', ['الكعبة', 'البيت الحرام', 'الكعبة المشرفة']], ['ما اسم الغزوة التي سُمّيت باسم حفر الحفرة حول المدينة؟', ['الخندق', 'غزوة الخندق', 'الاحزاب', 'الأحزاب']],
  ['ما السورة التي سُمّيت باسم حشرة تصنع العسل؟', ['النحل']], ['ما اسم الصحابي الذي لُقّب بالصديق؟', ['أبو بكر', 'ابو بكر', 'أبو بكر الصديق']],
]
const ISLAMIC = uniq([
  ...ISLAMIC_HAND,
  ...TRIVIA.filter(([q]) => /سورة|القرآن|المصحف|النبي|الصحابي|غزوة|رمضان|الإسلام|الصلوات|الخلفاء|الخليفة|الحج|الكعبة|حراء|ﷺ|الأنبياء|الفاتحة|الدعاء/.test(q)),
], (x) => x[0])
export const GAME_BANK_SIZES = () => ({ islamic: ISLAMIC.length, trivia: TRIVIA.length, capitals: CAPITALS.length, flags: FLAGS.length, words: WORDS.length, riddles: RIDDLES.length })

const scramble = (w) => { let s; do { s = [...w].sort(() => Math.random() - 0.5).join('') } while (s === w && w.length > 1); return s }
const BOARD = (b) => { const n = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣']; return [0, 3, 6].map((r) => b.slice(r, r + 3).map((x, i) => (x === 'X' ? '❌' : x === 'O' ? '⭕' : n[r + i])).join('')).join('\n') }
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
const HANG = ['😀', '🙂', '😐', '😟', '😨', '😱', '💀']

export function register(c) {
  const { cmd, P, T, panel, kv, tag, clean, getTarget, getMeta, isAdmin, db, save, sleep } = c
  const SEC = 'games'
  const games = new Map() // jid → { quiz, xo, guess, hang }
  const st = (jid) => games.get(jid) ?? games.set(jid, {}).get(jid)
  const REWARD = 50

  // اختيار من غير تكرار: بنفتكر آخر 85% من البنك لكل شات
  const fresh = (jid, key, list) => {
    const seen = ((db.seen ??= {})[`${jid}:${key}`] ??= [])
    const limit = Math.max(1, Math.floor(list.length * 0.85))
    let idx = Math.floor(Math.random() * list.length)
    for (let i = 0; i < 60 && seen.includes(idx); i++) idx = Math.floor(Math.random() * list.length)
    seen.push(idx)
    while (seen.length > limit) seen.shift()
    return list[idx]
  }

  // ── أسئلة بإجابة نصية (.اجابة) ──
  function startQuiz(e, title, q, answers, shown) {
    const s = st(e.jid)
    if (s.quiz && s.quiz.until > Date.now()) return e.reply(`${T.warn} في سؤال شغال: ${s.quiz.q}\nجاوب بـ ${P}اجابة أو اكتب ${P}حل`)
    const quiz = { q: shown ?? q, answers: answers.map(norm), shownAnswer: answers[0], until: Date.now() + 60_000, title }
    s.quiz = quiz
    setTimeout(async () => {
      if (st(e.jid).quiz === quiz) {
        st(e.jid).quiz = null
        try { await e.sock.sendMessage(e.jid, { text: `${T.time} انتهى الوقت! الإجابة: *${quiz.shownAnswer}*` }) } catch {}
      }
    }, 60_500)
    return e.reply(panel(`🎮 ${title}`, [q, '', `⏱ 60 ثانية | جاوب بـ ${P}اجابة ...`, `الجايزة: ${money(REWARD)}`]))
  }
  const quizCmd = (names, title, d, gen) =>
    cmd(names, 'all', (e) => { const [q, a, shown] = gen(e); return startQuiz(e, title, q, a, shown) }, { sec: SEC, d })

  quizCmd(['سؤال ديني'], 'ISLAMIC', 'سؤال في الدين والسيرة والقرآن', (e) => { const [q, a] = fresh(e.jid, 'isl', ISLAMIC); return [q, a] })
  quizCmd(['سؤال'], 'TRIVIA', 'سؤال ثقافة عامة', (e) => { const [q, a] = fresh(e.jid, 'trivia', TRIVIA); return [q, a] })
  quizCmd(['عواصم'], 'CAPITALS', 'خمّن العاصمة أو الدولة أو المدينة', (e) => { const [q, a] = fresh(e.jid, 'cap', CAPITALS); return [q, a] })
  quizCmd(['اعلام'], 'FLAGS', 'خمّن الدولة من العلم', (e) => { const [f, a] = fresh(e.jid, 'flag', FLAGS); return [`ده علم أنهي دولة؟\n${f}`, a] })
  quizCmd(['مبعثرة'], 'SCRAMBLE', 'رتّب الحروف المبعثرة', (e) => { const w = fresh(e.jid, 'scr', WORDS); return [`رتّب الحروف: *${scramble(w).split('').join(' ')}*`, [w]] })
  quizCmd(['لغز'], 'RIDDLE', 'لغز وإجابته', (e) => { const [q, a] = fresh(e.jid, 'rid', RIDDLES); return [q, a] })
  quizCmd(['تحدي حساب'], 'MATH', 'مسألة حسابية سريعة (أنواع متعددة)', () => {
    const r = (a, b) => a + Math.floor(Math.random() * (b - a + 1))
    const kind = r(0, 7)
    if (kind === 0) { const a = r(12, 99), b = r(3, 40); return [`احسب: ${a} + ${b} = ؟`, [String(a + b)]] }
    if (kind === 1) { const a = r(30, 150), b = r(3, 29); return [`احسب: ${a} - ${b} = ؟`, [String(a - b)]] }
    if (kind === 2) { const a = r(3, 30), b = r(3, 25); return [`احسب: ${a} × ${b} = ؟`, [String(a * b)]] }
    if (kind === 3) { const b = r(2, 15), q = r(2, 30); return [`احسب: ${b * q} ÷ ${b} = ؟`, [String(q)]] }
    if (kind === 4) { const n = r(4, 30); return [`ما مربع العدد ${n}؟`, [String(n * n)]] }
    if (kind === 5) { const p = rnd([10, 20, 25, 50]), y = r(2, 40) * (100 / p); return [`كم يساوي ${p}% من ${y}؟`, [String((p * y) / 100)]] }
    if (kind === 6) { const a = r(5, 60), x = r(5, 60); return [`أوجد العدد الناقص: ؟ + ${a} = ${a + x}`, [String(x)]] }
    const a = r(2, 20), d = r(2, 9); return [`أكمل المتتالية: ${a}, ${a + d}, ${a + 2 * d}, ${a + 3 * d}, ؟`, [String(a + 4 * d)]]
  })

  cmd(['اجابة'], 'all', async (e, args) => {
    const q = st(e.jid).quiz
    if (!q || q.until < Date.now()) return e.reply(`${T.info} مفيش سؤال شغال. جرب ${P}سؤال أو ${P}لغز`)
    if (!args.trim()) return e.reply(`${T.info} اكتب إجابتك: ${P}اجابة ...`)
    const a = norm(args.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    if (!q.answers.includes(a)) return e.reply(`❌ غلط! جرب تاني`)
    st(e.jid).quiz = null
    const prize = Math.round(REWARD * (user(e.sender).job === 'مدرس' ? 1.25 : 1))
    addCoins(e.sender, prize)
    addPts(e.sender, 10, true)
    track(e.sender, 'quiz'); track(e.sender, 'win')
    return e.reply(`${T.ok} ${tag(clean(e.sender))} جاوب صح! 🎉\nالإجابة: *${q.shownAnswer}*\n+${money(prize)} | +10 نقطة`, [clean(e.sender)])
  }, { sec: SEC, d: 'إجابة السؤال الشغال', u: 'اجابة ...' })

  cmd(['حل'], 'all', (e) => {
    const s = st(e.jid)
    if (s.quiz) { const a = s.quiz.shownAnswer; s.quiz = null; return e.reply(`🏳️ الإجابة: *${a}*`) }
    if (s.guess) { const n = s.guess.n; s.guess = null; return e.reply(`🏳️ الرقم كان *${n}*`) }
    if (s.hang) { const w = s.hang.word; s.hang = null; return e.reply(`🏳️ الكلمة كانت *${w}*`) }
    return e.reply(`${T.info} مفيش لعبة شغالة`)
  }, { sec: SEC, d: 'استسلم واعرف الإجابة' })

  // ── خمّن الرقم ──
  cmd(['خمن'], 'all', (e, args) => {
    const s = st(e.jid)
    const g = parseInt(args)
    if (!s.guess) {
      s.guess = { n: 1 + Math.floor(Math.random() * 100), tries: 0 }
      if (isNaN(g)) return e.reply(panel('🔢 GUESS', ['فكرت في رقم من 1 لـ 100', `خمّن بـ ${P}خمن 50`, 'عندك 8 محاولات']))
    }
    if (isNaN(g)) return e.reply(`${T.info} اكتب رقم: ${P}خمن 50`)
    const x = s.guess
    x.tries++
    if (g === x.n) {
      s.guess = null
      addCoins(e.sender, 100)
      addPts(e.sender, 15, true)
      track(e.sender, 'win')
      return e.reply(`${T.ok} صح! الرقم *${g}* في ${x.tries} محاولة 🎉 +${money(100)}`)
    }
    if (x.tries >= 8) { s.guess = null; return e.reply(`💥 خلصت المحاولات! الرقم كان *${x.n}*`) }
    return e.reply(`${g < x.n ? '⬆️ أكبر' : '⬇️ أصغر'} (محاولة ${x.tries}/8)`)
  }, { sec: SEC, d: 'خمّن الرقم من 1 لـ 100', u: 'خمن 50' })

  // ── المشنقة ──
  const hangView = (h) => panel('🪢 HANGMAN', [h.word.split('').map((ch) => (h.got.has(ch) ? ch : '＿')).join(' '), `${HANG[h.miss]} أخطاء: ${h.miss}/6`, h.bad.size ? `حروف غلط: ${[...h.bad].join(' ')}` : '', `خمّن حرف: ${P}حرف ب`].filter(Boolean))
  cmd(['اعدم'], 'all', (e) => {
    const s = st(e.jid)
    if (s.hang) return e.reply(hangView(s.hang))
    s.hang = { word: fresh(e.jid, 'hang', WORDS), got: new Set(), bad: new Set(), miss: 0 }
    return e.reply(hangView(s.hang))
  }, { sec: SEC, d: 'لعبة المشنقة' })
  cmd(['حرف'], 'all', (e, args) => {
    const h = st(e.jid).hang
    if (!h) return e.reply(`${T.info} ابدأ لعبة بـ ${P}اعدم`)
    const ch = normalize(args).replace(/\s/g, '')[0]
    if (!ch) return e.reply(`${T.info} اكتب حرف: ${P}حرف ب`)
    const word = normalize(h.word)
    if (h.got.has(ch) || h.bad.has(ch)) return e.reply('الحرف ده اتجرب قبل كده')
    if (word.includes(ch)) h.got.add(ch)
    else { h.bad.add(ch); h.miss++ }
    if ([...word].every((x) => h.got.has(x))) { st(e.jid).hang = null; addCoins(e.sender, 80); addPts(e.sender, 12, true); track(e.sender, 'win'); return e.reply(`${T.ok} كسبت! الكلمة *${h.word}* 🎉 +${money(80)}`) }
    if (h.miss >= 6) { st(e.jid).hang = null; return e.reply(`💀 خسرت! الكلمة كانت *${h.word}*`) }
    return e.reply(hangView({ ...h, word }))
  }, { sec: SEC, d: 'تخمين حرف في المشنقة', u: 'حرف ب' })

  // ── حجر ورقة مقص ──
  const RPS = [['حجر', '🪨'], ['ورقة', '📄'], ['مقص', '✂️']]
  RPS.forEach(([name, icon], i) =>
    cmd([name], 'all', (e) => {
      const j = Math.floor(Math.random() * 3)
      const r = i === j ? 'تعادل 🤝' : (i - j + 3) % 3 === 1 ? 'كسبت! 🎉' : 'البوت كسب 😎'
      if (r.startsWith('كسبت')) addPts(e.sender, 3, true)
      return e.reply(`${icon} ضد ${RPS[j][1]}\n${r}`)
    }, { sec: SEC, d: 'حجر ورقة مقص ضد البوت' })
  )

  // ── XO (لاعبين) ──
  const winner = (b) => { for (const [x, y, z] of LINES) if (b[x] && b[x] === b[y] && b[x] === b[z]) return b[x]; return b.every(Boolean) ? 'draw' : null }
  cmd(['xo', 'اكس او'], 'all', async (e, args) => {
    const s = st(e.jid)
    const me = clean(e.sender)
    const a = args.trim()
    if (/^(الغاء|إلغاء|cancel)$/i.test(a)) { s.xo = null; return e.reply(`${T.ok} اتلغت اللعبة`) }
    const n = parseInt(a)
    if (s.xo && !isNaN(n)) {
      const g = s.xo
      if (n < 1 || n > 9) return e.reply(`${T.info} اختار رقم من 1 لـ 9`)
      if (me !== g.players[g.turn]) return e.reply(`${T.warn} مش دورك! دور ${tag(g.players[g.turn])}`)
      if (g.b[n - 1]) return e.reply(`${T.warn} المربع ده محجوز`)
      g.b[n - 1] = g.turn === 0 ? 'X' : 'O'
      const w = winner(g.b)
      if (w) {
        s.xo = null
        if (w === 'draw') return e.reply(`${BOARD(g.b)}\n🤝 تعادل!`)
        addPts(me, 20, true); addCoins(me, 100)
        return e.reply(`${BOARD(g.b)}\n${T.ok} ${tag(me)} كسب! 🎉 +${money(100)}`, [me])
      }
      g.turn = 1 - g.turn
      return e.reply(`${BOARD(g.b)}\nدور ${tag(g.players[g.turn])} (${g.turn === 0 ? '❌' : '⭕'}) ${P}xo رقم`, [g.players[g.turn]])
    }
    const t = getTarget(e, args)
    if (!t) return e.reply(`${T.info} ابدأ بتحدي: ${P}xo @فلان ثم ${P}xo 5 للعب`)
    if (clean(t) === me) return e.reply(`${T.err} مينفعش تلعب ضد نفسك`)
    if (s.xo) return e.reply(`${T.warn} في لعبة شغالة (${P}xo الغاء)`)
    s.xo = { b: Array(9).fill(null), players: [me, clean(t)], turn: 0 }
    return e.reply(`${panel('❌⭕ XO', [`${tag(me)} ❌  ضد  ${tag(clean(t))} ⭕`])}\n${BOARD(s.xo.b)}\nدورك يا ${tag(me)}: ${P}xo رقم`, [me, clean(t)])
  }, { sec: SEC, group: true, d: 'XO ضد صاحبك', u: 'xo @ ثم xo 5' })

  cmd(['الغاء لعبة'], 'all', async (e) => {
    const s = st(e.jid)
    if (e.isGroup && !e.isOwner) { const m = await getMeta(e.sock, e.jid); if (!isAdmin(m, e.sender)) return e.reply(`${T.warn} للأدمن بس`) }
    games.set(e.jid, {})
    return e.reply(`${T.ok} اتلغت كل الألعاب هنا`)
  }, { sec: SEC, d: 'يلغي الألعاب الشغالة (للأدمن)' })

  cmd(['نقاطي'], 'all', (e) => {
    const u = user(e.sender)
    return e.reply(panel('🏅 MY STATS', [kv('نقاط الألعاب', u.pts || 0), kv('الانتصارات', u.wins || 0), kv('الرصيد', money(u.wallet))]))
  }, { sec: SEC, d: 'نقاطك وانتصاراتك' })

  cmd(['متصدري الالعاب'], 'all', (e) => {
    const top = Object.entries(db.eco).filter(([, u]) => (u.pts || 0) > 0).sort((a, b) => b[1].pts - a[1].pts).slice(0, 10)
    if (!top.length) return e.reply(`${T.info} لسه محدش لعب`)
    return e.reply(panel('🏆 TOP PLAYERS', top.map(([id, u], i) => `${i + 1}. ${tag(id)} — ${u.pts} نقطة`)), top.map(([id]) => id))
  }, { sec: SEC, d: 'أفضل لاعبين' })
}
