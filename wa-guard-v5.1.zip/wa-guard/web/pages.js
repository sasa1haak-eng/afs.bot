// توليد صفحات الموقع (عربي/إنجليزي) + robots + sitemap. محتوى ثابت بدون قوالب خارجية.
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
const jsonLd = (o) => JSON.stringify(o).replace(/</g, '\\u003c')

export const COUNTRIES = [
  ['🇸🇦', 'السعودية', 'Saudi Arabia', '966'], ['🇪🇬', 'مصر', 'Egypt', '20'], ['🇦🇪', 'الإمارات', 'UAE', '971'], ['🇰🇼', 'الكويت', 'Kuwait', '965'],
  ['🇶🇦', 'قطر', 'Qatar', '974'], ['🇧🇭', 'البحرين', 'Bahrain', '973'], ['🇴🇲', 'عُمان', 'Oman', '968'], ['🇯🇴', 'الأردن', 'Jordan', '962'],
  ['🇱🇧', 'لبنان', 'Lebanon', '961'], ['🇮🇶', 'العراق', 'Iraq', '964'], ['🇸🇾', 'سوريا', 'Syria', '963'], ['🇵🇸', 'فلسطين', 'Palestine', '970'],
  ['🇾🇪', 'اليمن', 'Yemen', '967'], ['🇱🇾', 'ليبيا', 'Libya', '218'], ['🇹🇳', 'تونس', 'Tunisia', '216'], ['🇩🇿', 'الجزائر', 'Algeria', '213'],
  ['🇲🇦', 'المغرب', 'Morocco', '212'], ['🇸🇩', 'السودان', 'Sudan', '249'], ['🇲🇷', 'موريتانيا', 'Mauritania', '222'], ['🇸🇴', 'الصومال', 'Somalia', '252'],
  ['🇹🇷', 'تركيا', 'Türkiye', '90'], ['🇺🇸', 'أمريكا/كندا', 'USA/Canada', '1'], ['🇬🇧', 'بريطانيا', 'UK', '44'], ['🇫🇷', 'فرنسا', 'France', '33'],
  ['🇩🇪', 'ألمانيا', 'Germany', '49'], ['🇮🇹', 'إيطاليا', 'Italy', '39'], ['🇪🇸', 'إسبانيا', 'Spain', '34'], ['🇮🇳', 'الهند', 'India', '91'],
  ['🇵🇰', 'باكستان', 'Pakistan', '92'], ['🇮🇩', 'إندونيسيا', 'Indonesia', '62'], ['🇲🇾', 'ماليزيا', 'Malaysia', '60'], ['🇧🇷', 'البرازيل', 'Brazil', '55'],
]

const L = {
  ar: {
    dir: 'rtl', locale: 'ar_AR', home: '/', other: '/en/', otherName: 'English',
    title: 'WA-Guard | اربط بوت واتساب بكل سهولة وأمان',
    desc: 'اربط بوت واتساب لحماية وإدارة جروباتك برقمك في دقيقة: أدخل رقمك، اكتب كود الربط في واتساب، وابدأ. مئات الأوامر للحماية والألعاب والأدوات والأمن السيبراني.',
    nav: [['#top', 'الرئيسية'], ['#features', 'المميزات'], ['#how', 'كيف يعمل'], ['#faq', 'الأسئلة الشائعة'], ['#support', 'الدعم']],
    h1a: 'اربط بوت واتساب الخاص بك', h1b: 'بكل سهولة وأمان',
    sub: 'من أي دولة في العالم .. ربط سريع بكود من 8 خانات، حماية متقدمة للجروبات، ومئات الأوامر الجاهزة.',
    cta: 'اربط بوتك الآن', cta2: 'كيف يعمل؟',
    strip: [['أي دولة', 'كود دولي + رقمك فقط'], ['حماية الجروبات', 'أكثر من 130 قاعدة حماية'], ['ربط سريع', 'كود من 8 خانات في ثوانٍ'], ['مئات الأوامر', 'ألعاب وأدوات وأمن وبرمجة'], ['التحكم بيدك', 'ألغِ الربط في أي وقت']],
    howT: 'كيف تعمل الخدمة؟', howLead: 'ثلاث خطوات فقط وبوتك شغّال.',
    steps: [['أدخل رقمك', 'اختر دولتك واكتب رقم واتساب الذي تريد ربطه.'], ['اكتب الكود في واتساب', 'واتساب ← الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف، ثم اكتب الكود الظاهر.'], ['ابدأ الاستخدام', 'أرسل <code>.قائمة</code> في أي محادثة لعرض الأوامر، وأضف البوت لجروباتك.']],
    featT: 'ماذا يقدّم البوت؟', featLead: 'أدوات جاهزة لإدارة الجروبات والترفيه والتعلّم.',
    feats: [['🛡️ حماية الجروبات', 'منع الروابط والسبام والاحتيال والملفات الخطرة، مع أكثر من 130 قاعدة تفعّلها بأمر واحد.'], ['🎮 ألعاب وترفيه', 'ألغاز وأسئلة ومسابقات وألعاب سريعة تنشّط الجروب.'], ['🧰 أدوات يومية', 'ملصقات وتحميل ووقت الصلاة وأدوات نصية ومالية وغيرها.'], ['🔐 أمن سيبراني', 'موسوعة توعية وأسئلة ومهام ونصائح لحماية حساباتك.'], ['💻 برمجة', 'مقتطفات جاهزة وسكربتات وشرح تشغيلها داخل واتساب.'], ['⚙️ تحكم كامل', 'تفعيل وتعطيل كل ميزة لكل جروب، وإلغاء الربط في أي لحظة.']],
    connT: 'اربط رقمك الآن', connLead: 'سنعرض لك كود ربط من 8 خانات تكتبه في واتساب على هاتفك.',
    phone: 'رقم الهاتف', phoneHint: 'مثال: 1012345678', consent: 'أوافق على <a href="/terms" target="_blank" rel="noopener">الشروط</a> و<a href="/privacy" target="_blank" rel="noopener">سياسة الخصوصية</a>، وأفهم أن البوت سيعمل على حسابي المرتبط.',
    go: 'احصل على كود الربط', codeT: 'اكتب هذا الكود في واتساب', codeSteps: ['افتح واتساب على هاتفك', 'الإعدادات ← الأجهزة المرتبطة ← ربط جهاز', 'اختر «الربط برقم الهاتف بدلاً من ذلك»', 'اكتب الكود الظاهر أعلاه'], left: 'ينتهي الكود خلال', copy: 'نسخ الكود', retry: 'رجوع', okT: 'تم ربط البوت بنجاح!', okS: 'أنت الآن جاهز. أرسل .قائمة في أي محادثة لعرض الأوامر.', unlink: 'إلغاء الربط',
    faqT: 'الأسئلة الشائعة',
    faq: [['هل ربط البوت آمن؟', 'الربط يتم عبر ميزة «الأجهزة المرتبطة» الرسمية في واتساب بكود يظهر لك فقط. يمكنك إلغاء الربط في أي وقت من الموقع أو من واتساب نفسه (الأجهزة المرتبطة ← تسجيل الخروج).'], ['هل يقرأ البوت محادثاتي الخاصة؟', 'البوت يستقبل الرسائل لينفّذ الأوامر والحماية فقط، ولا يحفظ محتوى محادثاتك. الرد الآلي بالذكاء الاصطناعي ميزة اختيارية ومعطّلة افتراضياً، وإن فعّلتها فنص الرسالة يُرسل لمزود الذكاء الاصطناعي المضبوط.'], ['لماذا لا يظهر كود الربط؟', 'قد يكون الرقم خاطئاً أو وصلت للحد المسموح من المحاولات أو لا توجد مقاعد متاحة. انتظر دقيقة وأعد المحاولة بالرقم صحيحاً بالكود الدولي.'], ['هل يمكن أن يُقيّد واتساب رقمي؟', 'البوتات تعمل عبر واجهة غير رسمية، وواتساب قد يقيّد الحسابات التي تُسيء الاستخدام أو ترسل بشكل مفرط. استخدم البوت بعقلانية، ويُفضّل رقم ثانوي للتجربة.'], ['كم رقماً يمكن ربطه؟', 'عدد المقاعد محدود بحسب قدرة الخادم، ويظهر العدد المتاح في أعلى الصفحة.'], ['كيف أحذف بياناتي؟', 'اضغط «إلغاء الربط» بعد الربط أو سجّل الخروج من الأجهزة المرتبطة في واتساب، وتُحذف جلستك من الخادم.']],
    seats: 'المقاعد المتاحة: {free} من {max}', full: 'اكتملت المقاعد حالياً، حاول لاحقاً', supT: 'الدعم', supLead: 'تواجه مشكلة في الربط؟ تواصل معنا.', supBtn: 'تواصل عبر واتساب',
    foot: 'جميع الحقوق محفوظة', terms: 'الشروط', privacy: 'الخصوصية', disc: 'هذا الموقع مستقل وغير تابع لـ WhatsApp أو Meta.',
    js: { seats: 'المقاعد المتاحة: {free} من {max}', full: 'اكتملت المقاعد حالياً', generic: 'حدث خطأ، حاول مرة أخرى بعد قليل', badPhone: 'اكتب رقماً صحيحاً بدون الكود الدولي', needConsent: 'يجب الموافقة على الشروط أولاً', verifying: 'جاري التحقق الأمني…', requesting: 'جاري طلب الكود…', expired: 'انتهت صلاحية الكود، اطلب كوداً جديداً', copied: 'تم النسخ ✓', confirmUnlink: 'هل تريد إلغاء ربط البوت من حسابك؟' },
  },
  en: {
    dir: 'ltr', locale: 'en_US', home: '/en/', other: '/', otherName: 'العربية',
    title: 'WA-Guard | Link a WhatsApp Bot Easily and Securely',
    desc: 'Link a WhatsApp bot to your number in a minute to protect and manage your groups: enter your number, type the pairing code in WhatsApp, and go. Hundreds of commands for protection, games, tools and cybersecurity.',
    nav: [['#top', 'Home'], ['#features', 'Features'], ['#how', 'How it works'], ['#faq', 'FAQ'], ['#support', 'Support']],
    h1a: 'Link your own WhatsApp bot', h1b: 'Easily and securely',
    sub: 'From any country .. fast linking with an 8-character code, advanced group protection and hundreds of ready commands.',
    cta: 'Link your bot now', cta2: 'How it works',
    strip: [['Any country', 'Country code + your number'], ['Group protection', '130+ protection rules'], ['Fast linking', '8-character code in seconds'], ['Hundreds of commands', 'Games, tools, security, coding'], ['You stay in control', 'Unlink any time']],
    howT: 'How does it work?', howLead: 'Three steps and your bot is running.',
    steps: [['Enter your number', 'Pick your country and type the WhatsApp number to link.'], ['Type the code in WhatsApp', 'WhatsApp → Linked devices → Link a device → Link with phone number, then type the code.'], ['Start using it', 'Send <code>.قائمة</code> in any chat to see the commands, and add the bot to your groups.']],
    featT: 'What does the bot offer?', featLead: 'Ready-made tools for group management, fun and learning.',
    feats: [['🛡️ Group protection', 'Block links, spam, scams and risky files with 130+ rules you enable with one command.'], ['🎮 Games & fun', 'Riddles, quizzes, contests and quick games to energize your group.'], ['🧰 Daily tools', 'Stickers, downloads, prayer times, text and finance tools and more.'], ['🔐 Cybersecurity', 'Awareness encyclopedia, quizzes, tasks and tips to protect your accounts.'], ['💻 Programming', 'Ready snippets and scripts with run instructions inside WhatsApp.'], ['⚙️ Full control', 'Enable or disable each feature per group, and unlink at any moment.']],
    connT: 'Link your number now', connLead: 'We will show an 8-character pairing code to type in WhatsApp on your phone.',
    phone: 'Phone number', phoneHint: 'e.g. 1012345678', consent: 'I agree to the <a href="/terms" target="_blank" rel="noopener">Terms</a> and <a href="/privacy" target="_blank" rel="noopener">Privacy Policy</a>, and understand the bot will run on my linked account.',
    go: 'Get pairing code', codeT: 'Type this code in WhatsApp', codeSteps: ['Open WhatsApp on your phone', 'Settings → Linked devices → Link a device', 'Choose “Link with phone number instead”', 'Type the code shown above'], left: 'Code expires in', copy: 'Copy code', retry: 'Back', okT: 'Bot linked successfully!', okS: 'You are ready. Send .قائمة in any chat to see the commands.', unlink: 'Unlink',
    faqT: 'Frequently asked questions',
    faq: [['Is linking the bot safe?', 'Linking uses WhatsApp’s official “Linked devices” feature with a code shown only to you. You can unlink any time from this site or from WhatsApp itself (Linked devices → log out).'], ['Does the bot read my private chats?', 'The bot receives messages only to run commands and protection, and does not store your chat contents. AI auto-reply is optional and off by default; if you enable it, the message text is sent to the configured AI provider.'], ['Why is no pairing code shown?', 'The number may be wrong, you hit the attempt limit, or no seats are free. Wait a minute and retry with the correct number and country code.'], ['Can WhatsApp restrict my number?', 'Bots work through an unofficial interface, and WhatsApp may restrict accounts that misbehave or send excessively. Use it sensibly, and prefer a secondary number to try it.'], ['How many numbers can be linked?', 'Seats are limited by server capacity; the free count is shown at the top of the page.'], ['How do I delete my data?', 'Press “Unlink” after linking or log out from Linked devices in WhatsApp, and your session is deleted from the server.']],
    seats: 'Free seats: {free} of {max}', full: 'All seats are taken right now, try later', supT: 'Support', supLead: 'Having trouble linking? Contact us.', supBtn: 'Contact on WhatsApp',
    foot: 'All rights reserved', terms: 'Terms', privacy: 'Privacy', disc: 'This site is independent and not affiliated with WhatsApp or Meta.',
    js: { seats: 'Free seats: {free} of {max}', full: 'All seats are taken right now', generic: 'Something went wrong, please try again shortly', badPhone: 'Enter a valid number without the country code', needConsent: 'Please accept the terms first', verifying: 'Running security check…', requesting: 'Requesting code…', expired: 'The code expired, request a new one', copied: 'Copied ✓', confirmUnlink: 'Unlink the bot from your account?' },
  },
}

const ICON = {
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg>',
  bolt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M13 2L4 14h7l-1 8 9-12h-7z"/></svg>',
  grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>',
  hand: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.5"/></svg>',
}
const LOGO = '<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="14" y="20" width="36" height="28" rx="10" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="25" cy="34" r="4" fill="currentColor"/><circle cx="39" cy="34" r="4" fill="currentColor"/><path d="M32 20v-7" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="11" r="3" fill="currentColor"/></svg>'
const HERO = (ok) => `<svg viewBox="0 0 420 460" role="img" aria-label="${esc(ok)}"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4af0b0"/><stop offset="1" stop-color="#1fb870"/></linearGradient></defs>
<ellipse cx="210" cy="260" rx="190" ry="60" fill="none" stroke="#4af0b0" stroke-opacity=".35" stroke-width="2" transform="rotate(-14 210 260)"/><ellipse cx="210" cy="250" rx="170" ry="48" fill="none" stroke="#4af0b0" stroke-opacity=".2" stroke-width="2" transform="rotate(10 210 250)"/>
<g transform="rotate(8 210 230)"><rect x="110" y="30" width="200" height="400" rx="34" fill="#0b1013" stroke="#2a3a3f" stroke-width="5"/><rect x="122" y="42" width="176" height="376" rx="24" fill="#071013"/><rect x="170" y="48" width="80" height="16" rx="8" fill="#0b1013"/>
<circle cx="210" cy="170" r="50" fill="url(#gg)"/><path d="M193 150c-4 8 1 20 12 30s22 15 30 11l4-8-12-7-6 5c-6-3-12-9-15-15l5-6-7-12z" fill="#04110b"/>
<circle cx="250" cy="206" r="20" fill="#1fb870" stroke="#071013" stroke-width="4"/><path d="M241 206l6 6 12-13" fill="none" stroke="#04110b" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
<text x="210" y="274" text-anchor="middle" fill="#eaf3f0" font-size="15" font-weight="700">${esc(ok)}</text><rect x="164" y="292" width="92" height="7" rx="3.5" fill="#2a3a3f"/><rect x="140" y="330" width="140" height="34" rx="12" fill="#0f2a22" stroke="#1fb870" stroke-opacity=".5"/></g></svg>`

function faqLd(l) { return { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: l.faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) } }

export function renderHome(lang, cfg) {
  const l = L[lang], base = cfg.siteUrl.replace(/\/$/, ''), url = base + l.home
  const name = cfg.siteName
  const og = cfg.hasOg ? `<meta property="og:image" content="${base}/og.png"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta name="twitter:image" content="${base}/og.png">` : ''
  const ld = [
    { '@context': 'https://schema.org', '@type': 'WebSite', name, url: base + '/', inLanguage: ['ar', 'en'] },
    { '@context': 'https://schema.org', '@type': 'SoftwareApplication', name, applicationCategory: 'UtilitiesApplication', operatingSystem: 'WhatsApp', description: l.desc, url, offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' } },
    faqLd(l),
  ]
  const icons = [ICON.globe, ICON.shield, ICON.bolt, ICON.grid, ICON.hand]
  const support = cfg.supportUrl ? `<section id="support"><div class="wrap"><h2>${l.supT}</h2><p class="lead">${l.supLead}</p><a class="btn" href="${esc(cfg.supportUrl)}" rel="noopener" target="_blank">${l.supBtn}</a></div></section>` : `<section id="support"><div class="wrap"><h2>${l.supT}</h2><p class="lead">${l.supLead}</p></div></section>`
  return `<!doctype html>
<html lang="${lang}" dir="${l.dir}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(l.title.replace('WA-Guard', name))}</title><meta name="description" content="${esc(l.desc)}"><meta name="theme-color" content="#070b0e"><meta name="robots" content="index,follow,max-image-preview:large">
<link rel="canonical" href="${url}"><link rel="alternate" hreflang="ar" href="${base}/"><link rel="alternate" hreflang="en" href="${base}/en/"><link rel="alternate" hreflang="x-default" href="${base}/">
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="/assets/style.css">
<meta property="og:type" content="website"><meta property="og:site_name" content="${esc(name)}"><meta property="og:title" content="${esc(l.title.replace('WA-Guard', name))}"><meta property="og:description" content="${esc(l.desc)}"><meta property="og:url" content="${url}"><meta property="og:locale" content="${l.locale}">${og}
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${esc(l.title.replace('WA-Guard', name))}"><meta name="twitter:description" content="${esc(l.desc)}">
${ld.map((o) => `<script type="application/ld+json">${jsonLd(o)}</script>`).join('\n')}
</head><body id="top">
<header class="top"><div class="wrap nav"><a class="brand" href="${l.home}" aria-label="${esc(name)}">${LOGO}<span>${esc(name)}</span></a>
<nav class="links" aria-label="main">${l.nav.map(([h, t], i) => `<a href="${h}"${i === 0 ? ' class="on"' : ''}>${t}</a>`).join('')}</nav>
<a class="lang" href="${l.other}" hreflang="${lang === 'ar' ? 'en' : 'ar'}">🌐 ${l.otherName}</a><button class="burger" aria-label="menu" type="button">☰</button></div></header>
<main>
<section class="hero"><div class="wrap"><div><h1>${l.h1a}<em>${l.h1b}</em></h1><p class="sub">${l.sub}</p>
<div class="cta"><a class="btn" href="#connect">${l.cta}</a><a class="btn ghost" href="#how">${l.cta2}</a></div><p class="seats"><span class="dot"></span><span id="seats"></span></p></div>
<div class="art">${HERO(l.okT)}</div></div>
<div class="wrap"><div class="strip">${l.strip.map(([t, s], i) => `<div>${icons[i]}<b>${t}</b><span>${s}</span></div>`).join('')}</div></div></section>
<section id="how"><div class="wrap"><h2>${l.howT}</h2><p class="lead">${l.howLead}</p><div class="steps">${l.steps.map(([t, d], i) => `<div class="step"><i>${i + 1}</i><h3>${t}</h3><p>${d}</p></div>`).join('')}</div></div></section>
<section id="connect"><div class="wrap"><div class="card"><h2>${l.connT}</h2><p class="lead">${l.connLead}</p>
<form id="pair-form" novalidate><label class="sr" for="cc">country</label><div class="field"><select id="cc" name="cc">${COUNTRIES.map((c) => `<option value="${c[3]}">${c[0]} ${lang === 'ar' ? c[1] : c[2]} (+${c[3]})</option>`).join('')}</select>
<label class="sr" for="phone">${l.phone}</label><input id="phone" type="tel" inputmode="numeric" autocomplete="tel-national" placeholder="${l.phoneHint}" maxlength="20" required></div>
<input id="hp" class="hp" type="text" tabindex="-1" autocomplete="off" aria-hidden="true">
<label class="check"><input id="consent" type="checkbox"><span>${l.consent}</span></label><button id="go" class="btn" type="submit">${l.go}</button></form>
<div id="code-view" class="codebox hidden"><h3>${l.codeT}</h3><div id="code" class="c" dir="ltr"></div><p class="timer">${l.left} <b id="left">2:30</b></p><ol>${l.codeSteps.map((s) => `<li>${s}</li>`).join('')}</ol><div class="row"><button id="copy" class="btn ghost" type="button">${l.copy}</button><button id="retry" class="btn ghost" type="button">${l.retry}</button></div></div>
<div id="ok-view" class="ok hidden"><div class="tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div><h3>${l.okT}</h3><p class="lead">${l.okS}</p><button id="unlink" class="btn ghost" type="button">${l.unlink}</button></div>
<p id="msg" class="msg" role="status" aria-live="polite"></p></div></div></section>
<section id="features"><div class="wrap"><h2>${l.featT}</h2><p class="lead">${l.featLead}</p><div class="feat">${l.feats.map(([t, d]) => `<article><h3>${t}</h3><p>${d}</p></article>`).join('')}</div></div></section>
<section id="faq"><div class="wrap"><h2>${l.faqT}</h2>${l.faq.map(([q, a]) => `<details><summary>${q}</summary><p>${a}</p></details>`).join('')}</div></section>
${support}
</main>
<footer><div class="wrap"><span>© ${new Date().getFullYear()} ${esc(name)} — ${l.foot}. ${l.disc}</span><nav><a href="/terms">${l.terms}</a><a href="/privacy">${l.privacy}</a></nav></div></footer>
<script id="i18n" type="application/json">${jsonLd(l.js)}</script><script src="/assets/app.js" defer></script></body></html>`
}

const LEGAL = {
  privacy: ['سياسة الخصوصية', [
    ['ما الذي نجمعه', 'رقم الهاتف الذي تدخله للربط، وبيانات جلسة واتساب اللازمة لتشغيل البوت على حسابك (مخزّنة على الخادم)، وإعدادات الجروبات التي تضبطها. نسجّل أيضاً عنوان IP مؤقتاً في الذاكرة لحدّ معدل الطلبات.'],
    ['ما الذي لا نفعله', 'لا نبيع بياناتك، ولا نحفظ محتوى محادثاتك الخاصة. الرد الآلي بالذكاء الاصطناعي اختياري ومعطّل افتراضياً، وإن فعّلته يُرسل نص الرسالة إلى مزود الذكاء الاصطناعي المضبوط.'],
    ['الأمان', 'تُحمى الجلسات بصلاحيات ملفات الخادم، ونستخدم تحقق عمل (Proof-of-Work) وحدود معدل لمنع إساءة استخدام الموقع.'],
    ['الحذف', 'يمكنك إلغاء الربط في أي وقت من الموقع أو من «الأجهزة المرتبطة» في واتساب، وتُحذف جلستك من الخادم.'],
  ]],
  terms: ['الشروط والأحكام', [
    ['الخدمة', 'نوفّر بوت واتساب يعمل على حسابك بعد ربطه بموافقتك. الخدمة مقدمة «كما هي» دون ضمانات، وقد تتوقف أو تتغير.'],
    ['مسؤوليتك', 'أنت مسؤول عن استخدام حسابك. لا تستخدم البوت في الإزعاج أو الاحتيال أو انتهاك خصوصية الآخرين أو مخالفة القانون أو شروط واتساب.'],
    ['مخاطر واتساب', 'البوت يعمل عبر واجهة غير رسمية، وقد يقيّد واتساب الحسابات التي تُسيء الاستخدام. نوصي بتجربة رقم ثانوي، ولا نتحمل مسؤولية أي تقييد.'],
    ['الإيقاف', 'نحتفظ بحق إيقاف أي ربط يخالف هذه الشروط أو يضر بالخدمة.'],
    ['إخلاء', 'الموقع مستقل وغير تابع لـ WhatsApp أو Meta.'],
  ]],
}
export function renderLegal(kind, cfg) {
  const [title, secs] = LEGAL[kind], base = cfg.siteUrl.replace(/\/$/, '')
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} | ${esc(cfg.siteName)}</title><meta name="description" content="${title} — ${esc(cfg.siteName)}"><link rel="canonical" href="${base}/${kind}"><meta name="robots" content="index,follow"><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="/assets/style.css"></head><body><header class="top"><div class="wrap nav"><a class="brand" href="/">${LOGO}<span>${esc(cfg.siteName)}</span></a></div></header><main class="legal"><h1>${title}</h1>${secs.map(([h, p]) => `<h2>${h}</h2><p>${p}</p>`).join('')}<p><a class="btn ghost" href="/">← الرئيسية</a></p></main></body></html>`
}
export const robots = (cfg) => `User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${cfg.siteUrl.replace(/\/$/, '')}/sitemap.xml\n`
export function sitemap(cfg) {
  const b = cfg.siteUrl.replace(/\/$/, ''), d = new Date().toISOString().slice(0, 10)
  const alt = `<xhtml:link rel="alternate" hreflang="ar" href="${b}/"/><xhtml:link rel="alternate" hreflang="en" href="${b}/en/"/>`
  const u = (p, extra = '', pr = '0.5') => `<url><loc>${b}${p}</loc><lastmod>${d}</lastmod><priority>${pr}</priority>${extra}</url>`
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">${u('/', alt, '1.0')}${u('/en/', alt, '0.9')}${u('/privacy')}${u('/terms')}</urlset>\n`
}
