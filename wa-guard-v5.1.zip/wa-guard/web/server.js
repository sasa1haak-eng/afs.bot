// خادم الموقع: صفحات (عربي/إنجليزي) + واجهة ربط الأرقام. بدون أي مكتبات خارجية (node:http فقط).
// الاعتماديات بتتحقن (installSub/removeSub/listSubs) فنقدر نختبره من غير واتساب.
import http from 'node:http'
import net from 'node:net'
import crypto from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import { fileURLToPath } from 'node:url'
import { renderHome, renderLegal, robots, sitemap } from './pages.js'

const PUB = path.join(path.dirname(fileURLToPath(import.meta.url)), 'public')
const MIME = { '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' }
const E = {
  bad: ['طلب غير صالح', 'Invalid request'], phone: ['رقم الهاتف غير صحيح، اكتبه مع اختيار الدولة الصحيحة', 'Invalid phone number — check the country and number'],
  consent: ['يجب الموافقة على الشروط', 'You must accept the terms'], pow: ['فشل التحقق الأمني، أعد المحاولة', 'Security check failed, please retry'],
  rate: ['محاولات كثيرة، انتظر قليلاً ثم أعد المحاولة', 'Too many attempts, please wait and retry'], full: ['اكتملت المقاعد حالياً، حاول لاحقاً', 'All seats are taken, try later'],
  wait: ['استنى دقيقة قبل ما تطلب كود تاني', 'Please wait a minute before requesting another code'], linked: ['هذا الرقم مرتبط بالفعل', 'This number is already linked'],
  fail: ['تعذّر إنشاء الكود الآن، حاول بعد قليل', 'Could not create the code right now, try again shortly'], notfound: ['غير موجود', 'Not found'],
}
const SECURITY = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; object-src 'none'",
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'geolocation=(), microphone=(), camera=(), payment=()', 'Cross-Origin-Opener-Policy': 'same-origin',
}
const b64 = (b) => Buffer.from(b).toString('base64url')
const leadingZeroBits = (buf) => { let z = 0; for (const b of buf) { if (b === 0) { z += 8; continue } z += Math.clz32(b) - 24; break } return z }
const maskPhone = (p) => p.slice(0, 3) + '****' + p.slice(-3)

export function createWebServer(deps, opts = {}) {
  const cfg = {
    siteUrl: opts.siteUrl || 'http://localhost:8080', siteName: opts.siteName || 'WA-Guard', supportUrl: opts.supportUrl || '',
    powBits: opts.powBits ?? 14, secret: opts.secret || crypto.randomBytes(32), https: /^https:/.test(opts.siteUrl || ''),
    codeTtl: opts.codeTtl ?? 150,
  }
  const log = deps.log || (() => {})
  const assets = {}
  const load = (name, url) => { try { const body = fs.readFileSync(path.join(PUB, name)); assets[url] = { body, gz: zlib.gzipSync(body), type: MIME[path.extname(name)] } } catch {} }
  load('style.css', '/assets/style.css'); load('app.js', '/assets/app.js'); load('favicon.svg', '/favicon.svg'); load('og.png', '/og.png')
  cfg.hasOg = !!assets['/og.png']

  const pages = new Map() // مسار ← { body, gz }
  const page = (p, html, type = 'text/html; charset=utf-8') => { const body = Buffer.from(html); pages.set(p, { body, gz: zlib.gzipSync(body), type }) }
  page('/', renderHome('ar', cfg)); page('/en/', renderHome('en', cfg)); page('/privacy', renderLegal('privacy', cfg)); page('/terms', renderLegal('terms', cfg))
  page('/robots.txt', robots(cfg), 'text/plain; charset=utf-8'); page('/sitemap.xml', sitemap(cfg), 'application/xml; charset=utf-8')

  // ── حدود المعدل (في الذاكرة) ──
  const buckets = new Map()
  const hit = (key, limit, ms) => {
    const now = Date.now(); const a = (buckets.get(key) || []).filter((t) => now - t < ms)
    if (a.length >= limit) { buckets.set(key, a); return false }
    a.push(now); buckets.set(key, a)
    if (buckets.size > 20000) for (const [k, v] of buckets) if (!v.some((t) => now - t < ms)) buckets.delete(k)
    return true
  }
  const used = new Map() // تحديات PoW المستخدمة
  const sessions = new Map() // token ← { phone, state, exp, at }
  const prune = () => {
    const now = Date.now()
    for (const [k, t] of used) if (now - t > 6 * 60_000) used.delete(k)
    for (const [k, s] of sessions) if (now - s.at > 24 * 3600_000) sessions.delete(k)
  }
  const pruneTimer = setInterval(prune, 60_000); pruneTimer.unref?.()

  const clientIp = (req) => {
    const r = (req.socket.remoteAddress || '').replace(/^::ffff:/, '')
    if (r === '127.0.0.1' || r === '::1') { // خلف نفق/بروكسي محلي (Cloudflare Tunnel)
      const f = req.headers['cf-connecting-ip'] || String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()
      if (f && net.isIP(f)) return f
    }
    return r || 'unknown'
  }
  const send = (req, res, code, body, type, extra = {}) => {
    const h = { ...SECURITY, 'Content-Type': type, ...extra }
    if (cfg.https) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    const gz = body.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '')
    const buf = gz ? body.gz : body.body ?? body
    if (gz) h['Content-Encoding'] = 'gzip'
    h.Vary = 'Accept-Encoding'; h['Content-Length'] = buf.length
    res.writeHead(code, h); res.end(req.method === 'HEAD' ? undefined : buf)
  }
  const json = (req, res, code, obj) => send(req, res, code, Buffer.from(JSON.stringify(obj)), 'application/json; charset=utf-8', { 'Cache-Control': 'no-store' })
  const fail = (req, res, code, key) => json(req, res, code, { error: E[key][0], error_en: E[key][1] })
  const readJson = (req) => new Promise((resolve, reject) => {
    if (!/application\/json/i.test(req.headers['content-type'] || '')) return reject(new Error('type'))
    let n = 0; const chunks = []
    const t = setTimeout(() => { reject(new Error('timeout')); req.destroy() }, 5000)
    req.on('data', (c) => { n += c.length; if (n > 4096) { clearTimeout(t); reject(new Error('big')); req.destroy() } else chunks.push(c) })
    req.on('end', () => { clearTimeout(t); try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))) } catch { reject(new Error('json')) } })
    req.on('error', reject)
  })
  const sign = (ch, exp, bits) => b64(crypto.createHmac('sha256', cfg.secret).update(`${ch}|${exp}|${bits}`).digest())
  const verifyPow = (b) => {
    if (typeof b.ch !== 'string' || typeof b.sig !== 'string' || !Number.isInteger(b.nonce) || b.nonce < 0 || b.nonce > 5e6) return false
    const exp = Number(b.exp), bits = Number(b.bits)
    if (bits !== cfg.powBits || !(exp > Date.now() / 1000) || b.ch.length > 40 || used.has(b.ch)) return false
    const want = Buffer.from(sign(b.ch, exp, bits)), got = Buffer.from(b.sig)
    if (want.length !== got.length || !crypto.timingSafeEqual(want, got)) return false
    if (leadingZeroBits(crypto.createHash('sha256').update(`${b.ch}:${b.nonce}`).digest()) < bits) return false
    used.set(b.ch, Date.now())
    return true
  }
  const stats = () => { const u = deps.listSubs().length, max = deps.maxSubs; return { max, used: u, free: Math.max(0, max - u) } }

  async function api(req, res, url, ip) {
    const p = url.pathname
    if (p === '/api/stats' && req.method === 'GET') return json(req, res, 200, stats())
    if (p === '/api/challenge' && req.method === 'GET') {
      if (!hit('ch:' + ip, 30, 60_000)) return fail(req, res, 429, 'rate')
      const ch = b64(crypto.randomBytes(12)), exp = Math.floor(Date.now() / 1000) + 300
      return json(req, res, 200, { ch, exp, bits: cfg.powBits, sig: sign(ch, exp, cfg.powBits) })
    }
    if (p === '/api/status' && req.method === 'GET') {
      if (!hit('st:' + ip, 120, 60_000)) return fail(req, res, 429, 'rate')
      const s = sessions.get(String(url.searchParams.get('token') || ''))
      if (!s) return fail(req, res, 404, 'notfound')
      if (s.state === 'waiting') {
        const sub = deps.listSubs().find((x) => x.number === s.phone)
        if (sub?.linked) s.state = 'linked'
        else if (Date.now() / 1000 > s.exp + 30) s.state = 'expired'
      }
      return json(req, res, 200, { state: s.state })
    }
    if (p === '/api/pair' && req.method === 'POST') {
      if (!hit('p1:' + ip, 8, 600_000) || !hit('pg', 40, 600_000)) return fail(req, res, 429, 'rate')
      let b; try { b = await readJson(req) } catch { return fail(req, res, 400, 'bad') }
      if (b.hp) return fail(req, res, 400, 'bad') // فخ البوتات
      if (b.consent !== true) return fail(req, res, 400, 'consent')
      const phone = typeof b.phone === 'string' ? b.phone : ''
      if (!/^[1-9]\d{7,14}$/.test(phone)) return fail(req, res, 400, 'phone')
      if (!verifyPow(b)) return fail(req, res, 400, 'pow')
      if (!hit('p2:' + ip, 3, 600_000)) return fail(req, res, 429, 'rate')
      if (!hit('num:' + phone, 3, 24 * 3600_000)) return fail(req, res, 429, 'rate') // يحمي أصحاب الأرقام من الإزعاج
      if (stats().free <= 0 || (deps.allow && !deps.allow())) return fail(req, res, 503, 'full')
      try {
        const token = b64(crypto.randomBytes(18))
        const rec = { phone, state: 'waiting', exp: Math.floor(Date.now() / 1000) + cfg.codeTtl, at: Date.now() }
        const code = await deps.installSub(phone, { onLinked: () => { rec.state = 'linked' }, onExpire: () => { if (rec.state === 'waiting') rec.state = 'expired' } })
        if (sessions.size > 3000) sessions.delete(sessions.keys().next().value)
        sessions.set(token, rec)
        log(`🌐 كود ربط صدر لـ ${maskPhone(phone)}`)
        return json(req, res, 200, { token, code: String(code).replace(/^(.{4})(.{4})$/, '$1-$2'), expiresIn: cfg.codeTtl })
      } catch (e) {
        const m = String(e?.message || '')
        if (m.includes('استنى دقيقة')) return fail(req, res, 429, 'wait')
        if (m.includes('متنصب بالفعل')) return fail(req, res, 409, 'linked')
        if (m.includes('الحد الأقصى')) return fail(req, res, 503, 'full')
        if (m.includes('الرقم غير صحيح')) return fail(req, res, 400, 'phone')
        log('🌐 فشل إنشاء كود ربط:', m)
        return fail(req, res, 502, 'fail')
      }
    }
    if (p === '/api/unlink' && req.method === 'POST') {
      if (!hit('ul:' + ip, 10, 600_000)) return fail(req, res, 429, 'rate')
      let b; try { b = await readJson(req) } catch { return fail(req, res, 400, 'bad') }
      const s = sessions.get(String(b.token || ''))
      if (!s) return fail(req, res, 404, 'notfound')
      try { await deps.removeSub(s.phone) } catch {}
      sessions.delete(b.token)
      return json(req, res, 200, { ok: true })
    }
    return fail(req, res, 404, 'notfound')
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x'), ip = clientIp(req)
      if (url.pathname.startsWith('/api/')) return await api(req, res, url, ip)
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(req, res, 405, Buffer.from('Method Not Allowed'), 'text/plain', { Allow: 'GET, HEAD' })
      const pth = url.pathname === '/en' ? '/en/' : url.pathname
      const pg = pages.get(pth)
      if (pg) return send(req, res, 200, pg, pg.type, { 'Cache-Control': pth.endsWith('.xml') || pth.endsWith('.txt') ? 'public, max-age=3600' : 'public, max-age=300' })
      const as = pth.startsWith('/assets/') ? assets[pth] : pth === '/favicon.svg' || pth === '/og.png' ? assets[pth] : null
      if (as) return send(req, res, 200, as, as.type, { 'Cache-Control': 'public, max-age=86400' })
      const nf = Buffer.from('<!doctype html><meta charset="utf-8"><title>404</title><p>404 — <a href="/">/</a></p>')
      return send(req, res, 404, nf, 'text/html; charset=utf-8', { 'X-Robots-Tag': 'noindex' })
    } catch (e) {
      log('🌐 خطأ:', e?.message)
      if (!res.headersSent) { res.writeHead(500, { 'Content-Type': 'text/plain' }); res.end('Server error') } else res.end()
    }
  })
  server.headersTimeout = 10_000; server.requestTimeout = 15_000; server.keepAliveTimeout = 5_000; server.maxHeadersCount = 50
  server.on('clientError', (_e, sock) => { try { sock.end('HTTP/1.1 400 Bad Request\r\n\r\n') } catch {} })
  server.on('close', () => clearInterval(pruneTimer))
  server.cfg = cfg
  return server
}
