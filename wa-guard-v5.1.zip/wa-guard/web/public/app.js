'use strict'
;(() => {
  const $ = (s) => document.querySelector(s)
  const T = JSON.parse(($('#i18n') || { textContent: '{}' }).textContent)
  const burger = $('.burger'), links = $('nav.links')
  if (burger) burger.addEventListener('click', () => links.classList.toggle('open'))
  document.querySelectorAll('nav.links a').forEach((a) => a.addEventListener('click', () => links.classList.remove('open')))

  // المقاعد المتاحة (بيانات حقيقية من الخادم)
  fetch('/api/stats').then((r) => r.json()).then((s) => {
    const el = $('#seats'); if (!el || typeof s.free !== 'number') return
    el.textContent = s.free > 0 ? T.seats.replace('{free}', s.free).replace('{max}', s.max) : T.full
  }).catch(() => {})

  const form = $('#pair-form'); if (!form) return
  const box = { form, code: $('#code-view'), ok: $('#ok-view') }
  const msg = $('#msg'), btn = $('#go')
  let token = '', timer = 0, poll = 0
  const show = (k) => { for (const [n, el] of Object.entries(box)) el.classList.toggle('hidden', n !== k) }
  const say = (t, err) => { msg.textContent = t || ''; msg.className = 'msg' + (err ? ' err' : '') }
  const api = async (url, body) => {
    const r = await fetch(url, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : undefined)
    const j = await r.json().catch(() => ({}))
    if (!r.ok) throw new Error((document.documentElement.lang === 'en' ? j.error_en : j.error) || T.generic)
    return j
  }
  // إثبات عمل خفيف (يمنع السكربتات الآلية من إغراق أرقام الناس بطلبات الربط)
  async function solve(ch, bits) {
    const enc = new TextEncoder()
    for (let n = 0; n < 5e6; n++) {
      const h = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(ch + ':' + n)))
      let z = 0
      for (const b of h) { if (b === 0) { z += 8; continue } z += Math.clz32(b) - 24; break }
      if (z >= bits) return n
    }
    throw new Error(T.generic)
  }
  function stop() { clearInterval(timer); clearInterval(poll) }
  function watch(exp) {
    const left = $('#left'); const end = Date.now() + exp * 1000
    timer = setInterval(() => {
      const s = Math.max(0, Math.round((end - Date.now()) / 1000))
      left.textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0')
      if (!s) { stop(); show('form'); say(T.expired, true) }
    }, 1000)
    poll = setInterval(async () => {
      try {
        const s = await api('/api/status?token=' + encodeURIComponent(token))
        if (s.state === 'linked') { stop(); show('ok') } else if (s.state === 'expired') { stop(); show('form'); say(T.expired, true) }
      } catch { /* نكمّل المحاولة */ }
    }, 3000)
  }
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); say('')
    const local = $('#phone').value.replace(/\D/g, '').replace(/^0+/, '')
    const phone = $('#cc').value + local
    if (!/^\d{8,15}$/.test(phone) || local.length < 5) return say(T.badPhone, true)
    if (!$('#consent').checked) return say(T.needConsent, true)
    btn.disabled = true; say(T.verifying)
    try {
      const c = await api('/api/challenge')
      const nonce = await solve(c.ch, c.bits)
      say(T.requesting)
      const r = await api('/api/pair', { phone, consent: true, hp: $('#hp').value, ch: c.ch, sig: c.sig, exp: c.exp, bits: c.bits, nonce })
      token = r.token
      $('#code').textContent = r.code
      show('code'); say(''); watch(r.expiresIn)
    } catch (err) { say(err.message, true) } finally { btn.disabled = false }
  })
  $('#copy').addEventListener('click', async (e) => { try { await navigator.clipboard.writeText($('#code').textContent.replace('-', '')); e.target.textContent = T.copied } catch {} })
  const back = () => { stop(); show('form'); say('') }
  $('#retry').addEventListener('click', back)
  $('#unlink').addEventListener('click', async () => { if (!confirm(T.confirmUnlink)) return; try { await api('/api/unlink', { token }) } catch {} back() })
})()
