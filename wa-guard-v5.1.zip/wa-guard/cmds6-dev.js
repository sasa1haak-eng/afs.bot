// ═══════════ 6.0 — موسوعة البرمجة: مقتطفات وأوامر جاهزة (Python/JS/SQL/Bash/Git/HTML/CSS/Regex) ═══════════
import { nm } from './core/names.js'

// الصيغة: اسم الأمر | عنوان | الكود (\n = سطر جديد)
const RAW = String.raw`
بايثون طباعة|Python: طباعة|print("مرحبا", name, sep=" ")\nprint(f"{x:.2f}")
بايثون متغيرات|Python: أنواع البيانات|x=5; y=2.5; s="نص"; b=True; n=None\ntype(x)  # <class 'int'>
بايثون شرط|Python: if|if x > 0:\n    print("موجب")\nelif x == 0:\n    print("صفر")\nelse:\n    print("سالب")
بايثون حلقة for|Python: for|for i in range(5):\n    print(i)\nfor i, v in enumerate(lst):\n    print(i, v)
بايثون حلقة while|Python: while|n = 3\nwhile n > 0:\n    n -= 1\n    if n == 1: break
بايثون دالة|Python: دالة|def add(a, b=0):\n    return a + b\nprint(add(2, 3))
بايثون lambda|Python: lambda|sq = lambda x: x*x\nlist(map(sq, [1,2,3]))
بايثون قائمة|Python: list|a = [1,2,3]\na.append(4); a.pop(); a[1:3]; a[::-1]; sorted(a, reverse=True)
بايثون قاموس|Python: dict|d = {"a": 1}\nd["b"] = 2\nd.get("c", 0)\nfor k, v in d.items(): print(k, v)
بايثون مجموعة|Python: set|s = {1,2,3}\ns & {2,3,4}  # تقاطع\ns | {9}        # اتحاد
بايثون list comprehension|Python: Comprehension|[x*x for x in range(10) if x % 2 == 0]\n{k: v for k, v in pairs}
بايثون ملفات|Python: قراءة وكتابة ملف|with open("a.txt", "r", encoding="utf-8") as f:\n    data = f.read()\nwith open("b.txt", "w", encoding="utf-8") as f:\n    f.write("hi")
بايثون استثناءات|Python: try/except|try:\n    x = int(s)\nexcept ValueError as e:\n    print("خطأ", e)\nfinally:\n    print("تم")
بايثون كلاس|Python: class|class Dog:\n    def __init__(self, name):\n        self.name = name\n    def bark(self):\n        return self.name + " woof"
بايثون وراثة|Python: وراثة|class Puppy(Dog):\n    def bark(self):\n        return super().bark() + "!"
بايثون json|Python: JSON|import json\nd = json.loads('{"a":1}')\ns = json.dumps(d, ensure_ascii=False, indent=2)
بايثون requests|Python: طلب HTTP|import requests\nr = requests.get(url, timeout=10)\nr.raise_for_status()\nr.json()
بايثون regex|Python: regex|import re\nre.findall(r"\\d+", "a12b345")\nre.sub(r"\\s+", " ", text)
بايثون تاريخ|Python: التاريخ|from datetime import datetime, timedelta\nnow = datetime.now()\n(now + timedelta(days=7)).strftime("%Y-%m-%d")
بايثون عشوائي|Python: random|import random\nrandom.randint(1, 10); random.choice(lst); random.shuffle(lst)\n# للأمان استخدم secrets.token_hex(16)
بايثون async|Python: asyncio|import asyncio\nasync def main():\n    await asyncio.sleep(1)\nasyncio.run(main())
بايثون ديكوريتر|Python: decorator|def timer(fn):\n    def w(*a, **k):\n        import time; t = time.time()\n        r = fn(*a, **k); print(time.time() - t); return r\n    return w
بايثون مولد|Python: generator|def count(n):\n    for i in range(n):\n        yield i\nsum(count(5))
بايثون بيئة افتراضية|Python: venv|python -m venv .venv\nsource .venv/bin/activate   # ويندوز: .venv\\Scripts\\activate\npip install -r requirements.txt
بايثون argparse|Python: وسائط سطر الأوامر|import argparse\np = argparse.ArgumentParser()\np.add_argument("--n", type=int, default=1)\nargs = p.parse_args()
بايثون ترتيب|Python: sorted بمفتاح|sorted(people, key=lambda p: p["age"], reverse=True)
بايثون collections|Python: Counter|from collections import Counter, defaultdict\nCounter("hello").most_common(2)\nd = defaultdict(list); d["a"].append(1)
بايثون dataclass|Python: dataclass|from dataclasses import dataclass\n@dataclass\nclass P:\n    name: str\n    age: int = 0
بايثون pandas|Python: pandas|import pandas as pd\ndf = pd.read_csv("a.csv")\ndf.groupby("city")["sales"].sum().sort_values()
جافاسكريبت متغيرات|JS: let/const|const a = 1; let b = 2;\nb += a;\n// تجنب var
جافاسكريبت دالة|JS: الدوال|function add(a, b = 0) { return a + b }\nconst mul = (a, b) => a * b
جافاسكريبت مصفوفة|JS: Array|const a = [1,2,3]\na.map(x => x*2).filter(x => x>2).reduce((s,x)=>s+x, 0)
جافاسكريبت كائن|JS: Object|const o = { a: 1, b: 2 }\nconst { a, ...rest } = o\nObject.entries(o).forEach(([k,v]) => console.log(k, v))
جافاسكريبت async|JS: async/await|async function load() {\n  const r = await fetch(url)\n  if (!r.ok) throw new Error(r.status)\n  return r.json()\n}
جافاسكريبت promise|JS: Promise|Promise.all([f1(), f2()]).then(([a,b]) => {}).catch(console.error)
جافاسكريبت حلقة|JS: حلقات|for (const x of arr) {}\nfor (const k in obj) {}\narr.forEach((x, i) => {})
جافاسكريبت كلاس|JS: class|class A {\n  #secret = 1\n  constructor(n) { this.n = n }\n  get double() { return this.n * 2 }\n}
جافاسكريبت وحدات|JS: ES Modules|export const x = 1\nexport default function f() {}\nimport f, { x } from "./a.js"
جافاسكريبت dom|JS: DOM|const el = document.querySelector("#id")\nel.textContent = "نص"   // آمن من XSS بدل innerHTML\nel.addEventListener("click", () => {})
جافاسكريبت خطأ|JS: try/catch|try { JSON.parse(s) } catch (e) { console.error(e.message) } finally {}
جافاسكريبت json|JS: JSON|const s = JSON.stringify(obj, null, 2)\nconst o = JSON.parse(s)
جافاسكريبت تاريخ|JS: Date|new Date().toISOString()\nnew Intl.DateTimeFormat("ar-EG").format(new Date())
جافاسكريبت تخزين|JS: localStorage|localStorage.setItem("k", JSON.stringify(v))\nJSON.parse(localStorage.getItem("k") ?? "null")
جافاسكريبت debounce|JS: debounce|const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms) } }
جافاسكريبت نسخ عميق|JS: structuredClone|const copy = structuredClone(obj)
جافاسكريبت سلسلة اختيارية|JS: ?. و ??|user?.profile?.name ?? "مجهول"
جافاسكريبت ترتيب|JS: sort|arr.sort((a, b) => a.n - b.n)\n["ب","أ"].sort((a,b)=>a.localeCompare(b,"ar"))
نود http|Node: سيرفر|import http from "node:http"\nhttp.createServer((q, r) => r.end("ok")).listen(3000)
نود ملفات|Node: ملفات|import fs from "node:fs/promises"\nconst t = await fs.readFile("a.txt", "utf8")\nawait fs.writeFile("b.txt", t)
نود express|Node: Express|app.get("/u/:id", (req, res) => res.json({ id: req.params.id }))\napp.use(express.json({ limit: "100kb" }))
نود env|Node: متغيرات البيئة|process.env.PORT ?? 3000\n// node --env-file=.env app.js
نود اختبار|Node: اختبارات مدمجة|import test from "node:test"\nimport assert from "node:assert/strict"\ntest("جمع", () => assert.equal(1+1, 2))
نود تنفيذ آمن|Node: تشغيل أمر بأمان|import { execFile } from "node:child_process"\nexecFile("ffmpeg", ["-i", file, out], cb)  // مصفوفة وسائط، مش نص مدموج
npm اوامر|npm: أوامر أساسية|npm init -y\nnpm i pkg\nnpm i -D pkg\nnpm run test\nnpm audit
sql اختيار|SQL: SELECT|SELECT name, age FROM users\nWHERE age >= 18\nORDER BY age DESC\nLIMIT 10;
sql ادخال|SQL: INSERT|INSERT INTO users (name, age) VALUES ('Sasa', 20);
sql تحديث|SQL: UPDATE|UPDATE users SET age = 21 WHERE id = 1;  -- لا تنسَ WHERE
sql حذف|SQL: DELETE|DELETE FROM users WHERE id = 1;  -- جرّب SELECT بنفس الشرط الأول
sql انضمام|SQL: JOIN|SELECT o.id, u.name\nFROM orders o\nJOIN users u ON u.id = o.user_id;
sql تجميع|SQL: GROUP BY|SELECT city, COUNT(*) n, AVG(age)\nFROM users GROUP BY city HAVING COUNT(*) > 5;
sql جدول|SQL: CREATE TABLE|CREATE TABLE users (\n  id INTEGER PRIMARY KEY,\n  email TEXT UNIQUE NOT NULL,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);
sql فهرس|SQL: INDEX|CREATE INDEX idx_users_email ON users(email);
sql استعلام مهيأ|SQL: استعلام آمن|-- بايثون: cur.execute("SELECT * FROM u WHERE id = ?", (uid,))\n-- لا تدمج المدخلات داخل النص أبداً
sql معاملة|SQL: Transaction|BEGIN;\nUPDATE a SET b = b - 10 WHERE id = 1;\nUPDATE a SET b = b + 10 WHERE id = 2;\nCOMMIT;
sql subquery|SQL: استعلام فرعي|SELECT * FROM users\nWHERE id IN (SELECT user_id FROM orders WHERE total > 100);
sql window|SQL: Window|SELECT name, salary, RANK() OVER (ORDER BY salary DESC) r FROM emp;
باش تنقل|Bash: التنقل|pwd; ls -la; cd /path; cd ..; cd -
باش ملفات|Bash: إدارة الملفات|cp -r a b; mv a b; rm -i f; mkdir -p d/e; touch f
باش عرض|Bash: عرض الملفات|cat f; head -n 20 f; tail -f log; less f; wc -l f
باش بحث|Bash: grep و find|grep -rn "text" .\nfind . -name "*.js" -mtime -7
باش صلاحيات|Bash: chmod|chmod 600 .env   # قراءة وكتابة للمالك فقط\nchmod +x run.sh\nchown user:group f
باش انابيب|Bash: Pipes|cat log | grep ERROR | sort | uniq -c | sort -nr | head
باش حلقة|Bash: for|for f in *.txt; do\n  echo "$f"\ndone
باش شرط|Bash: if|if [ -f "$f" ]; then echo yes; else echo no; fi
باش متغيرات|Bash: متغيرات|name="sasa"; echo "$name"; echo "$(date +%F)"
باش عمليات|Bash: العمليات|ps aux | grep node\ntop\nkill PID\nkill -9 PID   # آخر حل
باش شبكة|Bash: الشبكة|ping -c 3 host\ncurl -I https://example.com\nss -tulpn   # المنافذ المفتوحة
باش ضغط|Bash: الضغط|tar -czf a.tgz dir\ntar -xzf a.tgz\nzip -r a.zip dir; unzip a.zip
باش سكربت امن|Bash: سكربت آمن|#!/usr/bin/env bash\nset -euo pipefail\n# اقتبس المتغيرات دايماً: "$var"
جيت بداية|Git: البداية|git init\ngit clone URL\ngit status
جيت حفظ|Git: commit|git add -p\ngit commit -m "وصف واضح"
جيت فروع|Git: فروع|git switch -c feature\ngit switch main\ngit merge feature\ngit branch -d feature
جيت رفع|Git: push/pull|git pull --rebase\ngit push -u origin main
جيت تراجع|Git: التراجع|git restore f           # تجاهل تعديلات\ngit reset --soft HEAD~1  # الغاء commit\ngit revert HASH         # عكس commit بأمان
جيت stash|Git: stash|git stash push -m "مؤقت"\ngit stash list\ngit stash pop
جيت سجل|Git: السجل|git log --oneline --graph --decorate -20\ngit diff HEAD~1
جيت تجاهل|Git: .gitignore|node_modules/\n.env\n*.log\nauth/\n# أي ملف فيه أسرار لازم يتجاهل
جيت اسرار|Git: لو سرّبت سر|# غيّر السر فوراً (أهم خطوة)\n# ثم نظّف التاريخ بـ git filter-repo أو BFG\n# الحذف في commit جديد لا يكفي
html هيكل|HTML: هيكل صفحة|<!doctype html>\n<html lang="ar" dir="rtl">\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>صفحة</title></head>\n<body></body></html>
html نموذج|HTML: نموذج|<form method="post">\n  <label>الاسم <input name="n" required></label>\n  <button>إرسال</button>\n</form>
html جدول|HTML: جدول|<table><thead><tr><th>أ</th></tr></thead>\n<tbody><tr><td>1</td></tr></tbody></table>
html سيمانتك|HTML: عناصر دلالية|<header> <nav> <main> <article> <section> <aside> <footer>\n// أفضل للـ SEO وقارئات الشاشة
css مرن|CSS: Flexbox|.row { display:flex; gap:12px; align-items:center; justify-content:space-between }
css شبكة|CSS: Grid|.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px }
css متغيرات|CSS: Variables|:root { --main:#0a7; }\n.btn { background:var(--main) }
css استجابة|CSS: Media Query|@media (max-width: 600px) { .grid { grid-template-columns: 1fr } }
css مركز|CSS: توسيط|.c { display:grid; place-items:center; min-height:100vh }
css داكن|CSS: الوضع الداكن|@media (prefers-color-scheme: dark) { :root { --bg:#111; --fg:#eee } }
ريجكس اساسي|Regex: الأساسيات|\\d رقم · \\w حرف/رقم · \\s مسافة · . أي حرف\n+ واحد أو أكتر · * صفر أو أكتر · ? اختياري · {2,4} عدد
ريجكس ايميل|Regex: إيميل (مبسّط)|^[\\w.+-]+@[\\w-]+\\.[\\w.-]+$\n// للتحقق الحقيقي ابعت رسالة تأكيد
ريجكس مجموعات|Regex: مجموعات|(\\d{4})-(\\d{2})  → $1 $2\n(?:...) بدون التقاط · (?<y>\\d{4}) مجموعة مسماة
ريجكس امن|Regex: تجنب ReDoS|تجنب (a+)+ و(.*)*\nحدّ طول المدخل قبل الاختبار، واستخدم مهلة أو محرك آمن
خوارزمية بحث ثنائي|Binary Search|def bs(a, x):\n    lo, hi = 0, len(a)-1\n    while lo <= hi:\n        m = (lo+hi)//2\n        if a[m] == x: return m\n        lo, hi = (m+1, hi) if a[m] < x else (lo, m-1)\n    return -1
خوارزمية ترتيب|Sorting: Quick Sort|def qs(a):\n    if len(a) < 2: return a\n    p = a[0]\n    return qs([x for x in a[1:] if x < p]) + [p] + qs([x for x in a[1:] if x >= p])
خوارزمية فيبوناتشي|Fibonacci|def fib(n):\n    a, b = 0, 1\n    for _ in range(n): a, b = b, a+b\n    return a
خوارزمية اولي|الأعداد الأولية|def prime(n):\n    return n > 1 and all(n % i for i in range(2, int(n**.5)+1))
تعقيد|Big-O|O(1) ثابت · O(log n) بحث ثنائي · O(n) خطي · O(n log n) ترتيب كفء · O(n²) حلقتين متداخلتين · O(2ⁿ) أُسّي
هياكل بيانات|هياكل البيانات|Array: وصول سريع · Linked List: إدراج سريع · Stack: LIFO · Queue: FIFO · Hash Map: بحث O(1) · Tree/Heap/Graph للعلاقات والأولويات
rest|REST API|GET قراءة · POST إنشاء · PUT/PATCH تعديل · DELETE حذف\n200 OK · 201 Created · 400 · 401 · 403 · 404 · 429 · 500
http رموز|HTTP: رموز الحالة|2xx نجاح · 3xx إعادة توجيه · 4xx خطأ من العميل · 5xx خطأ من السيرفر\n401 غير مسجل · 403 ممنوع · 404 غير موجود · 429 طلبات كتير
بنية مشروع|بنية مشروع منظمة|src/ الكود · tests/ الاختبارات · docs/ التوثيق · .env.example بدون أسرار · README.md للتشغيل · .gitignore
كود نظيف|الكود النظيف|أسماء واضحة · دوال قصيرة بمسؤولية واحدة · لا تكرر نفسك (DRY) · علّق على الـ "ليه" مش الـ "إيه" · اكتب اختبارات
تصحيح|تصحيح الأخطاء|1) أعد إنتاج الخطأ 2) اقرأ رسالة الخطأ كاملة 3) قسّم المشكلة 4) اطبع/استخدم debugger 5) غيّر حاجة واحدة كل مرة
تعلم برمجة|خطة تعلم البرمجة|ابدأ بلغة واحدة (Python أو JS) · مشاريع صغيرة كل أسبوع · اقرأ كود غيرك · استخدم Git · ثم قواعد البيانات والـ API
مشاريع|أفكار مشاريع|بوت واتساب · مدير مهام · حاسبة · API بسيط · موقع شخصي · أداة تنظيف ملفات · لعبة تخمين
`
const ROWS = RAW.trim().split('\n').map((l) => { const [n, title, ...code] = l.split('|'); return [n.trim(), title.trim(), code.join('|').replace(/\\n/g, '\n').trim()] })
export const DEV = ROWS
export function register(c) {
  const { cmd, P, T, panel } = c
  const SEC = 'code6'
  for (const [name, title, code] of ROWS) {
    cmd(nm(name), 'all', (e) => e.reply(`💻 *${title}*\n\n\`\`\`${code}\`\`\``), { sec: SEC, d: title, u: name })
  }
  cmd(nm('فهرس برمجة'), 'all', (e, args) => {
    const pg = Math.max(1, parseInt(args) || 1), per = 30, tot = Math.ceil(ROWS.length / per)
    return e.reply(panel(`📚 CODE ${pg}/${tot}`, ROWS.slice((pg - 1) * per, pg * per).map(([n, t]) => `• ${n} — ${t.split(':')[0]}`), `${P}فهرس برمجة ${Math.min(pg + 1, tot)}`))
  }, { sec: SEC, d: 'فهرس مقتطفات البرمجة' })
  cmd(nm('بحث برمجة'), 'all', (e, args) => {
    const q = args.trim().toLowerCase()
    if (q.length < 2) return e.reply(`${T.info} اكتب: ${P}بحث برمجة كلمة`)
    const hits = ROWS.filter(([n, t, k]) => (n + t + k).toLowerCase().includes(q)).slice(0, 12)
    return e.reply(hits.length ? panel('🔎 CODE', hits.map(([n, t]) => `• ${P}${n.replace(/ /g, '_')} — ${t}`)) : `${T.err} مفيش نتايج`)
  }, { sec: SEC, d: 'بحث في مقتطفات البرمجة', u: 'بحث برمجة fetch' })
}
