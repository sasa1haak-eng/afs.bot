// ═══════════ أوامر النصوص والترميز والخطوط (كلها شغالة أوفلاين) ═══════════
import crypto from 'node:crypto'

const MORSE = {
  a: '.-', b: '-...', c: '-.-.', d: '-..', e: '.', f: '..-.', g: '--.', h: '....', i: '..', j: '.---', k: '-.-', l: '.-..', m: '--',
  n: '-.', o: '---', p: '.--.', q: '--.-', r: '.-.', s: '...', t: '-', u: '..-', v: '...-', w: '.--', x: '-..-', y: '-.--', z: '--..',
  0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.',
  '.': '.-.-.-', ',': '--..--', '?': '..--..', '!': '-.-.--', '/': '-..-.', '-': '-....-',
}
const MORSE_REV = Object.fromEntries(Object.entries(MORSE).map(([k, v]) => [v, k]))

// لوحة المفاتيح: إنجليزي ⇄ عربي
const KB_EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,./`"
const KB_AR = ['ض','ص','ث','ق','ف','غ','ع','ه','خ','ح','ج','د','ش','س','ي','ب','ل','ا','ت','ن','م','ك','ط','ئ','ء','ؤ','ر','لا','ى','ة','و','ز','ظ','ذ']

// خطوط يونيكود: [بداية الكبير، بداية الصغير، بداية الأرقام، استثناءات]
const MATH = (u, l, d, ex = {}) => ({ u, l, d, ex })
const FONTS = {
  bold: MATH(0x1d400, 0x1d41a, 0x1d7ce),
  italic: MATH(0x1d434, 0x1d44e, null, { h: 'ℎ' }),
  bolditalic: MATH(0x1d468, 0x1d482, null),
  script: MATH(0x1d4d0, 0x1d4ea, null),
  fraktur: MATH(0x1d56c, 0x1d586, null),
  double: MATH(0x1d538, 0x1d552, 0x1d7d8, { C: 'ℂ', H: 'ℍ', N: 'ℕ', P: 'ℙ', Q: 'ℚ', R: 'ℝ', Z: 'ℤ' }),
  mono: MATH(0x1d670, 0x1d68a, 0x1d7f6),
  full: { fn: (ch) => (/[!-~]/.test(ch) ? String.fromCodePoint(ch.charCodeAt(0) + 0xfee0) : ch) },
  circled: { fn: (ch) => (/[A-Z]/.test(ch) ? String.fromCodePoint(0x24b6 + ch.charCodeAt(0) - 65) : /[a-z]/.test(ch) ? String.fromCodePoint(0x24d0 + ch.charCodeAt(0) - 97) : /[1-9]/.test(ch) ? String.fromCodePoint(0x2460 + ch.charCodeAt(0) - 49) : ch === '0' ? '⓪' : ch) },
  squared: { fn: (ch) => (/[A-Za-z]/.test(ch) ? String.fromCodePoint(0x1f130 + ch.toUpperCase().charCodeAt(0) - 65) : ch) },
  negsq: { fn: (ch) => (/[A-Za-z]/.test(ch) ? String.fromCodePoint(0x1f170 + ch.toUpperCase().charCodeAt(0) - 65) : ch) },
  smallcaps: { fn: (ch) => ({ a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ', i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ', s: 'ꜱ', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ' }[ch.toLowerCase()] ?? ch) },
}
const UPSIDE = { a: 'ɐ', b: 'q', c: 'ɔ', d: 'p', e: 'ǝ', f: 'ɟ', g: 'ƃ', h: 'ɥ', i: 'ᴉ', j: 'ɾ', k: 'ʞ', l: 'l', m: 'ɯ', n: 'u', o: 'o', p: 'd', q: 'b', r: 'ɹ', s: 's', t: 'ʇ', u: 'n', v: 'ʌ', w: 'ʍ', x: 'x', y: 'ʎ', z: 'z', '?': '¿', '!': '¡', '.': '˙', ',': "'" }

export function applyFont(text, key) {
  const f = FONTS[key]
  let out = ''
  for (const ch of text) {
    if (f.fn) out += f.fn(ch)
    else if (f.ex[ch]) out += f.ex[ch]
    else if (ch >= 'A' && ch <= 'Z') out += String.fromCodePoint(f.u + ch.charCodeAt(0) - 65)
    else if (ch >= 'a' && ch <= 'z') out += String.fromCodePoint(f.l + ch.charCodeAt(0) - 97)
    else if (f.d && ch >= '0' && ch <= '9') out += String.fromCodePoint(f.d + ch.charCodeAt(0) - 48)
    else out += ch
  }
  return out
}

export function register(c) {
  const { cmd, P, T, panel, kv, pick, shuffle } = c
  const txt = (e, args) => (args || c.quotedText(e.ctx) || '').trim()
  const SEC = 'text'
  // أمر نصي بسيط: بياخد نص (أو رد على رسالة) ويرجع ناتج
  const tcmd = (names, usage, d, fn) =>
    cmd(names, 'all', async (e, args) => {
      const t = txt(e, args)
      if (!t) return e.reply(`${T.info} ${usage}`)
      await e.reply(String(await fn(t, e)))
    }, { sec: SEC, d, u: usage.replace(/^اكتب:?\s*/, '') })

  tcmd(['عكس'], `اكتب: ${P}عكس نص`, 'يعكس حروف النص', (t) => [...t].reverse().join(''))
  tcmd(['عكس الكلمات'], `اكتب: ${P}عكس الكلمات نص`, 'يعكس ترتيب الكلمات', (t) => t.split(/\s+/).reverse().join(' '))
  tcmd(['كبير'], `اكتب: ${P}كبير text`, 'حروف إنجليزي كبيرة', (t) => t.toUpperCase())
  tcmd(['صغير'], `اكتب: ${P}صغير TEXT`, 'حروف إنجليزي صغيرة', (t) => t.toLowerCase())
  tcmd(['عنوان'], `اكتب: ${P}عنوان hello world`, 'أول حرف من كل كلمة كبير', (t) => t.toLowerCase().replace(/(^|\s)(\S)/g, (m, a, b) => a + b.toUpperCase()))
  tcmd(['عد كلمات'], `اكتب: ${P}عد كلمات نص`, 'عدد الكلمات', (t) => `${T.info} عدد الكلمات: ${t.split(/\s+/).filter(Boolean).length}`)
  tcmd(['عد حروف'], `اكتب: ${P}عد حروف نص`, 'عدد الحروف', (t) => `${T.info} الحروف: ${[...t].length} | بدون مسافات: ${[...t.replace(/\s/g, '')].length}`)
  tcmd(['عد سطور'], `اكتب: ${P}عد سطور نص`, 'عدد السطور', (t) => `${T.info} عدد السطور: ${t.split(/\n/).length}`)
  tcmd(['ازالة التشكيل'], `اكتب: ${P}ازالة التشكيل نص`, 'يشيل التشكيل والتطويل', (t) => t.replace(/[\u064B-\u065F\u0670\u0640]/g, ''))
  tcmd(['ازالة المسافات'], `اكتب: ${P}ازالة المسافات نص`, 'يشيل كل المسافات', (t) => t.replace(/\s+/g, ''))
  tcmd(['تنظيف المسافات'], `اكتب: ${P}تنظيف المسافات نص`, 'يوحد المسافات الزايدة', (t) => t.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim())
  tcmd(['ترميز', 'base64'], `اكتب: ${P}ترميز نص`, 'نص ← Base64', (t) => Buffer.from(t).toString('base64'))
  tcmd(['فك ترميز'], `اكتب: ${P}فك ترميز SGVsbG8=`, 'Base64 ← نص', (t) => {
    if (!/^[A-Za-z0-9+/=_-]+$/.test(t.replace(/\s/g, ''))) throw new Error('ده مش Base64 صالح')
    return Buffer.from(t.replace(/\s/g, ''), 'base64').toString('utf8')
  })
  tcmd(['هيكس'], `اكتب: ${P}هيكس نص`, 'نص ← Hex', (t) => Buffer.from(t).toString('hex'))
  tcmd(['فك هيكس'], `اكتب: ${P}فك هيكس 48656c6c6f`, 'Hex ← نص', (t) => {
    const h = t.replace(/\s/g, '')
    if (!/^([0-9a-fA-F]{2})+$/.test(h)) throw new Error('ده مش Hex صالح')
    return Buffer.from(h, 'hex').toString('utf8')
  })
  tcmd(['ثنائي'], `اكتب: ${P}ثنائي نص`, 'نص ← أصفار وواحدات', (t) => [...Buffer.from(t)].map((b) => b.toString(2).padStart(8, '0')).join(' '))
  tcmd(['فك ثنائي'], `اكتب: ${P}فك ثنائي 01001000 01101001`, 'ثنائي ← نص', (t) => {
    const parts = t.split(/\s+/)
    if (!parts.every((p) => /^[01]{8}$/.test(p))) throw new Error('اكتب مجموعات من 8 أرقام (0/1) بينها مسافة')
    return Buffer.from(parts.map((p) => parseInt(p, 2))).toString('utf8')
  })
  tcmd(['روت13', 'rot13'], `اكتب: ${P}روت13 hello`, 'تشفير قيصر 13', (t) => t.replace(/[a-z]/gi, (ch) => String.fromCharCode(((ch.charCodeAt(0) - (ch <= 'Z' ? 65 : 97) + 13) % 26) + (ch <= 'Z' ? 65 : 97))))
  tcmd(['مورس'], `اكتب: ${P}مورس sos`, 'نص إنجليزي ← مورس', (t) => {
    const out = [...t.toLowerCase()].map((ch) => (ch === ' ' ? '/' : MORSE[ch] || '')).filter(Boolean).join(' ')
    if (!out) throw new Error('مورس بيدعم الحروف الإنجليزي والأرقام بس')
    return out
  })
  tcmd(['فك مورس'], `اكتب: ${P}فك مورس ... --- ...`, 'مورس ← نص', (t) => t.trim().split(/\s+/).map((m) => (m === '/' ? ' ' : MORSE_REV[m] ?? '?')).join(''))
  for (const alg of ['md5', 'sha1', 'sha256', 'sha512'])
    tcmd([alg], `اكتب: ${P}${alg} نص`, `بصمة ${alg.toUpperCase()}`, (t) => crypto.createHash(alg).update(t).digest('hex'))
  cmd(['معرف فريد', 'uuid'], 'all', (e) => e.reply(crypto.randomUUID()), { sec: SEC, d: 'UUID عشوائي' })
  cmd(['كلمة سر'], 'all', (e, args) => {
    const n = Math.min(Math.max(parseInt(args) || 16, 6), 64)
    const set = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?'
    let out = ''
    for (let i = 0; i < n; i++) out += set[crypto.randomInt(set.length)]
    return e.reply(panel('🔐 PASSWORD', [kv('الطول', n), out], 'متحفظش الباسورد في الشات 😉'))
  }, { sec: SEC, d: 'كلمة سر قوية (الطول اختياري)', u: 'كلمة سر 20' })
  tcmd(['ترميز رابط'], `اكتب: ${P}ترميز رابط نص عربي`, 'URL encode', (t) => encodeURIComponent(t))
  tcmd(['فك رابط'], `اكتب: ${P}فك رابط %D9%85`, 'URL decode', (t) => { try { return decodeURIComponent(t) } catch { throw new Error('ترميز غير صالح') } })
  tcmd(['جيسون', 'json'], `اكتب: ${P}جيسون {"a":1}`, 'ينسّق JSON', (t) => { try { return JSON.stringify(JSON.parse(t), null, 2) } catch { throw new Error('JSON غير صالح') } })
  tcmd(['ترتيب ابجدي'], `اكتب: ${P}ترتيب ابجدي (سطر لكل عنصر)`, 'يرتب السطور', (t) => t.split('\n').map((x) => x.trim()).filter(Boolean).sort((a, b) => a.localeCompare(b, 'ar')).join('\n'))
  tcmd(['ترتيب عكسي'], `اكتب: ${P}ترتيب عكسي (سطر لكل عنصر)`, 'يرتب السطور عكسياً', (t) => t.split('\n').map((x) => x.trim()).filter(Boolean).sort((a, b) => b.localeCompare(a, 'ar')).join('\n'))
  tcmd(['ازالة التكرار'], `اكتب: ${P}ازالة التكرار (سطر لكل عنصر)`, 'يشيل السطور المكررة', (t) => [...new Set(t.split('\n').map((x) => x.trim()).filter(Boolean))].join('\n'))
  tcmd(['ترقيم'], `اكتب: ${P}ترقيم (سطر لكل عنصر)`, 'يرقم السطور', (t) => t.split('\n').filter((x) => x.trim()).map((x, i) => `${i + 1}. ${x.trim()}`).join('\n'))
  tcmd(['خلط حروف'], `اكتب: ${P}خلط حروف كلمة`, 'يخلط ترتيب الحروف', (t) => shuffle([...t]).join(''))
  tcmd(['خلط كلمات'], `اكتب: ${P}خلط كلمات جملة هنا`, 'يخلط ترتيب الكلمات', (t) => shuffle(t.split(/\s+/)).join(' '))
  tcmd(['كيبورد عربي'], `اكتب: ${P}كيبورد عربي ،دفخ`, 'كلام اتكتب بكيبورد إنجليزي ← عربي', (t) => [...t].map((ch) => { const i = KB_EN.indexOf(ch.toLowerCase()); return i >= 0 ? KB_AR[i] : ch }).join(''))
  tcmd(['كيبورد انجليزي'], `اكتب: ${P}كيبورد انجليزي اهلا`, 'كلام اتكتب بكيبورد عربي ← إنجليزي', (t) => { let out = t.split('لا').join('b'); KB_AR.forEach((a, i) => { if (a !== 'لا') out = out.split(a).join(KB_EN[i]) }); return out })
  tcmd(['كشيدة'], `اكتب: ${P}كشيدة محمد`, 'يطوّل الحروف العربي', (t) => t.split(/\s+/).map((w) => [...w].map((ch, i, a) => (i < a.length - 1 && /[بتثجحخسشصضطظعغفقكلمنهيئ]/.test(ch) ? ch + 'ـــ' : ch)).join('')).join(' '))
  tcmd(['تباعد'], `اكتب: ${P}تباعد محمد`, 'مسافة بين كل حرف', (t) => [...t].join(' '))
  tcmd(['تهجئة'], `اكتب: ${P}تهجئة محمد`, 'حرف-حرف', (t) => [...t.replace(/\s/g, '')].join(' - '))
  tcmd(['اول حروف'], `اكتب: ${P}اول حروف جمهورية مصر العربية`, 'أول حرف من كل كلمة', (t) => t.split(/\s+/).map((w) => [...w][0]).join(''))
  tcmd(['اطول كلمة'], `اكتب: ${P}اطول كلمة جملة هنا`, 'أطول كلمة في النص', (t) => { const w = t.split(/\s+/).sort((a, b) => b.length - a.length)[0]; return `${w} (${[...w].length} حرف)` })
  tcmd(['تحليل نص'], `اكتب: ${P}تحليل نص كلام هنا`, 'إحصائيات النص', (t) => {
    const words = t.split(/\s+/).filter(Boolean)
    const freq = {}
    for (const w of words) freq[w] = (freq[w] || 0) + 1
    const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([w, n]) => `${w}×${n}`).join('  ')
    return panel('📝 TEXT', [kv('الحروف', [...t].length), kv('الكلمات', words.length), kv('الجمل', t.split(/[.!?؟\n]+/).filter((x) => x.trim()).length), kv('الأكثر تكراراً', top || '—')])
  })
  const frames = [
    ['اطار1', (t) => `╔═══════════╗\n  ${t}\n╚═══════════╝`],
    ['اطار2', (t) => `✦━━━━━━━━━━━✦\n  ${t}\n✦━━━━━━━━━━━✦`],
    ['اطار3', (t) => `┏━⟦ ${t} ⟧━┓\n┗━━━━━━━━━━━━┛`],
  ]
  for (const [n, f] of frames) tcmd([n], `اكتب: ${P}${n} نص`, 'يحط النص في إطار', f)
  const FONT_CMDS = [
    ['غامق', 'bold'], ['مائل', 'italic'], ['غامق مائل', 'bolditalic'], ['رقعة', 'script'], ['قوطي', 'fraktur'], ['مزدوج', 'double'],
    ['الة كاتبة', 'mono'], ['دائري', 'circled'], ['مربع', 'squared'], ['مربع اسود', 'negsq'], ['عريض', 'full'], ['كابس صغير', 'smallcaps'],
  ]
  for (const [n, k] of FONT_CMDS) tcmd([n], `اكتب: ${P}${n} Hello 123`, `خط ${n} (إنجليزي وأرقام)`, (t) => applyFont(t, k))
  tcmd(['مقلوب'], `اكتب: ${P}مقلوب hello`, 'نص مقلوب (إنجليزي)', (t) => [...t.toLowerCase()].reverse().map((ch) => UPSIDE[ch] || ch).join(''))
  tcmd(['مشطوب'], `اكتب: ${P}مشطوب نص`, 'خط في النص', (t) => [...t].map((ch) => ch + '\u0336').join(''))
  tcmd(['مسطر'], `اكتب: ${P}مسطر نص`, 'خط تحت النص', (t) => [...t].map((ch) => ch + '\u0332').join(''))
  tcmd(['زخرفة'], `اكتب: ${P}زخرفة Hello`, 'كل الخطوط مرة واحدة', (t) =>
    panel('✨ STYLES', Object.keys(FONTS).map((k) => applyFont(t, k)).concat([[...t].map((ch) => ch + '\u0336').join(''), [...t.toLowerCase()].reverse().map((ch) => UPSIDE[ch] || ch).join('')]))
  )
  tcmd(['ايموجي حروف'], `اكتب: ${P}ايموجي حروف hello`, 'حروف إنجليزي ← إيموجي', (t) => [...t.toUpperCase()].map((ch) => (/[A-Z]/.test(ch) ? String.fromCodePoint(0x1f1e6 + ch.charCodeAt(0) - 65) : ch === ' ' ? '   ' : ch)).join(' '))
  tcmd(['ايموجي ارقام'], `اكتب: ${P}ايموجي ارقام 2025`, 'أرقام ← إيموجي', (t) => [...t].map((ch) => (/[0-9]/.test(ch) ? ch + '\uFE0F\u20E3' : ch)).join(''))
  tcmd(['تكرار'], `اكتب: ${P}تكرار 3 نص`, 'يكرر النص n مرة', (t) => {
    const m = t.match(/^(\d{1,2})\s+([\s\S]+)$/)
    if (!m) throw new Error(`اكتب: ${P}تكرار 3 نص`)
    return Array(Math.min(Number(m[1]), 20)).fill(m[2]).join('\n')
  })
}
