# تشغيل الموقع على تيرمكس وربطه بدومين

الموقع جزء من البوت نفسه (نفس العملية). لما تضبط `WEB_PORT` في `.env` بيشتغل جنب البوت، والزائر يدخل رقمه فيظهرله كود الربط (بيستخدم نظام البوتات الفرعية الموجود `sessions.js`).

## 1) الدومين
- **الرابط `sasa_bot.com` مش ممكن**: أسماء الدومينات ما بتقبلش الشرطة السفلية `_`. استخدم `sasa-bot.com` أو `sasabot.com` (اشتريه من أي مسجّل ~10$ في السنة).
- ضيف الدومين على **Cloudflare** (مجاني) وغيّر الـ Nameservers عند المسجّل لبتوع Cloudflare.

## 2) إعداد البوت
في `~/wa-guard/.env`:
```
WEB_PORT=8080
SITE_URL=https://sasa-bot.com
SITE_NAME=WA-Guard
SUPPORT_URL=https://wa.me/201xxxxxxxxx
MAX_SUBBOTS=5
```
`MAX_SUBBOTS` هو عدد الأرقام اللي ممكن تتربط (كل رقم = اتصال واتساب كامل يستهلك ذاكرة). على تيرمكس خليه صغير (3–5) وراقب الذاكرة.
شغّل: `npm start` وجرّب محلياً: `curl -s localhost:8080/api/stats`

## 3) النشر بـ Cloudflare Tunnel (بدون فتح منافذ وبـ HTTPS مجاني)
```bash
pkg install cloudflared -y        # لو مش موجود: نزّل نسخة linux-arm64 من صفحة إصدارات cloudflared على GitHub
cloudflared tunnel login          # هيطبع رابط افتحه في المتصفح واختار الدومين
cloudflared tunnel create sasa
cloudflared tunnel route dns sasa sasa-bot.com
mkdir -p ~/.cloudflared && cat > ~/.cloudflared/config.yml <<'YML'
tunnel: sasa
credentials-file: /data/data/com.termux/files/home/.cloudflared/<TUNNEL-ID>.json
ingress:
  - hostname: sasa-bot.com
    service: http://127.0.0.1:8080
  - service: http_status:404
YML
cloudflared tunnel run sasa
```
(استبدل `<TUNNEL-ID>` بالملف اللي ظهر بعد `tunnel create`.)
للتجربة السريعة بدون دومين: `cloudflared tunnel --url http://127.0.0.1:8080` بيدّيك رابط مؤقت `trycloudflare.com`.

## 4) التشغيل المستمر
```bash
termux-wake-lock
cd ~/wa-guard && nohup bash scripts-lib/bot_watchdog.sh >/dev/null 2>&1 &
nohup cloudflared tunnel run sasa >~/tunnel.log 2>&1 &
```
خلّي الموبايل متوصل بالشاحن والإنترنت، وشيل التطبيق من توفير الطاقة.

## 5) الظهور في جوجل ومحركات البحث
الموقع جاهز تقنياً (عنوان ووصف وcanonical وhreflang عربي/إنجليزي وJSON-LD وrobots.txt وsitemap.xml وسرعة عالية). المطلوب منك:
1. **Google Search Console**: أضف الدومين (Domain property) وتحقق بسجل TXT من Cloudflare DNS، ثم ادخل Sitemaps وأضف `https://sasa-bot.com/sitemap.xml`، وجرّب «فحص عنوان URL» ← «طلب الفهرسة» للرئيسية.
2. **Bing Webmaster Tools**: نفس الخطوات (بيغذّي كمان DuckDuckGo وغيره).
3. الأرشفة بتاخد أيام لأسابيع، والترتيب في نتائج البحث مش مضمون: بيعتمد على المنافسة والمحتوى والروابط اللي بترجع للموقع. ابدأ بالبحث باسم الموقع نفسه، وانشر الرابط في قنواتك وجروباتك.
4. خلي الموقع شغال باستمرار (لو وقع كتير جوجل بيقلل ترتيبه).

## 6) التعديل
- النصوص والأقسام: `web/pages.js` (عربي وإنجليزي) — الشكل: `web/public/style.css`.
- صورة المشاركة: `web/public/og.png` (1200×630) — استبدلها بتصميمك.
- بعد أي تعديل أعد تشغيل البوت.

## 7) الحماية المدمجة
تحقق عمل (Proof-of-Work) قبل كل طلب كود، حد 3 طلبات/10 دقايق لكل IP، و3 طلبات/يوم لكل رقم (يحمي أصحاب الأرقام من الإزعاج)، ورسالة موافقة إجبارية، وفخ بوتات، وCSP صارم وهيدرات أمان، ورمز الحالة مربوط بتوكن عشوائي (مفيش طريقة لمعرفة مين مربوط من الخارج).
مقاييس: `curl -s localhost:8080/api/stats`.

## 8) تنبيهات مهمة (اقرأها)
- لما حد يربط رقمه، بيبقى عندك **جلسة كاملة لحساب واتساب بتاعه** (محفوظة في `sessions/`). ده مسؤولية كبيرة: احمِ مجلد `sessions/` و`.env`، وخد نسخ احتياطية مشفرة (`scripts-lib/backup_bot.sh`)، ومتستخدمش الجلسات في أي حاجة غير خدمة البوت.
- صفحتا **الخصوصية والشروط** في الموقع قوالب عامة. راجعهم وعدّلهم بما يناسب بلدك والقوانين المطبقة عليك قبل ما تفتح الموقع للناس.
- واتساب ممكن يقيّد حسابات تستخدم واجهات غير رسمية، والموقع بيوضّح ده للمستخدم. متوعدش الناس بحاجة مش في إيدك.
- الموقع بيعرض أرقام حقيقية فقط (المقاعد المتاحة). متضيفش إحصائيات أو آراء مش حقيقية.
